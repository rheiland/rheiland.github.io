#include <stdio.h>
#include <stdlib.h>
#include <GL/glx.h>
#include <GL/gl.h>
#define ALPHAPIXEL32(p) (p & 0xFF)
#define BLUEPIXEL32(p) ((p>>8) & 0xFF)
#define GREENPIXEL32(p) ((p>>16) & 0xFF)
#define REDPIXEL32(p) ((p>>24) & 0xFF)
	
#define BLUEPIXEL16(p) (p & 0x1F)
#define GREENPIXEL16(p) ((p>>6) & 0x1F)
//  | 0x07)
#define REDPIXEL16(p) ((p>>11) & 0x1F)
#define ALPHAPIXEL16(p) ((p>>16) & 0x1F)
#define BLUEPIXEL16s(p) ((p & 0x1F) << 3)
#define GREENPIXEL16s(p) (((p>>6) & 0x1F) << 3)
//  | 0x07)
#define REDPIXEL16s(p) (((p>>11) & 0x1F) << 3)
#define ALPHAPIXEL16s(p) ((p>>16) & 0x1F)
void PrintBinary(unsigned long val,int nbits){
  unsigned long mask = 1;
  printf("pixel=%lu\n",val);
  for(int i=0;i<nbits;i++){
    if(!(i%8)) printf(" ");
    if(val&mask) printf("1");
    else printf("0");
    mask<<=1;
  }
  puts("");
}
void writePPM(char *filename,XImage *img,int depth){
  FILE *ppmFile;
  register int x,y;
  register short bindex=0;
  unsigned char bigbuffer[2048*3];
  /* unsigned int *img=(unsigned int*)pbuffer; */
  unsigned long lastpix=0;

  /* Attempt to open file */
  if (!(ppmFile = fopen(filename, "w"))){
    printf("writePPM: Can't open data file %s\n", filename);
    return;
  }
  else 
    printf("opened %s for writing\n",filename);
  
  fprintf(ppmFile,"P6\n"); /* define as a PPM file */
  fprintf(ppmFile,"%d %d\n",img->width,img->height); /* width and height */
  if(depth>=24){
    fprintf(ppmFile,"255\n"); /* the maxval field */
    for(y=0,bindex=0;y<img->height;y++){
      for(x=0;x<img->width;x++){
	unsigned long pixel = XGetPixel(img,x,img->height-y);
	bigbuffer[bindex++] = REDPIXEL32(pixel);
	bigbuffer[bindex++] = GREENPIXEL32(pixel);
	bigbuffer[bindex++] = BLUEPIXEL32(pixel);
	if(x==1 && y==1) {
	  PrintBinary(pixel,32);
	  printf("R=%u G=%u B=%u A=%u\n",
		 (int)REDPIXEL32(pixel),
		 (int)GREENPIXEL32(pixel),
		 (int)BLUEPIXEL32(pixel),
		 (int)ALPHAPIXEL32(pixel));
	}
	/* idx++; */
	if(!(bindex%=sizeof(bigbuffer))){
	  fwrite(bigbuffer,1,sizeof(bigbuffer),ppmFile); 
	  // printf("\tDUMP--------------%u\n",sizeof(bigbuffer));
	} /* hairy modulo buffering scheme 
	     lowers opsys call overhead */
      }
    }
  }  
  else if(depth<=16){
    fprintf(ppmFile,"32\n"); /* the maxval field */
    for(y=0,bindex=0;y<img->height;y++){
      for(x=0;x<img->width;x++){
	unsigned long pixel = XGetPixel(img,x,img->height-y);
	bigbuffer[bindex++] = REDPIXEL16(pixel);
	bigbuffer[bindex++] = GREENPIXEL16(pixel);
	bigbuffer[bindex++] = BLUEPIXEL16(pixel);
	if(x==1 && y==1) {
	  PrintBinary(pixel,32);
	  printf("R=%u G=%u B=%u A=%u\n",
		 (int)REDPIXEL16(pixel),
		 (int)GREENPIXEL16(pixel),
		 (int)BLUEPIXEL16(pixel),
		 (int)ALPHAPIXEL16(pixel));
	}
	/* idx++; */
	if(!(bindex%=sizeof(bigbuffer))){
	  fwrite(bigbuffer,1,sizeof(bigbuffer),ppmFile); 
	  // printf("\tDUMP--------------%u\n",sizeof(bigbuffer));
	} /* hairy modulo buffering scheme 
	     lowers opsys call overhead */
      }
    }
  }
  fwrite(bigbuffer,1,bindex,ppmFile); /* get the rest dumped */
  fclose(ppmFile);
}

class OffscreenImage {
  int depth;
  GLXContext ContextId;
  Pixmap     pixmap;
  Window     WindowId;
  Window     NextWindowId;
  Display   *DisplayId;
  XVisualInfo *v;
  int Size[2];
  // int attributeList[] = { GLX_RGBA, None };

  
  void WindowInitialize (char *dpyname=NULL)
  {
    puts("vtkOpenGLOffScreen::WindowInitialize\n");
    
    int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
    int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
    
    // get the default display connection 
    if (!this->DisplayId)
      {
	this->DisplayId = XOpenDisplay((char *)dpyname); 
	if (this->DisplayId == NULL) 
	  {
	    perror("bad X server connection.\n");
	  }
      }
    
    // get visual info and set up pixmap buffer
    // v = this->GetDesiredVisualInfo();
    int attributeList[] = { GLX_RGBA, None };
    printf("glxChooseVis DPY=%u SCRN=%u \n",(unsigned int)(this->DisplayId),
	   DefaultScreen(this->DisplayId));
    this->v = glXChooseVisual(this->DisplayId,
			DefaultScreen(this->DisplayId),
			attributeList);
    fprintf(stderr,"Visual selected.\n");
    this->ContextId = glXCreateContext(this->DisplayId,this->v,0,GL_FALSE);
    /* create offscreen pixmap to render to (same depth as RootWindow of dpy) */
    this->pixmap = XCreatePixmap(this->DisplayId,
				 RootWindow(this->DisplayId,v->screen),
				 width,
				 height,
				 v->depth);
    printf("Depth=%d\n",v->depth);
    this->WindowId= glXCreateGLXPixmap(this->DisplayId,v,this->pixmap); 
    
    glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
    
    // initialize GL state
    //glMatrixMode( GL_MODELVIEW );
    //glDepthFunc( GL_LEQUAL );
    //glEnable( GL_DEPTH_TEST );
    //glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
    //glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
    // Paul!
    //glEnable(GL_BLEND);
    //glEnable( GL_NORMALIZE );
    //glAlphaFunc(GL_GREATER,0);
}
public:
  OffscreenImage(char *dpyname=NULL){
    Size[0]=Size[1]=0;
    WindowInitialize(dpyname);
  }
  ~OffscreenImage(){
    glXDestroyGLXPixmap(DisplayId,WindowId);
    XFreePixmap(DisplayId,pixmap);
    glXDestroyContext(DisplayId,ContextId);
    XFree(v); /* free the visual info */
  }
  void WriteImage(char *filename){
    //XImage *img = this->GetImage();   
    int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
    int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
    glFlush();
    XFlush(this->DisplayId);
    XImage *img = XGetImage(this->DisplayId,
			    this->pixmap,
			    0,0,  
			    width,height,
			    AllPlanes,
			    XYPixmap);
    writePPM(filename,img,this->v->depth);
    XDestroyImage(img);
  }
  void makeCurrent(){
    glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId); 
  }
};

int main(int argc, char **argv){
  OffscreenImage *offscreen;
  /*
  int attributeList[] = { GLX_RENDER_TYPE_SGIX, GLX_RGBA_BIT_SGIX, 
  GLX_RED_SIZE, 4,
                 GLX_GREEN_SIZE, 4, GLX_BLUE_SIZE, 4, None}; 
  int attributeListP[] = { GLX_PRESERVED_CONTENTS_SGIX, True, 
			   GLX_LARGEST_PBUFFER_SGIX, True,
			   None};
			   */
  if(argc>1)
    offscreen = new OffscreenImage(argv[1]);
  else
    offscreen = new OffscreenImage();
  puts("make context current");
  offscreen->makeCurrent();
  puts("made current");
  /* frambuffer setup */
  glClearColor(1.0,1.0,1.0,0.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glColor3f(0.0,0.0,1.0); // r g b
  glOrtho(-1,1,-1,1,-1,1);
  glBegin(GL_POLYGON);
	glVertex2f(-0.5,-0.5);
	glVertex2f(-0.5,0.5);
	glVertex2f(0.5,0.6);
  glEnd();
  glFlush();
  puts("done drawing");
  /* Must copy Pixmap to XImage to get data from Xserver to client.
   The pixmap may not be on the same machine as the client application. */
  // XFlush(dpy);
  // puts("DPY flushed");
  offscreen->WriteImage("test4.ppm");
  delete offscreen;
  return 0;
}

