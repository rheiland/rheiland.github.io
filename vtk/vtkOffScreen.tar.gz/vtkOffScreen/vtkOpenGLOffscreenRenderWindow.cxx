/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkOpenGLOffscreenRenderWindow.cxx,v $
  Language:  C++
  Date:      $Date: 1999/12/01 18:44:34 $
  Version:   $Revision: 1.16 $

Copyright (c) 1993-1999 Ken Martin, Will Schroeder, Bill Lorensen.

This software is copyrighted by Ken Martin, Will Schroeder and Bill Lorensen.
The following terms apply to all files associated with the software unless
explicitly disclaimed in individual files. This copyright specifically does
not apply to the related textbook "The Visualization Toolkit" ISBN
013199837-4 published by Prentice Hall which is covered by its own copyright.

The authors hereby grant permission to use, copy, and distribute this
software and its documentation for any purpose, provided that existing
copyright notices are retained in all copies and that this notice is included
verbatim in any distributions. Additionally, the authors grant permission to
modify this software and its documentation for any purpose, provided that
such modifications are not distributed without the explicit consent of the
authors and that existing copyright notices are retained in all copies. Some
of the algorithms implemented by this software are patented, observe all
applicable patent law.

IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
OF THE USE OF THIS SOFTWARE, ITS DOCUMENTATION, OR ANY DERIVATIVES THEREOF,
EVEN IF THE AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

THE AUTHORS AND DISTRIBUTORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING,
BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, AND NON-INFRINGEMENT.  THIS SOFTWARE IS PROVIDED ON AN
"AS IS" BASIS, AND THE AUTHORS AND DISTRIBUTORS HAVE NO OBLIGATION TO PROVIDE
MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.


=========================================================================*/
// .NAME vtkOpenGLOffscreenRenderWindow - Render OpenGL scene offscreen.
// .SECTION Description
// Renders the entire 3D scene without need of an on-screen window.  
// This is very useful for client-server visualization. 
// .SECTION Caveats
//  There are two ways of doing this.  The most generic method is to 
//  render to an offscreen XPixmap and copy the pixels back to the 
//  client application.  While this implementation completely conforms
//  to the GLX standard, it forces the rendering to occur in software.
//  The SGI GLXPbuffer extension can be used to take advantage of
//  any available hardware graphics acceleration on the client side.
//  However it is very sgi-specific and there is no guarantee that
//  you will be able to find a properly matching visual type (this
//  is my fault because the matching is pretty rudimentary right now).
// 
//  Unfortunately these two modes of operation must be selected at 
//  compilation time.  Use Pbuffers by defining USE_PBUFFER.
//  Also some debugging information could not use the vtkDebugMacro()
//  so you must #define DEBUG_OFFSCREEN in order to turn on verbose
//  debugging.
//
// .SECTION see also
// vtkOpenGLRenderWindow, vtkWin32OffscreenRenderWindow

#include <stdlib.h>
#include <math.h>
#include <iostream.h>
#include <unistd.h>
#include "vtkOpenGLOffscreenRenderWindow.h"
#include "vtkOpenGLRenderer.h"
#include "vtkOpenGLProperty.h"
#include "vtkOpenGLTexture.h"
#include "vtkOpenGLCamera.h"
#include "vtkOpenGLLight.h"
#include "vtkOpenGLActor.h"
#include "vtkOpenGLPolyDataMapper.h"
#include "GL/gl.h"
#include "GL/glu.h"
#ifdef USE_DMEDIA
#include <dmedia/cl.h>
#endif

#define MAX_LIGHTS 8
#ifdef USE_PBUFFER

#define USE_GRABFRAMEBUFFER // Use the SGI Pbuffer in such a way that everyone
// else is blocked from using it.
#define USE_CLOSEDISPLAY // When the SGI Pbuffer is released, also close the
// display.  This seems to be necessary on Octane machines in order
// to release the framebuffer for some reason that I haven't figured out yet.
#endif

#ifdef DEBUG_OFFSCREEN
#define offDebugMacro(x) cerr x
#else
#define offDebugMacro(x) // nil
#endif

#define offErrorMacro(x) cerr x

void minmax(unsigned int *buffer,int nelem,float &min,float &max){
  min=max=(float)(buffer[0]);
  for(int i=0;i<nelem;i++){
    float v=(float)(buffer[i]);
    if(v>max) max=v;
    if(v<min) min=v;
  }
}

void minmax(float *buffer, int nelem,float &min,float &max){
  min=max=(float)(buffer[0]);
  for(int i=0;i<nelem;i++){
    float v=(float)(buffer[i]);
    if(v>max) max=v;
    if(v<min) min=v;
  }
}
//typedef struct {
//  int type;
//  Display *display;   /* Display the event was read from */
//  unsigned long serial;/* serial number of failed request */
//  unsigned char error_code;/* error code of failed request */
//  unsigned char request_code;/* Major op-code of failed request */
//  unsigned char minor_code;/* Minor op-code of failed request */
//  XID resourceid;     /* resource id */
//} XErrorEvent;

int xerrorhandler(Display *dpy,XErrorEvent *event){
  printf("Captured XError: error_code=%u request_code=%u minor_code=%u\n",
	 event->error_code,event->request_code,event->minor_code);
  puts("\tRetrying Framebuffer Grab! ******************");
#ifdef USE_PBUFFER
  sginap(50); // nap a little in order to give system time to free up framebuffer
#endif
}
//----------------------------------------------------------------
#ifdef USE_DMEDIA
int vtkOpenGLOffscreenRenderWindow::GetJPEGsizeEstimate(){ 
  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  CLhandle cmp;
  int compressedBufferSize;

  // lets do it
  clOpenCompressor(CL_JPEG_SOFTWARE, &cmp); // this might be costly op
  clSetParam(cmp, CL_IMAGE_WIDTH,width);
  clSetParam(cmp, CL_IMAGE_HEIGHT,height);
  clSetParam(cmp, CL_FORMAT, CL_FORMAT_XBGR);
  compressedBufferSize=clGetParam(cmp,CL_COMPRESSED_BUFFER_SIZE);
  clCloseCompressor(cmp);
  return compressedBufferSize;
}
int vtkOpenGLOffscreenRenderWindow::WriteJPEGtoMemory(char *compressedBuffer,float compressionRatio){
  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  CLhandle cmp;
  int compressedBufferSize;
  
  // lets do it
  clOpenCompressor(CL_JPEG_SOFTWARE, &cmp); // this might be costly op (software JPEG)
  // use CL_JPEG_COSMO to do hardware assisted compression where available
  clSetParam(cmp, CL_IMAGE_WIDTH,width);
  clSetParam(cmp, CL_IMAGE_HEIGHT,height);
  clSetParam(cmp, CL_COMPRESSION_RATIO,CL_TypeIsInt(compressionRatio));
  // 0xXXBBGGRR 32-bit word format
  clSetParam(cmp, CL_FORMAT, CL_FORMAT_XBGR);
  compressedBufferSize = clGetParam(cmp,CL_COMPRESSED_BUFFER_SIZE);
  // allocate source image buffer
  unsigned int *xbgr_image = new unsigned int[width*height];
  // read the pixels from the framebuffer
  fbReadPixels(0,0,width,height,GL_ABGR_EXT,GL_UNSIGNED_BYTE,xbgr_image);
  // compress from xbgr_image source to compressedBuffer destination
  clCompress(cmp,1,xbgr_image,&compressedBufferSize,compressedBuffer);
  delete xbgr_image; // delete source image buffer
  clCloseCompressor(cmp);
  return compressedBufferSize;
}
int vtkOpenGLOffscreenRenderWindow::WriteJPEG(char *filename,float compressionRatio){
  char *compressedBuffer;
  FILE *jpeg = fopen(filename,"w");
  if(!jpeg){
    printf("vtkOpenGLOffscreenRenderWindow::WriteJPEG : error, could not open file [%s] for writing\n",filename);
    return 0;
  }
  int clen=GetJPEGsizeEstimate();
  compressedBuffer = new char[clen];
  clen=WriteJPEGtoMemory(compressedBuffer,compressionRatio);
  fwrite(compressedBuffer,1,clen,jpeg);
  fclose(jpeg);
  return 1;
}
#else
int vtkOpenGLOffscreenRenderWindow::GetJPEGsizeEstimate(){puts("Unsupported (enable with #define USE_DMEDIA or compile with -DUSE_DMEDIA if you are on an SGI system)");}
int vtkOpenGLOffscreenRenderWindow::WriteJPEGtoMemory(char *compressedBuffer,float compressionRatio){ puts("Unsupported (enable with #define USE_DMEDIA or compile with -DUSE_DMEDIA  if you are on an SGI system)");}
int vtkOpenGLOffscreenRenderWindow::WriteJPEG(char *filename,float compressionRatio){ puts("Unsupported (enable with #define USE_DMEDIA or compile with -DUSE_DMEDIA if you are on an SGI system)");}
#endif
//----------------------------------------------------------------
void vtkOpenGLOffscreenRenderWindow::WriteImage(char *filename)
{
  //XImage *img = this->GetImage(); 
  vtkDebugMacro(<< " vtkOpenGLOffscreenRenderWindow::WriteImage\n");  
  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  offDebugMacro(<< "\tSize is " << width << ':' << height << "\n" ); 
  if(this->ContextId && this->DisplayId && this->WindowId){
    glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId); 
    glFlush();
  }
#ifdef USE_PBUFFER
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId); 
  glFlush();
  unsigned int *pixelbuffer = new unsigned int[width*height];
  fbReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,pixelbuffer);
  WritePPMPbuffer(filename,width,height,pixelbuffer);
  delete pixelbuffer;
#else
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId); 
  glFlush();
  XFlush(this->DisplayId);
  vtkDebugMacro(<< "\nRead Pixels\n");  
  XImage *img = XGetImage(this->DisplayId,
			  this->pixmap,
			  0,0,
			  width,height,
			  AllPlanes,
			  XYPixmap);
  WritePPMXImage(filename,img);
  XDestroyImage(img);
#endif
}

//----------------------------------------------------------------
void vtkOpenGLOffscreenRenderWindow::WritePPMPbuffer(char *filename,
					 int width,int height,
					 unsigned int *img)
{
  FILE *ppmFile;
  register int x,y;
  register short bindex;
  char bigbuffer[2048*3];
  // unsigned int *img=(unsigned int*)pbuffer;
  int idx;
  /* Attempt to open file */
  if (!(ppmFile = fopen(filename, "w"))){
    offErrorMacro(<< "vtkOpenGLOffscreenRenderWindow::WritePPMPbuffer Could not open file " << filename << "\n" );  
    return;
  }
  
  offDebugMacro(<< "opened " << filename << " for writing\n" );
  
  fprintf(ppmFile,"P6\n"); /* define as a PPM file */
  fprintf(ppmFile,"%d %d\n",width,height); /* width and height */
  fprintf(ppmFile,"255\n"); /* the maxval field */
  for(x=0,idx=0,bindex=0;x<width;x++){
    for(y=0;y<height;y++){
      unsigned int pixel = img[idx++];
#define PB_ALPHAPIXEL(p) (p & 0xFF)
#define PB_BLUEPIXEL(p) ((p>>8) & 0xFF)
#define PB_GREENPIXEL(p) ((p>>16) & 0xFF)
#define PB_REDPIXEL(p) ((p>>24) & 0xff)
      bigbuffer[bindex++] = PB_REDPIXEL(pixel);
      bigbuffer[bindex++] = PB_GREENPIXEL(pixel);
      bigbuffer[bindex++] = PB_BLUEPIXEL(pixel);
      /* idx++; */
      if(!(bindex%=sizeof(bigbuffer)))
	fwrite(bigbuffer,1,sizeof(bigbuffer),ppmFile);  /* hairy modulo buffering scheme 
							   lowers opsys call overhead */
    }
  }
  fwrite(bigbuffer,1,bindex,ppmFile); /* get the rest dumped */
  fclose(ppmFile);
}

//----------------------------------------------------------------
void vtkOpenGLOffscreenRenderWindow::WritePPMXImage(char *filename,XImage *img)
{
  FILE *ppmFile;
  register int x,y;
  register short bindex;
  unsigned char bigbuffer[3*2048];

  /* Attempt to open file */
  if (!(ppmFile = fopen(filename, "w"))){
    offErrorMacro(<< "writePPM: Can't open data file " << filename << "\n" );
    return;
  }
  
  offDebugMacro( << "opened " << filename << " for writing\n\tWidth=" << img->width << " Height=" << img->height << "\n" );
  
  fprintf(ppmFile,"P6\n"); /* define as a PPM file */
  fprintf(ppmFile,"%d %d\n",img->width,img->height); /* width and height */
  fprintf(ppmFile,"255\n"); /* the maxval field */
  offDebugMacro(<< "StartDump\n");
  for(y=0,bindex=0;y<img->height;y++){
    for(x=0;x<img->width;x++){
      unsigned long pixel = XGetPixel(img,x,img->height-y);
#define REDPIXEL(p) (p & 0xFF)
#define BLUEPIXEL(p) ((p>>8) & 0xFF)
#define GREENPIXEL(p) ((p>>16) & 0xFF)
#define ALPHAPIXEL(p) ((p>>24) & 0xff)
      bigbuffer[bindex++] = REDPIXEL(pixel);
      bigbuffer[bindex++] = GREENPIXEL(pixel);
      bigbuffer[bindex++] = BLUEPIXEL(pixel);
      /* idx++; */
      if(!(bindex%=sizeof(bigbuffer))){
	fwrite(bigbuffer,1,sizeof(bigbuffer),ppmFile);  /* hairy modulo buffering scheme 
							   lowers opsys call overhead */
	// printf("Dump[%u:%u] %u bytes\n",x,y,sizeof(bigbuffer));
      }
    }
  }
  if(bindex>0)
    fwrite(bigbuffer,1,bindex,ppmFile); /* get the rest dumped */
  fclose(ppmFile);
}

//----------------------------------------------------------------
XVisualInfo *vtkOpenGLOffscreenRenderWindow::GetDesiredVisualInfo()
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetDesiredVisualInfo\n");

  int attributeList[] = { GLX_RGBA, GLX_RED_SIZE, 1,  GLX_GREEN_SIZE, 1, GLX_BLUE_SIZE, 1, GLX_DEPTH_SIZE, 1, None };
  return glXChooseVisual(this->DisplayId,
			 DefaultScreen(this->DisplayId),attributeList);
}

//----------------------------------------------------------------
// Constructor
vtkOpenGLOffscreenRenderWindow::vtkOpenGLOffscreenRenderWindow()
{
#ifdef USE_PBUFFER
  cout << "using PBuffers..." << endl;
#else
  cout << "NOT using PBuffers..." << endl;
#endif

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::vtkOpenGLOffscreenRenderWindow\n");
  this->framebuffer = 0;
  this->zbuffer=0;
  this->ContextId = NULL;
  this->MultiSamples = 8;
  this->DisplayId = (Display *)NULL;
  this->WindowId = (Window)NULL;
  this->NextWindowId = (Window)NULL;
  this->ColorMap = (Colormap)0;

  if ( this->WindowName ) 
    delete [] this->WindowName;
  this->WindowName = new char[strlen("Visualization Toolkit - OpenGL")+1];
  strcpy( this->WindowName, "Visualization Toolkit - OpenGL" );
}

//----------------------------------------------------------------
// Description:
// free up memory & close the window
vtkOpenGLOffscreenRenderWindow::~vtkOpenGLOffscreenRenderWindow()
{
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::~vtkOpenGLOffscreenRenderWindow\n");
  /* first delete all the old lights */
  // make sure we have been initialized 
  if(this->framebuffer) delete this->framebuffer;
  framebuffer=0;
  if(this->zbuffer) delete zbuffer;
  zbuffer=0;
  if (this->ContextId) {

    // disable all the lights
    for (short cur_light = GL_LIGHT0;
         cur_light < GL_LIGHT0+MAX_LIGHTS;
         cur_light++)
      glDisable((GLenum)cur_light);
    glXDestroyContext( this->DisplayId, this->ContextId);
    glXDestroyGLXPbufferSGIX(this->DisplayId, this->WindowId);
  }
}

//----------------------------------------------------------------
void vtkOpenGLOffscreenRenderWindow::Destroy()
{
  if (this->ContextId) {
    glXDestroyContext( this->DisplayId, this->ContextId);
#ifdef USE_PBUFFER
    glXDestroyGLXPbufferSGIX(this->DisplayId, this->WindowId);
#else
    glXDestroyGLXPixmap(this->DisplayId,this->WindowId);
    XFreePixmap(this->DisplayId,this->pixmap);
    this->pixmap=0;
#endif
    this->WindowId=0; this->ContextId=0;
  }
}

//----------------------------------------------------------------
// Description:
// Begin the rendering process.
void vtkOpenGLOffscreenRenderWindow::Start(void)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::Start\n");

  // if the renderer has not been initialized, do so now
  if (!this->ContextId)
    {
      this->Initialize();
    }
#ifdef USE_GRABFRAMEBUFFER
  GrabFramebuffer(); // for PBUFFERS
#endif
  // set the current window 
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
}

//----------------------------------------------------------------
// Description:
// End the rendering process and display the image.
void vtkOpenGLOffscreenRenderWindow::Frame(void)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::Frame\n");

  glFlush();
  if (!this->AbortRender && this->DoubleBuffer&&this->SwapBuffers)
    {

      vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::Frame swapbuffers\n");

      //glXSwapBuffers(this->DisplayId, this->WindowId);
      vtkDebugMacro(<< " glXSwapBuffers\n");
    }
#ifdef USE_GRABFRAMEBUFFER
  ReleaseFramebuffer(); // for PBUFFERS
#endif
}
 
//----------------------------------------------------------------
// Description:
// Update system if needed due to stereo rendering.
// STEREO RENDERING CURRENTLY NOT SUPPORTED
void vtkOpenGLOffscreenRenderWindow::StereoUpdate(void)
{
  return; // JMS: There is no stereo.  Now go away...
}

//----------------------------------------------------------------
// Description:
// Specify various window parameters.
void vtkOpenGLOffscreenRenderWindow::WindowConfigure()
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::WindowConfigure\n");

  // this is all handled by the desiredVisualInfo method
}
void QueryPbuffer(Display *dpy,GLXPbufferSGIX pbuf){
  unsigned int value;
  /* GLX_WIDTH_SGIX, GLX_HEIGHT_SGIX, GLX_LARGEST_PBUFFER_SGIX */
  offDebugMacro(<< "vtkOpenGLOffscreenRenderWindow.cxx : QueryPbuffer() glXQueryGLXPbufferSGIX() Info\n");
  glXQueryGLXPbufferSGIX(dpy,pbuf,GLX_WIDTH_SGIX,&value);
  offDebugMacro(<< "\tpbuffer width   = " << value <<" \n");
  glXQueryGLXPbufferSGIX(dpy,pbuf,GLX_HEIGHT_SGIX,&value);
  offDebugMacro(<< "\tpbuffer height  = " << value << "\n");
  glXQueryGLXPbufferSGIX(dpy,pbuf,GLX_LARGEST_PBUFFER_SGIX,&value);
  offDebugMacro(<< "\tpbuffer largest = " << value << "\n");
}

void QueryConfig(Display *dpy, GLXFBConfigSGIX config){
  int value;
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_BUFFER_SIZE
			   ,&value );
  offDebugMacro(<< "\tbuffersize(bits per cbuffer)=" << value << "\n");
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_LEVEL
			   ,&value );
  offDebugMacro(<< "\tOverlay buffer (0 is main buffer)=" << value << "\n");
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_RED_SIZE
			   ,&value );
  offDebugMacro(<< "\t\tRedsize=" << value << " : ");
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_BLUE_SIZE
			   ,&value );
  offDebugMacro(<< "Bluesize=" << value << " : ");
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_GREEN_SIZE
			   ,&value );
  offDebugMacro(<< "Greensize=" << value << " : ");
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_ALPHA_SIZE
			   ,&value );
  offDebugMacro(<< "Alphasize=" << value << "\n");
  
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_DEPTH_SIZE
			   ,&value );
  offDebugMacro(<< "\tDepth buffer size="<< value << "\n");
  
  
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_VISUAL_CAVEAT_EXT
			   ,&value );
  switch(value){
  case GLX_NONE_EXT:
    offDebugMacro(<< "\tNo Caveats\n");
    break;
  case GLX_SLOW_VISUAL_EXT:
    offDebugMacro(<< "\tSlow Visual\n");
    break;
    /* case GLX_NON_CONFORMANT_EXT:
       offDebugMacro(<< "\tNon_Conformant visual");
       break;*/
  default:
    offDebugMacro(<< "\tUnknown Caveat " << value << "\n");
    break;
  }
  glXGetFBConfigAttribSGIX(dpy,config,
			   GLX_RENDER_TYPE_SGIX
			   ,&value );
  if(value==GLX_RGBA_BIT_SGIX)
    offDebugMacro(<< "\tGLX_RGBA_BIT_SGIX\n");
  /*
    else if(value==GLX_COLOR_INDEX_SGIX)
    offDebugMacro(<< "\tGLX_COLOR_INDEX_SGIX"); */
  else offDebugMacro(<< "\tunknown (color index vs. rgba bit) " << value << "\n");
}

//----------------------------------------------------------------
// Description:
// Initialize the window for rendering.

void vtkOpenGLOffscreenRenderWindow::WindowInitialize (void)
{
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::WindowInitialize\n");
#ifdef USE_PBUFFER
  GrabFramebuffer(); // grab the framebuffer (this will create it)
  QueryPbuffer(this->DisplayId,this->WindowId);
#else  
  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  this->Size[0]=width;
  this->Size[1]=height;
  // this->SetSize(width,height);
  // get the default display connection 
  if (!this->DisplayId) {
    this->DisplayId = XOpenDisplay(":0"); 
    if (this->DisplayId == NULL) {
      vtkErrorMacro(<< "bad X server connection.\n");
    }
  }
  //  XSetErrorHandler(xerrorhandler);
  XVisualInfo  *v;
  int attributeList[] = { GLX_RGBA, GLX_RED_SIZE, 1,  
			  GLX_GREEN_SIZE, 1, GLX_BLUE_SIZE, 1, 
			  GLX_DEPTH_SIZE, 1, None };
  v = glXChooseVisual(this->DisplayId,
		      DefaultScreen(this->DisplayId),attributeList);
  //this->ContextId = glXCreateContext(dpy,vi,0,GL_FALSE);
  /* this->WindowId = CreateOffscreenPixmap(dpy,vi,&pixmap,width,height); */
  
  /* create offscreen pixmap to render to (same depth as RootThis->Window of dpy) */
  this->pixmap = XCreatePixmap(this->DisplayId,
			       RootWindow(this->DisplayId,v->screen),
			       width,
			       height,
			       v->depth);
  this->ContextId = glXCreateContext(this->DisplayId,v,0,GL_FALSE);
  this->WindowId = glXCreateGLXPixmap(this->DisplayId,v,this->pixmap); /*  make gl understand it as a window */
  if (v){
    XFree(v);
  }
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
  vtkDebugMacro(<< " glMatrixMode ModelView\n");
  glMatrixMode( GL_MODELVIEW );
  vtkDebugMacro(<< " zbuffer enabled\n");
  glDepthFunc( GL_LEQUAL );
  glEnable( GL_DEPTH_TEST );
  vtkDebugMacro(" texture stuff\n");
  glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
  // initialize blending for transparency
  vtkDebugMacro(<< " blend func stuff\n");
  glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
  glEnable(GL_BLEND);
  glEnable( GL_NORMALIZE );
  glAlphaFunc(GL_GREATER,0);
#endif
  this->Mapped = 0; // if its mapped, then it trys windowgetattributes which fails!
  this->SwapBuffers = 0;
  this->DoubleBuffer = 0;
#ifdef USE_GRABFRAMEBUFFER
  ReleaseFramebuffer();
#endif
}

void vtkOpenGLOffscreenRenderWindow::GrabFramebuffer(){
  // make sure we haven't already done this
  if(this->DisplayId && this->WindowId && this->ContextId) return;
#ifdef USE_PBUFFER  
  if (!this->DisplayId) {
      this->DisplayId = XOpenDisplay(":0"); 
      if (this->DisplayId == NULL) {
	  vtkErrorMacro(<< "bad X server connection.\n");
      }
  }
  XSetErrorHandler(xerrorhandler);
  int attributeList[] = { GLX_RENDER_TYPE_SGIX, GLX_RGBA_BIT_SGIX, GLX_RED_SIZE, 4,
			  GLX_GREEN_SIZE, 4, GLX_BLUE_SIZE, 4,GLX_DEPTH_SIZE, 4, None}; 
  int attributeListP[] = {GLX_PRESERVED_CONTENTS_SGIX, True,
			  GLX_LARGEST_PBUFFER_SGIX, True,
			  None};
  int nattribs;
  int confignum=0;
  GLXFBConfigSGIX *config;
  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  config = glXChooseFBConfigSGIX(this->DisplayId,DefaultScreen(this->DisplayId),attributeList,&nattribs);
  if(!config) vtkErrorMacro(<< "vtkOpenGLOffscreenRenderWindow::WindowInitialize : no matching config found\n");
  //puts("Create Context");
  while(!this->ContextId){ // should have a break-out (retrys forever now)
    this->ContextId = glXCreateContextWithConfigSGIX(this->DisplayId, config[confignum], 
						     GLX_RGBA_TYPE_SGIX, NULL,True);
  }
  // create a PBUFFER window to render to.
  //puts("Make pbuffer");
  while(!this->WindowId){ // should have a break-out (retrys forever now)
    this->WindowId = glXCreateGLXPbufferSGIX(this->DisplayId,config[confignum],
					     width,height,attributeListP);
  }
  //puts("Created pbuffer");
  vtkDebugMacro(<< "created offscreen pbuffer. Now make current\n");
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
  // initialize GL state
  vtkDebugMacro(<< " glMatrixMode ModelView\n");
  glMatrixMode( GL_MODELVIEW );
  vtkDebugMacro(<< " zbuffer enabled\n");
  glDepthFunc( GL_LEQUAL );
  glEnable( GL_DEPTH_TEST );
  vtkDebugMacro(" texture stuff\n");
  glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
  // initialize blending for transparency
  vtkDebugMacro(<< " blend func stuff\n");
  glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
  glEnable(GL_BLEND);
  glEnable( GL_NORMALIZE );
  glAlphaFunc(GL_GREATER,0);
  if(this->framebuffer){
    vtkDebugMacro(<< " Copy framebuffer from user-memory.\n");
    glDrawPixels(width,height,GL_RGBA,GL_UNSIGNED_BYTE,framebuffer);
    glDrawPixels(width,height,GL_DEPTH_COMPONENT,GL_FLOAT,zbuffer);
  }
#endif
}
void vtkOpenGLOffscreenRenderWindow::ReleaseFramebuffer(){
  if(!this->ContextId) return; // already deallocated
#ifdef USE_PBUFFER
  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId); 
  glFlush();
  if(this->framebuffer) delete this->framebuffer;
  if(this->zbuffer) delete this->zbuffer;
  this->framebuffer = new unsigned int[width*height];
  this->zbuffer = new float[width*height];
  vtkDebugMacro(<< "\nCopy Pixels from framebuffer\n");  
  glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,framebuffer);
  glReadPixels(0,0,width,height,GL_DEPTH_COMPONENT,GL_FLOAT,zbuffer);
  glXDestroyContext(this->DisplayId, this->ContextId);
  glXDestroyGLXPbufferSGIX(this->DisplayId, this->WindowId);
  this->ContextId=0;
  this->WindowId=0;
#ifdef USE_CLOSEDISPLAY
  XCloseDisplay(this->DisplayId);
  this->DisplayId=0;
#endif
#endif
}
void vtkOpenGLOffscreenRenderWindow::fbReadPixels(GLint x, GLint y,
		  GLsizei width, GLsizei height,
		  GLenum format, GLenum type,
		  GLvoid *pixels ){
  if(this->ContextId && this->WindowId){
    //puts("using glReadPixels");
    glReadPixels(x,y,width,height,format,type,pixels);
  }
  else{
    int fwidth = ((this->Size[0] > 0) ? this->Size[0] : 300);
    int fheight = ((this->Size[1] > 0) ? this->Size[1] : 300);
    switch(format){
#ifdef USE_DMEDIA
    case GL_ABGR_EXT:
      switch(type){
      case GL_FLOAT: // TOTALLY BOGUS (just for algorithm testing)
	// this is the older "slow" algorithm.
	{
	  // puts("Converts ABGR unsigned byte");
	  for(int idx=0,j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++,idx+=4){
	      unsigned int pixel = framebuffer[i+j*fwidth];
	      unsigned int p1,p2,p3,p4;
	      p1 = (pixel & 0x000000FF);
	      p2 = ((pixel>>8) & 0x000000FF);
	      p3 = ((pixel>>16) & 0x000000FF);
	      p4 = ((pixel>>24) & 0x000000FF);
	      pixel = (p1<<24 | p2<<16 | p3<<8 | p4);
	      ((unsigned int*)pixels)[ii+jj*width]=pixel;
	    }
	  }
	}
	break;
      case GL_UNSIGNED_BYTE: // this is totally bogus (for experimentation
	{
	  register unsigned char *pix=(unsigned char*)pixels;
	  register unsigned int *fb=framebuffer;
	  register unsigned int isrc;
	  register unsigned char *src=(unsigned char*)(&isrc);
	  //st=(unsigned char *)(&idst);
	  
	  // puts("Converts ABGR unsigned byte");
	  for(int idx=0,j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++,idx+=4){
	      isrc = *(fb++);
	      // do the swap thing...
	      *(pix++)=src[3];
	      *(pix++)=src[2];
	      *(pix++)=src[1];
	      *(pix++)=src[0];
	    }
	  }
	}
	break;
      default:
	puts("Cant deal with this type (GL_ABGR which isn't UNSIGNED_BYTE)");
	break;
      }
      break;
#endif
    case GL_RGBA:
      switch(type){
      case GL_UNSIGNED_BYTE:
	{
	  for(int j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++){
	      ((unsigned int*)pixels)[ii+jj*width]=framebuffer[i+j*fwidth];
	    }
	  }
	}
	break;
      case GL_FLOAT:
	{
	  for(int idx=0,j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++){
	      unsigned int pixel = framebuffer[i+j*fwidth];
	      for(int p=0;p<4;p++){
		((float*)pixels)[idx++]=((float)(pixel & 0x000000FF))/255.0;
		pixel>>=8; // shift down a byte
	      }
	    }
	  }
	}
	break;
      }
      break;
    case GL_DEPTH_COMPONENT:
      switch(type){
      case GL_UNSIGNED_BYTE:
	vtkErrorMacro(<< "Cant do this yet!!! (fbReadPixels on depthbuffer as unsigned byte)\n");
	break;
      case GL_FLOAT:
	{
	  for(int j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++){
	      ((float*)pixels)[ii+jj*width]=zbuffer[i+j*fwidth];
	    }
	  }
	}
	break;
      }
      break;
    }
  }
}
void vtkOpenGLOffscreenRenderWindow::fbDrawPixels(
		  GLsizei width, GLsizei height,
		  GLenum format, GLenum type,
		  GLvoid *pixels ){
  int x=0,y=0;
  if(this->ContextId && this->WindowId){
    glDrawPixels(width,height,format,type,pixels);
  }
  else {
    
    int fwidth = ((this->Size[0] > 0) ? this->Size[0] : 300);
    int fheight = ((this->Size[1] > 0) ? this->Size[1] : 300);
    switch(format){
    case GL_RGBA:
      switch(type){
      case GL_UNSIGNED_BYTE:
	{
	  for(int j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++){
	      framebuffer[i+j*fwidth]=((unsigned int*)pixels)[ii+jj*width];
	    }
	  }
	}
	break;
      case GL_FLOAT:
	{
	  unsigned char *fb=(unsigned char*)(this->framebuffer);
	  unsigned char *pix = (unsigned char*)(pixels);
	  for(int idx=0,j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++){
	      for(int p=0;p<4;p++,idx++)
		fb[idx]=(unsigned char)(255.0*pix[idx]);
	    }
	  }
	}
	break;
      }
      break;
    case GL_DEPTH_COMPONENT:
      switch(type){
      case GL_UNSIGNED_BYTE:
	vtkErrorMacro(<< "Cant do this yet!!! (fbReadPixels on depthbuffer as unsigned byte)");
	break;
      case GL_FLOAT:
	{
	  for(int j=y,jj=0;jj<height;jj++,j++){
	    for(int i=x,ii=0;ii<width;ii++,i++){
	      zbuffer[i+j*fwidth]=((float*)pixels)[ii+jj*width];
	    }
	  }
	}
	break;
      }
      break;
    }
  }
}
//----------------------------------------------------------------
// Description:
// Initialize the rendering window.
void vtkOpenGLOffscreenRenderWindow::Initialize (void)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::Initialize\n");

  // make sure we havent already been initialized 
  if (this->ContextId)
    return;

  // now initialize the window 
  this->WindowInitialize();
}

//----------------------------------------------------------------
// Description:
// Change the window to fill the entire screen.
void vtkOpenGLOffscreenRenderWindow::SetFullScreen(int arg)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::SetFullScreen\n");
  PrefFullScreen(); // Danger McFly!!
  return;
}

//----------------------------------------------------------------
// Description:
// Set the preferred window size to full screen.
void vtkOpenGLOffscreenRenderWindow::PrefFullScreen()
{
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::PrefFullScreen\n");
  int *size = this->GetScreenSize();
  this->Position[0] = 0;
  this->Position[1] = 0;
  this->Size[0] = size[0];
  this->Size[1] = size[1];
  this->Borders = 0;
  return;
}

// Description:
// Resize the window.
void vtkOpenGLOffscreenRenderWindow::WindowRemap()
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::WindowRemap\n");

  short cur_light;

  /* first delete all the old lights */
  for (cur_light = GL_LIGHT0; cur_light < GL_LIGHT0+MAX_LIGHTS; cur_light++)
    {
      glDisable((GLenum)cur_light);
    }
  
  glXDestroyContext( this->DisplayId, this->ContextId);
  // then close the old window 
  if (this->OwnWindow)
    {
      XDestroyWindow(this->DisplayId,this->WindowId);
    }
  
  // set the default windowid 
  this->WindowId = this->NextWindowId;
  this->NextWindowId = (Window)NULL;

  // configure the window 
  this->WindowInitialize();
}

void vtkOpenGLOffscreenRenderWindow::SetPosition(int x,int y)
{
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::SetPosition\n");
  this->Position[0]=x;
  this->Position[1]=y;
  // JMS:  but there is nothing to remap here... 
  // just preventing some other parent class from doing that.
}

// Description:
// Specify the size of the rendering window.
void vtkOpenGLOffscreenRenderWindow::SetSize(int x,int y){
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::SetSize\n");
  if ((this->Size[0] != x)||(this->Size[1] != y)){
    this->Modified();
    this->Size[0] = x;
    this->Size[1] = y;
  }
  if(this->ContextId){ // window exists
    Destroy();
    WindowInitialize();
  }
  //JMS: need to figure out how to resize this
  // well, maybe not just yet...  Gotta fix the resizing
  //XResizeWindow(this->DisplayId,this->WindowId,x,y);
  //XSync(this->DisplayId,False);
}

int *vtkOpenGLOffscreenRenderWindow::GetSize(){
  offDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetSize() " << Size[0] << ":" << Size[1] << "\n");
  return this->Size;
}

int vtkOpenGLOffscreenRenderWindow::GetDesiredDepth(){
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetDesiredDepth\n");
  XVisualInfo *v;
  // get the default visual to use 
  v = this->GetDesiredVisualInfo();
  return v->depth;  
}



// Description:
// Get a visual from the windowing system.
Visual *vtkOpenGLOffscreenRenderWindow::GetDesiredVisual ()
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetDesiredVisual\n");
  XVisualInfo *v;
  // get the default visual to use 
  v = this->GetDesiredVisualInfo();
  return v->visual;  
}


// Description:
// Get a colormap from the windowing system.
Colormap vtkOpenGLOffscreenRenderWindow::GetDesiredColormap ()
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetDesiredColormap (JMS: This is *VERY* problematic for Pbuffers!!!!\n Find a way to avoid doing this\n");
  XVisualInfo *v;
  if (this->ColorMap) return this->ColorMap;
  // get the default visual to use 
  v = this->GetDesiredVisualInfo();
  this->ColorMap = XCreateColormap(this->DisplayId,
				   RootWindow( this->DisplayId, v->screen),
				   v->visual, AllocNone );
  return this->ColorMap;  
}

void vtkOpenGLOffscreenRenderWindow::PrintSelf(ostream& os, vtkIndent indent)
{
  this->vtkXRenderWindow::PrintSelf(os,indent);
  os << indent << "ContextId: " << this->ContextId << "\n";
  os << indent << "MultiSamples: " << this->MultiSamples << "\n";
}


unsigned char *vtkOpenGLOffscreenRenderWindow::GetPixelData(int x1, int y1, int x2, int y2, 
						int front)
{
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetPixelData\n");
  long     xloop,yloop;
  int     y_low, y_hi;
  int     x_low, x_hi;
  unsigned char   *buffer;
  unsigned char   *data = NULL;
  unsigned char   *p_data = NULL;

  // set the current window 
  if(this->ContextId && this->WindowId && this->DisplayId)
    glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
  
  buffer = new unsigned char [4*(abs(x2 - x1)+1)];
  data = new unsigned char[(abs(x2 - x1) + 1)*(abs(y2 - y1) + 1)*3];

  if (y1 < y2)
    {
      y_low = y1; 
      y_hi  = y2;
    }
  else
    {
      y_low = y2; 
      y_hi  = y1;
    }

  if (x1 < x2)
    {
      x_low = x1; 
      x_hi  = x2;
    }
  else
    {
      x_low = x2; 
      x_hi  = x1;
    }

  if (front)
    {
      glReadBuffer(GL_FRONT);
    }
  else
    {
      glReadBuffer(GL_BACK);
    }
  p_data = data;
  for (yloop = y_low; yloop <= y_hi; yloop++)
    {
      // read in a row of pixels 
      fbReadPixels(x_low,yloop,(x_hi-x_low+1),1, 
		   GL_RGBA, GL_UNSIGNED_BYTE, buffer);
      for (xloop = 0; xloop <= (abs(x2-x1)); xloop++)
	{
	  *p_data = buffer[xloop*4]; p_data++;
	  *p_data = buffer[xloop*4+1]; p_data++;
	  *p_data = buffer[xloop*4+2]; p_data++;
	}
    }
  
  delete [] buffer;

  return data;
}

void vtkOpenGLOffscreenRenderWindow::SetPixelData(int x1, int y1, int x2, int y2,
				      unsigned char *data, int front)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::SetPixelData\n");

  int     y_low, y_hi;
  int     x_low, x_hi;
  int     xloop,yloop;
  unsigned char   *buffer;
  unsigned char   *p_data = NULL;
  GrabFramebuffer();
  // set the current window 
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);

  if (front)
    {
      glDrawBuffer(GL_FRONT);
    }
  else
    {
      glDrawBuffer(GL_BACK);
    }

  buffer = new unsigned char [4*(abs(x2 - x1)+1)];

  if (y1 < y2)
    {
      y_low = y1; 
      y_hi  = y2;
    }
  else
    {
      y_low = y2; 
      y_hi  = y1;
    }
  
  if (x1 < x2)
    {
      x_low = x1; 
      x_hi  = x2;
    }
  else
    {
      x_low = x2; 
      x_hi  = x1;
    }
  
  // now write the binary info one row at a time 
  p_data = data;
  for (yloop = y_low; yloop <= y_hi; yloop++)
    {
      for (xloop = 0; xloop <= (abs(x2-x1)); xloop++)
	{
	  buffer[xloop*4] = *p_data; p_data++; 
	  buffer[xloop*4+1] = *p_data; p_data++;
	  buffer[xloop*4+2] = *p_data; p_data++;
	  buffer[xloop*4+3] = 0xff;
	}
      /* write out a row of pixels */
      glMatrixMode( GL_MODELVIEW );
      glPushMatrix();
      glLoadIdentity();
      glMatrixMode( GL_PROJECTION );
      glPushMatrix();
      glLoadIdentity();
      glRasterPos3f( (2.0 * (GLfloat)(x_low) / this->Size[0] - 1), 
		     (2.0 * (GLfloat)(yloop) / this->Size[1] - 1),
		     -1.0 );
      glMatrixMode( GL_MODELVIEW );
      glPopMatrix();
      glMatrixMode( GL_PROJECTION );
      glPopMatrix();

      glDrawPixels((x_hi-x_low+1),1, GL_RGBA, GL_UNSIGNED_BYTE, buffer);
    }
  
  delete [] buffer;
  ReleaseFramebuffer();
}

float *vtkOpenGLOffscreenRenderWindow::GetRGBAPixelData(int x1, int y1, int x2, int y2, int front)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetRGBAPixelData\n");

  int     y_low, y_hi;
  int     x_low, x_hi;
  int     width, height;
  float   *data = NULL;
  // set the current window 
  if(this->ContextId && this->WindowId && this->DisplayId)
    glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
  if (y1 < y2)
    {
      y_low = y1; 
      y_hi  = y2;
    }
  else
    {
      y_low = y2; 
      y_hi  = y1;
    }

  if (x1 < x2)
    {
      x_low = x1; 
      x_hi  = x2;
    }
  else
    {
      x_low = x2; 
      x_hi  = x1;
    }

  if (front)
    {
      glReadBuffer(GL_FRONT);
    }
  else
    {
      glReadBuffer(GL_BACK);
    }

  width  = abs(x_hi - x_low) + 1;
  height = abs(y_hi - y_low) + 1;

  data = new float[ (width*height*4) ];

  fbReadPixels( x_low, y_low, width, height, GL_RGBA, GL_FLOAT, data);

  return data;
}

void vtkOpenGLOffscreenRenderWindow::SetRGBAPixelData(int x1, int y1, int x2, int y2,
					  float *data, int front)
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::SetRGBAPixelData\n");

  int     y_low, y_hi;
  int     x_low, x_hi;
  int     width, height;
  // set the current window 
  if(this->ContextId)
    glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
  if (front)
    {
      glDrawBuffer(GL_FRONT);
    }
  else
    {
      glDrawBuffer(GL_BACK);
    }

  if (y1 < y2)
    {
      y_low = y1; 
      y_hi  = y2;
    }
  else
    {
      y_low = y2; 
      y_hi  = y1;
    }
  
  if (x1 < x2)
    {
      x_low = x1; 
      x_hi  = x2;
    }
  else
    {
      x_low = x2; 
      x_hi  = x1;
    }
  
  width  = abs(x_hi-x_low) + 1;
  height = abs(y_hi-y_low) + 1;

  /* write out a row of pixels */
  glMatrixMode( GL_MODELVIEW );
  glPushMatrix();
  glLoadIdentity();
  glMatrixMode( GL_PROJECTION );
  glPushMatrix();
  glLoadIdentity();
  glRasterPos3f( (2.0 * (GLfloat)(x_low) / this->Size[0] - 1), 
                 (2.0 * (GLfloat)(y_low) / this->Size[1] - 1),
		 -1.0 );
  glMatrixMode( GL_MODELVIEW );
  glPopMatrix();
  glMatrixMode( GL_PROJECTION );
  glPopMatrix();

  fbDrawPixels( width, height, GL_RGBA, GL_FLOAT, data);
}

float *vtkOpenGLOffscreenRenderWindow::GetZbufferData( int x1, int y1, int x2, int y2  )
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetZbufferData\n");

  int             y_low, y_hi;
  int             x_low, x_hi;
  int             width, height;
  float           *z_data = NULL;
  // set the current window 
  if(this->ContextId)
    this->MakeCurrent();
  
  if (y1 < y2)
    {
      y_low = y1; 
//      y_hi  = y2;
    }
  else
    {
      y_low = y2; 
//      y_hi  = y1;
    }

  if (x1 < x2)
    {
      x_low = x1; 
//      x_hi  = x2;
    }
  else
    {
      x_low = x2; 
//      x_hi  = x1;
    }

  width =  abs(x2 - x1)+1;
  height = abs(y2 - y1)+1;

  z_data = new float[width*height];

  fbReadPixels( x_low, y_low, 
		width, height,
		GL_DEPTH_COMPONENT, GL_FLOAT,
		z_data );

  return z_data;
}

void vtkOpenGLOffscreenRenderWindow::SetZbufferData( int x1, int y1, int x2, int y2,
					 float *buffer )
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::SetZbufferData\n");

  int             y_low, y_hi;
  int             x_low, x_hi;
  int             width, height;

  // set the current window 
  this->MakeCurrent();

  if (y1 < y2)
    {
      y_low = y1; 
//      y_hi  = y2;
    }
  else
    {
      y_low = y2; 
//      y_hi  = y1;
    }

  if (x1 < x2)
    {
      x_low = x1; 
//      x_hi  = x2;
    }
  else
    {
      x_low = x2; 
//      x_hi  = x1;
    }

  width =  abs(x2 - x1)+1;
  height = abs(y2 - y1)+1;

  glMatrixMode( GL_MODELVIEW );
  glPushMatrix();
  glLoadIdentity();
  glMatrixMode( GL_PROJECTION );
  glPushMatrix();
  glLoadIdentity();
  glRasterPos2f( 2.0 * (GLfloat)(x_low) / this->Size[0] - 1, 
                 2.0 * (GLfloat)(y_low) / this->Size[1] - 1);
  glMatrixMode( GL_MODELVIEW );
  glPopMatrix();
  glMatrixMode( GL_PROJECTION );
  glPopMatrix();

  glDrawPixels( width, height, GL_DEPTH_COMPONENT, GL_FLOAT, buffer);
}

void vtkOpenGLOffscreenRenderWindow::MakeCurrent()
{

  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::MakeCurrent\n");

  // set the current window 
  if(this->ContextId && this->WindowId && this->DisplayId)
  glXMakeCurrent(this->DisplayId,this->WindowId,this->ContextId);
}

// return the current framebuffer as a JPG image
XImage *vtkOpenGLOffscreenRenderWindow::GetImage()
{
  vtkDebugMacro(<< "vtkOpenGLOffscreenRenderWindow::GetImage\n");

  int width = ((this->Size[0] > 0) ? this->Size[0] : 300);
  int height = ((this->Size[1] > 0) ? this->Size[1] : 300);
  XImage *img = XGetImage(this->DisplayId,
			  this->pixmap,
			  0, 0, width, height, AllPlanes, XYPixmap);
  // return new dlImage(img);
  return img;
}

