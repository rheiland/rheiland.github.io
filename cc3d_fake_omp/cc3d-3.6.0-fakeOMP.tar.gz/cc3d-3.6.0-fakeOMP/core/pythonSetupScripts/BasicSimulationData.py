
import sys, os

class BasicSimulationData():
    def __init__(self):
        self.sim=None
        self.fieldDim=None
        self.numberOfSteps=0
        
        
        