# -*- coding: utf-8 -*-
import os, sys
import string



class CC3DResource:
    def __init__(self):
        self.path=""
        self.type=""
        self.module=""
        self.origin="" # e.g. serialized
        self.copy=True
    def __str__(self):
        return "ResourcePath: "+self.path+"\n"+"Type: "+self.type+"\n"+"Module: "+self.module+"\n"+"Origin: "+self.origin+"\n"
    def __repr__(self):
        return self.__str__()
        
    
class CC3DSimulationData:
    def __init__(self):
        self.pythonScript=""
        self.xmlScript=""
        self.pifFile=""
        
        self.pythonScriptResource=CC3DResource()
        self.xmlScriptResource=CC3DResource()
        self.pifFileResource=CC3DResource()
        
        
        self.resources={} # dictionary of resource files with description (types, plugin, etc)
        self.path="" # full path to project file
        self.basePath="" # full path to the directory of project file
        
        
        self.version="3.5.1"
        
    def __str__(self):
        return "CC3DSIMULATIONDATA: "+self.basePath+"\n"+"\tpython file: "+self.pythonScript+"\n"+"\txml file: "+self.xmlScript+"\n"+\
        "\tpifFile="+self.pifFile+"\n"+str(self.resources)
        
    def addNewResource(self,_fileName,_type):
        
        if _type=="XMLScript":
        
            self.xmlScript=os.path.abspath(_fileName)
            self.xmlScriptResource.path=self.xmlScript
            self.xmlScriptResource.type="XML"
            return 
        if _type=="PythonScript":
        
            self.pythonScript=os.path.abspath(_fileName)
            self.pythonScriptResource.path=self.pythonScript
            self.pythonScriptResource.type="Python"
            return 
            
        if _type=="PIFFile":        
            # we have to check if there is  PIF file assigned resource. If so we do not want to modify this resource, rather add another one as a generic type of resource
            if self.pifFileResource.path=='':
                self.pifFile=os.path.abspath(_fileName)
                self.pifFileResource.path=self.pifFile
                self.pifFileResource.type="PIFFile"
            # we will also add PIF File as generic resource
        
        # adding generic resource type - user specified        
        fullPath=os.path.abspath(_fileName)
        resource=CC3DResource()
        resource.path=fullPath
        resource.type=_type
        self.resources[fullPath]=resource
        
        print "self.resources=",self.resources
        
        return 
        
    def removeResource(self,_fileName):
        fileName=os.path.abspath(_fileName)
        
        # file name can be associated with many resources - we have to erase all such associations
        
        if fileName==self.xmlScript:
        
            self.xmlScript=""
            self.xmlScriptResource=CC3DResource()
            
        if fileName==self.pythonScript:
        
            self.pythonScript=""
            self.pythonScriptResource=CC3DResource()
            
        if fileName==self.pifFile:
        
            self.pifFile=""
            self.pifFileResource=CC3DResource()

            
        try:
            del self.resources[fileName]
        except LookupError,e:
            pass
            
        
        return 

            
class CC3DSimulationDataHandler:
    def __init__(self,_tabViewWidget):
        self.cc3dSimulationData=CC3DSimulationData()
        self.tabViewWidget=_tabViewWidget
        
        
    def copySimulationDataFiles(self,_dir):
        import shutil
        
        simulationPath = os.path.join(_dir,'Simulation')
        
        
        if not os.path.exists(simulationPath):
            
            
            os.mkdir(simulationPath)
            
        #copy project file        
        try:            
            shutil.copy(self.cc3dSimulationData.path,os.path.join(_dir,os.path.basename(self.cc3dSimulationData.path))) 
        except: # ignore any copy errors
            pass
        
        if self.cc3dSimulationData.pythonScript!="":
            shutil.copy(self.cc3dSimulationData.pythonScript,os.path.join(simulationPath,os.path.basename(self.cc3dSimulationData.pythonScript))) 
            
        if self.cc3dSimulationData.xmlScript!="":
            shutil.copy(self.cc3dSimulationData.xmlScript,os.path.join(simulationPath,os.path.basename(self.cc3dSimulationData.xmlScript))) 
        
        if self.cc3dSimulationData.pifFile!="":
            shutil.copy(self.cc3dSimulationData.pifFile,os.path.join(simulationPath,os.path.basename(self.cc3dSimulationData.pifFile))) 
        
        #copy resource files
        fileNames=self.cc3dSimulationData.resources.keys()
        
        for fileName in fileNames:            
            try:
                if self.cc3dSimulationData.resources[fileName].copy:    
                    shutil.copy(fileName,os.path.join(simulationPath,os.path.basename(fileName))) 
            except:
                #ignore any copy errors
                pass
    
    def readCC3DFileFormat(self,_fileName):        
        
        import XMLUtils
        xml2ObjConverter = XMLUtils.Xml2Obj()

        fileFullPath=os.path.abspath(_fileName)
        self.cc3dSimulationData.basePath=os.path.dirname(fileFullPath)
        
        self.cc3dSimulationData.path=fileFullPath
        
        bp=self.cc3dSimulationData.basePath
        
        root_element=xml2ObjConverter.Parse(fileFullPath) # this is simulation element
        
        
        if root_element.getFirstElement("XMLScript"):
            self.cc3dSimulationData.xmlScript=root_element.getFirstElement("XMLScript").getText()
            self.cc3dSimulationData.xmlScript=os.path.abspath(os.path.join(bp,self.cc3dSimulationData.xmlScript)) #normalizing path to xml script
            self.cc3dSimulationData.xmlScriptResource.path=self.cc3dSimulationData.xmlScript
            self.cc3dSimulationData.xmlScriptResource.type="XMLScript"
        if root_element.getFirstElement("PythonScript"):
            self.cc3dSimulationData.pythonScript=root_element.getFirstElement("PythonScript").getText()
            self.cc3dSimulationData.pythonScript=os.path.abspath(os.path.join(bp,self.cc3dSimulationData.pythonScript)) #normalizing path to python script
            self.cc3dSimulationData.pythonScriptResource.path=self.cc3dSimulationData.pythonScript
            self.cc3dSimulationData.pythonScriptResource.type="PythonScript"

        if root_element.getFirstElement("PIFFile"):
            self.cc3dSimulationData.pifFile=root_element.getFirstElement("PIFFile").getText()
            self.cc3dSimulationData.pifFile=os.path.abspath(os.path.join(bp,self.cc3dSimulationData.pifFile)) #normalizing path to python script
            self.cc3dSimulationData.pifFileResource.path=self.cc3dSimulationData.pifFile
            self.cc3dSimulationData.pifFileResource.type="PIFFile"

            
            
        
        resourceList=XMLUtils.CC3DXMLListPy(root_element.getElements("Resource"))
        for resourceElem in resourceList:
            
            cc3dResource=CC3DResource()
            
            cc3dResource.path=os.path.abspath(os.path.join(bp,resourceElem.getText()))
            
            
            if resourceElem.findAttribute("Type"):
                cc3dResource.type=resourceElem.getAttribute("Type")
            if resourceElem.findAttribute("Module"):
                cc3dResource.module=resourceElem.getAttribute("Module")
            if resourceElem.findAttribute("Origin"):
                cc3dResource.origin=resourceElem.getAttribute("Origin")
            if resourceElem.findAttribute("Copy"):
                copyAttr=resourceElem.getAttribute("Copy")
                if copyAttr.lower()=="no":
                    cc3dResource.copy=False

                    
                
            self.cc3dSimulationData.resources[cc3dResource.path]=cc3dResource
            
    def formatResourceElement(self,_resource,_elementName=""):
        
        elName=""
        
        if _elementName!="":
            elName=_elementName
        else:
            elName="Resource"
        
        attributeDict={}
        
        if _resource.type!="":
            attributeDict["Type"]=_resource.type
            
        if _resource.module!="":
            attributeDict["Module"]=_resource.module
        
        if _resource.origin!="":
            attributeDict["Origin"]=_resource.origin
            
        if not _resource.copy:
            attributeDict["Copy"]="No"
            
        
        return elName,attributeDict,self.findRelativePath(self.cc3dSimulationData.basePath,_resource.path)
    
    def writeCC3DFileFormat(self,_fileName):        
        from XMLUtils import ElementCC3D
        csd=self.cc3dSimulationData
        simulationElement=ElementCC3D("Simulation",{"version":csd.version})
        
        if csd.xmlScriptResource.path!="":
            elName,attributeDict,path = self.formatResourceElement(csd.xmlScriptResource,"XMLScript")
            simulationElement.ElementCC3D(elName,attributeDict,path)
            
        if csd.pythonScriptResource.path!="":
            elName,attributeDict,path = self.formatResourceElement(csd.pythonScriptResource,"PythonScript")
            simulationElement.ElementCC3D(elName,attributeDict,path)
            
        if csd.pifFileResource.path!="":
            elName,attributeDict,path = self.formatResourceElement(csd.pifFileResource,"PIFFile")
            simulationElement.ElementCC3D(elName,attributeDict,path)
        
        resourcesDict={}    
        #storing resources in a dictionary using resource type as a key   
        for resourceKey, resource in csd.resources.iteritems():
            if resource.type=="PIFFile" and csd.pifFileResource.path==resource.path:
                print "IGNORING RESOURCE =",resource.path
                continue
            
            try:
                resourcesDict[resource.type].append(resource)
            except LookupError,e:
                resourcesDict[resource.type]=[resource]
                
            
            # elName,attributeDict,path = self.formatResourceElement(resource)
            # simulationElement.ElementCC3D(elName,attributeDict,path)

        #sort resources according to path name
        for resourceType,resourceList in resourcesDict.iteritems():
            
            resourceList = sorted(resourceList, key=lambda x: x.path)
            
            # after sorting have to reinsert list into dictionary to have it available later
            resourcesDict[resourceType]=resourceList
            
            

        sortedResourceTypeNames=resourcesDict.keys()
        sortedResourceTypeNames.sort()
        
        for resourceType in sortedResourceTypeNames:
            for resource in resourcesDict[resourceType]:
                elName,attributeDict,path = self.formatResourceElement(resource)
                simulationElement.ElementCC3D(elName,attributeDict,path)
                
        
        simulationElement.CC3DXMLElement.saveXML(str(_fileName))   
    
    # Based on code by  Cimarron Taylor
    # Date: July 6, 2003
    
    def findRelativePathSegments(self,basePath,p, rest=[]):
    
        """
            This function finds relative path segments of path p with respect to base path    
            It returns list of relative path segments and flag whether operation succeeded or not    
        """
        
        h,t = os.path.split(p)
        pathMatch=False
        if h==basePath:
            pathMatch=True
            return [t]+rest,pathMatch
        print "(h,t,pathMatch)=",(h,t,pathMatch)
        if len(h) < 1: return [t]+rest,pathMatch
        if len(t) < 1: return [h]+rest,pathMatch
        return self.findRelativePathSegments(basePath,h,[t]+rest)
        
    def findRelativePath(self,basePath,p):
        relativePathSegments,pathMatch=self.findRelativePathSegments(basePath,p)
        if pathMatch:
            relativePath=""
            for i in range(len(relativePathSegments)):
                segment=relativePathSegments[i]
                relativePath+=segment
                if i !=len(relativePathSegments)-1:
                    relativePath+="/" # we use unix style separators - they work on all (3) platforms
            return relativePath
        else:
            return p
