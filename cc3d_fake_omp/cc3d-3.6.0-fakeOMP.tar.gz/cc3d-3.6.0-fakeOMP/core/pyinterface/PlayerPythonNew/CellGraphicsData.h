#ifndef CELLGRAPHICSDATA_H
#define CELLGRAPHICSDATA_H

class CellGraphicsData{

   public:
      CellGraphicsData():type(0),id(0)
      {}
      unsigned short type;
      long id;

};



#endif
