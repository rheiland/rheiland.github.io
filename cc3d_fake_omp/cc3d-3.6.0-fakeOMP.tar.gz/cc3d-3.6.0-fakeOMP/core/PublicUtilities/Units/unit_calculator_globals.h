#ifndef unit_calculator_globals_h
#define unit_calculator_globals_h
struct unit_t_list_t allocatedUnitList;
struct unit_t_list_t * tail;
int allocatedUnitNumber;
#endif

