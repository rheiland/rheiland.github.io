#ifndef unitParserException_h
#define unitParserException_h
//#include <string>

//#ifdef __cplusplus
//extern "C" {
//#endif
#ifdef __cplusplus
extern "C"
#endif
void throwParserException(char * _exceptionText);	
 
/* #ifdef __cplusplus
}
#endif*/

#endif 