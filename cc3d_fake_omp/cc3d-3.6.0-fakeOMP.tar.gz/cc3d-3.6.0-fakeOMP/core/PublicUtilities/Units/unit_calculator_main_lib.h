#ifndef unit_calculator_main_lib_h
#define unit_calculator_main_lib_h


struct unit_t parseUnit(char * _unitStr);
 

#endif 