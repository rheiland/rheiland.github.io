"""pyQt widgets for VTK."""

# __all__ = ['QVTKRenderWidget', 'QVTKRenderWindowInteractor']
__all__ = ['QVTKRenderWidget']