class DrawingParameters:
    def __init__(self):
        self.plane="XY"
        self.planePosition=0
        self.bsd=None # basic simulationdata
        self.fieldName="Cell_Field"
        self.fieldType="CellField"
        
        