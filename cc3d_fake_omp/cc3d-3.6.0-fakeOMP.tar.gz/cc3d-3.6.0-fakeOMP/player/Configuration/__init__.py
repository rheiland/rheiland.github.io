from PyQt4.QtGui import *
from PyQt4.QtCore import *

#from Messaging import stdMsg, dbgMsg,pd, errMsg, setDebugging
#setDebugging(1)

from os import environ,path
import os

(ORGANIZATION, APPLICATION) = ("Biocomplexity", "PyQtPlayerNew")
LATTICE_TYPES = {"Square":1,"Hexagonal":2}

maxNumberOfRecentFiles=5

MODULENAME = '------- player/Configuration/__init__.py: '

#def dbgMsg(a1,a2=0,a3=0,a4=0):
#        print a1,
#        if a2: print a2,
#        if a3: print a3,
#        if a4: print a4,
#        print
        
class Configuration():

#    LATTICE_TYPES = {"Square":1,"Hexagonal":2}

#    def __init__(self):

#        LATTICE_TYPES = {"Square":1,"Hexagonal":2}
        #default settings
        defaultConfigs={}
        
        # Make thins a bit simpler by create 'type' lists
        paramTypeBool = []
        paramTypeInt = []
        paramTypeDouble = []
        paramTypeString = []
        paramTypeColor = []
        
#        dbgMsg( MODULENAME, ' >>>>>>>>>>>>>>   __init__  <<<<<<<<<<<<<<<<<<')
#        print MODULENAME, ' >>>>>>>>>>>>>>   __init__  <<<<<<<<<<<<<<<<<<'
       
        defaultConfigs["TabIndex"] = 0; paramTypeInt.append("TabIndex")
        defaultConfigs["RecentFile"] = QString(""); paramTypeString.append("RecentFile")
        defaultConfigs["RecentSimulations"] = []
       
       # Output tab
        defaultConfigs["ScreenUpdateFrequency"] = 10; paramTypeInt.append("ScreenUpdateFrequency")
        defaultConfigs["ImageOutputOn"] = True; paramTypeBool.append("ImageOutputOn")
        defaultConfigs["SaveImageFrequency"] = 1; paramTypeInt.append("SaveImageFrequency")
        defaultConfigs["LatticeOutputOn"] = False; paramTypeBool.append("LatticeOutputOn")
        defaultConfigs["SaveLatticeFrequency"] = 2; paramTypeInt.append("SaveLatticeFrequency")
        defaultConfigs["UseInternalConsole"] = False; paramTypeBool.append("UseInternalConsole")
        defaultConfigs["ClosePlayerAfterSimulationDone"] = False; paramTypeBool.append("ClosePlayerAfterSimulationDone")
        # defaultConfigs["ProjectLocation"] = QString(os.path.join(os.path.expanduser('~'),'CC3DProjects')); paramTypeString.append("ProjectLocation")
        defaultConfigs["ProjectLocation"] = QString(os.path.join(environ['PREFIX_CC3D'],'Demos')); paramTypeString.append("ProjectLocation")
        
        defaultConfigs["OutputLocation"] = QString(os.path.join(os.path.expanduser('~'),'CC3DWorkspace')); paramTypeString.append("OutputLocation")
        
        
        # Cell Type tab
        defaultConfigs["TypeColorMap"] = { 0:QColor(Qt.black), 1:QColor(Qt.green), 2:QColor(Qt.blue),
            3: QColor(Qt.red),
            4: QColor(Qt.darkYellow),
            5: QColor(Qt.lightGray),
            6: QColor(Qt.magenta),
            7: QColor(Qt.darkBlue),
            8: QColor(Qt.cyan),
            9: QColor(Qt.darkGreen),
            10: QColor(Qt.white)
            }
        defaultConfigs["BorderColor"] = QColor(Qt.yellow); paramTypeColor.append("BorderColor")
        defaultConfigs["ClusterBorderColor"] = QColor(Qt.blue); paramTypeColor.append("ClusterBorderColor")
        defaultConfigs["ContourColor"] = QColor(Qt.white); paramTypeColor.append("ContourColor")
        defaultConfigs["BrushColor"] = QColor(Qt.white); paramTypeColor.append("BrushColor")
        defaultConfigs["PenColor"] = QColor(Qt.black); paramTypeColor.append("PenColor")


        # Colormap tab
        defaultConfigs["MinRange"] = 0.0; paramTypeDouble.append("MinRange")
        defaultConfigs["MinRangeFixed"] = False; paramTypeBool.append("MinRangeFixed")
        defaultConfigs["MaxRange"] = 1.0; paramTypeDouble.append("MaxRange")
        defaultConfigs["MaxRangeFixed"] = False; paramTypeBool.append("MaxRangeFixed")
        
        defaultConfigs["NumberOfLegendBoxes"] = 6; paramTypeInt.append("NumberOfLegendBoxes")
        defaultConfigs["NumberAccuracy"] = 2; paramTypeInt.append("NumberAccuracy")
        defaultConfigs["LegendEnable"] = True; paramTypeBool.append("LegendEnable")
        
        defaultConfigs["NumberOfContourLines"] = 5; paramTypeInt.append("NumberOfContourLines")
        defaultConfigs["ContoursOn"] = False; paramTypeBool.append("ContoursOn")
        
        
        # Vectors tab
        defaultConfigs["MinMagnitude"] = 0.0; paramTypeDouble.append("MinMagnitude")
        defaultConfigs["MinMagnitudeFixed"] = False; paramTypeBool.append("MinMagnitudeFixed")
        defaultConfigs["MaxMagnitude"] = 1.0; paramTypeDouble.append("MaxMagnitude")
        defaultConfigs["MaxMagnitudeFixed"] = False; paramTypeBool.append("MaxMagnitudeFixed")
        
        defaultConfigs["NumberOfLegendBoxesVector"] = 6; paramTypeInt.append("NumberOfLegendBoxesVector")
        defaultConfigs["NumberAccuracyVector"] = 2; paramTypeInt.append("NumberAccuracyVector")
        defaultConfigs["LegendEnableVector"] = True; paramTypeBool.append("LegendEnableVector")
        
        defaultConfigs["ScaleArrowsOn"] = False; paramTypeBool.append("ScaleArrowsOn")
        defaultConfigs["ArrowColor"] = QColor(Qt.white); paramTypeColor.append("ArrowColor")
        defaultConfigs["ArrowLength"] = 1.0; paramTypeDouble.append("ArrowLength")
        defaultConfigs["FixedArrowColorOn"] = False; paramTypeBool.append("FixedArrowColorOn")
        
        defaultConfigs["OverlayVectorsOn"] = False; paramTypeBool.append("OverlayVectorsOn")
        
        
        # 3D tab
        defaultConfigs["Types3DInvisible"] = QString("0"); paramTypeString.append("Types3DInvisible")
        
        
        #------------- prefs from menu items, etc. (NOT in Preferences dialog) -----------
        # player layout
        defaultConfigs["PlayerSizes"] = QByteArray()
        defaultConfigs["MainWindowSize"] = QSize(900, 650)  # --> VTK winsize of (617, 366)
#        defaultConfigs["MainWindowSize"] = QSize(1083, 884)  # --> VTK winsize of (800, 600); experiment for Rountree/EPA
        defaultConfigs["MainWindowPosition"] = QPoint(0,0)
        
        # visual
        defaultConfigs["Projection"] = 0; paramTypeInt.append("Projection")
        defaultConfigs["CellsOn"] = True; paramTypeBool.append("CellsOn")
        defaultConfigs["CellBordersOn"] = True; paramTypeBool.append("CellBordersOn")
        defaultConfigs["ClusterBordersOn"] = False; paramTypeBool.append("ClusterBordersOn")
        defaultConfigs["CellGlyphsOn"] = False; paramTypeBool.append("CellGlyphsOn")
        defaultConfigs["FPPLinksOn"] = False; paramTypeBool.append("FPPLinksOn")
        defaultConfigs["FPPLinksColorOn"] = False; paramTypeBool.append("FPPLinksColorOn")
        defaultConfigs["ContoursOn"] = True; paramTypeBool.append("ContoursOn")
        defaultConfigs["ConcentrationLimitsOn"] = True; paramTypeBool.append("ConcentrationLimitsOn")
        defaultConfigs["CC3DOutputOn"] = True; paramTypeBool.append("CC3DOutputOn")
        defaultConfigs["ZoomFactor"] = 1.0; paramTypeDouble.append("ZoomFactor")
        
        
#        modifiedKeyboardShortcuts={} # dictionary actionName->shortcut for modified keyboard shortcuts - only reassigned shortcuts are stored
        
        settings = QSettings(QSettings.NativeFormat, QSettings.UserScope, ORGANIZATION, APPLICATION)
#        initSyncSettings()
#        updatedConfigs = {}
        
        
#def getLatticeTypes(:
#        return LATTICE_TYPES.keys()
    
#def getLatticeTypeVal(_key):
#        dbgMsg MODULENAME, '  ------- getLatticeTypeVal'
##        if _key in ["Square","Hexagonal"]:
#        return LATTICE_TYPES[_key]
        

def getVersion():
    import Version
    return Version.getVersionAsString()
    
def getSetting(_key):
#        dbgMsg MODULENAME, '  ------- getSetting, _key = ', _key
        if _key in Configuration.paramTypeBool:
            val = Configuration.settings.value(_key)
#            dbgMsg MODULENAME, ' _key,val, val.isValid=',_key,val,val.isValid()
            if val.isValid():
                return val.toBool()
            else:
                return Configuration.defaultConfigs[_key]
        
        elif _key in Configuration.paramTypeString:
            val = Configuration.settings.value(_key)
            if val.isValid():
                return val.toString()
            else:
                return Configuration.defaultConfigs[_key]
        
        elif _key in Configuration.paramTypeInt:   # ["ScreenUpdateFrequency","SaveImageFrequency"]:
            val = Configuration.settings.value(_key)
            if val.isValid():
                return val.toInt()[0] # toInt returns tuple: first = integer; second = flag
            else:
                return Configuration.defaultConfigs[_key]
            
        elif _key in Configuration.paramTypeDouble:
            val = Configuration.settings.value(_key)
            if val.isValid():
                return val.toDouble()[0]
            else:
                return Configuration.defaultConfigs[_key]
            
        elif _key in Configuration.paramTypeColor:
            val = Configuration.settings.value(_key)
            if val.isValid():
                return QColor(val.toString())
            else:
                return Configuration.defaultConfigs[_key]
        
        elif _key in ["RecentSimulations"]:
            val = Configuration.settings.value(_key)
            if val.isValid():
                recentSimulationsList = val.toStringList()
                recentSimulations=[]
                for i in range(recentSimulationsList.count()):
                    recentSimulations.append(str(recentSimulationsList[i]))
                return recentSimulations
            else:
                return Configuration.defaultConfigs[key]
                                         
        elif _key in ["MainWindowSize","InitialSize"]: # QSize values
            val = Configuration.settings.value(_key)
            if val.isValid():
                return val.toSize() 
            else:
                return Configuration.defaultConfigs[_key]                             

        elif _key in ["MainWindowPosition","InitialPosition"]: # QPoint values
            val = Configuration.settings.value(_key)
            if val.isValid():
                pval = val.toPoint()
#                print MODULENAME, 'getSetting(), val isValid, type(pval), pval=',type(pval), pval
                return val.toPoint() 
            else:
                return Configuration.defaultConfigs[_key]
            
        elif _key in ["PlayerSizes"]:
            val = Configuration.settings.value(_key)
            if val.isValid():
                return val.toByteArray() 
            else:
                return Configuration.defaultConfigs[_key]
            
        elif _key in ["TypeColorMap"]:
#            print MODULENAME, '  ------- getSetting, _key = ', _key
            colorMapStr = Configuration.settings.value(_key)
    
            if colorMapStr.isValid():
                colorList = colorMapStr.toStringList()
                if colorList.count() == 0:
                    # colorList = prefClass.colorsDefaults[key]
                    colorMapPy = Configuration.defaultConfigs["TypeColorMap"]
                    colorList = QStringList()
                    
                    for _key in colorMapPy.keys():
                        colorList.append(str(_key))
                        colorList.append(colorMapPy[_key].name())
                        
                import sys        
                
                # Do color dictionary                
                colorDict = {}
                k = 0
                for i in range(colorList.count()/2):
                    key, ok  = colorList[k].toInt()
                    k       += 1
                    value   = colorList[k]
                    k       += 1
                    if ok:
                        colorDict[key]  = QColor(value)
#                print MODULENAME, '  ------- return colorDict '
                return colorDict
            else:
#                print MODULENAME, '  ------- return default typecolormap!! '
                return Configuration.defaultConfigs["TypeColorMap"]
            
                
#        elif _key in ["ListOfOpenFiles","FRFindHistory","FRReplaceHistory","FRFiltersHistory","FRDirectoryHistory","KeyboardShortcuts"]: # QStringList values
#            val = Configuration.settings.value(_key)
#            if val.isValid():
#                return val.toStringList() 
#            else:
#                return defaultConfigs[_key]

        else:
            print MODULENAME,' getSetting(), bogus key =',_key
            raise # exception

def addNewSimulation(recentSimulationsList,value):
#    print MODULENAME,'  addNewSimulation:  value=',value
#    print MODULENAME,'  addNewSimulation:  str(value)=',str(value)
#    dbgMsg( MODULENAME,'  addNewSimulation:  str(value)=',str(value) )
#    print MODULENAME,'  addNewSimulation:  value.toString()=',value.toString()
    if str(value)=="":
        return False
    elementExists=False
    idxFound = -1
    for idx in range(recentSimulationsList.count()):
#        print "recentSimulationsList[idx]=",recentSimulationsList[idx]
#        print "value=",value
        if str(recentSimulationsList[idx])==value:
            elementExists=True
            idxFound=idx
            break
    if not elementExists:    
#        print '  --- addNewSimulation (dne):  str(value)=',value
        recentSimulationsList.prepend(str(value))
        return True
    else:
        # moving existing item to the beginning of the list
        fileNameTmp = recentSimulationsList[idxFound]
#        print '  --- addNewSimulation:  fileNameTmp=',fileNameTmp
        recentSimulationsList.removeAt(idxFound)
        recentSimulationsList.prepend(fileNameTmp)
        return False
                
def setSetting(_key,_value):  # rf. ConfigurationDialog.py, updatePreferences()
#        print MODULENAME, '  --- setSetting, _key,_value=',_key,_value
        if _key in Configuration.paramTypeBool:
            Configuration.settings.setValue(_key,QVariant(_value))
        elif _key in Configuration.paramTypeInt:
            Configuration.settings.setValue(_key,_value)
        elif _key in Configuration.paramTypeDouble:
#            print MODULENAME,' setSetting: _key,_value=',_key,_value
            Configuration.settings.setValue(_key,QVariant(_value))
        elif _key in Configuration.paramTypeString:
#            print MODULENAME,' setSetting: ',_key,_value
            Configuration.settings.setValue(_key,_value)
        elif _key in Configuration.paramTypeColor:
            Configuration.settings.setValue(_key,_value)
        
        elif _key in ["RecentSimulations"]:
#            print MODULENAME,' setSetting:RecentSimulations:  _key,_value= ',_key,_value
            recentSimulationsVariant = Configuration.settings.value("RecentSimulations")
            if recentSimulationsVariant.isValid():
                recentSimulationsList = recentSimulationsVariant.toStringList()
#                print "setSetting:  recentSimulationsList.count()=",recentSimulationsList.count()
#                print "setSetting: maxNumberOfRecentFiles=",maxNumberOfRecentFiles
                if recentSimulationsList.count() >= maxNumberOfRecentFiles:    
                    addingSuccessful = addNewSimulation(recentSimulationsList,_value)
                    if addingSuccessful:
                        recentSimulationsList.removeAt(recentSimulationsList.count()-1)
                else:
#                    print 'setSetting:    addNewSim... _value = ',_value
#                    print '    addNewSim... _value.toString() = ',_value.toString()
                    addingSuccessful = addNewSimulation(recentSimulationsList,_value)
        
                Configuration.settings.setValue("RecentSimulations", QVariant(recentSimulationsList))
                # for idx in range(recentSimulationsList.count()):
                    # print "READ EXISTING FILE  =",idx," file name=", recentSimulationsList[idx]
            else:
                print "       recentSimulationsVariant is NOT valid:  _key,_value=",_key,_value
                recentSimulationsList = QStringList()
#                recentSimulationsList.prepend(QString(_value))
                Configuration.settings.setValue("RecentSimulations", QVariant(recentSimulationsList))
            
        # string
        elif _key in ["BaseFontName","BaseFontSize"]:
            Configuration.settings.setValue(_key,QVariant(_value))
        
        # QSize, QPoint,QStringList , QString
        elif _key in ["InitialSize","InitialPosition","KeyboardShortcuts"]:
            Configuration.settings.setValue(_key,QVariant(_value))
            
        elif _key in ["PlayerSizes","MainWindowSize","MainWindowPosition"]:
            Configuration.settings.setValue(_key, QVariant(_value))
            
        elif _key in ["TypeColorMap"]:
#            print MODULENAME,' setSetting:TypeColorMap= '
#            print 'type(_value) = ',type(_value)   # <type 'dict'> or <class 'PyQt4.QtCore.QVariant'>
#            print '_value =',_value
            penColorList = QStringList()
            
            if type(_value) == dict:
#                print 'yes, _value is a dict'
                for i in range(len(_value)):
                    keys = _value.keys()
                    penColorList.append(str(keys[i]))
                    penColorList.append(str(_value[keys[i]].name()))
#                    print i,str(keys[i]),str(_value[keys[i]].name())
                    
                Configuration.settings.setValue(_key, QVariant(penColorList))
 
            # rwh: I confess I'm confused, but it seems this block is not even needed
#            else:            # QVariant
#            dbgMsg ('     >>>> TODO! setSetting TypeColorMap')
#            for i in range(len(_value)):
#            for i in range(len(QVariant(_value))):
#            keys = Configuration.defaultConfigs["TypeColorMap"].keys()
#            print MODULENAME,' TypeColorMap keys= ',keys
#            for i in range(len(Configuration.defaultConfigs["TypeColorMap"])):
#            for i in range(len(dict(_value))):  #  _value is a dict

#                clist = _value.toStringList()
#                numColors = len(clist)
#                print 'numColors = ',numColors
#                for i in range(len(_value.toStringList())):  #  _value is a QVariant
#                    print i,clist[i]

#                keys = _value.keys()
#                penColorList.append(str(keys[i]))
#                penColorList.append(str(_value[keys[i]].name()))
                
#            Configuration.settings.setValue(_key, QVariant(penColorList))

        
        else:
#            dbgMsg("Wrong format of configuration option:",_key,":",_value)
            print MODULENAME,"Wrong format of configuration option:" + str(_key) + ":" + str(_value)
            
#    def setKeyboardShortcut(_actionName,_keyboardshortcut):
#        modifiedKeyboardShortcuts[_actionName]=_keyboardshortcut    
#        
#    def keyboardShortcuts(:
#        return modifiedKeyboardShortcuts
#    
#    def prepareKeyboardShortcutsForStorage(:
#        modifiedKeyboardShortcutsStringList=QStringList()
#        for actionName in modifiedKeyboardShortcuts.keys():
#            modifiedKeyboardShortcutsStringList.append(actionName)
#            modifiedKeyboardShortcutsStringList.append(self.modifiedKeyboardShortcuts[actionName])
#            
#        setSetting("KeyboardShortcuts",self.modifiedKeyboardShortcutsStringList)    

def getPlayerParams():
#    print MODULENAME,' getPlayerParams() called'
    playerParamsDict = {}
    for key in Configuration.defaultConfigs.keys():
        if key not in ["PlayerSizes"]:
            playerParamsDict[key] = getSetting(key)

#        dbgMsg 'playerParamsDict=',playerParamsDict
    return playerParamsDict
    
def syncPreferences():
#    print MODULENAME,'----------- syncPreferences -------------'
    for key in Configuration.defaultConfigs.keys():
        val = Configuration.settings.value(key)
#        print 'key: type(key,val,Configuration.defaultConfigs[key] = ',key,type(key),type(val),type(Configuration.defaultConfigs[key])
        if val.isValid():  # if setting exists (is valid) in the .plist
            if not key == 'RecentSimulations':
                setSetting(key,val)
        else:
#            if key=="TypeColorMap":
#                setSetting(key,QVariant(Configuration.defaultConfigs[key]))
#            else:
            setSetting(key,Configuration.defaultConfigs[key])
            
#    print MODULENAME,'----------- leaving syncPreferences -------------'
                
        # initialize modifiedKeyboardShortcuts
#        modifiedKeyboardShortcutsStringList=self.setting("KeyboardShortcuts")
#        for i in range(0,modifiedKeyboardShortcutsStringList.count(),2): 
#            modifiedKeyboardShortcuts[str(self.modifiedKeyboardShortcutsStringList[i])]=str(self.modifiedKeyboardShortcutsStringList[i+1])        

                
#    def syncPreferences(prefClass = Configs):
##    Module function to sync the preferences to disk.
##    In addition to syncing, the central configuration store is reinitialized as well.
##    @param prefClass preferences class used as the storage area
#        dbgMsg MODULENAME," syncPreferences(), WILL WRITE SETTINGS"
#    # import time
#    # time.sleep(5)
#    
#        prefClass.settings.setValue("General/Configured", QVariant(1))
#        initPreferences()
                
        # initialize modifiedKeyboardShortcuts
#        modifiedKeyboardShortcutsStringList=self.setting("KeyboardShortcuts")
#        for i in range(0,modifiedKeyboardShortcutsStringList.count(),2): 
#            modifiedKeyboardShortcuts[str(self.modifiedKeyboardShortcutsStringList[i])] = 
#                  str(modifiedKeyboardShortcutsStringList[i+1])
        
        
#syncPreferences()   # don't think needed; rf. UI/
