versionMajor=3
versionMinor=6
versionBuild=0

def getVersionAsString():
    return str(versionMajor)+"."+str(versionMinor)+"."+str(versionBuild)
    
def getVersionMajor():
    return versionMajor
    
def getVersionMinor():
    return versionMinor

def getVersionBuild():
    return versionBuild
    
