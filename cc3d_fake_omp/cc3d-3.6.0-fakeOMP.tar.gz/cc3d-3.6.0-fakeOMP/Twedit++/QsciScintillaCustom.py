from PyQt4.QtCore import *
from PyQt4.QtGui import *

from PyQt4.Qsci import *

from PyQt4 import QtCore, QtGui

# have to implement custom class for QSciScintilla to handle properly wheel even with and without ctrl pressed 
class QsciScintillaCustom(QsciScintilla):
    def __init__(self,parent=None):
        super(QsciScintillaCustom,self).__init__(parent)
        
    def wheelEvent(self,event):
        if qApp.keyboardModifiers()==Qt.ControlModifier:
            # Forwarding wheel event to editor windowwheelEvent
            event.ignore()    
             
        else:
            # # calling wheelEvent from base class - regular scrolling
            super(QsciScintillaCustom,self).wheelEvent(event)