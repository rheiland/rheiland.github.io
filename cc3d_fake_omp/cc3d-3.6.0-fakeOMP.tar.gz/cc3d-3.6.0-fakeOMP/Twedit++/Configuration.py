from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.Qsci import *

from PyQt4 import QtCore, QtGui
from Messaging import stdMsg, dbgMsg, errMsg, setDebugging
(ORGANIZATION, APPLICATION) = ("SwatInternationalProductions", "CC3DTwedit++")

class Configuration:
    def __init__(self):

        #default settings
        self.defaultConfigs={}
        self.defaultConfigs["TabSpaces"]=4
        self.defaultConfigs["UseTabSpaces"]=True
        self.defaultConfigs["DisplayLineNumbers"]=True
        self.defaultConfigs["FoldText"]=True
        self.defaultConfigs["TabGuidelines"]=True
        self.defaultConfigs["DisplayWhitespace"]=False
        self.defaultConfigs["DisplayEOL"]=False
        self.defaultConfigs["WrapLines"]=False
        self.defaultConfigs["ShowWrapSymbol"]=False
        self.defaultConfigs["DontShowWrapLinesWarning"]=False
        self.defaultConfigs["RestoreTabsOnStartup"]=True
        self.defaultConfigs["EnableAutocompletion"]=False
        self.defaultConfigs["AutocompletionThreshold"]=2
        self.defaultConfigs["InitialSize"]=QSize(600,600)
        self.defaultConfigs["InitialPosition"]=QPoint(0,0)
        self.defaultConfigs["ListOfOpenFiles"]=QStringList()
        self.defaultConfigs["FRFindHistory"]=QStringList() #FR stands for Find & Replace
        self.defaultConfigs["FRReplaceHistory"]=QStringList()
        self.defaultConfigs["FRFiltersHistory"]=QStringList()
        self.defaultConfigs["FRDirectoryHistory"]=QStringList()
        self.defaultConfigs["FRInSelection"]=False
        self.defaultConfigs["FRInAllSubfolders"]=False
        self.defaultConfigs["FRSyntaxIndex"]=0
        self.defaultConfigs["FRTransparencyEnable"]=True
        self.defaultConfigs["FROnLosingFocus"]=True        
        self.defaultConfigs["FRAlways"]=False
        self.defaultConfigs["FROpacity"]=75
        self.defaultConfigs["ZoomRange"]=0
        self.defaultConfigs["ZoomRangeFindDisplayWidget"]=0
        self.defaultConfigs["CurrentTabIndex"]=-1 # index of the current tab  - 1 means we should make last open tab current
        self.defaultConfigs["KeyboardShortcuts"]=QStringList()
        self.defaultConfigs["BaseFontName"]=QString("Courier New")
        self.defaultConfigs["BaseFontSize"]=QString("10")
        
        self.modifiedKeyboardShortcuts={} # dictionary actionName->shortcut for modified keyboard shortcuts - only reassinged shortcuts are stored
        
        self.settings = QSettings(QSettings.NativeFormat, QSettings.UserScope, ORGANIZATION, APPLICATION)
        self.initSyncSettings()
        self.updatedConfigs={}
        

        

        
    # def configuration(self,_key):
        # return self.configs[_key]

    def setting(self,_key):
        if _key in ["UseTabSpaces","DisplayLineNumbers","FoldText","TabGuidelines","DisplayWhitespace","DisplayEOL","WrapLines","ShowWrapSymbol","DontShowWrapLinesWarning",\
        "RestoreTabsOnStartup","EnableAutocompletion","FRInSelection","FRInAllSubfolders","FRTransparencyEnable","FROnLosingFocus","FRAlways"]: # Boolean values
            val = self.settings.value(_key)
            if val.isValid():
                return val.toBool()
            else:
                return self.defaultConfigs[_key]
                
        elif _key in ["BaseFontSize","BaseFontName"]:
            val = self.settings.value(_key)
            if val.isValid():
                return val.toString()
            else:
                return self.defaultConfigs[_key]
            
        elif _key in ["TabSpaces","ZoomRange","ZoomRangeFindDisplayWidget","AutocompletionThreshold","FRSyntaxIndex","FROpacity","CurrentTabIndex"]: # integer values
            val = self.settings.value(_key)
            if val.isValid():
                return val.toInt()[0] # toInt returns tuple and first element of if is the integer the second one is flag
            else:
                return self.defaultConfigs[_key]
                
        elif _key in ["InitialSize"]: # QSize values
            val = self.settings.value(_key)
            if val.isValid():
                return val.toSize() 
            else:
                return self.defaultConfigs[_key]                             

        elif _key in ["InitialPosition"]: # QPoint values
            val = self.settings.value(_key)
            if val.isValid():
                return val.toPoint() 
            else:
                return self.defaultConfigs[_key]
                
        elif _key in ["ListOfOpenFiles","FRFindHistory","FRReplaceHistory","FRFiltersHistory","FRDirectoryHistory","KeyboardShortcuts"]: # QStringList values
            val = self.settings.value(_key)
            if val.isValid():
                return val.toStringList() 
            else:
                return self.defaultConfigs[_key]

                
    def setSetting(self,_key,_value):
        if _key in ["UseTabSpaces","DisplayLineNumbers","FoldText","TabGuidelines","DisplayWhitespace","DisplayEOL","WrapLines","ShowWrapSymbol","DontShowWrapLinesWarning",\
        "RestoreTabsOnStartup","EnableAutocompletion","FRInSelection","FRInAllSubfolders","FRTransparencyEnable","FROnLosingFocus","FRAlways"]: # Boolean values
            self.settings.setValue(_key,QVariant(_value))
            
        elif _key in ["TabSpaces","ZoomRange","ZoomRangeFindDisplayWidget","AutocompletionThreshold","FRSyntaxIndex","FROpacity","CurrentTabIndex"]: # integer values
            self.settings.setValue(_key,_value)

            
        elif _key in ["BaseFontName","BaseFontSize"]: # string values
            self.settings.setValue(_key,QVariant(_value))
            
        elif _key in ["InitialSize","InitialPosition","ListOfOpenFiles","FRSyntax","FRFindHistory","FRReplaceHistory","FRFiltersHistory","FRDirectoryHistory","KeyboardShortcuts"]: # QSize, QPoint,QStringList , QString values
            self.settings.setValue(_key,QVariant(_value))
        else:
            dbgMsg("Wrong format of configuration option:",_key,":",_value)
            
    def setKeyboardShortcut(self,_actionName,_keyboardshortcut):
        self.modifiedKeyboardShortcuts[_actionName]=_keyboardshortcut    
        
    def keyboardShortcuts(self):
        return self.modifiedKeyboardShortcuts
    
    def prepareKeyboardShortcutsForStorage(self):
        self.modifiedKeyboardShortcutsStringList=QStringList()
        for actionName in self.modifiedKeyboardShortcuts.keys():
            self.modifiedKeyboardShortcutsStringList.append(actionName)
            self.modifiedKeyboardShortcutsStringList.append(self.modifiedKeyboardShortcuts[actionName])
            
        self.setSetting("KeyboardShortcuts",self.modifiedKeyboardShortcutsStringList)    
            
        
    
    def initSyncSettings(self):
        for key in self.defaultConfigs.keys():
            
            val = self.settings.value(key)
            if not val.isValid():
                self.setSetting(key,self.defaultConfigs[key])
                
        # initialize self.modifiedKeyboardShortcuts
        self.modifiedKeyboardShortcutsStringList=self.setting("KeyboardShortcuts")
        for i in range(0,self.modifiedKeyboardShortcutsStringList.count(),2): 
            self.modifiedKeyboardShortcuts[str(self.modifiedKeyboardShortcutsStringList[i])]=str(self.modifiedKeyboardShortcutsStringList[i+1])        
            
        
            