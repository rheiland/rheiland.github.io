import re
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import PyQt4.QtCore as QtCore
# import ui_findandreplacedlg

import sys

import os
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from Messaging import stdMsg, dbgMsg,pd, errMsg, setDebugging

# import ui_findandreplacedlg
import ui_findinfilesdlg

ALL_IN_FILES=0
ALL_IN_ALL_OPEN_DOCS=1
ALL_IN_CURRENT_DOC=2

MAC = "qt_mac_set_native_menubar" in dir()
class FindInFilesResults:
    def __init__(self,_fileName="",_textToFind="",_unsavedFile=False):
        self.fileName=_fileName
        self.textToFind=_textToFind
        self.lineOccurences=[] # format of each list element is [lineNumber, lineText]
        self.lastLineAdded=-1
        self.totalHits=0
        self.unsavedFile=_unsavedFile
    def addLineWithText(self, _lineNumber,_text):
        if self.lastLineAdded!=_lineNumber:
            if not _text.endsWith('\n'):
                _text.append('\n')
            self.lineOccurences.append([_lineNumber,_text])
            self.lastLineAdded=_lineNumber
            
        self.totalHits+=1
        
    def lastLineNumberAdded(self):
        return 
    #this function will properly format find in files result so that they can be properly interpretted by the lexer
    #have to make lexer more robust though...
    def produceSummaryRepr(self,findInFilesResultsList,_textToFind=""):
        findInFileResultRepr="" 
        allHits=0
        numberOfFiles=len(findInFilesResultsList)
        for findInFileResult in findInFilesResultsList:
            allHits+=findInFileResult.totalHits
            
            
            findInFileResultRepr+=findInFileResult.__str__()
        hitsString="hits"
        if allHits==1:    
            hitString="hit"
        filesString="files"
        if numberOfFiles==1:
            filesString="file"
        
        headerFindInFileResultRepr="Search \""+str(_textToFind)+"\" ("+str(allHits)+" "+ hitsString+" in "+str(numberOfFiles)+" " +filesString+")\n"        

        
        return headerFindInFileResultRepr+findInFileResultRepr
    def __str__(self):
        # header="Search \""+str(self.textToFind)+"\"\n"
        # rep=header
        rep=''
        if self.unsavedFile:
            rep="  File: "+self.fileName# "normalizing" file name to make sure \ and / are used in a consistent manner
        else:
            rep="  File: "+os.path.abspath(str(self.fileName)) # "normalizing" file name to make sure \ and / are used in a consistent manner
            
        if self.totalHits==1:
            rep+=" (1 hit)"
        else:    
            rep+=" ("+str(self.totalHits)+" hits)"
        rep+="\n"
        for lineData in self.lineOccurences:
            rep+="    Line "+str(lineData[0])+":    "+str(lineData[1])
        return rep    
            
    
class FindAndReplaceHistory:
    def __init__(self, _historyLength=20):    
        self.findHistory=QStringList()
        self.replaceHistory=QStringList()
        self.historyLength=_historyLength
        self.textToFind=""
        self.replaceText=""
        self.wo=False # words only
        self.re=False # regular experessions flag
        self.cs=False # case sensitive flag
        self.wrap=True # start from the beginnig after reaching the end of text
        self.syntaxIndex=0
        self.inSelection=False
        self.inAllSubfolders=False
        self.opacity=75
        self.opacityOnLosingFocus=True
        self.opacityAlways=False
        self.transparencyEnable=True
        

        # self.findHistoryIF=QStringList()
        # self.replaceHistoryIF=QStringList()
        self.filtersHistoryIF=QStringList()
        self.directoryHistoryIF=QStringList()        
        self.textToFindIF=""
        self.replaceTextIF=""
        self.filtersIF=""
        self.directoryIF=""
        
        

        
    def newSearchParameters(self,_text,_re,_cs,_wo,_wrap,_inSelection):
        flag=False
        if self.textToFind!=_text:
            self.textToFind = _text        
            self.findHistory.prepend(self.textToFind)
            self.findHistory.removeDuplicates()
            if self.findHistory.count()>=self.historyLength:
                self.findHistory.removeAt(self.findHistory.count() - 1)
                # looks like this does not work in PyQt4
                # self.findHistory.removeLast() 
                
            # dbgMsg(self.findHistory)
            flag=True
        if self.re!=_re:
            self.re=_re
            flag=True
        if self.cs!=_cs:
            self.cs=_cs
            flag=True
        if self.wo!=_wo:
            self.wo=_wo
            flag=True            
        if self.wrap!=_wrap:
            self.wrap=_wrap
            flag=True
        if self.inSelection!=_inSelection:
            self.inSelection=_inSelection
            flag=True
            
        return flag   
    def newSearchParametersIF(self,_text,_filters,_directory):
        flag=False
        if self.textToFindIF!=_text:
            self.textToFindIF = _text        
            self.findHistory.prepend(self.textToFindIF)
            self.findHistory.removeDuplicates()
            if self.findHistory.count()>=self.historyLength:
                self.findHistory.removeAt(self.findHistory.count() - 1)
                # looks like this does not work in PyQt4
                # self.findHistory.removeLast()                 
            flag=True    
            
        if self.filtersIF!=_filters:
            self.filtersIF = _filters        
            self.filtersHistoryIF.prepend(self.filtersIF)
            self.filtersHistoryIF.removeDuplicates()
            if self.filtersHistoryIF.count()>=self.historyLength:
                self.filtersHistoryIF.removeAt(self.filtersHistoryIF.count() - 1)
                # self.filtersHistoryIF.removeLast()
                
            flag=True
            
            # dbgMsg(self.findHistory)
        if self.directoryIF!=_directory:
            self.directoryIF = _directory        
            self.directoryHistoryIF.prepend(self.directoryIF)
            self.directoryHistoryIF.removeDuplicates()
            if self.directoryHistoryIF.count()>=self.historyLength:
                self.directoryHistoryIF.removeAt(self.directoryHistoryIF.count() - 1)
                # self.directoryHistoryIF.removeLast()
            flag=True
            # dbgMsg(self.findHistory)
        # for in files operations we always do search regardless if parameters change or not
        flag=True     
        return flag         
         
        
    def newReplaceParameters(self,_text,_replaceText,_re,_cs,_wo,_wrap,_inSelection):
        flag=self.newSearchParameters(_text,_re,_cs,_wo,_wrap,_inSelection)
        # pd("flag after newSearchParameters=",flag)
        # pd("self.replaceText=",self.replaceText," _replaceText=",_replaceText)
        if self.replaceText!=_replaceText:
            self.replaceText=_replaceText
            
            self.replaceHistory.prepend(self.replaceText)
            self.replaceHistory.removeDuplicates()
            if self.replaceHistory.count()>=self.historyLength:
                self.replaceHistory.removeAt(self.replaceHistory.count() - 1)
                # self.replaceHistory.removeLast()
                
            # dbgMsg(self.findHistory)
            flag=True

        return flag    
        
    def newReplaceParametersIF(self,_text,_replaceText,_filters,_directory):
        flag=self.newSearchParametersIF(_text,_filters,_directory)
        
        if self.replaceTextIF!=_replaceText:
            self.replaceTextIF=_replaceText
            
            self.replaceHistory.prepend(self.replaceTextIF)
            self.replaceHistory.removeDuplicates()
            if self.replaceHistory.count()>=self.historyLength:
                self.replaceHistory.removeAt(self.replaceHistory.count() - 1)
                # self.replaceHistory.removeLast()
                
            # dbgMsg(self.findHistory)
            flag=True

        return flag  
        
class ClickToFocusEventFilter(QObject):
    def __init___(self,_qLineEdit):
        QObject.__init__(self)
        self.qLineEdit=_qLineEdit
        
    def eventFilter(self,  obj,  event):
        dbgMsg("INSIDE EVENT FILTER ",event.type())
        if event.type() == QEvent.FocusIn:
            self.qLineEdit.selectAll()
            # if event.key() == Qt.Key_Delete:
                # self.delkeyPressed.emit()
                # dbgMsg('delkey pressed')
            return True
        return False
   
class QLineEditCustom(QLineEdit):
    def __init__(self,_parent=None):
        QLineEdit.__init__(self,_parent)
        self.focusInCalled=False
        # have to monitor cursor position because qLineEdit inside QComboBox behaves weirdly - after each typed character the cursor is moved to the end of the word making it hard to type inside the line
        self.textEdited.connect(self.monitorCursor)
        self.cursorPositionChanged.connect(self.repositionCursor)
        self.pos=-1
        
    # seems the solution is to eat MouseButtonPress and MouseButtonRelease events...
    # http://www.qtcentre.org/threads/10539-QLineEdit-selectAll%28%29-in-eventFilter
    # to highlight content of QLine edit we need to implement focusInEvent and also change behavior of mousePressEvent
    # when mousePressEvent is called right after focusIn we do nothing otherwise we use default mousePress Event
    
    
    
    def mousePressEvent(self,event): # this event handler is called second
            
        # dbgMsg("self.focusInCalled=",self.focusInCalled)
        if self.focusInCalled:
            self.focusInCalled=False            
        else:
            QLineEdit.mousePressEvent(self,event)
      

    def focusInEvent(self,event): # this event handler is called first
        

        self.selectAll()
        self.focusInCalled=True
        QLineEdit.focusInEvent(self,event)
       
    def focusOutEvent(self,event):
        self.deselect()
        self.focusInCalled=False
        QLineEdit.focusOutEvent(self,event)

    def monitorCursor(self,_str):
        self.pos=self.cursorPosition()

        
    def repositionCursor(self,_oldPos,_newPos):
        #dbgMsg("repositionCursor=",(_oldPos,_newPos))
        if self.pos!=-1:
            self.setCursorPosition(self.pos)
            self.pos=-1

        
class FindAndReplaceDlg(QDialog,ui_findinfilesdlg.Ui_FindInFiles):
    #signals
    searchingSignal = QtCore.pyqtSignal( ('char*',))
    searchingAllInAllOpenDocsSignal = QtCore.pyqtSignal( ('char*','char*','char*','int',)) # text, filters,directory, search mode
    replacingSignal = QtCore.pyqtSignal( ('char*','char*',))
    replacingAllSignal = QtCore.pyqtSignal( ('char*','char*',bool))    
    replacingAllInOpenDocsSignal = QtCore.pyqtSignal( ('char*','char*','char*','char*','int',))  #text,replaceText, filters,directory. replace mode  
    searchingSignalIF = QtCore.pyqtSignal( ('char*','char*','char*',)) # text, filters,directory
    replacingSignalIF = QtCore.pyqtSignal( ('char*','char*','char*','char*')) # text,replaceText, filters,directory
    
    def __init__(self, text="", parent=None):
        super(FindAndReplaceDlg, self).__init__(parent)
        self.editorWindow=parent
        self.__text = unicode(text)
        self.__index = 0
        self.setupUi(self)

        self.findLineEdit=QLineEditCustom()
        self.findComboBox.setLineEdit(self.findLineEdit)
        self.findComboBox.completer().setCaseSensitivity(1)

        self.replaceLineEdit=QLineEditCustom()
        self.replaceComboBox.setLineEdit(self.replaceLineEdit)
        self.replaceComboBox.completer().setCaseSensitivity(1)

        # there are issues with Drawer dialog not getting focus when being displayed on linux
        # they are also not positioned properly so, we use "regular" windows 
        if sys.platform.startswith('win'): 
            self.setWindowFlags(Qt.Drawer) # dialogs without context help - only close button exists

        self.findAndReaplceHistory=None
        
        
        # IF stands for "in files"
        self.findLineEditIF=QLineEditCustom()
        self.findComboBoxIF.setLineEdit(self.findLineEditIF)
        self.findComboBoxIF.completer().setCaseSensitivity(1)
        self.replaceLineEditIF=QLineEditCustom()
        self.replaceComboBoxIF.setLineEdit(self.replaceLineEditIF)
        self.replaceComboBoxIF.completer().setCaseSensitivity(1)

        self.filtersLineEditIF=QLineEditCustom()
        self.filtersComboBoxIF.setLineEdit(self.filtersLineEditIF)
        self.filtersComboBoxIF.completer().setCaseSensitivity(1)
        
        self.directoryLineEditIF=QLineEditCustom()
        self.directoryComboBoxIF.setLineEdit(self.directoryLineEditIF)
        self.directoryComboBoxIF.completer().setCaseSensitivity(1)

        
        # self.findComboBox.setCompleter(0) # disallow word completion
        # synchronizing find and replace boxes on two tabs
        self.connect(self.findLineEdit,SIGNAL("textChanged(const QString &)"),self.findLineEditIF,SLOT("setText(const QString &)"))
        self.connect(self.findLineEditIF,SIGNAL("textChanged(const QString &)"),self.findLineEdit,SLOT("setText(const QString &)"))
        self.connect(self.replaceLineEdit,SIGNAL("textChanged(const QString &)"),self.replaceLineEditIF,SLOT("setText(const QString &)"))
        self.connect(self.replaceLineEditIF,SIGNAL("textChanged(const QString &)"),self.replaceLineEdit,SLOT("setText(const QString &)"))
        #synchronizing check boxes
        self.connect(self.wholeCheckBox,SIGNAL("toggled(bool)"),self.wholeCheckBoxIF, SLOT("setChecked(bool)"))
        self.connect(self.wholeCheckBoxIF,SIGNAL("toggled(bool)"),self.wholeCheckBox, SLOT("setChecked(bool)"))
        self.connect(self.caseCheckBox,SIGNAL("toggled(bool)"),self.caseCheckBoxIF, SLOT("setChecked(bool)"))
        self.connect(self.caseCheckBoxIF,SIGNAL("toggled(bool)"),self.caseCheckBox, SLOT("setChecked(bool)"))
        
        self.connect(self.tabWidget,SIGNAL("currentChanged(int)"),self.tabChanged)
        self.connect(self.alwaysRButton,SIGNAL("toggled(bool)"),self.alwaysRButtonToggled)
        self.connect(self.onLosingFocusRButton,SIGNAL("toggled(bool)"),self.onLosingFocusRButtonToggled)
        
        self.connect(self.transparencyGroupBox,SIGNAL("toggled(bool)"),self.transparencyGroupBoxToggled)
        
        #synchronizing syntax boxes
        self.connect(self.syntaxComboBox,SIGNAL("activated(int)"),self.syntaxComboBoxIF, SLOT("setCurrentIndex(int)"))
        self.connect(self.syntaxComboBoxIF,SIGNAL("activated(int)"),self.syntaxComboBox, SLOT("setCurrentIndex(int)"))
        

        if not MAC:
            # # self.findButton.setFocusPolicy(Qt.NoFocus)
            self.replaceButton.setFocusPolicy(Qt.NoFocus)
            self.replaceAllButton.setFocusPolicy(Qt.NoFocus)
            self.closeButton.setFocusPolicy(Qt.NoFocus)
        self.updateUi()
        
    def tabChanged(self,idx):
        title=self.tabWidget.tabText(idx)
        dbgMsg("TITLE=",title)
        self.setWindowTitle(title)
    
    def changeEvent(self,event):
        if event.type()==QEvent.ActivationChange:
            if self.transparencyGroupBox.isChecked() and self.onLosingFocusRButton.isChecked():
                # opacity setting is often window manager dependent - e.g. on linux (KDE) you might need to enable desktop effects to enable transparency
                if self.isActiveWindow():
                    
                    self.setWindowOpacity(1.0)
                else:
                    self.setWindowOpacity(self.transparencySlider.sliderPosition()/100.0)

    def setFindAndReaplceHistory(self,_frh):
        self.findAndReaplceHistory=_frh
    
    def showEvent(self, event):
        self.findLineEdit.setFocus(True)
        self.initializeAllSearchLists(self.findAndReaplceHistory)
        if self.editorWindow.getCurrentEditor().hasSelectedText():
            self.findLineEdit.setText(self.editorWindow.getCurrentEditor().selectedText())         
        # self.initializeSearchLists()

        ## this is quite strange but on windows there is no need to position dialog box, but on Linux, you have to do it manually
        #self.move(0,0) #always position popup at (0,0) then calculate required shift
        #self.adjustSize()
            
            
        ##setting position of the find dialog widget
        #geom=self.editorWindow.geometry()            
        #pGeom=self.geometry()            
        
        #pCentered_x=geom.x()+(geom.width()-pGeom.width())/2
        #pCentered_y=geom.y()+(geom.height()-pGeom.height())/2
        
        #self.move(pCentered_x,pCentered_y)
            
            #pGeom=self.cycleTabsPopup.geometry()
        
        QDialog.showEvent(self,event) # necesary to move dialog to the correct position - we do it only if we override show event
    
    def closeEvent(self, event):
        dbgMsg("CLOSE EVENT FOR FIND DIALOG")
        self.editorWindow.findDialogForm=None
        frh=self.findAndReaplceHistory
        frh.wo=self.wholeCheckBox.isChecked()
        frh.cs=self.caseCheckBox.isChecked()
        
        frh.syntaxIndex=self.syntaxComboBoxIF.currentIndex()
        
        frh.inSelection=self.inSelectionBox.isChecked()
        frh.inAllSubfolders=self.inAllSubFoldersCheckBoxIF.isChecked()
        
        frh.transparencyEnable=self.transparencyGroupBox.isChecked()
        frh.opacityOnLosingFocus=self.onLosingFocusRButton.isChecked()
        frh.opacityAlways=self.alwaysRButton.isChecked()
        frh.opacity=self.transparencySlider.sliderPosition()    
        
        
    def initializeDialog(self,_frh):
            
        if _frh.cs:
            self.caseCheckBox.setChecked(True)
        else:
            self.caseCheckBox.setChecked(False)
            
        if _frh.wo:
            self.wholeCheckBox.setChecked(True)
        else:
            self.wholeCheckBox.setChecked(False)    
        self.initializeAllSearchLists(_frh)
        
        #initializing syntax index
        self.syntaxComboBox.setCurrentIndex(_frh.syntaxIndex)
        self.syntaxComboBoxIF.setCurrentIndex(_frh.syntaxIndex) #have to manually change current index both syntax combo boxes
        
        
        #initializing searchModifiers settings
        self.inSelectionBox.setChecked(_frh.inSelection)
        self.inAllSubFoldersCheckBoxIF.setChecked(_frh.inAllSubfolders)
        
        #initializing transparency settings        
        self.transparencyGroupBox.setChecked(_frh.transparencyEnable)
        self.onLosingFocusRButton.setChecked(_frh.opacityOnLosingFocus)
        self.alwaysRButton.setChecked(_frh.opacityAlways)
        self.transparencySlider.setSliderPosition(_frh.opacity)

    def alwaysRButtonToggled(self,_flag):
        if self.transparencyGroupBox.isChecked() and _flag:
            self.setWindowOpacity(self.transparencySlider.sliderPosition()/100.0)
            
    def onLosingFocusRButtonToggled(self,_flag):
        if _flag:
            self.setWindowOpacity(1.0) 
        
    def transparencyGroupBoxToggled(self,_flag):
        if _flag:
            if self.alwaysRButton.isChecked():
                self.alwaysRButtonToggled(_flag)
        else:    
            self.setWindowOpacity(1.0)    
            
    def initializeSearchLists(self,_frh):        
        # if self.replaceLineEdit.text()!=_frh.replaceHistory.first():
            # if self.replaceLineEdit.text()!='':
                # _frh.replaceHistory.prepend(self.replaceLineEdit.text())
        replaceTextToDisplayFirst=self.replaceLineEdit.text()
        replaceHistoryFirstItem=''
        if _frh.replaceHistory.count():
            replaceHistoryFirstItem=_frh.replaceHistory.first()
        #pd("self.replaceLineEdit.text()=",self.replaceLineEdit.text()," _frh.replaceHistory.first()=",_frh.replaceHistory.first())
        if self.replaceLineEdit.text()!=replaceHistoryFirstItem:
            if self.replaceLineEdit.text()!='':
                replaceTextToDisplayFirst=self.replaceLineEdit.text()
                

            
        self.findComboBox.clear()
        self.replaceComboBox.clear()
        self.findComboBoxIF.clear()
        self.replaceComboBoxIF.clear()
        
        self.findComboBox.addItems(_frh.findHistory)
        if replaceTextToDisplayFirst!='':
            self.findComboBox.addItem(replaceTextToDisplayFirst)
                
        self.replaceComboBox.addItems(_frh.replaceHistory) 
        
                
        
        self.findComboBoxIF.addItems(_frh.findHistory)
        self.replaceComboBoxIF.addItems(_frh.replaceHistory)        
        
    def initializeAllSearchLists(self,_frh):        
        self.initializeSearchLists(_frh)
        self.directoryComboBoxIF.clear()
        self.filtersComboBoxIF.clear()
        self.directoryComboBoxIF.addItems(_frh.directoryHistoryIF)
        self.filtersComboBoxIF.addItems(_frh.filtersHistoryIF)
        
    def findLineEditProcess(self,_text):
        dbgMsg("clicked Find Line Edit")

    # not including @pyqtSignature("") causes multiple calls to this fcn
    @pyqtSignature("") 
    def on_findNextButton_clicked(self):
        # dbgMsg("this is on findNext button clicked")
        self.searchingSignal.emit(str(self.findComboBox.lineEdit().text()))
        return
        
    @pyqtSignature("")    
    def on_findAllInOpenDocsButton_clicked(self):        
        self.searchingAllInAllOpenDocsSignal.emit(str(self.findComboBox.lineEdit().text()),'','',ALL_IN_ALL_OPEN_DOCS)    
        return
        
    @pyqtSignature("")    
    def on_findAllInCurrentDocButton_clicked(self):
        self.searchingAllInAllOpenDocsSignal.emit(str(self.findComboBox.lineEdit().text()),'','',ALL_IN_CURRENT_DOC)     
        return
        
    @pyqtSignature("")        
    def on_replaceAllInOpenDocsButton_clicked(self):
        self.replacingAllInOpenDocsSignal.emit(str(self.findComboBox.lineEdit().text()),str(self.replaceComboBox.lineEdit().text()),'','',ALL_IN_ALL_OPEN_DOCS)
        return
        
    @pyqtSignature("")
    def on_findCPB_clicked(self):
        # dbgMsg("this is on findNext button clicked"  )
         
        self.findAndReaplceHistory.findHistory.clear()
        self.findComboBox.clear()
        self.findComboBoxIF.clear()
        
    @pyqtSignature("")
    def on_replaceCPB_clicked(self):
        dbgMsg("CLEAR REAPLCE HISTORY button clicked"        )
        self.findAndReaplceHistory.replaceHistory.clear()
        self.replaceComboBox.clear()
        self.replaceComboBoxIF.clear()
        
    @pyqtSignature("")      
    def on_filtersCPB_clicked(self):
        # dbgMsg("this is on findNext button clicked"        )
        self.findAndReaplceHistory.filtersHistoryIF.clear()
        self.filtersComboBoxIF.clear()
        
    @pyqtSignature("")              
    def on_directoryCPB_clicked(self):
        # dbgMsg("this is on findNext button clicked"        )
        self.findAndReaplceHistory.directoryHistoryIF.clear()
        self.directoryComboBoxIF.clear()
        
    @pyqtSignature("")
    def on_replaceButton_clicked(self):
        # dbgMsg("this is on replace buttin clicked" )
        self.replacingSignal.emit(str(self.findComboBox.lineEdit().text()),str(self.replaceComboBox.lineEdit().text()))
        return
    
        dbgMsg("this is on replace buttin clicked" )
        return
        regex = self.makeRegex()
        self.__text = regex.sub(unicode(self.replaceLineEdit.text()),
                                self.__text, 1)
        

    @pyqtSignature("")
    def on_replaceAllButton_clicked(self):
        dbgMsg("this is on replaceAll buttin clicked")
        self.replacingAllSignal.emit(str(self.findComboBox.lineEdit().text()),str(self.replaceComboBox.lineEdit().text()),self.inSelectionBox.isChecked())
        return
        regex = self.makeRegex()
        self.__text = regex.sub(unicode(self.replaceLineEdit.text()),
                                self.__text)
        

    def updateUi(self):
        pass

            
    def text(self):
        return self.__text
        
    @pyqtSignature("")
    def on_pickDirectoryButtonIF_clicked(self):
        dbgMsg("this is on pick directory button clicked")
        directory=QFileDialog.getExistingDirectory ( self, "Look for files in the directory...")
        dbgMsg("directory=",directory)
        self.directoryLineEditIF.setText(directory)
        return
        
    @pyqtSignature("")
    def on_findAllButtonIF_clicked(self):       
        self.searchingSignalIF.emit(str(self.findComboBoxIF.lineEdit().text()),str(self.filtersComboBoxIF.lineEdit().text()),str(self.directoryComboBoxIF.lineEdit().text()))
        
    @pyqtSignature("")
    def on_replaceButtonIF_clicked(self):        
        self.replacingSignalIF.emit(str(self.findComboBoxIF.lineEdit().text()),str(self.replaceComboBoxIF.lineEdit().text()),str(self.filtersComboBoxIF.lineEdit().text()),str(self.directoryComboBoxIF.lineEdit().text()))
        
        
# class FindDock
import sys
from PyQt4.Qsci import *
from PyQt4 import Qsci
from PyQt4 import QtGui
# from QsciScintillaCustom import QsciScintillaCustom
# from PyQt4.Qsci.QsciScintilla import *
# NOTICE: complete scintilla documentation can be found here:
# http://www.scintilla.org/ScintillaDoc.htm
class FindDisplayWidget(QsciScintilla):
    """
    Class providing a specialized text edit for displaying logging information.
    """
    def __init__(self, parent = None):
        """
        Constructor
        
        @param parent reference to the parent widget (QWidget) - here it is EditorWindow class
        """
        self.editorWindow=parent
        QsciScintilla.__init__(self,parent)
        # # self.setFolding(5)
        self.setFolding(QsciScintilla.BoxedTreeFoldStyle)
        # self.setMarginSensitivity(3,True) 
        lexer=QsciLexerPython()
        dbgMsg(lexer.keywords(1),"\n\n\n\n")
        findInFilesLexer=FindInFilesLexer(self)
        self.setLexer(findInFilesLexer)
       
        self.setReadOnly(True)
        self.setCaretLineVisible(True)
        
        self.setCaretLineBackgroundColor(QtGui.QColor('#E0E0F8')) #current line has this color
        self.setSelectionBackgroundColor(QtGui.QColor('#E0E0F8')) # any selection in the current line due to double click has the same color too	
        #connecting SCN_DOUBLECLICK(int,int,int) to editor double-click
        #notice  QsciScintilla.SCN_DOUBLECLICK(int,int,int) is not the right name        
        self.connect(self, SIGNAL("SCN_DOUBLECLICK(int,int,int)"), self.onDoubleClick)
        
        GETFOLDLEVEL = QsciScintilla.SCI_GETFOLDLEVEL
        SETFOLDLEVEL = QsciScintilla.SCI_SETFOLDLEVEL
        HEADERFLAG = QsciScintilla.SC_FOLDLEVELHEADERFLAG
        LEVELBASE = QsciScintilla.SC_FOLDLEVELBASE
        NUMBERMASK = QsciScintilla.SC_FOLDLEVELNUMBERMASK
        WHITEFLAG = QsciScintilla.SC_FOLDLEVELWHITEFLAG
        
        headerLevel = LEVELBASE | HEADERFLAG
        lineStart=1        
        lineEnd=3

        self.SendScintilla(QsciScintilla.SCI_SETCARETSTYLE, QsciScintilla.CARETSTYLE_INVISIBLE) # make caret invisible
        

        self.lineNumberExtractRegex=re.compile('^[\s]*Line[\s]*([0-9]*)')
        self.fileNameWithSearchTextExtractRegex=re.compile('^[\s]*File:[\s]*([\S][\s\S]*)\(')
        
        self.zoomRange=self.editorWindow.configuration.setting("ZoomRangeFindDisplayWidget")
        self.zoomTo(self.zoomRange)
        
        dbgMsg("marginSensitivity=",self.marginSensitivity(0))

    def addNewFindInFilesResults(self, _str):
        self.setFolding(QsciScintilla.BoxedTreeFoldStyle)# stray fold character workaround 
        self.insertAt(_str,0,0)
        self.setCursorPosition(0,0)
        # self.append(_str)
        
    # context menu handling
    def contextMenuEvent(self,event):
        menu=QMenu(self)
        copyAct=menu.addAction("Copy")
        selectAllAct=menu.addAction("Select All")
        clearAllAct=menu.addAction("Clear All")
        self.connect(copyAct,SIGNAL("triggered()"),self.copy)
        self.connect(selectAllAct,SIGNAL("triggered()"),self.selectAll)
        self.connect(clearAllAct,SIGNAL("triggered()"),self.clearAll)
        
        menu.exec_(event.globalPos())
        
    def wheelEvent(self,event):
        if qApp.keyboardModifiers()==Qt.ControlModifier:
            # Forwarding wheel event to editor windowwheelEvent
            if event.delta()>0:
                self.zoomIn()
                self.zoomRange+=1
            else:
                self.zoomOut() 
                self.zoomRange-=1                
            self.editorWindow.configuration.setSetting("ZoomRangeFindDisplayWidget",self.zoomRange)    
        else:
            # # calling wheelEvent from base class - regular scrolling
            super(QsciScintilla,self).wheelEvent(event)        
        
    def clearAll(self):
        # self.clearFolds()
        self.clear()
        # SCI=self.SendScintilla
        # HEADERFLAG = QsciScintilla.SC_FOLDLEVELHEADERFLAG        
        # LEVELBASE = QsciScintilla.SC_FOLDLEVELBASE
        # SETFOLDLEVEL = QsciScintilla.SCI_SETFOLDLEVEL
        # headerLevel = LEVELBASE | HEADERFLAG
        # SCI(SETFOLDLEVEL, 0, headerLevel)
                        
        # 
        # 
        self.setFolding(QsciScintilla.NoFoldStyle) # stray fold character workaround 
        # self.setFolding(QsciScintilla.BoxedTreeFoldStyle)
        
    def onMarginClick(self,_pos,_modifier, _margin):
        dbgMsg("_pos:",_pos," modifier:",_modifier," _margin:",_margin)
        lineClick = self.SendScintilla(QsciScintilla.SCI_LINEFROMPOSITION, _pos)
        dbgMsg("lineClick=",lineClick)
        levelClick = self.SendScintilla(QsciScintilla.SCI_GETFOLDLEVEL, lineClick)
        dbgMsg("levelClick=",levelClick)
        if levelClick & QsciScintilla.SC_FOLDLEVELHEADERFLAG:
            dbgMsg("Clicked Fold Header")
            self.SendScintilla(QsciScintilla.SCI_TOGGLEFOLD, lineClick)

    def onDoubleClick(self,_position,_line,_modifiers):
        dbgMsg("position=",_position," line=",_line," modifiers=",_modifiers)
        lineText=str(self.text(_line))
        dbgMsg("line text=",lineText)
        lineNumberGroups=self.lineNumberExtractRegex.search(lineText)
        lineNumber=-1
        lineNumberWithFileName=-1
        try: 
            if lineNumberGroups:
                lineNumber=int(lineNumberGroups.group(1))
                dbgMsg("Searched text at line=",lineNumber)
                lineNumberWithFileName = self.SendScintilla(QsciScintilla.SCI_GETFOLDPARENT, _line)    
        except IndexError,e:
            
            dbgMsg("Line number not found")

        if lineNumberWithFileName>=0:
            dbgMsg("THIS IS LINE WITH FILE NAME:")
            lineWithFileName= str(self.text(lineNumberWithFileName))
            
            dbgMsg(lineWithFileName)
            fileNameGroups=self.fileNameWithSearchTextExtractRegex.search(lineWithFileName)
            if fileNameGroups:
                try:
                    fileNameWithSearchedText=fileNameGroups.group(1)                    
                    fileNameWithSearchedText=fileNameWithSearchedText.strip() # removing trailing white spaces                    
                    fileNameWithSearchedTextOrig=fileNameWithSearchedText # store original file name as found by regex - it is used to locate unsaved files                   
                    # "normalizing" file name to make sure \ and / are used in a consistent manner
                    fileNameWithSearchedText=os.path.abspath(fileNameWithSearchedText)
                    dbgMsg("FILE NAME WITH SEARCHED TEXT:",fileNameWithSearchedText)
                    # first we check if file exists and is readable:
                    currentEditorTab=None
                    try:
                        f=open(fileNameWithSearchedText,'rb')
                        f.close()
                        self.editorWindow.loadFile(fileNameWithSearchedText)
                        currentEditorTab=self.editorWindow.editTab.currentWidget()
                    except IOError:
                        # in case file does not exist search for open tab with matching tab text                        
                        currentEditorTab=self.findTabWithMatchingTabText(fileNameWithSearchedTextOrig)        
                    
                    if not currentEditorTab:
                        return
                        
                    self.editorWindow.editTab.setCurrentWidget(currentEditorTab)    
                    currentEditorTab.setCursorPosition(lineNumber,0)
                    currentEditorTab.ensureCursorVisible()
                    currentEditorTab.SendScintilla(QsciScintilla.SCI_SETFOCUS,True)
                except IndexError,e:
                    dbgMsg("Could not extract file name")
                    
    def findTabWithMatchingTabText(self,_tabText):
        """
            Looks for a tab in self.editorWindow with tab label matchin _tabText. returns this tab or None
        """
            
        for i in range(self.editorWindow.editTab.count()):
            
            currentTabText=str(self.editorWindow.editTab.tabText(i))
            # import string
            # currentTabText=string.rstrip(currentTabText)
            currentTabText=currentTabText.strip()# removing trailing white spaces
            
            if currentTabText==_tabText:            
                return self.editorWindow.editTab.widget(i)
        return None        
            
        
# lineWithFileNameText ="  File: C:/Program Files/twedit/tw edit.py (8 hits)"    
# lineWithFileNameGroups=re.search('^[\s]*File:[\s]*([\S][\s\S]*)\(',lineWithFileNameText)
# dbgMsg(lineWithFileNameGroups)
# if lineWithFileNameGroups:
    # dbgMsg("group 0=",lineWithFileNameGroups.group(0))
    # dbgMsg("group 1=",lineWithFileNameGroups.group(1)        )
        # figuring out the file name
        # using http://www.scintilla.org/ScintillaDoc.html#SCI_GETFOLDPARENT
       
        
            
            
        # self.foldLine(0)
        # self.foldAll()
    # def __handleShowContextMenu(self, coord):
        # """
        # Private slot to show the context menu.
        
        # @param coord the position of the mouse pointer (QPoint)
        # """
        # dbgMsg("Context Menu")
        # # coord = self.mapToGlobal(coord)
        # # self.__menu.popup(coord)
        
        
class CustomLexer(QsciLexerCustom):
    def __init__(self, parent):
        Qsci.QsciLexerCustom.__init__(self, parent)
        self._styles = {
            0: 'Default',
            1: 'Comment',
            2: 'Key',
            3: 'Assignment',
            4: 'Value',
            }
        for key,value in self._styles.iteritems():
            setattr(self, value, key)
        self.editorWidget=parent
    def description(self, style):
        return self._styles.get(style, '')

    def defaultColor(self, style):
        if style == self.Default:
            return QtGui.QColor('#000000')
        elif style == self.Comment:
            return QtGui.QColor('#C0C0C0')
        elif style == self.Key:
            return QtGui.QColor('#0000CC')
        elif style == self.Assignment:
            return QtGui.QColor('#CC0000')
        elif style == self.Value:
            return QtGui.QColor('#00CC00')
        return Qsci.QsciLexerCustom.defaultColor(self, style)
    def keywords(self,i):
        return "fcn"   
    def styleText(self, start, end):
        editor = self.editor()
        if editor is None:
            return

        # scintilla works with encoded bytes, not decoded characters.
        # this matters if the source contains non-ascii characters and
        # a multi-byte encoding is used (e.g. utf-8)
        source = ''
        if end > editor.length():
            end = editor.length()
        if end > start:
            if sys.hexversion >= 0x02060000:
                # faster when styling big files, but needs python 2.6
                source = bytearray(end - start)
                editor.SendScintilla(
                    editor.SCI_GETTEXTRANGE, start, end, source)
            else:
                source = unicode(editor.text()
                                ).encode('utf-8')[start:end]
        if not source:
            return

        # the line index will also be needed to implement folding
        index = editor.SendScintilla(editor.SCI_LINEFROMPOSITION, start)
        if index > 0:
            # the previous state may be needed for multi-line styling
            pos = editor.SendScintilla(
                      editor.SCI_GETLINEENDPOSITION, index - 1)
            state = editor.SendScintilla(editor.SCI_GETSTYLEAT, pos)
        else:
            state = self.Default

        set_style = self.setStyling
        self.startStyling(start, 0x1f)
        
        # SCI = self.SendScintilla
        SCI=self.editorWidget.SendScintilla
        GETFOLDLEVEL = QsciScintilla.SCI_GETFOLDLEVEL
        SETFOLDLEVEL = QsciScintilla.SCI_SETFOLDLEVEL
        HEADERFLAG = QsciScintilla.SC_FOLDLEVELHEADERFLAG
        LEVELBASE = QsciScintilla.SC_FOLDLEVELBASE
        NUMBERMASK = QsciScintilla.SC_FOLDLEVELNUMBERMASK
        WHITEFLAG = QsciScintilla.SC_FOLDLEVELWHITEFLAG
        # scintilla always asks to style whole lines
        for line in source.splitlines(True):
            length = len(line)
            if line.startswith('#'):
                state = self.Comment
                dbgMsg("STYLING COMMENT")
            else:
                # the following will style lines like "x = 0"
                pos = line.find('=')
                if pos > 0:
                    set_style(pos, self.Key)#styling LHS pos is the length of styled text
                    set_style(1, self.Assignment)#styling = 1 is the length of styled text
                    length = length - pos - 1 # Value styling is applied to RHS
                    state = self.Value
                else:
                    state = self.Default
            set_style(length, state)
            # folding implementation goes here
            # headerLevel = LEVELBASE | HEADERFLAG
            # dbgMsg("HEADER LEVEL",headerLevel)
            
            # if index==0:
                # SCI(SETFOLDLEVEL, index, headerLevel)
            # else:
                # SCI(SETFOLDLEVEL, index, LEVELBASE+1)
            index += 1
            
# Folding is sensitive to new lines - works fin if there is no new empty lines
# have to make sure that Search,Line, File at the beginning of the line do not have to include certain number fo leading spaces 
# to make lexer work properly

# IMPORTANT. by default Lexer will process only visible text so if there is a state you want to pas from line to line you 
# have to store it in class variable or have a way to restore previous state  (here we use self.searchText) as a state variable to hold value of the searched text for each line. 

class FindInFilesLexer(QsciLexerCustom):
    def __init__(self, parent):
        Qsci.QsciLexerCustom.__init__(self, parent)
        self._styles = {
            0: 'Default',
            1: 'SearchInfo',
            2: 'FileInfo',
            3: 'LineInfo',
            4: 'TextToFind'
            }
        for key,value in self._styles.iteritems():
            setattr(self, value, key)
        self.editorWidget=parent
        self.colorizeEntireLineStates=[self.SearchInfo,self.FileInfo]
        
        self.baseFont=Qsci.QsciLexerCustom.defaultFont(self, 0)
        self.baseFontBold=QFont(self.baseFont)        
        self.baseFontBold.setBold(True)
        self.searchText=""
        
    def description(self, style):
        return self._styles.get(style, '')
    #used by QsciLexer to style font colors
    def defaultColor(self, style):
        if style == self.Default:
            return QtGui.QColor('#000000')
        elif style == self.SearchInfo:
            return QtGui.QColor('#0404B4')
        elif style == self.FileInfo:
            return QtGui.QColor('#04B404')
        elif style == self.LineInfo:    
            return QtGui.QColor('#000000')            
        elif style == self.TextToFind:
            return QtGui.QColor('#FF0000')
            
        return Qsci.QsciLexerCustom.defaultColor(self, style)
        
    #used by QsciLexer to style font properties    
    def defaultFont(self, style):

        
        if style == self.Default:
            return self.baseFont
        elif style == self.SearchInfo:
            # baseFont.setBold(True)
            return self.baseFontBold
        elif style == self.FileInfo:
            return self.baseFontBold
  
        return Qsci.QsciLexerCustom.defaultFont(self, style)  
        
    #used by QsciLexer to style paper properties (background color)
    def defaultPaper(self, style):

        if style == self.Default:
            return QtGui.QColor('#FFFFFF')
        elif style == self.SearchInfo:            
            return QtGui.QColor('#A9D0F5')
        elif style == self.FileInfo:
            return QtGui.QColor('#E0F8E0')
        elif style == self.TextToFind:
            return QtGui.QColor('#F2F5A9')
  
        return Qsci.QsciLexerCustom.defaultPaper(self, style)    
        
    # To colorize entire line containit Search or File info we use  defaultEolFill fcn   
    def defaultEolFill(self, style):
    # This allowed to colorize all the background of a line.
        if style in self.colorizeEntireLineStates:
            return True
        return QsciLexerCustom.defaultEolFill(self, style)  
        
    def styleText(self, start, end):
        editor = self.editor()
        if editor is None:
            return

        # scintilla works with encoded bytes, not decoded characters.
        # this matters if the source contains non-ascii characters and
        # a multi-byte encoding is used (e.g. utf-8)
        source = ''
        if end > editor.length():
            end = editor.length()
        if end > start:
            if sys.hexversion >= 0x02060000:
                # faster when styling big files, but needs python 2.6
                source = bytearray(end - start)
                editor.SendScintilla(
                    editor.SCI_GETTEXTRANGE, start, end, source)
            else:
                # source = unicode(editor.text()
                                # ).encode('utf-8')[start:end]
                source=unicode(editor.text()).encode('utf-8') # scanning entire text is way more efficient that doing it on demand especially when folding top level text (Search)               
        if not source:
            return
            
        
        
        
        # the line index will also be needed to implement folding
        index = editor.SendScintilla(editor.SCI_LINEFROMPOSITION, start)
        if index > 0:
            # the previous state may be needed for multi-line styling
            pos = editor.SendScintilla(
                      editor.SCI_GETLINEENDPOSITION, index - 1)
            state = editor.SendScintilla(editor.SCI_GETSTYLEAT, pos)
        else:
            state = self.Default

        set_style = self.setStyling
        self.startStyling(start, 0x1f)
        
        # SCI = self.SendScintilla
        SCI=self.editorWidget.SendScintilla
        GETFOLDLEVEL = QsciScintilla.SCI_GETFOLDLEVEL
        SETFOLDLEVEL = QsciScintilla.SCI_SETFOLDLEVEL
        HEADERFLAG = QsciScintilla.SC_FOLDLEVELHEADERFLAG
        LEVELBASE = QsciScintilla.SC_FOLDLEVELBASE
        NUMBERMASK = QsciScintilla.SC_FOLDLEVELNUMBERMASK
        WHITEFLAG = QsciScintilla.SC_FOLDLEVELWHITEFLAG
        # scintilla always asks to style whole lines
       
        for line in source.splitlines(True):
            length = len(line)
            # dbgMsg("line=",line)
            # dbgMsg(line)
            if line.startswith('\n'):
                style=self.Default
                dbgMsg("GOT EMPTY LINE")
                # sys.exit()
            else:    
                if line.startswith('Search'):
                    state = self.SearchInfo
                    
                    searchGroups =re.search('"([\s\S]*)"', line) # we have to use search instead of match - match matches onle beginning of the string , search searches through entire string

                    
                    # dbgMsg("searchGroups=",searchGroups)
                    
                    try: 
                    
                        if searchGroups:                        
                            # dbgMsg(searchGroups.group(1))
                            self.searchText=searchGroups.group(1)
                            
                            # dbgMsg("self.searchText=",self.searchText)
                    except IndexError,e:
                        self.searchText=""
                        dbgMsg("COULD NOT EXTRACT TEXT")
                        
                            
                            
                # elif line.startswith('  File'):
                elif line.startswith('  F'):
                    state = self.FileInfo
                   
                # elif line.startswith('    Line'):    
                elif line.startswith('   '):
                
                    
                    if self.searchText!="":
                        # dbgMsg("self.searchText=",self.searchText)
                        searchTextLength=len(self.searchText)
                        # pos = line.find(self.searchText)
                        # set_style(pos, self.LineInfo) # styling begining of the line
                        # set_style(searchTextLength, self.TextToFind) # styling searchText of the line
                        # length = length - pos - searchTextLength  # Default styling is applied to RHS
                        # state = self.SearchInfo
                        # dbgMsg("LENGTH=",length)
                        
                        # length = length - pos
                        # dbgMsg("line=",line)
                        startPos=0
                        # string line is not use to output to the screen it is local to this fcn therefore it is safe to use lower
                        pos = line.lower().find(self.searchText.lower())
                        while pos!=-1:
                        
                            set_style(pos-startPos, self.LineInfo) # styling begining of the line
                            set_style(searchTextLength, self.TextToFind) # styling searchText of the line
                            startPos=pos+searchTextLength
                            pos = line.find(self.searchText,startPos)
                            state = self.LineInfo
                            
                        
                        state = self.LineInfo
                        length=length-startPos # last value startPos if startPos point to the location right after last found searchText - to continue styling we tell lexer to style reminder of the line (length-startPos) with LineInfo style
                    else:
                        dbgMsg("DID NOT FIND SEARCH TEXT")
                        # state = self.Default
                        state = self.LineInfo
                    
                    # # the following will style lines like "x = 0"
                    
                    # pos = line.find('\tFile')
                    
                    # if pos > 0:
                        # set_style(pos, self.SearchInfo) #styling LHS pos is the length of styled text
                        # set_style(1, self.FileInfo)#styling = 1 is the length of styled text
                        # length = length - pos - 1
                        # state = self.SearchInfo
                    # else:
                        # state = self.Default
                else:
                    # state = self.Default
                    state = self.LineInfo
                
            set_style(length, state)
            # folding implementation goes here
            headerLevel = LEVELBASE | HEADERFLAG
            # dbgMsg("HEADER LEVEL",headerLevel)
            
            # if index==0:
            if state==self.SearchInfo:
                SCI(SETFOLDLEVEL, index, headerLevel)
            elif state==self.FileInfo:   
                SCI(SETFOLDLEVEL, index, headerLevel+1) # this subheader - inside header for SearchInfo style - have to add +1 to folding level
            elif state==self.LineInfo:
                SCI(SETFOLDLEVEL, index, LEVELBASE+2) # this is non-header fold line - since it is inside header level and headerLevel +1 i had to add +3 to the  LEVELBASE+2
            else:                
                SCI(SETFOLDLEVEL, index, LEVELBASE+2) # this is non-header fold line - since it is inside header level and headerLevel +1 i had to add +3 to the  LEVELBASE+2
                
            index += 1
            
class ConfigLexer(QsciLexerCustom):
    def __init__(self, parent):
        QsciLexerCustom.__init__(self, parent)
        self._styles = {
            0: 'Default',
            1: 'MultiLinesComment_Start',
            2: 'MultiLinesComment',
            3: 'MultiLinesComment_End',
            4: 'SingleLineComment'
            }
        for key,value in self._styles.iteritems():
            setattr(self, value, key)
        self._foldcompact = True
        self.__comment = [self.MultiLinesComment,
                          self.MultiLinesComment_End,
                          self.MultiLinesComment_Start,
                          self.SingleLineComment]

    def foldCompact(self):
        return self._foldcompact

    def setFoldCompact(self, enable):
        self._foldcompact = bool(enable)

    def language(self):
        return 'Config Files'

    def description(self, style):
        return self._styles.get(style, '')

    def defaultColor(self, style):
        if style == self.Default:
            return QColor('#000000')
        elif style in self.__comment:
            return QColor('#A0A0A0')
        return QsciLexerCustom.defaultColor(self, style)

    def defaultFont(self, style):
        if style in self.__comment:
            if sys.platform in ('win32', 'cygwin'):
                return QFont('Comic Sans MS', 9, QFont.Bold)
            return QFont('Bitstream Vera Serif', 9, QFont.Bold)
        return QsciLexerCustom.defaultFont(self, style)

    def defaultPaper(self, style):
# Here we change the color of the background.
# We want to colorize all the background of the line.
# This is done by using the following method defaultEolFill() .
        if style in self.__comment:
            return QColor('#FFEECC')
        return QsciLexerCustom.defaultPaper(self, style)

    def defaultEolFill(self, style):
# This allowed to colorize all the background of a line.
        if style in self.__comment:
            return True
        return QsciLexerCustom.defaultEolFill(self, style)

    def styleText(self, start, end):
        editor = self.editor()
        if editor is None:
            return

        SCI = editor.SendScintilla
        GETFOLDLEVEL = QsciScintilla.SCI_GETFOLDLEVEL
        SETFOLDLEVEL = QsciScintilla.SCI_SETFOLDLEVEL
        HEADERFLAG = QsciScintilla.SC_FOLDLEVELHEADERFLAG
        LEVELBASE = QsciScintilla.SC_FOLDLEVELBASE
        NUMBERMASK = QsciScintilla.SC_FOLDLEVELNUMBERMASK
        WHITEFLAG = QsciScintilla.SC_FOLDLEVELWHITEFLAG
        set_style = self.setStyling

        source = ''
        if end > editor.length():
            end = editor.length()
        if end > start:
            source = bytearray(end - start)
            SCI(QsciScintilla.SCI_GETTEXTRANGE, start, end, source)
        if not source:
            return

        compact = self.foldCompact()

        index = SCI(QsciScintilla.SCI_LINEFROMPOSITION, start)
        if index > 0:
            pos = SCI(QsciScintilla.SCI_GETLINEENDPOSITION, index - 1)
            prevState = SCI(QsciScintilla.SCI_GETSTYLEAT, pos)
        else:
            prevState = self.Default

        self.startStyling(start, 0x1f)

        for line in source.splitlines(True):
# Try to uncomment the following line to see in the console
# how Scintiallla works. You have to think in terms of isolated
# lines rather than globally on the whole text.
#            dbgMsg(line)

            length = len(line)
# We must take care of empty lines.
# This is done here.
            if length == 1:
                if prevState == self.MultiLinesComment or prevState == self.MultiLinesComment_Start:
                    newState = self.MultiLinesComment
                else:
                    newState = self.Default
# We work with a non empty line.
            else:
                if line.startswith('/*'):
                    newState = self.MultiLinesComment_Start
                elif line.startswith('*/'):
                    if prevState == self.MultiLinesComment or prevState == self.MultiLinesComment_Start:
                        newState = self.MultiLinesComment_End
                    else:
                        newState = self.Default
                elif line.startswith('//'):
                    if prevState == self.MultiLinesComment or prevState == self.MultiLinesComment_Start:
                        newState = self.MultiLinesComment
                    else:
                        newState = self.SingleLineComment
                elif prevState == self.MultiLinesComment or prevState == self.MultiLinesComment_Start:
                    newState = self.MultiLinesComment
                else:              
                    newState = self.Default

            set_style(length, newState)
# Definition of the folding.
# Documentation : http://scintilla.sourceforge.net/ScintillaDoc.html#Folding
            if newState == self.MultiLinesComment_Start:
                if prevState == self.MultiLinesComment:
                    level = LEVELBASE + 1
                else:
                    level = LEVELBASE | HEADERFLAG
            elif newState == self.MultiLinesComment or newState == self.MultiLinesComment_End:
                level = LEVELBASE + 1
            else:
                level = LEVELBASE

            SCI(SETFOLDLEVEL, index, level)

            pos = SCI(QsciScintilla.SCI_GETLINEENDPOSITION, index)
            prevState = SCI(QsciScintilla.SCI_GETSTYLEAT, pos)

            index += 1
        
