import re
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import PyQt4.QtCore as QtCore
import ui_newsimulationwizard
import string
import sys
import os.path


MAC = "qt_mac_set_native_menubar" in dir()

# # Can be used for advanced editing in the Model Editor.
# class FreezeDelegate(QItemDelegate):

    # def __init__(self, parent=None):
        # QItemDelegate.__init__(self, parent)
        
    # def createEditor(self, parent, option, index):
        # # Create editor object of QLineEdit
        # if index.column() == 1:
            # editor = QCheckBox(parent)
            # self.connect(editor, SIGNAL("returnPressed()"), self.commitAndCloseEditor)
            # return editor
        # else:
            # return QItemDelegate.createEditor(self, parent, option, index)

    # def commitAndCloseEditor(self):
        # editor = self.sender()
        # if isinstance(editor, (QLineEdit)):
            
            # # self.emit(SIGNAL("commitData(QWidget*)"), editor)
            # self.emit(SIGNAL("closeEditor(QWidget*)"), editor)

    # def setEditorData(self, editor, index):
        # text = index.model().data(index, Qt.DisplayRole).toString()
        # if index.column() == 1:
            # editor.setText(text)
        # else:
            # QItemDelegate.setEditorData(self, editor, index)
    
    # def setModelData(self, editor, model, index):
        # # Method uses model.setData()! 
        # # Make sure that you implemented setData() method
        # if index.column() == 1:
            # model.setData(index, QVariant(editor.text()))
        # else:
            # QItemDelegate.setModelData(self, editor, model, index)


class NewSimulationWizard(QWizard,ui_newsimulationwizard.Ui_NewSimulationWizard):
    #signals
    # gotolineSignal = QtCore.pyqtSignal( ('int',))
    
    def __init__(self,parent=None):
        super(NewSimulationWizard, self).__init__(parent)
        self.cc3dProjectTreeWidget=parent
        self.plugin = self.cc3dProjectTreeWidget.plugin
        # there are issues with Drawer dialog not getting focus when being displayed on linux
        # they are also not positioned properly so, we use "regular" windows 
        if sys.platform.startswith('win'): 
            self.setWindowFlags(Qt.Drawer) # dialogs without context help - only close button exists
        # self.gotolineSignal.connect(self.editorWindow.goToLine)
        
        self.mainProjDir=""
        self.simulationFilesDir=""
        
        
        self.projectPath=""
        self.setupUi(self)
        #This dictionary holds references to certain pages e.g. plugin configuration pages are inserten on demand and access to those pages is facilitated via self.pageDict
        self.pageDict={}
        self.updateUi()
        
        
        
    def keyPressEvent(self, event):            
        
        if self.currentPage()==self.pageDict["CellType"][0]:
            cellType=str(self.cellTypeLE.text())
            cellType=string.rstrip(cellType)
        
            if event.key()==Qt.Key_Return :
                if cellType!="":
                    self.on_cellTypeAddPB_clicked()
                    event.accept()
                else:
                    nextButton=self.button(QWizard.NextButton)
                    nextButton.emit(SIGNAL("clicked(bool)") , True)
                    
        elif self.currentPage()==self.pageDict["ContactMultiCad"][0]:
            cadherin=str(self.cmcMoleculeLE.text())
            cadherin=string.rstrip(cadherin)
            if event.key()==Qt.Key_Return :
                if cadherin!="":
                    self.on_cmcMoleculeAddPB_clicked()
                    event.accept()
                else:
                    nextButton=self.button(QWizard.NextButton)
                    nextButton.emit(SIGNAL("clicked(bool)") , True)
        elif self.currentPage()==self.pageDict["AdhesionFlex"][0]:
            molecule=str(self.afMoleculeLE.text())
            molecule=string.rstrip(molecule)
            if event.key()==Qt.Key_Return :
                if molecule!="":
                    self.on_afMoleculeAddPB_clicked()
                    event.accept()
                else:
                    nextButton=self.button(QWizard.NextButton)
                    nextButton.emit(SIGNAL("clicked(bool)") , True)
            
        elif self.currentPage()==self.pageDict["FinalPage"][0]: # last page
            if event.key()==Qt.Key_Return:
                finishButton=self.button(QWizard.FinishButton)
                finishButton.emit(SIGNAL("clicked(bool)") , True)            
        else:
            if event.key()==Qt.Key_Return:
                # move to the next page
                nextButton=self.button(QWizard.NextButton)
                print "nextButton=",nextButton
                nextButton.emit(SIGNAL("clicked(bool)") , True)
            # nextButton.emit(clicked,True)
            
            pass
            
        # event.ignore()

    # @pyqtSignature("") # signature of the signal emited by the button
    # def on_okButton_clicked(self):
        # self.findChangedConfigs()        
        # self.close()

    @pyqtSignature("") # signature of the signal emited by the button
    def on_cellTypeAddPB_clicked(self):
        
        cellType=str(self.cellTypeLE.text())
        cellType=string.rstrip(cellType)
        rows=self.cellTypeTable.rowCount()
        if cellType =="":
            return
            
        # check if cell type with this name already exist               
        cellTypeAlreadyExists=False
        for rowId in range(rows):
            
            name=str(self.cellTypeTable.item(rowId,0).text())
            name=string.rstrip(name)
            print "CHECKING name=",name+"1"," type=",cellType+"1"
            print "name==cellType ",name==cellType
            if name==cellType:
                cellTypeAlreadyExists=True
                break
        print "cellTypeAlreadyExists=",cellTypeAlreadyExists
        if cellTypeAlreadyExists:
            print "WARNING"
            QMessageBox.warning(self,"Cell type name already exists","Cell type name already exist. Please choose different name",QMessageBox.Ok)
            return
            
        self.cellTypeTable.insertRow(rows)        
        cellTypeItem=QTableWidgetItem(cellType)
        self.cellTypeTable.setItem (rows,0,  cellTypeItem)
        
        cellTypeFreezeItem=QTableWidgetItem()
        cellTypeFreezeItem.data(Qt.CheckStateRole)
        if self.freezeCHB.isChecked():
            
            cellTypeFreezeItem.setCheckState(Qt.Checked)
        else:
            cellTypeFreezeItem.setCheckState(Qt.Unchecked)
            
        self.cellTypeTable.setItem (rows,1,  cellTypeFreezeItem)
        # reset cell type entry line
        self.cellTypeLE.setText("")
        return 
        
    @pyqtSignature("") # signature of the signal emited by the button
    def on_clearCellTypeTablePB_clicked(self):
    
        rows=self.cellTypeTable.rowCount()
        for i in range (rows-1,-1,-1):
            self.cellTypeTable.removeRow(i)
        
        
        #insert Medium    
        self.cellTypeTable.insertRow(0)        
        mediumItem=QTableWidgetItem("Medium")
        self.cellTypeTable.setItem (0,0,  mediumItem)
        mediumFreezeItem=QTableWidgetItem()        
        mediumFreezeItem.data(Qt.CheckStateRole)
        mediumFreezeItem.setCheckState(Qt.Unchecked)
        self.cellTypeTable.setItem (0,1,  mediumFreezeItem)
                
    @pyqtSignature("") # signature of the signal emited by the button    
    def on_afMoleculeAddPB_clicked(self):
        
        molecule=str(self.afMoleculeLE.text())
        molecule=string.rstrip(molecule)
        rows=self.afTable.rowCount()
        if molecule =="":
            return

        # check if molecule with this name already exist               
        moleculeAlreadyExists=False
        for rowId in range(rows):
            name=str(self.afTable.item(rowId,0).text())
            name=string.rstrip(name)
            if name==molecule:
                moleculeAlreadyExists=True
                break
        
        if moleculeAlreadyExists:
            QMessageBox.warning(self,"Molecule Name Already Exists","Molecule name already exist. Please choose different name",QMessageBox.Ok)
            return
            
        self.afTable.insertRow(rows)        
        moleculeItem=QTableWidgetItem(molecule)
        self.afTable.setItem (rows,0,  moleculeItem)
        
        # reset molecule entry line
        self.afMoleculeLE.setText("")
        return 
        
    @pyqtSignature("") # signature of the signal emited by the button
    def on_clearAFTablePB_clicked(self):
        rows=self.afTable.rowCount()
        for i in range (rows-1,-1,-1):
            self.afTable.removeRow(i)
            
            
    @pyqtSignature("") # signature of the signal emited by the button    
    def on_cmcMoleculeAddPB_clicked(self):        
        cadherin=str(self.cmcMoleculeLE.text())
        cadherin=string.rstrip(cadherin)
        rows=self.cmcTable.rowCount()
        if cadherin =="":
            return
            
        # check if cadherin with this name already exist               
        cadherinAlreadyExists=False
        for rowId in range(rows):
            name=str(self.cmcTable.item(rowId,0).text())
            name=string.rstrip(name)
            if name==cadherin:
                cadherinAlreadyExists=True
                break
        
        if cadherinAlreadyExists:
            QMessageBox.warning(self,"Cadherin Name Already Exists","Cadherin name already exist. Please choose different name",QMessageBox.Ok)
            return
            
        self.cmcTable.insertRow(rows)        
        cadherinItem=QTableWidgetItem(cadherin)
        self.cmcTable.setItem (rows,0,  cadherinItem)
        
        # reset cadherin entry line
        self.cmcMoleculeLE.setText("")
        
        return 
    @pyqtSignature("") # signature of the signal emited by the button
    def on_clearCMCTablePB_clicked(self):
        rows=self.cmcTable.rowCount()
        for i in range (rows-1,-1,-1):
            self.cmcTable.removeRow(i)

    @pyqtSignature("") # signature of the signal emited by the button
    def on_plotAddPB_clicked(self):
        
        plotName=str(self.plotLE.text())
        plotName=string.rstrip(plotName)
        
        plotType=str(self.plotTypeCB.currentText())
        plotType=string.rstrip(plotType)

        if plotName =="":
            return
        
        # check if plot with this name already exist               
        rows=self.plotTable.rowCount()
        
        plotAlreadyExists=False
        for rowId in range(rows):
            name=str(self.plotTable.item(rowId,0).text())
            name=string.rstrip(name)
            if name==plotName:
                plotAlreadyExists=True
                break
        
        if plotAlreadyExists:
            QMessageBox.warning(self,"Plot name already exists","Plot name already exist. Please choose different name",QMessageBox.Ok)
            return
        
        
            
        self.plotTable.insertRow(rows)        
        plotNameItem=QTableWidgetItem(plotName)
        self.plotTable.setItem (rows,0,  plotNameItem)
        
        plotTypeItem=QTableWidgetItem(plotType)
        self.plotTable.setItem (rows,1,  plotTypeItem)
        
            
        
        # reset cell type entry line
        self.plotLE.setText("")
        return 

    @pyqtSignature("") # signature of the signal emited by the button
    def on_clearPlotTablePB_clicked(self):
        rows=self.plotTable.rowCount()
        for i in range (rows-1,-1,-1):
            self.plotTable.removeRow(i)

            
    @pyqtSignature("") # signature of the signal emited by the button        
    def on_dirPB_clicked(self):
        name=str(self.nameLE.text())
        name=string.rstrip(name)
        
        projDir=self.plugin.configuration.setting("RecentNewProjectDir")
        
        if name!="":
            dir=QFileDialog.getExistingDirectory(self,"Specify Location for your project",projDir)
            self.plugin.configuration.setSetting("RecentNewProjectDir",dir)
            self.dirLE.setText(dir)
        # else:
            # QMessageBox.information(self,"Project Name Missing","Please specify project name first",QMessageBox.Ok)
        
    # @pyqtSignature("") # signature of the signal emited by the button
    # def on_cellTypeLE_returnPressed(self):
        # print "GOT ENTER EVENT"
        # self.on_cellTypeAddPB_clicked()
    
        
    #initialize properties dialog
    def updateUi(self):
        # Multi cad plugin is being deprecated
        self.contactMultiCadCHB.setEnabled(False)
    
        # have to set base size in QDesigner and then read it to rescale columns. For some reason reading size of the widget does not work properly
        pageIds=self.pageIds()        
        self.pageDict["FinalPage"]=[self.page(pageIds[-1]),len(pageIds)-1]
        self.pageDict["CellType"]=[self.page(1),1]                
        self.pageDict["AdhesionFlex"]=[self.page(3),3]        
        self.pageDict["ContactMultiCad"]=[self.page(4),4]
        self.pageDict["PythonScript"]=[self.page(5),5]
        
        self.removePage(3)
        self.removePage(4)
        self.removePage(5)
        
        self.nameLE.selectAll()
        projDir=self.plugin.configuration.setting("RecentNewProjectDir")
        print "projDir=",projDir
        if str(projDir)=="":
            projDir=os.environ["PREFIX_CC3D"]
        self.dirLE.setText(projDir)    
        
        # self.cellTypeLE.setFocus(True)
        self.cellTypeTable.insertRow(0)        
        mediumItem=QTableWidgetItem("Medium")
        self.cellTypeTable.setItem (0,0,  mediumItem)
        mediumFreezeItem=QTableWidgetItem()        
        mediumFreezeItem.data(Qt.CheckStateRole)
        mediumFreezeItem.setCheckState(Qt.Unchecked)
        self.cellTypeTable.setItem (0,1,  mediumFreezeItem)

        baseSize=self.cellTypeTable.baseSize()
        self.cellTypeTable.setColumnWidth (0,baseSize.width()/2)
        self.cellTypeTable.setColumnWidth (1,baseSize.width()/2)
        self.cellTypeTable.horizontalHeader().setStretchLastSection(True)
        
        # AF molecule table
        self.afTable.horizontalHeader().setStretchLastSection(True)
        
        # CMC cadherin table
        self.cmcTable.horizontalHeader().setStretchLastSection(True)
        
        # plotTypeTable
        baseSize=self.plotTable.baseSize()
        self.plotTable.setColumnWidth (0,baseSize.width()/2)
        self.plotTable.setColumnWidth (1,baseSize.width()/2)
        self.plotTable.horizontalHeader().setStretchLastSection(True)

        
        # self.cellTypeTable.insertRow(0)
        # self.cellTypeTable.horizontalHeader().resizeSections(QHeaderView.Interactive)
        # self.cellTypeTable.horizontalHeader().setStretchLastSection(True)
        
        width=self.cellTypeTable.horizontalHeader().width()
        print "column 0 width=",self.cellTypeTable.horizontalHeader().sectionSize(0)
        print "column 1 width=",self.cellTypeTable.horizontalHeader().sectionSize(1)
        
        # width=self.cellTypeTable.width()
        print "size=",self.cellTypeTable.size()
        print "baseSize=",self.cellTypeTable.baseSize()
        
        print "width=",width
        print "column width=",self.cellTypeTable.columnWidth(0)
        # self.cellTypeTable.setColumnWidth (0,200/2)
        # self.cellTypeTable.setColumnWidth (1,200/2)
        # return
        
    def insertModulePage(self,_page):
        # get FinalPage id
        finalId=-1
        pageIds=self.pageIds()
        for id in pageIds:
            if self.page(id)==self.pageDict["FinalPage"]:
                finalId=id
                break
        if  finalId ==-1:
            print "COULD NOT INSERT PAGE  COULD NOT FIND LAST PAGE "
            return
        print "FinalId=",finalId
        
        self.setPage(finalId-1,_page)
        
    def removeModulePage(self,_page):
    
        pageIds=self.pageIds()
        for id in pageIds:
            if self.page(id)==_page:
                self.removePage(id)
                break
        
    def validateCurrentPage(self):
        
        print "THIS IS VALIDATE FOR PAGE ",self.currentId
        if self.currentId()==0:
            dir=str(self.dirLE.text())
            dir=string.rstrip(dir)
            name=str(self.nameLE.text())
            name=string.rstrip(name)
            if self.xmlRB.isChecked():
                self.removePage(self.pageDict["PythonScript"][1])
            else:
                self.setPage(self.pageDict["PythonScript"][1],self.pageDict["PythonScript"][0])
                
            if dir=="" or name=="":        
                QMessageBox.warning(self,"Missing information","Please specify name of the simulation and directory where it should be written to",QMessageBox.Ok)
                return False
            else:
                if dir!="":            
                    self.plugin.configuration.setSetting("RecentNewProjectDir",dir)            
        
            
                return True
        if self.currentId()==2:
            print self.pageDict
            if self.contactMultiCadCHB.isChecked():
                self.setPage(self.pageDict["ContactMultiCad"][1],self.pageDict["ContactMultiCad"][0])
                # self.insertModulePage(self.pageDict["ContactMultiCad"])
                # self.setPage(3,self.pageDict["ContactMultiCad"])
            else:
                self.removePage(self.pageDict["ContactMultiCad"][1])
                # self.removeModulePage(self.pageDict["ContactMultiCad"])
                # pageIds=self.pageIds()
                # for id in pageIds:
                    # if self.page(id)==self.pageDict["ContactMultiCad"]:
                        # self.removePage(id)
        
            if self.adhesionFlexCHB.isChecked():
                self.setPage(self.pageDict["AdhesionFlex"][1],self.pageDict["AdhesionFlex"][0])
                # self.insertModulePage(self.pageDict["AdhesionFlex"])
                # self.setPage(3,self.pageDict["AdhesionFlex"])
            else:
                self.removePage(self.pageDict["AdhesionFlex"][1])
                # self.removeModulePage(self.pageDict["AdhesionFlex"])            
                # pageIds=self.pageIds()
                # for id in pageIds:
                    # if self.page(id)==self.pageDict["AdhesionFlex"]:
                        # self.removePage(id)

            
            return True
            
        if self.currentPage() == self.pageDict["ContactMultiCad"][0]:  
            if not self.cmcTable.rowCount():
                QMessageBox.warning(self,"Missing information","Please specify at least one cadherin name to be used in ContactMultiCad plugin",QMessageBox.Ok)
                return False
            else:
                return True
            
        if self.currentPage() == self.pageDict["AdhesionFlex"][0]:  
            if not self.afTable.rowCount():
                QMessageBox.warning(self,"Missing information","Please specify at least one adhesion molecule name to be used in AdhesionFlex plugin",QMessageBox.Ok)
                return False
            else:
                return True
            
            
        return True
        
    def makeProjectDirectories(self,dir,name):
        
        try:
            self.mainProjDir=os.path.join(dir,name)
            self.plugin.makeDirectory(self.mainProjDir)
            self.simulationFilesDir=os.path.join(self.mainProjDir,"Simulation")
            self.plugin.makeDirectory(self.simulationFilesDir)
            
        except IOError,e:
            raise IOError
        return
        
    def generateNewProject(self):    
        dir=str(self.dirLE.text())
        dir=os.path.abspath(dir)
        dir=string.rstrip(dir)
        name=str(self.nameLE.text())        
        name=string.rstrip(name)
        
        print "name=",name," dir=",dir
        
        typeTable=[]
        
        self.makeProjectDirectories(dir,name)
        # extract cell type information form the table
        for row in range(self.cellTypeTable.rowCount()):
            type=str(self.cellTypeTable.item(row,0).text())
            freeze=False
            if self.cellTypeTable.item(row,1).checkState()==Qt.Checked:
                print "self.cellTypeTable.item(row,1).checkState()=",self.cellTypeTable.item(row,1).checkState()
                freeze=True
            typeTable.append([type,freeze])
        
        afTable=[]
        for row in range(self.afTable.rowCount()):
            molecule=str(self.afTable.item(row,0).text())
            afTable.append(molecule)
            
        formula=str(self.bindingFormulaLE.text())
        formula=string.rstrip(formula)            
        
        
        cmcTable=[]
        for row in range(self.cmcTable.rowCount()):
            cadherin=str(self.cmcTable.item(row,0).text())
            cmcTable.append(cadherin)
        
        plotTypeTable=[]
        for row in range(self.plotTable.rowCount()):
            plotName=str(self.plotTable.item(row,0).text())
            plotName=string.rstrip(plotName)
            
            plotType=str(self.plotTable.item(row,1).text())
            plotType=string.rstrip(plotType)
            plotTypeTable.append([plotName,plotType])
            
        # constructing Project XMl Element        
        
        from XMLUtils import ElementCC3D
        simulationElement=ElementCC3D("Simulation",{"version":"3.5.1"})
        

            
        if self.pythonXMLRB.isChecked() or self.xmlRB.isChecked():
            #generate XML ------------------------------------------------------------------------------------
            from CC3DXMLGenerator import CC3DXMLGenerator
            xmlGenerator=CC3DXMLGenerator(self.simulationFilesDir,name)
            xmlGenerator.setCellTypeTable(typeTable)
            xmlGenerator.setAFTable(afTable)
            xmlGenerator.setCMCTable(cmcTable)
            xmlGenerator.setAFFormula(formula)
            
            
            self.generateXML(xmlGenerator)
            simulationElement.ElementCC3D("XMLScript",{"Type":"XMLScript"},self.getRelativePathWRTProjectDir(xmlGenerator.fileName))
            #end of generate XML ------------------------------------------------------------------------------------
            
        if self.pythonXMLRB.isChecked():
            #generate Python ------------------------------------------------------------------------------------
            from CC3DPythonGenerator import CC3DPythonGenerator
            pythonGenerator=CC3DPythonGenerator(self.simulationFilesDir,name)
            
            pythonGenerator.setPlotTypeTable(plotTypeTable)
            
            if self.dictCB.isChecked():
                pythonGenerator.attachDictionary=True
            if self.listCB.isChecked():
                pythonGenerator.attachList=True
                
            pythonGenerator.generateMainPythonScript()
            simulationElement.ElementCC3D("PythonScript",{"Type":"PythonScript"},self.getRelativePathWRTProjectDir(pythonGenerator.mainPythonFileName))            
            pythonGenerator.generateSteppablePythonScript()
            simulationElement.ElementCC3D("Resource",{"Type":"Python"},self.getRelativePathWRTProjectDir(pythonGenerator.steppablesPythonFileName))            
            #end of generate Python ------------------------------------------------------------------------------------
            
        if self.pythonOnlyRB.isChecked():
            #generate Python ------------------------------------------------------------------------------------        
            from CC3DPythonGenerator import CC3DPythonGenerator
            pythonGenerator=CC3DPythonGenerator(self.simulationFilesDir,name)
            
            
            
            pythonGenerator.setCellTypeTable(typeTable)            
            pythonGenerator.setPlotTypeTable(plotTypeTable)
            
            if self.dictCB.isChecked():
                pythonGenerator.attachDictionary=True
            if self.listCB.isChecked():
                pythonGenerator.attachList=True
                
            self.generatePythonConfigureSim(pythonGenerator)    
            
            pythonGenerator.generateMainPythonScript()
            simulationElement.ElementCC3D("PythonScript",{"Type":"PythonScript"},self.getRelativePathWRTProjectDir(pythonGenerator.mainPythonFileName))            
            pythonGenerator.generateSteppablePythonScript()
            simulationElement.ElementCC3D("Resource",{"Type":"Python"},self.getRelativePathWRTProjectDir(pythonGenerator.steppablesPythonFileName))            
            #end of generate Python ------------------------------------------------------------------------------------
        
        # save Project file
        projFileName=os.path.join(self.mainProjDir,name+".cc3d")
        simulationElement.CC3DXMLElement.saveXML(projFileName)
        #open newly created project in the ProjectEditor
        self.plugin.openCC3Dproject(projFileName)

    def generatePythonConfigureSim(self,pythonGenerator):
        pythonGenerator.generateConfigureSimulationHeader()
        pythonGenerator.generatePottsSection()        
        pythonGenerator.generateCellTypePlugin()
        
        if self.contactCHB.isChecked():
            pythonGenerator.generateContactPlugin()
        if self.compartmentCHB.isChecked():
            pythonGenerator.generateCompartmentPlugin()
        if self.contactLocalProductCHB.isChecked():
            pythonGenerator.generateContactLocalProductPlugin()
        if self.contactMultiCadCHB.isChecked():
            pythonGenerator.generateContactMultiCadPlugin()
        if self.adhesionFlexCHB.isChecked():
            pythonGenerator.generateAdhesionFlexPlugin()
        if self.volumeFlexCHB.isChecked():
            pythonGenerator.generateVolumeFlexPlugin()
        if self.surfaceFlexCHB.isChecked():
            pythonGenerator.generateSurfaceFlexPlugin()
    
        pythonGenerator.generateUniformInitializerSteppable()
        
    def generateXML(self,xmlGenerator):

        xmlGenerator.generatePottsSection()        
        xmlGenerator.generateCellTypePlugin()
        
        if self.contactCHB.isChecked():
            xmlGenerator.generateContactPlugin()
        if self.compartmentCHB.isChecked():
            xmlGenerator.generateCompartmentPlugin()
        if self.contactLocalProductCHB.isChecked():
            xmlGenerator.generateContactLocalProductPlugin()
        if self.contactMultiCadCHB.isChecked():
            xmlGenerator.generateContactMultiCadPlugin()
        if self.adhesionFlexCHB.isChecked():
            xmlGenerator.generateAdhesionFlexPlugin()
        if self.volumeFlexCHB.isChecked():
            xmlGenerator.generateVolumeFlexPlugin()
        if self.surfaceFlexCHB.isChecked():
            xmlGenerator.generateSurfaceFlexPlugin()
        
        xmlGenerator.generateUniformInitializerSteppable()
        
        xmlGenerator.saveCC3DXML()
        #end of generate XML ------------------------------------------------------------------------------------
        
    def findRelativePathSegments(self,basePath,p, rest=[]):
    
        """
            This function finds relative path segments of path p with respect to base path    
            It returns list of relative path segments and flag whether operation succeeded or not    
        """
        
        h,t = os.path.split(p)
        pathMatch=False
        if h==basePath:
            pathMatch=True
            return [t]+rest,pathMatch
        print "(h,t,pathMatch)=",(h,t,pathMatch)
        if len(h) < 1: return [t]+rest,pathMatch
        if len(t) < 1: return [h]+rest,pathMatch
        return self.findRelativePathSegments(basePath,h,[t]+rest)
        
    def findRelativePath(self,basePath,p):
        relativePathSegments,pathMatch=self.findRelativePathSegments(basePath,p)
        if pathMatch:
            relativePath=""
            for i in range(len(relativePathSegments)):
                segment=relativePathSegments[i]
                relativePath+=segment
                if i !=len(relativePathSegments)-1:
                    relativePath+="/" # we use unix style separators - they work on all (3) platforms
            return relativePath
        else:
            return p   
            
    def getRelativePathWRTProjectDir(self,path):
        return self.findRelativePath(self.mainProjDir,path)
             
    
        