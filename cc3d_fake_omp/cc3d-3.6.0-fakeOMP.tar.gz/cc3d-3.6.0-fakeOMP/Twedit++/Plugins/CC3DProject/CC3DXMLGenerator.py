from XMLUtils import ElementCC3D
import os.path

class CC3DXMLGenerator:
    def __init__(self,simulationDir,simulationName):
        self.simulationDir=simulationDir
        self.simulationName=simulationName
        
        
        self.fileName=os.path.join(str(self.simulationDir),str(self.simulationName)+".xml")
        
        self.cellTypeTable=[["Medium",False]]
        self.cc3d=ElementCC3D("CompuCell3D",{"version":"3.6.0"})
        self.afMolecules=[]
        self.afFormula='min(Molecule1,Molecule2)'
        self.cmcCadherins=[]

    def setCMCTable(self,_table):
        self.cmcCadherins=_table

    def setAFFormula(self,_formula):        
        self.afFormula=_formula
        
    def setAFTable(self,_table):
        self.afMolecules=_table
        
    def setCellTypeTable(self,_table):
        self.cellTypeTable=_table
        #generate typeId to typeTuple lookup dictionary
        
        self.idToTypeTupleDict={}
        typeCounter=0
        
        for typeTupple in self.cellTypeTable:
            self.idToTypeTupleDict[typeCounter]=typeTupple            
            typeCounter+=1
            
    def generatePottsSection(self):
        potts=self.cc3d.ElementCC3D("Potts")
        potts.ElementCC3D("Dimensions",{"x":100,"y":100,"z":1})
        potts.ElementCC3D("Steps",{},1000)
        potts.ElementCC3D("Temperature",{},10)
        potts.ElementCC3D("NeighborOrder",{},2)    
        
    def generateCellTypePlugin(self):
        cellTypePluginElement=self.cc3d.ElementCC3D("Plugin",{"Name":"CellType"})
        for id, typeTuple in self.idToTypeTupleDict.iteritems():
            dict={}
            dict["TypeName"]=typeTuple[0]

            dict["TypeId"]=str(id)
            if typeTuple[1]:
                dict["Freeze"]=""
            cellTypePluginElement.ElementCC3D("CellType", dict)

    def generateContactPlugin(self):
        contactPluginElement=self.cc3d.ElementCC3D("Plugin",{"Name":"Contact"})
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                contactPluginElement.ElementCC3D("Energy",dict,10)
                
        contactPluginElement.ElementCC3D("NeighborOrder",{},2)        
            
            
    def generateCompartmentPlugin(self):
        compratmentPluginElement=self.cc3d.ElementCC3D("Plugin",{"Name":"ContactCompartment"})
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                compratmentPluginElement.ElementCC3D("Energy",dict,10)

        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                compratmentPluginElement.ElementCC3D("InternalEnergy",dict,5)
                
        compratmentPluginElement.ElementCC3D("NeighborOrder",{},2)        

        
    def generateContactLocalProductPlugin(self):
        clpPluginElement=self.cc3d.ElementCC3D("Plugin",{"Name":"ContactLocalProduct"})
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                clpPluginElement.ElementCC3D("ContactSpecificity",dict,-1)
                
        clpPluginElement.ElementCC3D("ContactFunctionType",{},"linear")
        
        clpPluginElement.ElementCC3D("EnergyOffset",{},0.0)                        
        clpPluginElement.ElementCC3D("NeighborOrder",{},2)        
        
    def generateContactMultiCadPlugin(self):
        cmcPluginElement=self.cc3d.ElementCC3D("Plugin",{"Name":"ContactMultiCad"})
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                cmcPluginElement.ElementCC3D("Energy",dict,10)
                
        specificityCadherinElement=cmcPluginElement.ElementCC3D("SpecificityCadherin")                        
        
        cadMax=len(self.cmcCadherins)
        for cad1 in range(cadMax):
            for cad2 in range(cad1,cadMax):
                
                dict={"Cadherin1":self.cmcCadherins[cad1],"Cadherin2":self.cmcCadherins[cad2]}            
                specificityCadherinElement.ElementCC3D("Specificity",dict,-1)
                
        cmcPluginElement.ElementCC3D("ContactFunctionType",{},"linear")
        cmcPluginElement.ElementCC3D("EnergyOffset",{},0.0)                        
        cmcPluginElement.ElementCC3D("NeighborOrder",{},2)        
        
    def generateAdhesionFlexPlugin(self):
        afPluginElement=self.cc3d.ElementCC3D("Plugin",{"Name":"AdhesionFlex"})
        maxId=max(self.idToTypeTupleDict.keys())
        # listing adhesion molecules
        for molecule in self.afMolecules:
            afPluginElement.ElementCC3D("AdhesionMolecule",{"Molecule":molecule})
            
        for id1 in range(0,maxId+1):
            for molecule in self.afMolecules:
                afPluginElement.ElementCC3D("AdhesionMoleculeDensity",{"CellType":self.idToTypeTupleDict[id1][0],  "Molecule":molecule,"Density":0.8})
                
        formulaElement=afPluginElement.ElementCC3D("BindingFormula",{"Name":"Binary"})    
        formulaElement.ElementCC3D("Formula",{},self.afFormula)
        variablesElement=formulaElement.ElementCC3D("Variables")
        aimElement=variablesElement.ElementCC3D("AdhesionInteractionMatrix")
        
        moleculeMax=len(self.afMolecules)        
        for molecule1 in range(moleculeMax):
            for molecule2 in range(molecule1,moleculeMax):
                dict={"Molecule1":self.afMolecules[molecule1],"Molecule2":self.afMolecules[molecule2]}
                aimElement.ElementCC3D("BindingParameter",dict,-1.0)
            
        afPluginElement.ElementCC3D("NeighborOrder",{},2)        

    def generateVolumeFlexPlugin(self):
        vfElement=self.cc3d.ElementCC3D("Plugin",{"Name":"Volume"})
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            if self.idToTypeTupleDict[id1][0]=="Medium":
                continue
            dict={"CellType":self.idToTypeTupleDict[id1][0],"TargetVolume":25,"LambdaVolume":2.0}    
            vfElement.ElementCC3D("VolumeEnergyParameters",dict)    
        
    def generateSurfaceFlexPlugin(self):
        sfElement=self.cc3d.ElementCC3D("Plugin",{"Name":"Surface"})
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            if self.idToTypeTupleDict[id1][0]=="Medium":
                continue
            dict={"CellType":self.idToTypeTupleDict[id1][0],"TargetSurface":20,"LambdaSurface":0.5}    
            sfElement.ElementCC3D("SurfaceEnergyParameters",dict)    
        
    def generateUniformInitializerSteppable(self):
        uiElement=self.cc3d.ElementCC3D("Steppable",{"Type":"UniformInitializer"})
        region=uiElement.ElementCC3D("Region")
        region.ElementCC3D("BoxMin",{"x":20,"y":20,"z":0})
        region.ElementCC3D("BoxMax",{"x":80,"y":80,"z":1})
        region.ElementCC3D("Gap",{},0)
        region.ElementCC3D("Width",{},5)
        typesString=""
        
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            if self.idToTypeTupleDict[id1][0]=="Medium":
                continue
                
            typesString+=self.idToTypeTupleDict[id1][0]
            if id1<maxId:
                typesString+=","
            
        region.ElementCC3D("Types",{},typesString)
        
    def saveCC3DXML(self):
        
        self.cc3d.CC3DXMLElement.saveXML(str(self.fileName)) 
        print "SAVING XML = ",self.fileName