import os.path
import sys
import string

class CC3DPythonGenerator:
    def __init__(self,simulationDir,simulationName):
        self.simulationDir=simulationDir
        self.simulationName=simulationName
        
        
        self.mainPythonFileName=os.path.join(str(self.simulationDir),str(self.simulationName)+".py")
        self.steppablesPythonFileName=os.path.join(str(self.simulationDir),str(self.simulationName)+"Steppables.py")        
        
        self.configureSimLines=''
        
        self.attachDictionary=False
        self.attachList=False
        self.plotTypeTable=[]
        self.pythonPlotsLines=''
        
        
        self.cellTypeTable=[["Medium",False]]
        self.afMolecules=[]
        self.afFormula='min(Molecule1,Molecule2)'
        self.cmcCadherins=[]        
        
    def setCMCTable(self,_table):
        self.cmcCadherins=_table

    def setAFFormula(self,_formula):        
        self.afFormula=_formula
        
    def setAFTable(self,_table):
        self.afMolecules=_table
        
    def setCellTypeTable(self,_table):
        self.cellTypeTable=_table
        #generate typeId to typeTuple lookup dictionary
        
        self.idToTypeTupleDict={}
        typeCounter=0
        
        for typeTupple in self.cellTypeTable:
            self.idToTypeTupleDict[typeCounter]=typeTupple            
            typeCounter+=1
            
    def setPlotTypeTable(self,_table):
        self.plotTypeTable=_table
        
        if not len(self.plotTypeTable):
            return
        
        self.pythonPlotsLines='''
# -------------- extra fields  -------------------      
dim=sim.getPotts().getCellFieldG().getDim()        
        '''
        for plotTupple in self.plotTypeTable:
            plotName=plotTupple[0]
                
            plotType=plotTupple[1]
            if plotType=="ScalarField":
                fieldLines='''
%sField=simthread.createFloatFieldPy(dim,"%s")                
                ''' %(plotName,plotName)
                self.pythonPlotsLines+=fieldLines
                
            elif plotType=="CellLevelScalarField":
                fieldLines='''
%sField=simthread.createScalarFieldCellLevelPy("%s")                
                ''' %(plotName,plotName)
                self.pythonPlotsLines+=fieldLines
                
            elif plotType=="VectorField":
                fieldLines='''
%sField=simthread.createVectorFieldPy(dim,"%s") 
                ''' %(plotName,plotName)
                self.pythonPlotsLines+=fieldLines
                
            elif plotType=="CellLevelVectorField":
                fieldLines='''
%sField=simthread.createVectorFieldCellLevelPy("%s") 
                ''' %(plotName,plotName)
                self.pythonPlotsLines+=fieldLines
                
        self.pythonPlotsLines+='''
# --------------end of extra fields  -------------------      

        '''
        
    def generateMainPythonScript(self):
        file=open(self.mainPythonFileName,"w")
        print "self.pythonPlotsLines=",self.pythonPlotsLines
        header=''
        
        if self.configureSimLines!='':
            header+=self.configureSimLines
            header+='''
            
    CompuCellSetup.setSimulationXMLDescription(cc3d)
            '''
            
            
            
        header+='''
import sys
from os import environ
from os import getcwd
import string

sys.path.append(environ["PYTHON_MODULE_PATH"])


import CompuCellSetup


sim,simthread = CompuCellSetup.getCoreSimulationObjects()
        '''
        if self.configureSimLines!='':
            header+='''
configureSimulation(sim)            
            '''
        header+='''    
# add extra attributes here
        '''
        attachListLine='''
pyAttributeListAdder,listAdder=CompuCellSetup.attachListToCells(sim)
        '''
        attachDicttionaryLine='''
pyAttributeDictionaryAdder,dictAdder=CompuCellSetup.attachDictionaryToCells(sim)
        '''
        
        initSimObjectLine='''    
CompuCellSetup.initializeSimulationObjects(sim,simthread)
# Definitions of additional Python-managed fields go here
        '''
        steppableRegistryLine='''
#Add Python steppables here
steppableRegistry=CompuCellSetup.getSteppableRegistry()
        '''
        steppableRegistrationLine='''
from %s import %s
steppableInstance=%s(sim,_frequency=100)
steppableRegistry.registerSteppable(steppableInstance)
        '''%(self.simulationName+"Steppables",self.simulationName+"Stetppable",self.simulationName+"Stetppable" )
        
        mainLoopLine='''
CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)
        
        '''
        script=header
        if self.attachDictionary:
            script+=attachDicttionaryLine
        if self.attachList:
            script+=attachListLine
            
        script+=initSimObjectLine
        
        if self.pythonPlotsLines!='':
            script+=self.pythonPlotsLines
            
        script+=steppableRegistryLine
        script+=steppableRegistrationLine
        script+=mainLoopLine
        
        file.write(script)
        file.close()
        
    def generateSteppablePythonScript(self):
        file=open(self.steppablesPythonFileName,"w")
        
        header='''
from PySteppables import *
import CompuCell
import sys
'''

        
        classDefinitionLine='''class %s(SteppableBasePy):'''%(self.simulationName+"Stetppable")
        steppableBody='''    

    def __init__(self,_simulator,_frequency=10):
        SteppableBasePy.__init__(self,_simulator,_frequency)
    def start(self):
        # any code in the start function runs before MCS=0
        pass
    def step(self,mcs):        
        #type here the code that will run every _frequency MCS
        for cell in self.cellList:
            print "cell.id=",cell.id
    def finish(self):
        # Finish Function gets called after the last MCS
        pass
        '''
        file.write(header)
        file.write(classDefinitionLine)
        file.write(steppableBody)
    
        file.close()    
        
    def setCellTypeTable(self,_table):
        self.cellTypeTable=_table
        #generate typeId to typeTuple lookup dictionary
        
        self.idToTypeTupleDict={}
        typeCounter=0
        
        for typeTupple in self.cellTypeTable:
            self.idToTypeTupleDict[typeCounter]=typeTupple            
            typeCounter+=1
            
    def generateConfigureSimulationHeader(self):
        self.configureSimLines+='''
def configureSimulation(sim):
    import CompuCellSetup
    from XMLUtils import ElementCC3D
    
    cc3d=ElementCC3D("CompuCell3D",{"version":"3.6.0"})    
        '''
        
        
    def generatePottsSection(self):
        self.configureSimLines+=''' 
        
    potts=cc3d.ElementCC3D("Potts")
    potts.ElementCC3D("Dimensions",{"x":100,"y":100,"z":1})
    potts.ElementCC3D("Steps",{},1000)
    potts.ElementCC3D("Temperature",{},10)
    potts.ElementCC3D("NeighborOrder",{},2)    
        '''
        
    def generateCellTypePlugin(self):
        self.configureSimLines+='''
        
    cellTypePluginElement=cc3d.ElementCC3D("Plugin",{"Name":"CellType"})'''
        for id, typeTuple in self.idToTypeTupleDict.iteritems():
            dict={}
            dict["TypeName"]=typeTuple[0]

            dict["TypeId"]=str(id)
            if typeTuple[1]:
                dict["Freeze"]=""
            
                
            dictString=''    
            entryCount=len(dict)
            if entryCount:
                dictString+='{'
            idx=0    
            
            for attrName, attrValue in dict.iteritems():
                
                dictString+='\"'+str(attrName)+'\"'+':'+'\"'+str(attrValue)+'\"'
                
                idx+=1
                if idx<entryCount:
                    dictString+=','
                
            
            if len(dict):
                dictString+='}'
                
                dictString=string.rstrip(dictString)    
                
            self.configureSimLines+='''    
    cellTypePluginElement.ElementCC3D("CellType", %s)'''%(dictString)        
        
    def generateContactPlugin(self):
        self.configureSimLines+='''
        
    contactPluginElement=cc3d.ElementCC3D("Plugin",{"Name":"Contact"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                # dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                
                self.configureSimLines+='''        
    contactPluginElement.ElementCC3D("Energy",{"Type1":"%s","Type2":"%s"},10)'''%(self.idToTypeTupleDict[id1][0],self.idToTypeTupleDict[id2][0])        
        
        self.configureSimLines+='''
    contactPluginElement.ElementCC3D("NeighborOrder",{},2)'''    
            
    def generateCompartmentPlugin(self):
        self.configureSimLines+='''
        
    compratmentPluginElement=cc3d.ElementCC3D("Plugin",{"Name":"ContactCompartment"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                self.configureSimLines+='''
    compratmentPluginElement.ElementCC3D("Energy",{"Type1":"%s","Type2":"%s"},10)'''%(self.idToTypeTupleDict[id1][0],self.idToTypeTupleDict[id2][0])
                

        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                self.configureSimLines+='''
    compratmentPluginElement.ElementCC3D("InternalEnergy",{"Type1":"%s","Type2":"%s"},5)'''%(self.idToTypeTupleDict[id1][0],self.idToTypeTupleDict[id2][0])
                
        self.configureSimLines+='''        
    compratmentPluginElement.ElementCC3D("NeighborOrder",{},2)
        '''

        
    def generateContactLocalProductPlugin(self):
        self.configureSimLines+='''
        
    clpPluginElement=cc3d.ElementCC3D("Plugin",{"Name":"ContactLocalProduct"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                self.configureSimLines+='''
    clpPluginElement.ElementCC3D("ContactSpecificity",{"Type1":"%s","Type2":"%s"},-1)'''%(self.idToTypeTupleDict[id1][0],self.idToTypeTupleDict[id2][0])
    
        self.configureSimLines+='''
        
    clpPluginElement.ElementCC3D("ContactFunctionType",{},"linear")
    
    clpPluginElement.ElementCC3D("EnergyOffset",{},0.0)                        
    clpPluginElement.ElementCC3D("NeighborOrder",{},2)        
        '''
        
    def generateContactMultiCadPlugin(self):
        self.configureSimLines+='''
        
    cmcPluginElement=cc3d.ElementCC3D("Plugin",{"Name":"ContactMultiCad"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            for id2 in range(id1,maxId+1):            
                dict={"Type1":self.idToTypeTupleDict[id1][0],"Type2":self.idToTypeTupleDict[id2][0]}            
                self.configureSimLines+='''                
    cmcPluginElement.ElementCC3D("Energy",{"Type1":"%s","Type2":"%s"},10)'''%(self.idToTypeTupleDict[id1][0],self.idToTypeTupleDict[id2][0])
        self.configureSimLines+='''
    specificityCadherinElement=cmcPluginElement.ElementCC3D("SpecificityCadherin")'''                        
        
        cadMax=len(self.cmcCadherins)
        for cad1 in range(cadMax):
            for cad2 in range(cad1,cadMax):                
                dict={"Cadherin1":self.cmcCadherins[cad1],"Cadherin2":self.cmcCadherins[cad2]}            
                self.configureSimLines+='''
                specificityCadherinElement.ElementCC3D("Specificity",{"Cadherin1":"%S","Cadherin2":"%S"},-1)'''%(self.cmcCadherins[cad1],self.cmcCadherins[cad2])
        self.configureSimLines+='''        
    cmcPluginElement.ElementCC3D("ContactFunctionType",{},"linear")
    cmcPluginElement.ElementCC3D("EnergyOffset",{},0.0)                        
    cmcPluginElement.ElementCC3D("NeighborOrder",{},2)'''        
        
    def generateAdhesionFlexPlugin(self):
        self.configureSimLines+='''        
    afPluginElement=cc3d.ElementCC3D("Plugin",{"Name":"AdhesionFlex"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        # listing adhesion molecules
        for molecule in self.afMolecules:
            self.configureSimLines+='''        
    afPluginElement.ElementCC3D("AdhesionMolecule",{"Molecule":"%s"})'''%(molecule)
            
        for id1 in range(0,maxId+1):
            for molecule in self.afMolecules:
                self.configureSimLines+='''
    afPluginElement.ElementCC3D("AdhesionMoleculeDensity",{"CellType":"%s",  "Molecule":"%s","Density":0.8})'''%(self.idToTypeTupleDict[id1][0],molecule)
        
        self.configureSimLines+='''
    formulaElement=afPluginElement.ElementCC3D("BindingFormula",{"Name":"Binary"})    
    formulaElement.ElementCC3D("Formula",{},"%s")
    
    variablesElement=formulaElement.ElementCC3D("Variables")
    
    aimElement=variablesElement.ElementCC3D("AdhesionInteractionMatrix")'''%(self.afFormula)
        
        moleculeMax=len(self.afMolecules)        
        for molecule1 in range(moleculeMax):
            for molecule2 in range(molecule1,moleculeMax):
                dict={"Molecule1":self.afMolecules[molecule1],"Molecule2":self.afMolecules[molecule2]}
                self.configureSimLines+='''
    aimElement.ElementCC3D("BindingParameter",{"Molecule1":"%s","Molecule2":"%s"},-1.0)'''%(self.afMolecules[molecule1],self.afMolecules[molecule2])
                
        self.configureSimLines+='''    
    afPluginElement.ElementCC3D("NeighborOrder",{},2)
        '''        

    def generateVolumeFlexPlugin(self):
        self.configureSimLines+='''
        
    vfElement=cc3d.ElementCC3D("Plugin",{"Name":"Volume"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            if self.idToTypeTupleDict[id1][0]=="Medium":
                continue
            dict={"CellType":self.idToTypeTupleDict[id1][0],"TargetVolume":25,"LambdaVolume":2.0}
            self.configureSimLines+='''            
    vfElement.ElementCC3D("VolumeEnergyParameters",{"CellType":"%s","TargetVolume":25,"LambdaVolume":2.0})'''%(self.idToTypeTupleDict[id1][0])    
        
    def generateSurfaceFlexPlugin(self):
        self.configureSimLines+='''
        
    sfElement=cc3d.ElementCC3D("Plugin",{"Name":"Volume"})
        '''
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            if self.idToTypeTupleDict[id1][0]=="Medium":
                continue
            dict={"CellType":self.idToTypeTupleDict[id1][0],"TargetSurface":20,"LambdaSurface":0.5}    
            self.configureSimLines+='''
    sfElement.ElementCC3D("SurfaceEnergyParameters",{"CellType":"%s","TargetSurface":20,"LambdaSurface":0.5}    )'''%(self.idToTypeTupleDict[id1][0])    
    
        
    def generateUniformInitializerSteppable(self):
        self.configureSimLines+='''
        
    uiElement=cc3d.ElementCC3D("Steppable",{"Type":"UniformInitializer"})
    region=uiElement.ElementCC3D("Region")
    region.ElementCC3D("BoxMin",{"x":20,"y":20,"z":0})
    region.ElementCC3D("BoxMax",{"x":80,"y":80,"z":1})
    region.ElementCC3D("Gap",{},0)
    region.ElementCC3D("Width",{},5)
        '''
        
        typesString=""
        
        maxId=max(self.idToTypeTupleDict.keys())
        for id1 in range(0,maxId+1):
            if self.idToTypeTupleDict[id1][0]=="Medium":
                continue
                
            typesString+=self.idToTypeTupleDict[id1][0]
            if id1<maxId:
                typesString+=","
                
        self.configureSimLines+='''        
    region.ElementCC3D("Types",{},"%s")''' %(typesString)
