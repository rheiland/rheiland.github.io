import re
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import PyQt4.QtCore as QtCore
import ui_configurationdlg
import sys


MAC = "qt_mac_set_native_menubar" in dir()



class ConfigurationDlg(QDialog,ui_configurationdlg.Ui_ConfigurationDlg):
    #signals
    # gotolineSignal = QtCore.pyqtSignal( ('int',))
    
    def __init__(self,_currentEditor=None,parent=None):
        super(ConfigurationDlg, self).__init__(parent)
        self.editorWindow=parent
        self.currentEditor=_currentEditor
        # there are issues with Drawer dialog not getting focus when being displayed on linux
        # they are also not positioned properly so, we use "regular" windows 
        if sys.platform.startswith('win'): 
            self.setWindowFlags(Qt.Drawer) # dialogs without context help - only close button exists
        # self.gotolineSignal.connect(self.editorWindow.goToLine)
        self.setupUi(self)
  
        
        if not MAC:
            self.cancelButton.setFocusPolicy(Qt.NoFocus)
        self.updateUi()

    @pyqtSignature("") # signature of the signal emited by the button
    def on_okButton_clicked(self):
        self.findChangedConfigs()        
        self.close()
        
    def findChangedConfigs(self):
        configuration=self.editorWindow.configuration
        configuration.updatedConfigs={}
        
        if configuration.setting("UseTabSpaces")!=self.tabSpacesCheckBox.isChecked():
            configuration.updatedConfigs["UseTabSpaces"]=self.tabSpacesCheckBox.isChecked()
            
        if configuration.setting("TabSpaces")!=self.spacesSpinBox.value():
            configuration.updatedConfigs["TabSpaces"]=self.spacesSpinBox.value()
            
        if configuration.setting("DisplayLineNumbers")!=self.lineNumberCheckBox.isChecked():
            configuration.updatedConfigs["DisplayLineNumbers"]=self.lineNumberCheckBox.isChecked()
            
        if configuration.setting("FoldText")!=self.foldTextCheckBox.isChecked():
            configuration.updatedConfigs["FoldText"]=self.foldTextCheckBox.isChecked()            
            
        if configuration.setting("TabGuidelines")!=self.tabGuidelinesCheckBox.isChecked():
            configuration.updatedConfigs["TabGuidelines"]=self.tabGuidelinesCheckBox.isChecked()            
            
        if configuration.setting("DisplayWhitespace")!=self.whiteSpaceCheckBox.isChecked():
            configuration.updatedConfigs["DisplayWhitespace"]=self.whiteSpaceCheckBox.isChecked() 
            
        if configuration.setting("DisplayEOL")!=self.eolCheckBox.isChecked():
            configuration.updatedConfigs["DisplayEOL"]=self.eolCheckBox.isChecked()
            
        if configuration.setting("WrapLines")!=self.wrapLinesCheckBox.isChecked():
            configuration.updatedConfigs["WrapLines"]=self.wrapLinesCheckBox.isChecked()  

        if configuration.setting("ShowWrapSymbol")!=self.showWrapSymbolCheckBox.isChecked():
            configuration.updatedConfigs["ShowWrapSymbol"]=self.showWrapSymbolCheckBox.isChecked()  
            
        if configuration.setting("RestoreTabsOnStartup")!=self.restoreTabsCheckBox.isChecked():
            configuration.updatedConfigs["RestoreTabsOnStartup"]=self.restoreTabsCheckBox.isChecked()            

        if configuration.setting("EnableAutocompletion")!=self.autocompletionCheckBox.isChecked():
            configuration.updatedConfigs["EnableAutocompletion"]=self.autocompletionCheckBox.isChecked()
            
        if configuration.setting("AutocompletionThreshold")!=self.autocompletionSpinBox.value():
            configuration.updatedConfigs["AutocompletionThreshold"]=self.autocompletionSpinBox.value()
            
        if configuration.setting("BaseFontName")!=self.fontComboBox.currentText():
            configuration.updatedConfigs["BaseFontName"]=self.fontComboBox.currentText()
            
        if configuration.setting("BaseFontSize")!=self.fontSizeComboBox.currentText():
            configuration.updatedConfigs["BaseFontSize"]=self.fontSizeComboBox.currentText()
            
            
        #store changed values in settings    
        for key in configuration.updatedConfigs.keys():
            configuration.setSetting(key,configuration.updatedConfigs[key])
        
    def updateUi(self):
        configuration=self.editorWindow.configuration
        self.tabSpacesCheckBox.setChecked(configuration.setting("UseTabSpaces"))
        self.spacesSpinBox.setValue(configuration.setting("TabSpaces"))
        self.lineNumberCheckBox.setChecked(configuration.setting("DisplayLineNumbers"))
        self.foldTextCheckBox.setChecked(configuration.setting("FoldText"))
        self.tabGuidelinesCheckBox.setChecked(configuration.setting("TabGuidelines"))
        self.whiteSpaceCheckBox.setChecked(configuration.setting("DisplayWhitespace"))
        self.eolCheckBox.setChecked(configuration.setting("DisplayEOL"))
        self.wrapLinesCheckBox.setChecked(configuration.setting("WrapLines"))
        if not self.wrapLinesCheckBox.isChecked():
            self.showWrapSymbolCheckBox.setEnabled(False)
        
        self.showWrapSymbolCheckBox.setChecked(configuration.setting("ShowWrapSymbol"))
        
        self.restoreTabsCheckBox.setChecked(configuration.setting("RestoreTabsOnStartup"))

        self.autocompletionCheckBox.setChecked(configuration.setting("EnableAutocompletion"))
        self.autocompletionSpinBox.setValue(configuration.setting("AutocompletionThreshold"))
        
        #not ideal solution but should work
        baseFontName=configuration.setting("BaseFontName")
        for idx in range(self.fontComboBox.count()):
            if baseFontName==self.fontComboBox.itemText(idx):                        
                self.fontComboBox.setCurrentIndex(idx)
                break
        
        baseFontSize=configuration.setting("BaseFontSize")
        
        for idx in range(self.fontSizeComboBox.count()):
            if baseFontSize==self.fontSizeComboBox.itemText(idx):                        
                self.fontSizeComboBox.setCurrentIndex(idx)
                break
        
        

