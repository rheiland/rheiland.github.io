"""
TO DO:
* window menu
* help menu
* expand guessLexer function to include more languages
* implement file change autosensing
* list of recent files
* proper command line handling
* replace lock files with named mutex on windows and pid search in unix
* write keyboard shortcut editor widget
* write lexers for additional languages - extend CustomLexer class
* handle undo better
* deal with write protected, hidden, or non-standard files
* have to find better way to check if a given file is open
* saveAs dialog should automatically pick extension based on current extension of edited file
* add printing capabilities
* add EOL conversion
* add text encodings
* add auto completion
* website
* help menu
* find in files should display message - "assembling file list", "searching files" 
* margin click to bookmark/unbookmark
* easy map from/to tab to/from document name 
* remove dbgMsg(statements )
* lexer in find in files has to scan entire text before displaying it - otherwise gui may become unresponsive on fold text 
* change name to twedit++
* cursor change on ? click # done using QtDrawer and setWindowFlags
* add context menu
* check what happens if there is python error during binary file execution - perhaps use try /except in the main script to catch any errors in the
* for new documents save as dialog should open up in directory of the previous widget - if this is not available then default path
* recent file list may be storing too many elements when destroying tabs before exiting
* add new function add new document (it inintializes fileDict. ) and avoid maniulating file dict directly
* figure out how to display binary files including control characters
* add context menu to clear find in files dialog
* add fold all/unfoldall - have to change existing toggle fold all
* python indentation does not work correctly after enter - sohuld assume indent of the previous line - maybe have to do it with API
* NOTICE findNext()
          replace() does not work you have to use findFirst with arguments  
          it als has issues with undo actions so it is best to use findFirst always...
 
* add context menus to tabs (close, delete, rename etc...)
* context menu to for editor
* Default editor should be removed anyway the moment we open any new file
* groups brackets ( ) in regex string have to be escaped - e.g. \(.*\) - have to fix it to make sure you can put regular brackets
* clean up loadFile fcn
* display information if text cannot be found
* list of recent documents
* variables for naming platforms
* Allow new window to be open
* add contex menu to tab - see notepad++ options
 """

VERSION_MAJOR=0
VERSION_MINOR=9
VERSION_BUILD=0

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtNetwork import *
from PyQt4.Qsci import *

from PyQt4 import QtCore, QtGui
import os
import ActionManager as am
    
# import application_rc
import twedit_plus_plus_rc
import os

from findandreplacedlg import FindAndReplaceDlg
from findandreplacedlg import FindAndReplaceHistory
from findandreplacedlg import FindInFilesResults
from findandreplacedlg import FindDisplayWidget
from gotolinedlg import GoToLineDlg
from Configuration import Configuration
from configurationdlg import ConfigurationDlg
from LanguageManager import LanguageManager
from CycleTabsPopup import CycleTabsPopup
from CycleTabsPopup import CycleTabFileList
from QsciScintillaCustom import QsciScintillaCustom
from PrinterTwedit import PrinterTwedit
from KeyboardShortcutsDlg import KeyboardShortcutsDlg

from DataSocketCommunicators import FileNameReceiver
import Encoding
import string
import sys

import re
from codecs import BOM_UTF8, BOM_UTF16, BOM_UTF32   

from PluginManager.PluginManager import PluginManager

coding_regexps = [
    (2, re.compile(r'''coding[:=]\s*([-\w_.]+)''')), 
    (1, re.compile(r'''<\?xml.*\bencoding\s*=\s*['"]([-\w_.]+)['"]\?>''')), 
]     

from findandreplacedlg import ALL_IN_FILES , ALL_IN_ALL_OPEN_DOCS , ALL_IN_CURRENT_DOC


from Messaging import stdMsg, dbgMsg,pd, errMsg, setDebugging



class ChangedTextHandler:
    def __init__(self,_editor,_editorWindow):
        self.editor=_editor
        self.editorWindow=_editorWindow
        
    def handleChangedText(self):
        
        self.editorWindow.updateTextSizeLabel()

        
    def handleModificationChanged(self,m):
        self.editorWindow.setWindowModified(m)
        if m: #document has been modified
            index=self.editorWindow.editTab.indexOf(self.editor)
            self.editorWindow.editTab.setTabIcon(index,QtGui.QIcon(':/icons/document-edited.png'))
            
        else: #document has been restored to original state
            index=self.editorWindow.editTab.indexOf(self.editor)
            self.editorWindow.editTab.setTabIcon(index,QtGui.QIcon(':/icons/document-clean.png'))
        self.editorWindow.checkActions()
        
        
class CustomTabWidget(QTabWidget):
    def __init__(self , _parent=None):
        QTabWidget.__init__(self , _parent)
        self.editorWindow=_parent
        
    def contextMenuEvent(self , event):
        menu=QMenu(self)
        menu.addAction(am.actionDict["Save"])
        menu.addAction(am.actionDict["Save As..."])
        menu.addAction(am.actionDict["Print..."])
        menu.addSeparator()        
        #---------------------------         
        menu.addAction(am.actionDict["Close Tab"])
        menu.addAction(am.actionDict["Close All Tabs"])
        menu.addAction(am.actionDict["Close All But Current Tab"])
        menu.addAction(am.actionDict["Delete from disk"])
        menu.addSeparator()        
        #--------------------------- 
        fnToClipAct=menu.addAction("File name to clipboard")
        fdToClipAct=menu.addAction("File directory to clipboard")
        
        self.connect(fnToClipAct,SIGNAL("triggered()"),self.editorWindow.fileNameToClipboard)
        self.connect(fdToClipAct,SIGNAL("triggered()"),self.editorWindow.fileDirToClipboard)
        
        menu.exec_(event.globalPos())
        
class EditorWindow(QMainWindow):
    
    def __init__(self,_startFileListener=True):
        super(EditorWindow, self).__init__()
        self.setWindowIcon(QtGui.QIcon(":/icons/twedit-icon.png"))
        self.extensionLanguageMap={".py":"Python",
        ".pyw":"Python",
        ".xml":"XML",
        ".c":"C",
        ".cpp":"C",
        ".cc":"C",
        ".cxx":"C",
        ".h":"C",
        ".hxx":"C",
        ".hpp":"C",
        ".cmake":"CMake",
        ".cs":"C#",        
        ".css":"CSS",
        ".d":"D",
        ".diff":"Diff",
        ".patch":"Diff",
        ".pas":"Pascal",
        ".inc":"Pascal",
        ".pl":"Perl",
        ".rb":"Ruby",
        ".rbw":"Ruby",
        ".f":"Fortran77",
        ".F":"Fortran77",
        ".f90":"Fortran",
        ".F90":"Fortran",
        ".java":"Java",
        ".js":"JavaScript",
        ".lua":"Lua",
        ".ps":"PostScript",
        ".properties":"Properties",
        ".pov":"POV",
        ".cir":"Spice",
        ".sql":"SQL",
        ".tcl":"TCL",
        ".v":"Verilog",
        ".vhd":"VHDL",
        ".vhdl":"VHDL",
        ".yml":"YML",
        ".bat":"Batch",
        ".sh":"Bash",
        ".html":"HTML",
        ".tex":"TeX"
        }

        self.fileDialogFilters,self.filterExtensionsDict = self.prepareFileDialogFilters(self.extensionLanguageMap)
        
        self.findDialogForm=None # reference to findDialogForm - we check if current value is non-None to make sure we can create an instance. Multiple instances are disallowed
        
        self.keyboardShortcutDlg=None # reference to keyboardShortcut dialog
        
        if _startFileListener:
            self.fileNameReceiver=FileNameReceiver(self)
        
            self.fileNameReceiver.newlyReadFileName.connect(self.processNewlyReadFileName)
        
        self.textSizeLabel=QLabel("SIZE LABEL")
        self.currentPositionLabel=QLabel("CURRENT POSITION")
        self.encodingLabel=QLabel("Encoding")
        
        self.statusBar().addPermanentWidget(self.textSizeLabel)
        self.statusBar().addPermanentWidget(self.currentPositionLabel)
        self.statusBar().addPermanentWidget(self.encodingLabel)
        
        self.deactivateChangeSensing=False
        
        
        
        self.curFile = ''
        self.configuration=Configuration()
        
        self.zoomRange=self.configuration.setting("ZoomRange")
        
        # self.textEdit = QsciScintillaCustom()
        self.resize(self.configuration.setting("InitialSize"))
        self.move(self.configuration.setting("InitialPosition"))
        
        self.baseFont=QFont(self.configuration.setting("BaseFontName"),int(self.configuration.setting("BaseFontSize")))
        
        self.editTab=CustomTabWidget(self)
        self.editTab.setTabsClosable(True)
        self.editTab.setMovable(True)
        self.editTab.setUsesScrollButtons(True)
        self.setCentralWidget(self.editTab)

        
        textEditLocal=QsciScintillaCustom()
        self.defaultEditor=textEditLocal
        self.textChangedHandlers={}
        
        self.editTab.addTab(textEditLocal,QtGui.QIcon(':/icons/document-clean.png'),"New Document "+str(self.editTab.count()+1))
    
        
        
        
        
        textEditLocal.setFocus(True)

        self.textToFind=""
        # dbgMsg("QsciScintilla.SC_MARK_SHORTARROW=",QsciScintilla.SC_MARK_SHORTARROW)
        
        self.setEditorProperties(textEditLocal)
        # fetching bookmark Mask
        textEditLocal.markerAdd(0,self.lineBookmark)
        self.bookmarkMask=textEditLocal.markersAtLine(0)
        textEditLocal.markerDelete(0)
        self.indendationGuidesColor=QColor("silver")
        
        self.findAndReplaceHistory=FindAndReplaceHistory()
        self.restoreFindAndReplaceHistory(self.findAndReplaceHistory)
        
        self.commentStyleDict={self.editTab.currentWidget():['','']}
                
        dbgMsg("textEditLocal.braceMatching()=",textEditLocal.braceMatching())

        self.createActions()
        self.createMenus()
        self.createToolBars()
        self.createStatusBar()
        
        self.languageManager=LanguageManager(self)
        self.languageManager.createActions()

        
        # setting up dock window to display Find in files results
        self.findDock=self.__createDockWindow("Find Results")
        self.findDisplayWidget=FindDisplayWidget(self)
        self.__setupDockWindow(self.findDock, Qt.BottomDockWidgetArea, self.findDisplayWidget, self.trUtf8("Find In Files Results"))
        
        # self.showFindInFilesDockAct.trigger() # calling toggle does not emit triggered signal and thus action slot is not called. calling trigger does the trick
        


        self.setCurrentFile('')
        self.setUnifiedTitleAndToolBarOnMac(True)
        
        self.fileDict={} # we will store information about editor, file name, modificationtime and encoding in a dictionary:
        #{key=editorwidget: [fileName,modificationTime,encoding]}
        self.setPropertiesInEditorList(self.editTab.currentWidget(),'',0)

        
        self.textChangedHandlers[textEditLocal]=ChangedTextHandler(textEditLocal,self)
        self.editTab.widget(0).modificationChanged.connect(self.textChangedHandlers[textEditLocal].handleModificationChanged)
        self.editTab.widget(0).textChanged.connect(self.textChangedHandlers[textEditLocal].handleChangedText)
        self.editTab.widget(0).cursorPositionChanged.connect(self.handleCursorPositionChanged)
        
        
        
        if self.configuration.setting("RestoreTabsOnStartup"):
            self.restoreTabs()

        self.lastFileOpenPath=""
        self.ctrlTabShortcut=QShortcut(QKeySequence("Ctrl+Tab") ,self)
        self.CtrlKeyEquivalent=Qt.Key_Control
        
        if sys.platform.startswith("darwin"):
            self.ctrlTabShortcut=QShortcut(QKeySequence("Alt+Tab") ,self)
            self.CtrlKeyEquivalent=Qt.Key_Alt
        
            
            
        self.connect( self.ctrlTabShortcut, SIGNAL("activated()"), self.cycleTabs )
        self.ctrlPressed=False # used as a flag to display list of open tabs during cycling
        self.cycleTabsFlag=False
        self.cycleTabsPopup=None
        self.cycleTabFilesList=CycleTabFileList(self)
        
        
        
        self.pm=PluginManager(self)
        
        
        lexer=textEditLocal.lexer()
        if lexer:
            lexer.setFont(self.baseFont)   
            
        textEditLocal.setFont(self.baseFont)    
        
        self.argv=None
        
        self.processId=0 # used only in windows
        
    # fcns for accessing/manipulating dictionary storing tab/editor information
    
    def setProcessId(self,_id):
        self.processId=_id
        
    def getProcessId(self):
        return self.processId
        
    def getEditorList(self):
        return self.fileDict.keys()
        
    def getCurrentDocumentName(self):
        # editor=self.editTab.currentWidget()
        return self.getEditorFileName(self.editTab.currentWidget())
    
    def getCurrentEditor(self):
        return self.editTab.currentWidget()
    
    def checkIfEditorExists(self,_editor):
        try:
            self.fileDict[_editor]
            return True
        except KeyError:
            return False
        
    def getEditorFileName(self,_editor):
        try:
            return self.fileDict[_editor][0]
        except (KeyError,IndexError):
            return ''
            
    def getEditorFileModificationTime(self,_editor):
        try:
            return self.fileDict[_editor][1]
        except (KeyError,IndexError):
            return 0
            
    def getEditorFileEncoding(self,_editor):
        try:
            return self.fileDict[_editor][2]
        except (KeyError,IndexError):
            return ''  
            
    def removeEditor(self,_editor):
        try:
            del self.fileDict[_editor]
        except KeyError:
            pass
            
    def setEditorFileName(self,_editor,_name):
        try:
            self.fileDict[_editor][0]=_name
        except (KeyError,IndexError):
            pass
            
    def setEditorFileModificationTime(self,_editor,_time):
        try:
            self.fileDict[_editor][1]=_time
        except (KeyError,IndexError):
            pass
            
    def setEditorFileEncoding(self,_editor,_encoding):
        try:
            self.fileDict[_editor][2]=_encoding
        except (KeyError,IndexError):
            pass            
            
    def setPropertiesInEditorList(self,_editor,_fileName='',_modificationTime=0,_encoding=''):        
        try:
            self.fileDict[_editor][0]=_fileName
            self.fileDict[_editor][1]=_modificationTime
            self.fileDict[_editor][2]=_encoding
        except KeyError:
            self.fileDict[_editor]=[_fileName,_modificationTime,_encoding]
        except IndexError:
            pass
                   
    def getPropertiesFromEditorList(self,_editor):
        try:
            return self.fileDict[_editor]
        except KeyError:
            return ('',0,'')
        
    # fcns dealing with status bar
    def handleCursorPositionChanged(self,_line,_index):
        self.currentPositionLabel.setText("Ln : %s  Col : %s"%(_line,_index))
        
    def updateTextSizeLabel(self):
        editor=self.editTab.currentWidget() 
        try:# in case editor is None
            self.textSizeLabel.setText("Length : %s  lines : %s"%(editor.length(),editor.lines()))
        except:
            pass
    def updateEncodingLabel(self):
        editor=self.editTab.currentWidget() 
        try:
            self.encodingLabel.setText(Encoding.normalizeEncodingName(self.getEditorFileEncoding(editor)))
            
        except KeyError:
            self.encodingLabel.setText("Unknown encoding")
    
    def prepareFileDialogFilters(self,_extensionLanguageMap):
        filterList=QString()
        filterDict={}
        for extension, language in _extensionLanguageMap.iteritems():
            dbgMsg("extension=",extension," language=",language)
            try:
                filterDict[language]=filterDict[language]+" *"+extension
            except KeyError:
                filterDict[language]="*"+extension
        
        keysSorted=filterDict.keys()
        keysSorted.sort()    
        
        # filterDict={} # reassign filter dict
        
        for language in keysSorted:            
            if language=="C":                
                filterList.append("C/C++"+" file ("+filterDict[language]+");;")
                continue
            if language=="CMake":                                
                filterList.append(language+" file ("+filterDict[language]+" CMakeLists.*);;")
                continue
                
            filterList.append(language+" file ("+filterDict[language]+");;")    
        
        filterList.insert(0,"Text file (*.txt);;")            
        filterList.insert(0,"All files (*);;")    
        return filterList,filterDict     
    
    def getCurrentFilterString(self,_extension):
        currentFilter=""
        language=""
        if _extension==".txt":
            return "Text file (*.txt)"
        try:
            language=self.extensionLanguageMap[_extension]
               
        except KeyError:
            return currentFilter
            
        try:
            if language=="C":        
                currentFilter="C/C++"+" file ("+self.filterExtensionsDict[language]+")"
            else:
                currentFilter=language+" file ("+self.filterExtensionsDict[language]+")"
            return currentFilter
        except KeyError:
            return currentFilter
        
    def getFileNameToEditorWidgetMap(self):
        openFileDict={}
        # key is QScintilla widget
        for key in self.fileDict.keys():
            if self.fileDict[key][0]!='':
                openFileDict[self.fileDict[key][0]]=key
            else:
                documentName=self.editTab.tabText(self.editTab.indexOf(key))
                if documentName!='':
                    openFileDict[documentName]=key
        return openFileDict        
                
    def cycleTabs(self):
        dbgMsg("CYCLE TABS")
        if not self.cycleTabsFlag: # first time entering cycle tabs - prepare list of files
            self.cycleTabsFlag=True
            
            dbgMsg("Preparing list of Tabs")
            
            self.cycleTabsPopup=CycleTabsPopup(self)            
            self.cycleTabFilesList.initializeTabFileList()
            

        if self.cycleTabFilesList:  
            
            self.cycleTabFilesList.initializeTabFileList()
            self.cycleTabsPopup.initializeContent(self.cycleTabFilesList)
            
            self.cycleTabsPopup.move(0,0) #always position popup at (0,0) then calculate required shift
            self.cycleTabsPopup.adjustSize()
            
            
            #setting position of the popup cycle tabs window
            geom=self.geometry()            
            pGeom=self.cycleTabsPopup.geometry()            
            
            pCentered_x=geom.x()+(geom.width()-pGeom.width())/2
            pCentered_y=geom.y()+(geom.height()-pGeom.height())/2
            
            self.cycleTabsPopup.move(pCentered_x,pCentered_y)
            
            pGeom=self.cycleTabsPopup.geometry()
            self.cycleTabsPopup.show()
            dbgMsg("self.cycleTabsPopup.pos()=",str(self.cycleTabsPopup.pos())+"\n\n\n\n")
            

           
    def keyPressEvent(self, event):            
        if event.key()==self.CtrlKeyEquivalent:
            dbgMsg("CTRL key pressed")
            self.ctrlPressed=True

                
    def keyReleaseEvent(self, event):
    
        if event.key()==self.CtrlKeyEquivalent:
            dbgMsg("CTRL RELEASED")
            self.ctrlPressed=False
            if self.cycleTabsFlag: # release cycleTabs flag and switch to new tab
                self.cycleTabsFlag=False
                self.cycleTabsPopup.close()
                self.cycleTabsPopup=None
            
        
    def onMarginClick(self,_margin,_line, _state):
        dbgMsg("_margin:",_margin," line:",_line," _state:",_state)
        
    def openFileList(self,_fileList):
        import os
        for fileName in _fileList:
            dbgMsg("THIS IS THE FILE TO BE OPEN:", os.path.abspath(str(fileName)))
            self.loadFile(os.path.abspath(str(fileName)))
        self.activateWindow()
        
    def processCommandLine(self):
        dbgMsg("\n\n\n\n\n PROCESSING CMD LINE")
        import os
        for fileName in self.argv:
            dbgMsg("THIS IS THE FILE TO BE OPEN:", os.path.abspath(str(fileName)))
            self.loadFile(os.path.abspath(str(fileName)))
        self.activateWindow()

    def processNewlyReadFileName(self,_fileName):
        dbgMsg("processNewlyReadFileName fileName=",_fileName)
        self.loadFile(os.path.abspath(str(_fileName)))
        if not sys.platform.startswith('win'):
            self.showNormal()
            self.activateWindow()
            self.raise_()
            self.setFocus(True)
        

        #if sys.platform!='win32':
        
        
    def wheelEvent(self, event):        
        dbgMsg("WHEEL EVENT")
        if qApp.keyboardModifiers()==Qt.ControlModifier:
            editor=self.editTab.currentWidget()
            
            if event.delta()>0:
                self.zoomIn()
            else:
                self.zoomOut()
                
            dbgMsg("WHEEL EVENT WITH CTRL")

            
    def restoreTabs(self):
        fileList=self.configuration.setting("ListOfOpenFiles")
        for i in range(fileList.count()):            
            self.loadFile(fileList[i], True)
            
        currentTabIndex=self.configuration.setting("CurrentTabIndex") 
        self.editTab.setCurrentIndex(currentTabIndex)        
          
    def setArgv(self,_argv):
        dbgMsg("\n\n\n command line arguments",_argv)
        self.argv=_argv
    def getArgv(self):
        return self.argv

    
    def closeEvent(self, event):
        self.pm.unloadPlugins()
        openFilesToRestore={}
        self.deactivateChangeSensing=True
        
        # determining index of the current tab        
        
        self.configuration.setSetting("CurrentTabIndex",self.editTab.currentIndex())
        
        # only file names which are assigned prior to closing are being stored
        dbgMsg("\n\n\n self.getEditorList()=",self.getEditorList())
        # dbgMsg("self.fileDict=",self.fileDict)
        for editor in self.getEditorList():            
            dbgMsg("OPEN FILE NAME=",self.getEditorFileName(editor))
            if not self.getEditorFileName(editor)=='':
                openFilesToRestore[self.editTab.indexOf(editor)]=self.getEditorFileName(editor) # saving file name and position of the tab
        dbgMsg(" \n\n\n\n openFilesToRestore=",openFilesToRestore)
        for editor in self.getEditorList():            
            self.editTab.setCurrentWidget(editor)            
            self.closeTab()
            
        self.deactivateChangeSensing=False
        
        
        #saving open file names to restore
        self.saveSettingsOpenFilesToRestore(openFilesToRestore)
        # saving find and replace history
        self.saveSettingsFindAndReplaceHistory(self.findAndReplaceHistory)
        
        self.configuration.setSetting("InitialSize",self.size())
        # self.configuration.setSetting("InitialState",self.saveState()) #  state of docking windows and their position  
        self.configuration.setSetting("InitialPosition",self.pos())
        
        #prepare to store reassgined shortcuts
        self.configuration.prepareKeyboardShortcutsForStorage()
        

        
        event.accept()
    
    def saveSettingsOpenFilesToRestore(self,openFilesToRestore):
        
        keys=openFilesToRestore.keys()
        keys.sort() # sorting by the tab number 
        fileNamesSorted=[openFilesToRestore[key] for key in keys]
        fileList=QStringList()
        dbgMsg(dir(fileList))
        for fileName in fileNamesSorted:
            fileList.append(fileName)
        dbgMsg("saving fileList.count()=",fileList.count()    )
        self.configuration.setSetting("ListOfOpenFiles",fileList)
        
        dbgMsg("saveSettingsOpenFilesToRestore")
        
    def restoreFindAndReplaceHistory(self,_frh):
        
        findHistoryList=self.configuration.setting("FRFindHistory")
        for i in range(findHistoryList.count()):
            _frh.findHistory.append(findHistoryList[i])
            
        replaceHistoryList=self.configuration.setting("FRReplaceHistory")            
        for i in range(replaceHistoryList.count()):
            _frh.replaceHistory.append(replaceHistoryList[i])
            
        filtersHistoryList=self.configuration.setting("FRFiltersHistory")                        
        for i in range(filtersHistoryList.count()):
            _frh.filtersHistoryIF.append(filtersHistoryList[i])
            
        directoryHistoryList=self.configuration.setting("FRDirectoryHistory")                        
        for i in range(directoryHistoryList.count()):
            _frh.directoryHistoryIF.append(directoryHistoryList[i])
        
        _frh.syntaxIndex=self.configuration.setting("FRSyntaxIndex")        
        _frh.inSelection=self.configuration.setting("FRInSelection")
        _frh.inAllSubfolders=self.configuration.setting("FRInAllSubfolders")
        _frh.opacity=self.configuration.setting("FROpacity")
        _frh.transparencyEnable=self.configuration.setting("FRTransparencyEnable")        
        _frh.opacityOnLosingFocus=self.configuration.setting("FROnLosingFocus")        
        _frh.opacityAlways=self.configuration.setting("FRAlways")
        


        
        
    def saveSettingsFindAndReplaceHistory(self,_frh):
        
        
        findHistoryList=QStringList()        
        for findText in _frh.findHistory:
            findHistoryList.append(findText)
        self.configuration.setSetting("FRFindHistory",findHistoryList)
        
        replaceHistoryList=QStringList()        
        for replaceText in _frh.replaceHistory:
            replaceHistoryList.append(replaceText)
        self.configuration.setSetting("FRReplaceHistory",replaceHistoryList)
        
        filtersHistoryList=QStringList()        
        for filtersText in _frh.filtersHistoryIF:
            filtersHistoryList.append(filtersText)
        self.configuration.setSetting("FRFiltersHistory",filtersHistoryList)
        
        directoryHistoryList=QStringList()        
        for directoryText in _frh.directoryHistoryIF:
            directoryHistoryList.append(directoryText)
        self.configuration.setSetting("FRDirectoryHistory",directoryHistoryList)
        
        
        self.configuration.setSetting("FRSyntaxIndex",_frh.syntaxIndex)
        
        self.configuration.setSetting("FRInSelection",_frh.inSelection)
        self.configuration.setSetting("FRInAllSubfolders",_frh.inAllSubfolders)        
        self.configuration.setSetting("FROpacity",_frh.opacity)
        self.configuration.setSetting("FRTransparencyEnable",_frh.transparencyEnable)        
        self.configuration.setSetting("FROnLosingFocus",_frh.opacityOnLosingFocus)        
        self.configuration.setSetting("FRAlways",_frh.opacityAlways)  
        
        dbgMsg("saveSettingsFindAndReplaceHistory"      )
        
    # QChangeEvent detects changes in application status such as e.g. being ectivated or not see qt docuentation for more 
    # see also QEvent documentation for list of type of events
    # event.type() prints numeric value of gien event
    def changeEvent(self,event):
        if self.deactivateChangeSensing:
            return
        dbgMsg("THIS IS CHANGE EVENT ",event.type())
        if event.type()==QEvent.ActivationChange:
            dbgMsg("application focus has changed")
            dbgMsg("isActiveWindow()=",self.isActiveWindow())
            if self.isActiveWindow():
                self.deactivateChangeSensing=True
                self.checkIfDocumentsWereModified()
                self.deactivateChangeSensing=False
       
            
    def checkIfDocumentsWereModified(self):
        for editor in self.getEditorList():
            fileName=self.getEditorFileName(editor)
            try:
                if fileName!='' and os.path.getmtime(str(fileName))>self.getEditorFileModificationTime(editor):
                    dbgMsg("DOCUMENT ",fileName, " was modified")
                    reloadFlag=self.maybeReload(editor)
                    if not reloadFlag:
                        self.setEditorFileModificationTime(editor,os.path.getmtime(str(fileName)))                  
                    dbgMsg("reloadFlag=",reloadFlag)
                    # check if the document exists at all
            except os.error:        
                if not editor.isModified():
                    message="File <b>\"%s\"</b>  <br> has been deleted <br> Keep it in Editor?"%fileName
                    ret = QtGui.QMessageBox.warning(self, "Replace in Files",message,QtGui.QMessageBox.Yes |QtGui.QMessageBox.No)
                    if ret == QtGui.QMessageBox.Yes:            
                        lastModTime=self.getEditorFileModificationTime(editor)
                        
                        self.deactivateChangeSensing=False
                        # here we will insert and remove space at the end of the line - enough to trigger modification signal of the document 
                        self.setEditorFileModificationTime(editor,lastModTime+1)
                        lineNo=editor.lines()-1 # lines are numbnered from 0 
                        
                        lineLength=editor.lineLength(lineNo)
                        editor.insertAt(' ' ,lineNo,lineLength)
                        editor.setSelection(lineNo,lineLength,lineNo,lineLength+1)
                        editor.removeSelectedText()
                        self.deactivateChangeSensing=True
                    else:
                        self.closeTab( self.editTab.indexOf(editor),False)
                    
                
    

        
    def setEditorProperties(self,_editor):
        #lines are displayed on margin 0
        lineNumbersFlag=self.configuration.setting("DisplayLineNumbers")
        _editor.setMarginLineNumbers(0, lineNumbersFlag)
        _editor.setMarginWidth(0,QString('0'*8*int(lineNumbersFlag)))     
        
        
        
        useTabSpaces=self.configuration.setting("UseTabSpaces")
        
        
        _editor.setIndentationsUseTabs(not useTabSpaces) 
        if useTabSpaces:
            _editor.setIndentationWidth(self.configuration.setting("TabSpaces"))                    
        else:
            _editor.setIndentationWidth(0)#If width is 0 then the value returned by tabWidth() is used                    
        self.lineBookmark = _editor.markerDefine(QsciScintilla.SC_MARK_SHORTARROW) #All editors tab share same markers        
        # _editor.setMarginMarkerMask(2,QsciScintilla.SC_MARK_SHORTARROW) # mask has to correspond to marker number returned by markerDefine or it has to simply be 0 not sure
        
        #Bookmarks are displayed on margin 1 but I have to pass 2 to set mask for margin 1  
        _editor.setMarginMarkerMask(2,QsciScintilla.SC_MARK_SHORTARROW) # mask has to correspond to marker number returned by markerDefine or it has to simply be 0 not sure
        
        # dbgMsg("MASK 0=",_editor.marginMarkerMask(0))
        # dbgMsg("MASK 1=",_editor.marginMarkerMask(1))
        # dbgMsg("MASK 2=",_editor.marginMarkerMask(2))
        #enable bookmarking by click
        _editor.setMarginSensitivity(1,True)        
        _editor.marginClicked.connect(self.marginClickedHandler)
        
        _editor.setMarkerBackgroundColor(QColor("lightsteelblue"), self.lineBookmark)
        
        if self.configuration.setting("FoldText"):
            _editor.setFolding(QsciScintilla.BoxedTreeFoldStyle)
        else:
            _editor.setFolding(QsciScintilla.NoFoldStyle)
        _editor.setCaretLineVisible(True)
        _editor.setCaretLineBackgroundColor(QtGui.QColor('#EFEFFB'))        
        # _editor.modificationChanged.connect(self.modificationChangedSlot)
        
        # _editor.setEolMode(QsciScintilla.EolWindows) # SETTING EOL TO WINDOWS MESSES THINGS UP AS SAVE FCN (MOST LIKELY)ADS EXTRA CR SIGNS - 
        # _editor.setEolMode(QsciScintilla.EolUnix) # SETTING EOL TO WINDOWS MESSES THINGS UP AS SAVE FCN (MOST LIKELY)ADS EXTRA CR SIGNS - 
        # _editor.setEolMode(QsciScintilla.EolMac) # SETTING EOL TO WINDOWS MESSES THINGS UP AS SAVE FCN (MOST LIKELY)ADS EXTRA CR SIGNS - 
        # _editor.setUtf8(True) # using UTF-8 encoding
        
        
        displayWhitespace=self.configuration.setting("DisplayWhitespace")
        if displayWhitespace:
            _editor.setWhitespaceVisibility(QsciScintilla.SCWS_VISIBLEALWAYS)
        else:
            _editor.setWhitespaceVisibility(QsciScintilla.SCWS_INVISIBLE)

        displayEol=self.configuration.setting("DisplayEOL")
        _editor.setEolVisibility(displayEol)

        wrapLines=self.configuration.setting("WrapLines")
        showWrapSymbol=self.configuration.setting("ShowWrapSymbol")
        
        _editor.setAutoIndent(True)
        
        if wrapLines:
            if sys.platform.startswith("darwin"):
                # when opening file on Mac we simply ignore fold setting as they cause large files to open very slowly, users can set wrap lines setting individually for each editor tab
                _editor.setWrapMode(QsciScintilla.WrapNone) 
            else:            
                _editor.setWrapMode(QsciScintilla.WrapWord)
                if showWrapSymbol:
                    _editor.setWrapVisualFlags(QsciScintilla.WrapFlagByText)
        
        # Autocompletion
        if self.configuration.setting("EnableAutocompletion"):
            _editor.setAutoCompletionThreshold(self.configuration.setting("AutocompletionThreshold"))
        # _editor.setAutoCompletionSource(QsciScintilla.AcsDocument)
            _editor.setAutoCompletionSource(QsciScintilla.AcsAll)
        else:
            _editor.setAutoCompletionSource(QsciScintilla.AcsNone)

        lexer=_editor.lexer()
        if lexer:
            lexer.setFont(self.baseFont)   
            
        _editor.setFont(self.baseFont)              
        
    def modificationChangedSlot(self, _flag):
        dbgMsg("THIS IS CHANGED DOCUMENT")
                            
    def blockComment(self):
        editor=self.editTab.currentWidget()        
        if not self.commentStyleDict[editor][0]: # this language does not allow comments 
            return
        
        commentStringBegin=self.commentStyleDict[editor][0]
        commentStringEnd=self.commentStyleDict[editor][1]

        
        if editor.hasSelectedText():
            line_from, index_from, line_to, index_to = editor.getSelection()
            if index_to==0: # do not comment last line if no character in this line is selected
                line_to-=1
                
            editor.beginUndoAction()     
            for l in range(line_from, line_to+1):
                # dbgMsg("inside loop of single line comments=",l)
                self.commentSingleLine(l,commentStringBegin,commentStringEnd)       
            editor.endUndoAction()    
                
  
            # dbgMsg("line_from, _index_from, line_to, _index_to=",line_from, index_from, line_to, index_to)
            # restoring selection  
            if index_to==0:
                line_to+=1       
                editor.setSelection(line_from, index_from+len(commentStringBegin), line_to, index_to)
            else:
                editor.setSelection(line_from, index_from+len(commentStringBegin), line_to, index_to+len(commentStringBegin))    
            
                          
            
  
        else: # single line comments
            currentLine,currentColumn=editor.getCursorPosition()            
            editor.beginUndoAction()                            
            self.commentSingleLine(currentLine,commentStringBegin,commentStringEnd)                    
            editor.endUndoAction()              
            
                    
    def commentSingleLine(self,currentLine,commentStringBegin,commentStringEnd):
        editor=self.editTab.currentWidget()
        # dbgMsg("trying to comment current line:",editor.text(currentLine))
        if commentStringEnd: # handling comments which require additions at the beginning and at the end of the line   
            
            if not editor.text(currentLine).trimmed().isEmpty(): # checking if the line contains non-white characters
                # editor.beginUndoAction()            
                editor.insertAt( commentStringBegin , currentLine, 0 )  
                # dbgMsg("currentLineLength=",editor.text(currentLine).size())
                # dbgMsg("editor.text(currentLine)=",editor.text(currentLine),"|")
                # we have to account for the fact the EOL character can be CR LF or CR or LF
                eolPos=editor.text(currentLine).size()
                lineText=editor.text(currentLine)
                if lineText[eolPos-2]=="\r" or lineText[eolPos-2]=="\n":# second option is just in case - checking if we are dealign with CR LF or simple CR or LF end of line                    
                    editor.insertAt( commentStringEnd , currentLine, eolPos-2)                        
                else:
                    editor.insertAt( commentStringEnd , currentLine, eolPos-1)
                # editor.endUndoAction()    
        else:# handling comments which require additions only at the beginning of the line
            if not editor.text(currentLine).trimmed().isEmpty(): # checking if the line contains non-white characters
                # editor.beginUndoAction()                            
                editor.insertAt( commentStringBegin , currentLine, 0 )                
                # editor.endUndoAction()    
        
    
    def copy(self):
        editor=self.editTab.currentWidget()
        editor.copy()
        
    def cut(self):
        editor=self.editTab.currentWidget()
        editor.cut()
    
        
    def paste(self):
        editor=self.editTab.currentWidget()
        editor.paste()
        
    def increaseIndent(self):

        editor=self.editTab.currentWidget()
        line, index = editor.getCursorPosition()
        if editor.hasSelectedText():
            line_from, index_from, line_to, index_to = editor.getSelection()
            if index_to == 0 :
                line_to -= 1        
            editor.beginUndoAction()
            for line in range(line_from, line_to+1):
        
                editor.indent(line)
            editor.endUndoAction()
        else: # here I sohuld insert indenttion inside the string in the current position
            tabString=""
            indentationWidth=1
            if editor.indentationsUseTabs():
                tabString="\t"
            else:
                indentationWidth=editor.indentationWidth()
                tabString=" "*indentationWidth
                
            editor.insertAt(tabString,line, index)
            editor.setCursorPosition(line,index+indentationWidth)
            # editor.indent(line)
  

    def decreaseIndent(self):
        editor=self.editTab.currentWidget()
        line, index = editor.getCursorPosition()
        if editor.hasSelectedText():
            line_from, index_from, line_to, index_to = editor.getSelection()
            if index_to == 0 :
                line_to -= 1        
            editor.beginUndoAction()
            for line in range(line_from, line_to+1):
        
                editor.unindent(line)
            editor.endUndoAction()
        else:
            editor.unindent(line)
            
    def blockUncomment(self):
        editor=self.editTab.currentWidget()
        if not self.commentStyleDict[editor][0]: # this language does not allow comments 
            return           
            
        commentStringBegin=QString(self.commentStyleDict[editor][0])
        commentStringBeginTrunc=commentStringBegin.trimmed() # comments without white spaces
        
        
        if commentStringBeginTrunc=="REM":
            commentStringBeginTrunc=commentStringBegin # comments which begin with a word  - e.g. REM should not be truncated
        
        commentStringEnd=QString()
        if self.commentStyleDict[editor][1]:
            commentStringEnd=QString(self.commentStyleDict[editor][1])
        commentStringEndTrunc=commentStringEnd.trimmed()
        
        
        if editor.hasSelectedText():
            line_from, index_from, line_to, index_to = editor.getSelection()
            if index_to == 0 :
                line_to -= 1        
            firstLineBeginCommentLength=0
            lastLineBeginCommentLength=0            
            
            editor.beginUndoAction()
            
            for line in range(line_from, line_to+1):
            
                beginCommentLength,endCommentLength = self.uncommentLine(line,commentStringBegin,commentStringBeginTrunc,commentStringEnd,commentStringEndTrunc)
                if line==line_from:
                    firstLineBeginCommentLength=beginCommentLength
                if line==line_to:
                    lastLineBeginCommentLength=beginCommentLength
            editor.endUndoAction()
            
            # restoring selection  
            if index_to==0:
                line_to+=1       
                editor.setSelection(line_from, index_from-firstLineBeginCommentLength, line_to, index_to)
            else:
                editor.setSelection(line_from, index_from-firstLineBeginCommentLength, line_to, index_to-lastLineBeginCommentLength)
    
            
        else:
          
            # Uncomment current line
            line, index = editor.getCursorPosition()
            editor.beginUndoAction()            
            self.uncommentLine(line,commentStringBegin,commentStringBeginTrunc,commentStringEnd,commentStringEndTrunc)            
            editor.endUndoAction()
                        
    def uncommentLine(self,line,commentStringBegin,commentStringBeginTrunc,commentStringEnd,commentStringEndTrunc):
        # line, index = editor.getCursorPosition()
        editor=self.editTab.currentWidget()
        commentsFound=False
        
        lineText=editor.text(line)
        origLineTextLength=lineText.size()
        indexOf=lineText.indexOf(commentStringBegin)
        
        beginCommentLength=0
        endCommentLength=0
        
        #processing begining of the line    
        if indexOf != -1:
            lineText.remove(indexOf,commentStringBegin.size())
            beginCommentLength=commentStringBegin.size()
            commentsFound=True

        else: 
            indexOf=lineText.indexOf(commentStringBeginTrunc) 
            if indexOf != -1:
                lineText.remove(indexOf,commentStringBeginTrunc.size())
                beginCommentLength=commentStringBeginTrunc.size()
                commentsFound=True
                
        if  commentStringEnd.size()  :
        
            #processing begining of the line    
            lastIndexOf=lineText.lastIndexOf(commentStringEnd)
            if lastIndexOf!=-1 :
                lineText.remove(lastIndexOf,commentStringEnd.size())
                endCommentLength=commentStringEnd.size()
                commentsFound=True
            else:
                lastIndexOf=lineText.lastIndexOf(commentStringEndTrunc)
                if lastIndexOf!=-1 :
                    lineText.remove(lastIndexOf,commentStringEndTrunc.size())
                    endCommentLength=commentStringEndTrunc.size()
                    commentsFound=True
                    
        if commentsFound:
            eolPos=lineText.size()            
            if lineText[eolPos-2]=="\r" or lineText[eolPos-2]=="\n":# second option is just in case - checking if we are dealign with CR LF or simple CR or LF end of line                                        
                editor.setSelection(line,0,line,origLineTextLength-1)
            else:
                editor.setSelection(line,0,line,origLineTextLength)
                
            editor.removeSelectedText()
            
            editor.insertAt(lineText,line,0)   
            
        return beginCommentLength,endCommentLength    
    
    def find(self):

        if self.findDialogForm:
            self.findDialogForm.show()
            return
            
        self.findDialogForm = FindAndReplaceDlg("",self)
        self.findDialogForm.setFindAndReaplceHistory(self.findAndReplaceHistory)
        
        # putting highlighted text into findLineEdit
        editor=self.editTab.currentWidget()

        self.findDialogForm.searchingSignal.connect(self.findNext)
        self.findDialogForm.replacingSignal.connect(self.replaceNext)
        self.findDialogForm.replacingAllSignal.connect(self.replaceAll)
        self.findDialogForm.initializeDialog(self.findAndReplaceHistory)# resizes widget among other things
        
        # if editor.hasSelectedText():
            # self.findDialogForm.findLineEdit.setText(editor.selectedText()) 
            
        
        # find in files
        self.findDialogForm.searchingSignalIF.connect(self.findInFiles)
        self.findDialogForm.replacingSignalIF.connect(self.replaceInFiles)
        #find All in All open Docs
        self.findDialogForm.searchingAllInAllOpenDocsSignal.connect(self.findInFiles)
        
        #replace All in All open Docs
        self.findDialogForm.replacingAllInOpenDocsSignal.connect(self.replaceInFiles)
         
        self.findDialogForm.show()   
        
    def findInFiles(self,_text,_filters,_directory,_mode=ALL_IN_FILES):
        self.findDialogForm.setEnabled(False)
        dbgMsg("findInFiles")
        # ALL_IN_FILES=0
        # ALL_IN_ALL_OPEN_DOCS=1
        # ALL_IN_CURRENT_DOC=2    
        
        dbgMsg("search parameters",_text," ", _filters," ",_directory)

        reFlag=False
        
        if str(self.findDialogForm.syntaxComboBoxIF.currentText())=="Regular expression":
            reFlag=True        
            
        newSearchFlag=self.findAndReplaceHistory.newSearchParametersIF(_text,_filters,_directory)        
        
        # self.findDialogForm.initializeAllSearchLists(self.findAndReplaceHistory)
        #constructing the list of files to be searched based on directory and filters input
        
        import fnmatch
        import os
        filters=str(_filters).split()
        dbgMsg(filters)
        
        matches = []
        if _mode==ALL_IN_FILES:
            for filter in filters:
                if self.findDialogForm.inAllSubFoldersCheckBoxIF.isChecked():
                    for root, dirnames, filenames in os.walk(str(_directory)):
                        for filename in fnmatch.filter(filenames, filter):
                            matches.append(os.path.join(root, filename))
                else:
                    root=str(_directory)
                    for filename in os.listdir(root):
                        if fnmatch.fnmatch(filename, filter):
                            matches.append(os.path.join(root, filename))
                        

                
            
        # dbgMsg("matches=",matches)
        
        foundFiles=[]
        
        if _mode==ALL_IN_FILES:
            foundFiles=self.findFiles(matches,_text,reFlag)
        elif _mode==ALL_IN_ALL_OPEN_DOCS:
            foundFiles=self.findAllInOpenDocs(_text,reFlag)            
        elif _mode==ALL_IN_CURRENT_DOC:
            foundFiles=self.findAllInOpenDocs(_text,reFlag,True)
        else:
            self.findDialogForm.setEnabled(True)
            return
            

        findInFilesFormatter=FindInFilesResults()  # use  empty FindInFilesResults object as a formatter         
        self.findDisplayWidget.addNewFindInFilesResults(findInFilesFormatter.produceSummaryRepr(foundFiles,_text))
        if not self.showFindInFilesDockAct.isChecked():
            self.showFindInFilesDockAct.trigger() # calling toggle does not emit triggered signal and thus action slot is not called. calling trigger does the trick
        self.findDialogForm.setEnabled(True)    
                    
    def findAllInOpenDocs(self,_text,_reFlag=False, _inCurrentDoc=False): 
        # progress dialog not necessary here        
        foundFiles = []
        editorList=[]
        if _inCurrentDoc:
            editorList.append(self.editTab.currentWidget())
        else:
            editorList=self.getEditorList()
            
        findText=QString(_text) # a new copy of a textTo Find       
        if _reFlag:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")
            
        for editor in editorList:
            currentLine,currentIndex = editor.getCursorPosition() # record current cursor position
            filename=self.getEditorFileName(editor)
            if filename=='':
                
                # we will use tab label as a filename for unsaved documents
                filename=self.editTab.tabText(self.editTab.indexOf(editor))
                # continue # we do not allow searching in the unsaved files
            
            foundFlag=editor.findFirst(findText,_reFlag,\
            self.findDialogForm.caseCheckBox.isChecked(),\
            self.findDialogForm.wholeCheckBox.isChecked(),\
            False,\
            True,0,0,False)            
            
            findResults=None
            if foundFlag:
                foundFiles.append(FindInFilesResults(filename,_text,True))
                findResults=foundFiles[-1]
                
            while foundFlag:
                line,index=editor.getCursorPosition()
                # dbgMsg("FOUND OCCURENCE IN LINE ",line)
                findResults.addLineWithText(line,editor.text(line))
                foundFlag=editor.findNext()
                
            editor.setCursorPosition(currentLine,currentIndex)   # restore cursor position
            
           
        
        return foundFiles   
    
    def findFiles(self, _files, _text,_reFlag=False):
        progressDialog = QtGui.QProgressDialog(self)

        progressDialog.setCancelButtonText("&Cancel")
        numberOfFiles=len(_files)
        progressDialog.setRange(0, numberOfFiles)
        progressDialog.setWindowTitle("Find Text in Files")

        foundFiles = []
        i=1
        
        findText=QString(_text) # a new copy of a textTo Find       
        if _reFlag:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")
            
        for filename in _files:
            # dbgMsg("SEARCHING ", filename)
            progressDialog.setValue(i)
            progressDialog.setLabelText("Searching file number %d of %d..." % (i, numberOfFiles))
            QtGui.qApp.processEvents()

            if progressDialog.wasCanceled():
                break

            inFile = QtCore.QFile(filename)

            if inFile.open(QtCore.QIODevice.ReadOnly):
                stream = QtCore.QTextStream(inFile)
                
                textEditLocal=QsciScintillaCustom()
                
                textEditLocal.setText(stream.readAll())
                
                foundFlag=textEditLocal.findFirst(findText,_reFlag,\
                self.findDialogForm.caseCheckBoxIF.isChecked(),\
                self.findDialogForm.wholeCheckBoxIF.isChecked(),\
                False,\
                True,0,0,False)     
                findResults=None
                if foundFlag:
                    foundFiles.append(FindInFilesResults(filename,_text))
                    findResults=foundFiles[-1]
                    
                while foundFlag:
                    line,index=textEditLocal.getCursorPosition()
                    # dbgMsg("FOUND OCCURENCE IN LINE ",line)
                    findResults.addLineWithText(line,textEditLocal.text(line))
                    foundFlag=textEditLocal.findNext()
                         

            i+=1
        progressDialog.close()

        return foundFiles
        

    def replaceInFiles(self,_text,_replaceText,_filters,_directory,_mode=ALL_IN_FILES):
        # dbgMsg("search parameters",_text," ", _filters," ",_directory)
        message="About to replace all occurences of <b>\"%s\"</b>  <br> in ALL <b>\"%s\"</b> files inside directory:<br> %s  <br> Proceed?"%(_text,_filters,_directory)
        ret = QtGui.QMessageBox.warning(self, "Replace in Files",
                message,
                QtGui.QMessageBox.Ok |QtGui.QMessageBox.Cancel)
        if ret == QtGui.QMessageBox.Cancel:            
            return 
            
            
        reFlag=False
        
        if str(self.findDialogForm.syntaxComboBoxIF.currentText())=="Regular expression":
            reFlag=True        
            
        newSearchFlag=self.findAndReplaceHistory.newReplaceParametersIF(_text,_replaceText,_filters,_directory)        
        # self.findDialogForm.initializeAllSearchLists(self.findAndReplaceHistory)
        
        self.findDialogForm.setEnabled(False)
        #constructing the list of files to be searched based on directory and filters input
        
        import fnmatch
        import os
        filters=str(_filters).split()
        dbgMsg(filters)
        
        matches = []
        if _mode==ALL_IN_FILES:
            for filter in filters:
                if self.findDialogForm.inAllSubFoldersCheckBoxIF.isChecked():
                    for root, dirnames, filenames in os.walk(str(_directory)):
                        for filename in fnmatch.filter(filenames, filter):
                            matches.append(os.path.join(root, filename))
                else:
                    root=str(_directory)
                    for filename in os.listdir(root):
                        if fnmatch.fnmatch(filename, filter):
                            matches.append(os.path.join(root, filename))
                        
        
            
        # dbgMsg("matches=",matches)
        
        replaceInFilesData=[]
        
        if _mode==ALL_IN_FILES:
            replaceInFilesData=self.processReplaceInFiles(matches,_text,_replaceText,reFlag)
        elif _mode==ALL_IN_ALL_OPEN_DOCS: 
            replaceInFilesData=self.processReplaceInAllOpenDocs(_text,_replaceText,reFlag)
        else:
            self.findDialogForm.setEnabled(True)
            return
        
        try:
            message="Replaced %s occurences of \"<b>%s</b>\" in %s files"%(str(replaceInFilesData[0]),_text,str(replaceInFilesData[1]))
            ret = QtGui.QMessageBox.information(self, "Replace in Files",
                    message,
                    QtGui.QMessageBox.Ok )
  
        except IndexError:
            pass
            
        self.findDialogForm.setEnabled(True)    
   
    def processReplaceInAllOpenDocs(self,_text,_replaceText,_reFlag):
        # progress dialog not necessary here
        replaceInFilesData = []
        
        fileCounter=0
        substitutionCounter=0        

  
        editorList=self.getEditorList()
        
        findText=QString(_text) # a new copy of a textTo Find       
        if _reFlag:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")        
            
        for editor in editorList:
            currentLine,currentIndex = editor.getCursorPosition() # record current cursor position
            filename=self.getEditorFileName(editor)
            if filename=='':
                continue # we do not allow searching or replacing in the unsaved files
            
            foundFlag=editor.findFirst(findText,_reFlag,\
            self.findDialogForm.caseCheckBox.isChecked(),\
            self.findDialogForm.wholeCheckBox.isChecked(),\
            False,\
            True,0,0,False)            
            
            newFileCountedFlag=False 
          
            editor.beginUndoAction()

                
            while foundFlag:
                line,index=editor.getCursorPosition()

                editor.replace(_replaceText)
                
                if not newFileCountedFlag:
                    fileCounter+=1
                    newFileCountedFlag=True
                substitutionCounter+=1
                foundFlag=editor.findFirst(findText,_reFlag,\
                self.findDialogForm.caseCheckBox.isChecked(),\
                self.findDialogForm.wholeCheckBox.isChecked(),\
                False)

            editor.endUndoAction()    
            editor.setCursorPosition(currentLine,currentIndex)   # restore cursor position
            
        replaceInFilesData=[substitutionCounter,fileCounter]    
        return replaceInFilesData
        # no progress dialog is necessary
        
    def processReplaceInFiles(self, _files, _text,_replaceText,_reFlag=False):
        # have to deal with files which are currently open - enable undo action and use open editor for them
        #dbgMsg(warning before execution replace in files)
        progressDialog = QtGui.QProgressDialog(self)

        progressDialog.setCancelButtonText("&Cancel")
        numberOfFiles=len(_files)
        progressDialog.setRange(0, numberOfFiles)
        progressDialog.setWindowTitle("Replacing Text in Files")
        
        findText=QString(_text) # a new copy of a textTo Find       
        if _reFlag:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")
            
        replaceInFilesData = []
        i=1
        # this is used to construct dict of open files
        openFileDict=self.getFileNameToEditorWidgetMap()
        
        fileCounter=0
        substitutionCounter=0        
        
        
        
        for filename in _files:
            # dbgMsg("SEARCHING ", filename)
            progressDialog.setValue(i)
            progressDialog.setLabelText("Searching file number %d of %d..." % (i, numberOfFiles))
            QtGui.qApp.processEvents()

            if progressDialog.wasCanceled():
                break
                
            textEditLocal=None    
            
            usingOpenEditor=False
            openFileForReplaceFlag=False
            
            fileNameNormalized=os.path.abspath(str(filename))
            
            if fileNameNormalized in  openFileDict.keys():
                # textEditLocal=self.editTab.currentWidget()
                textEditLocal=openFileDict[fileNameNormalized]
                textEditLocal.setCursorPosition(0,0) # have to move cursor to the begining of the document

                usingOpenEditor=True
            else:
                
            
                inFile = QtCore.QFile(filename)
                if not inFile.open(QtCore.QIODevice.ReadWrite): # this will take care of write protected files - we will not process them   
                    continue
                stream = QtCore.QTextStream(inFile)
                textEditLocal=QsciScintillaCustom()                
                textEditLocal.setText(stream.readAll())
                
            # if inFile.open(QtCore.QIODevice.ReadWrite): # this will take care of write protected files - we will not process them
            # stream = QtCore.QTextStream(inFile)
            
            # if not textEditLocal:
                # textEditLocal=QsciScintillaCustom()                
                # textEditLocal.setText(stream.readAll())
            
            foundFlag=textEditLocal.findFirst(findText,_reFlag,\
            self.findDialogForm.caseCheckBoxIF.isChecked(),\
            self.findDialogForm.wholeCheckBoxIF.isChecked(),\
            False,\
            True,0,0,False)     
            findResults=None

                
            newFileCountedFlag=False 
            if usingOpenEditor:
                textEditLocal.beginUndoAction()
                # textEditLocal.modificationChanged.disconnect(self.textChangedHandlers[textEditLocal].handleModificationChanged) 
                
            while foundFlag:
                line,index=textEditLocal.getCursorPosition()
                textEditLocal.replace(_replaceText)
                
                if not newFileCountedFlag:
                    fileCounter+=1
                    newFileCountedFlag=True
                substitutionCounter+=1
                foundFlag=textEditLocal.findFirst(findText,_reFlag,\
                self.findDialogForm.caseCheckBoxIF.isChecked(),\
                self.findDialogForm.wholeCheckBoxIF.isChecked(),\
                False)
     
                
            if usingOpenEditor:
                textEditLocal.endUndoAction()

                if newFileCountedFlag:
                    self.saveFile(filename,textEditLocal) # using saveFile function for open editor
                    # heve to deactivate modification time sensing
                    textEditLocal.modificationChanged.disconnect(self.textChangedHandlers[textEditLocal].handleModificationChanged)
                    
                    self.setEditorFileModificationTime(textEditLocal,os.path.getmtime(str(filename)))
                    
                    # heve to reactivate modification time sensing
                    textEditLocal.modificationChanged.connect(self.textChangedHandlers[textEditLocal].handleModificationChanged)
                    # self.reloadFile(textEditLocal,self.fileDict[textEditLocal][0])
                # textEditLocal.modificationChanged.connect(self.textChangedHandlers[textEditLocal].handleModificationChanged)     
            else:    
                
                inFile.close() # before writing we close the file - alternatively we may move file pointer to the begining
                
                if newFileCountedFlag and inFile.open(QtCore.QIODevice.WriteOnly):   
                    outf = QtCore.QTextStream(inFile)
                    outf << textEditLocal.text()

            i+=1
            
        progressDialog.close()
        
        replaceInFilesData=[substitutionCounter,fileCounter]
        return replaceInFilesData

    def swapEscaping(self,_str,_char):
        """
            This fcn escapes character _str and if it is escaped it unescapes it 
        """
        dbgMsg("string=",_str)                                       
        idx=0

        while idx>=0:
            idx=_str.indexOf(_char,idx)
            # pd("Found index in position ",idx)
            if idx==0:
                _str.insert(idx,"\\")
                idx+=2
            elif idx>=1:
                
                if QString(_str.at(idx-1))=="\\":
                    
                    _str.remove(idx-1,1)
                else:
                    _str.insert(idx,"\\")
                    idx+=2    
        return _str
        
    def findNext(self,_text):
        editor=self.editTab.currentWidget()
        self.findDialogForm.setEnabled(False)
        reFlag=False
        
        if str(self.findDialogForm.syntaxComboBox.currentText())=="Regular expression":
            reFlag=True
            
        # dbgMsg("RE FLAG:=",reFlag)
        

        
        newSearchFlag=self.findAndReplaceHistory.newSearchParameters(_text,reFlag,self.findDialogForm.caseCheckBox.isChecked(),self.findDialogForm.wholeCheckBox.isChecked(),True,self.findDialogForm.inSelectionBox.isChecked())
        # dbgMsg("self.findDialogForm.wholeCheckBox.isChecked()=",self.findDialogForm.wholeCheckBox.isChecked())
        # this is handled in the showEvent of the find inf files dialog
        # self.findDialogForm.initializeSearchLists(self.findAndReplaceHistory)
 
        
        # dbgMsg("self.findAndReplaceHistory.re:=",self.findAndReplaceHistory.re)    
        findText=QString(self.findAndReplaceHistory.textToFind) # a new copy of a textTo Find
        if self.findAndReplaceHistory.re:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")
            # pd("findText=",findText)
                
        if newSearchFlag:
            foundFlag=editor.findFirst(findText,self.findAndReplaceHistory.re,self.findAndReplaceHistory.cs,self.findAndReplaceHistory.wo,self.findAndReplaceHistory.wrap)
            if not foundFlag:                
                message="Cannot find \"<b>%s</b>\""%self.findAndReplaceHistory.textToFind
                ret = QtGui.QMessageBox.information(self, "Find",
                        message,
                        QtGui.QMessageBox.Ok )            
        else:
            # pd("calling findNext")
            # for some reason findNext does not work after undo action...
            foundFlag=editor.findFirst(findText,self.findAndReplaceHistory.re,self.findAndReplaceHistory.cs,self.findAndReplaceHistory.wo,self.findAndReplaceHistory.wrap)
            # foundFlag=editor.findNext()    
            # pd("find next flag=",foundFlag)
            if not foundFlag:                
                message="Cannot find \"<b>%s</b>\""%self.findAndReplaceHistory.textToFind
                ret = QtGui.QMessageBox.information(self, "Find",
                        message,
                        QtGui.QMessageBox.Ok )             

        self.findDialogForm.setEnabled(True)    
        
    def findNextSimple(self):
        editor=self.editTab.currentWidget() 
        editor.findNext()
        
    def replaceNext(self,_text,_replaceText):
        # dbgMsg("Find text=",_text," replaceText=",_replaceText   )
        self.findDialogForm.setEnabled(False)
        editor=self.editTab.currentWidget()
        
        reFlag=False
        inSelectionFlag=self.findDialogForm.inSelectionBox.isChecked()
        
        if str(self.findDialogForm.syntaxComboBox.currentText())=="Regular expression":
            reFlag=True
            
        newReplaceFlag=self.findAndReplaceHistory.newReplaceParameters(_text,_replaceText,reFlag,self.findDialogForm.caseCheckBox.isChecked(),self.findDialogForm.wholeCheckBox.isChecked(),True,inSelectionFlag)

        # self.findDialogForm.initializeSearchLists(self.findAndReplaceHistory)

        findText=QString(_text)
        # pd("REPLACE newReplaceFlag=",newReplaceFlag)
        if self.findAndReplaceHistory.re:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")
            
        lineFrom,indexFrom,lineTo,indexTo=editor.getSelection()    
        
        if newReplaceFlag:

            
            foundFlag=editor.findFirst(findText,self.findAndReplaceHistory.re,self.findAndReplaceHistory.cs,self.findAndReplaceHistory.wo,False,True,lineFrom,indexFrom)
            if not foundFlag:                
                message="Cannot find \"<b>%s</b>\""%self.findAndReplaceHistory.textToFind
                ret = QtGui.QMessageBox.information(self, "Replace",
                        message,
                        QtGui.QMessageBox.Ok )
                self.findDialogForm.setEnabled(True)        
                return
            
            editor.replace(self.findAndReplaceHistory.replaceText)
        else:
            #for some reason there are problem using findNext together with replace - since editor is expanding consecutive calls 
            # to replace (especially when replacing short string with long string) result in replace abbandoning changes because it may think there is not eanough space. findFirst works fine though
            foundFlag=editor.findFirst(findText,self.findAndReplaceHistory.re,self.findAndReplaceHistory.cs,self.findAndReplaceHistory.wo,True,True)
            # editor.SendScintilla(QsciScintilla.SCI_REPLACESEL,0, self.findAndReplaceHistory.replaceText)
            if not foundFlag:                
                message="Cannot find \"<b>%s</b>\""%self.findAndReplaceHistory.textToFind
                ret = QtGui.QMessageBox.information(self, "Replace",
                        message,
                        QtGui.QMessageBox.Ok )
                self.findDialogForm.setEnabled(True)                
                return            
            
            editor.replace(self.findAndReplaceHistory.replaceText)
            
    def replaceAll(self,_text,_replaceText,_inSelectionFlag):
        # dbgMsg("Find text=",_text," replaceText=",_replaceText   )
        self.findDialogForm.setEnabled(False)        
        editor=self.editTab.currentWidget()
        
        reFlag=False
        inSelectionFlag=_inSelectionFlag
        
        if str(self.findDialogForm.syntaxComboBox.currentText())=="Regular expression":
            reFlag=True
        
        newReplaceFlag=self.findAndReplaceHistory.newReplaceParameters(_text,_replaceText,reFlag,self.findDialogForm.caseCheckBox.isChecked(),self.findDialogForm.wholeCheckBox.isChecked(),True,inSelectionFlag)
        
        # self.findDialogForm.initializeSearchLists(self.findAndReplaceHistory)
        
        substitutionCounter=0 

        findText=QString(self.findAndReplaceHistory.textToFind) # a new copy of a textTo Find       
        if self.findAndReplaceHistory.re:
            #here I will replace ( with \( and vice versa - to be consistent with  regex convention                   
            findText=self.swapEscaping(findText,"(")
            findText=self.swapEscaping(findText,")")
        
        if inSelectionFlag and editor.hasSelectedText():
        # if editor.hasSelectedText():
            line_before, index_before = editor.getCursorPosition()
            line_from, index_from, line_to, index_to = editor.getSelection()
            foundFlag=editor.findFirst(findText,\
            self.findAndReplaceHistory.re,\
            self.findAndReplaceHistory.cs,\
            self.findAndReplaceHistory.wo,\
            False,\
            True,line_from,index_from,False)     
            if not foundFlag:                
                message="Cannot find \"<b>%s</b>\""%self.findAndReplaceHistory.textToFind
                ret = QtGui.QMessageBox.information(self, "Replace All",
                        message,
                        QtGui.QMessageBox.Ok )
                self.findDialogForm.setEnabled(True)                
                return            
            line, index = editor.getCursorPosition()
            
            editor.beginUndoAction() # undo
            while foundFlag and (line<line_to or (line==line_to and index<=index_to)) :                 
                # dbgMsg("line, index=",line, index)
                editor.replace(self.findAndReplaceHistory.replaceText)
                substitutionCounter+=1 
                foundFlag=editor.findFirst(findText,\
                self.findAndReplaceHistory.re,\
                self.findAndReplaceHistory.cs,\
                self.findAndReplaceHistory.wo,\
                False)                 
                # editor.findNext()    
                line, index = editor.getCursorPosition()
            editor.endUndoAction() # undo
            
            editor.setCursorPosition(line_before, index_before)    
        elif not inSelectionFlag:
        
            line_from=0 
            index_from=0
            line_before, index_before = editor.getCursorPosition()
            foundFlag=editor.findFirst(findText,\
            self.findAndReplaceHistory.re,\
            self.findAndReplaceHistory.cs,\
            self.findAndReplaceHistory.wo,\
            False,\
            True,line_from,index_from,False)     
            editor.beginUndoAction() # undo                    
            if not foundFlag:                
                message="Cannot find \"<b>%s</b>\""%self.findAndReplaceHistory.textToFind
                ret = QtGui.QMessageBox.information(self, "Replace All",
                        message,
                        QtGui.QMessageBox.Ok )
                self.findDialogForm.setEnabled(True)                
                return                
            # previousLine,previousPos=editor.getCursorPosition()
            while foundFlag:
                # dbgMsg("FOUND TEXT ",findText, " position ", editor.getCursorPosition())
                editor.replace(self.findAndReplaceHistory.replaceText)
                substitutionCounter+=1 
                foundFlag=editor.findFirst(findText,\
                self.findAndReplaceHistory.re,\
                self.findAndReplaceHistory.cs,\
                self.findAndReplaceHistory.wo,\
                False)

            editor.endUndoAction() # undo   
            
            editor.setCursorPosition(line_before, index_before)   

        
        message="Replaced %s occurences of \"<b>%s</b>\""%(str(substitutionCounter),_text)
        ret = QtGui.QMessageBox.information(self, "Replace in Files",
                message,
                QtGui.QMessageBox.Ok )
                
        self.findDialogForm.setEnabled(True)            
        # dbgMsg("replaceAll")
        
    def marginClickedHandler(self,_margin,_line,_keyboardState):
        editor=self.editTab.currentWidget()      
        if _margin==1:
            if editor.markersAtLine(_line)!=self.bookmarkMask: # check if there is marker in this liine
                marker=editor.markerAdd(_line,self.lineBookmark)                  
            else: #otherwise remove bookmark
                editor.markerDelete(_line)  	
        
    
    def toggleBookmark(self):
        # dbgMsg("Toggle bookmarks, marker=",self.lineBookmark        )
        editor=self.editTab.currentWidget()
        line, index = editor.getCursorPosition()        
        if editor.markersAtLine(line)!=self.bookmarkMask: # check if there is marker in this liine
            # dbgMsg("ADDING BOOKMARK")
            # if not add bookmark
            marker=editor.markerAdd(line,self.lineBookmark)  
            
        else: #otherwise remove bookmark
            # dbgMsg("REMOVING BOOKMARK")
            editor.markerDelete(line)  	
        
        

    def goToNextBookmark(self):
        # dbgMsg(" Next Bookmark" )
        editor=self.editTab.currentWidget()
        line, index = editor.getCursorPosition()
        # dbgMsg("current line=",line)
        lineNext=editor.markerFindNext(line,self.bookmarkMask)
        # dbgMsg("lineNext=",lineNext," line=",line)
        
        if lineNext==line:
            lineNext=editor.markerFindNext(line+1,self.bookmarkMask)
            
        if  lineNext==-1:
            lineNext=editor.markerFindNext(0,self.bookmarkMask)
            if lineNext==-1:
                return

        if lineNext!=line and lineNext!=-1:
            editor.setCursorPosition(lineNext,0)
            return

                
    def goToPreviousBookmark(self):
        # dbgMsg(" Previous Bookmark" )
        editor=self.editTab.currentWidget()
        line, index = editor.getCursorPosition()
        
        linePrevious=editor.markerFindPrevious(line,self.bookmarkMask)
        # dbgMsg("linePrevious=",linePrevious," line=",line)
        
        if linePrevious==line:
            linePrevious=editor.markerFindPrevious(line-1,self.bookmarkMask)
            
        if  linePrevious==-1:
            linePrevious=editor.markerFindPrevious(editor.lines(),self.bookmarkMask)
            if linePrevious==-1:
                return
        
        if linePrevious!=line and linePrevious!=-1:
            editor.setCursorPosition(linePrevious,0)
            return        
        
    def deleteAllBookmarks(self):
        editor=self.editTab.currentWidget()
        editor.markerDeleteAll(self.lineBookmark)

    def goToLineShow(self,_line):
        editor=self.editTab.currentWidget()
        self.goToLineDlg=GoToLineDlg(editor,self)
        self.goToLineDlg.show()
        #self.goToLineDlg.setFocus(True)
        #self.goToLineDlg.activateWindow()

    def goToLine(self,_line):
        dbgMsg("GO TO LINE SLOT = ",_line)
        editor=self.editTab.currentWidget()
        editor.setCursorPosition(_line-1,0)
        

        
    def goToMatchingBrace(self):        
        editor=self.editTab.currentWidget()
        editor.moveToMatchingBrace()
        
    def selectToMatchingBrace(self):
        # dbgMsg("select to matching brace")
        editor=self.editTab.currentWidget()
        editor.selectToMatchingBrace()
        
    def configurationUpdate(self):
        # dbgMsg("configuration update")
        editor=self.editTab.currentWidget()
        configurationDlg= ConfigurationDlg(editor,self)
        if configurationDlg.exec_():
            for key in self.configuration.updatedConfigs.keys():
                dbgMsg("NEW SETTING = ",key,":",self.configuration.updatedConfigs[key])
                configureFcn=getattr(self,"configure"+key)
                configureFcn(self.configuration.updatedConfigs[key])
        self.checkActions()                    

    def configureRestoreTabsOnStartup(self,_flag):
        self.configuration.setSetting("RestoreTabsOnStartup",_flag)
        
    def configureBaseFontName(self,_name):
        self.configuration.setSetting("BaseFontName",_name)
        self.baseFont=QFont(self.configuration.setting("BaseFontName"),int(self.configuration.setting("BaseFontSize")))
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            lexer=self.editTab.widget(i).lexer()
            if lexer:
                lexer.setFont(self.baseFont)    
        
            self.editTab.widget(i).setFont(self.baseFont) 
        
        
        
    def configureBaseFontSize(self,_size):
        self.configuration.setSetting("BaseFontSize",int(_size))
        self.baseFont=QFont(self.configuration.setting("BaseFontName"),int(self.configuration.setting("BaseFontSize")))
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            lexer=self.editTab.widget(i).lexer()
            if lexer:
                lexer.setFont(self.baseFont)    
            self.editTab.widget(i).setFont(self.baseFont)
            
        
        
    def configureUseTabSpaces(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            self.editTab.widget(i).setIndentationsUseTabs( not _flag)
            if _flag:
                self.editTab.widget(i).setIndentationWidth(self.configuration.setting("TabSpaces")) 
            else:
                self.editTab.widget(i).setIndentationWidth(0) # If width is 0 then the value returned by tabWidth() is used 
                
        
            
    def configureTabSpaces(self,_value):
        numberOfDocuments=self.editTab.count()
        
        flag=self.configuration.setting("UseTabSpaces")
        for i in  range(numberOfDocuments):
            self.editTab.widget(i).setIndentationsUseTabs( not flag)
            if flag:
                self.editTab.widget(i).setIndentationWidth(_value) 
            else:
                self.editTab.widget(i).setIndentationWidth(0) # If width is 0 then the value returned by tabWidth() is used 
                
        
                
                
    def configureFoldText(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            if _flag:
                self.editTab.widget(i).setFolding(QsciScintilla.BoxedTreeFoldStyle) # 5 corresponds to BoxedTreeFoldStyle
            else:
                self.editTab.widget(i).setFolding(QsciScintilla.NoFoldStyle) # no folding
                
        
    
    def configureDisplayWhitespace(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            if _flag:
                self.editTab.widget(i).setWhitespaceVisibility(QsciScintilla.SCWS_VISIBLEALWAYS) # 
            else:
                self.editTab.widget(i).setWhitespaceVisibility(QsciScintilla.SCWS_INVISIBLE) # no whitespaces
                
        
                
    def configureDisplayEOL(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            self.editTab.widget(i).setEolVisibility(_flag)
            
        

    def configureWrapLines(self,_flag):
    
        # on Mac setting word wrap can be very slow so it is best to avoid processing many documents at once
        
        if sys.platform.startswith('darwin'):
            return
            
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            if _flag:            
                self.editTab.widget(i).setWrapMode(QsciScintilla.WrapWord)
            else:
                self.editTab.widget(i).setWrapMode(QsciScintilla.WrapNone)
                
        

    def configureShowWrapSymbol(self,_flag):
        numberOfDocuments=self.editTab.count()        
        for i in  range(numberOfDocuments):
            if _flag:            
                self.editTab.widget(i).setWrapVisualFlags(QsciScintilla.WrapFlagByText)
            else:
                self.editTab.widget(i).setWrapVisualFlags(QsciScintilla.WrapFlagNone)
        
        
                
    def configureTabGuidelines(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            self.editTab.widget(i).setIndentationGuides(_flag)  
            
        
            
    def configureDisplayLineNumbers(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            # self.editTab.widget(i).setMarginLineNumbers(1,_flag)
            self.editTab.widget(i).setMarginLineNumbers(0, _flag)
            self.editTab.widget(i).setMarginWidth(0,QString('0'*8*int(_flag)))     
            
        

            
    def configureEnableAutocompletion(self,_flag):
        numberOfDocuments=self.editTab.count()
        for i in  range(numberOfDocuments):
            if _flag:
                self.editTab.widget(i).setAutoCompletionThreshold(self.configuration.setting("AutocompletionThreshold"))
                self.editTab.widget(i).setAutoCompletionSource(QsciScintilla.AcsAll)
            else:
                self.editTab.widget(i).setAutoCompletionSource(QsciScintilla.AcsNone)
    
    def configureAutocompletionThreshold(self,_value):
        numberOfDocuments=self.editTab.count()
        flag=self.configuration.setting("EnableAutocompletion")
        for i in  range(numberOfDocuments):
            if flag:
                self.editTab.widget(i).setAutoCompletionThreshold(_value)
                self.editTab.widget(i).setAutoCompletionSource(QsciScintilla.AcsAll)
            else:
                self.editTab.widget(i).setAutoCompletionThreshold(_value)
                self.editTab.widget(i).setAutoCompletionSource(QsciScintilla.None)
    
    
    def newFile(self):
        
        # am.setActionKeyboardShortcut("New","Ctrl+P")
        
        textEditLocal = QsciScintillaCustom()
        textEditLocal.clear()
        self.editTab.addTab(textEditLocal,QtGui.QIcon(':/icons/document-clean.png'),"New Document "+str(self.editTab.count()+1))
        self.editTab.setCurrentWidget(textEditLocal)        
   
        self.setCurrentFile('')
        self.setEditorProperties(textEditLocal)
        self.commentStyleDict[self.editTab.currentWidget()]=['','']
        self.setPropertiesInEditorList(self.editTab.currentWidget(),'',0,'utf-8')

        # adding text Changed Handler
        self.textChangedHandlers[textEditLocal]=ChangedTextHandler(textEditLocal,self)
        editorIndex=self.editTab.indexOf(textEditLocal)

        self.editTab.widget(editorIndex).modificationChanged.connect(self.textChangedHandlers[textEditLocal].handleModificationChanged)
        self.editTab.widget(editorIndex).textChanged.connect(self.textChangedHandlers[textEditLocal].handleChangedText)
        self.editTab.widget(editorIndex).cursorPositionChanged.connect(self.handleCursorPositionChanged)

    def open(self):
        # if self.maybeSave():
        #get path to file in the current widget
        
        # REMARK: on some linux distros you need to run manually ibus-setup to enable proper behavior of QFile dialog. 
        # Maybe there is a way to ensure it without this step - have to check it though
        dbgMsg("INSIDE OPEN")
        currentFilePath=None
        try:
            # currentFilePath=self.fileDict[self.editTab.currentWidget()][0]  
            currentFilePath=self.getEditorFileName(self.editTab.currentWidget())              
        except KeyError:
            
            pass
            
        if currentFilePath:
            currentFilePath=os.path.dirname(str(currentFilePath))
            self.lastFileOpenPath=currentFilePath
        else:
            currentFilePath=self.lastFileOpenPath
            
        dbgMsg("THIS IS CURRENT PATH=",currentFilePath)
        fileNames = QtGui.QFileDialog.getOpenFileNames(self,"Open new file...",currentFilePath,self.fileDialogFilters)
        if fileNames.count():
            self.loadFiles(fileNames)                
                
    def closeTabIndex(self, index):
        self.closeTab(index)
        
    def closeTab(self, index=None,_askToSave=True):
        dbgMsg("closing tab ",index)
        textEditLocal=None
        if index is not None and not isinstance(index, bool) : # ctrl+w calls closeTab with False bool type argument and we need to make sure that it is not converted to int index
            textEditLocal=self.editTab.widget(index)
        else:
            textEditLocal= self.editTab.currentWidget()   
        
        
        if _askToSave:
            reallyClose=self.maybeSave(textEditLocal)
            if not reallyClose:
                return
            
        
        if self.editTab.count()==1:
            self.editTab.currentWidget().clear()
            self.editTab.currentWidget().setModified(False) # clearing document modifies its content but since no new text has been typed we set modified to false              
            self.editTab.setTabText(0,'Empty Document')
            self.setCurrentFile('')
            self.commentStyleDict[self.editTab.currentWidget()]=['','']
            if self.editTab.currentWidget() in self.getEditorList():
                # del self.fileDict[self.editTab.currentWidget()]
                self.removeEditor(self.editTab.currentWidget())

            self.editTab.setTabIcon(0,QtGui.QIcon(':/icons/document-clean.png') ) 
        else:
            self.editTab.removeTab( self.editTab.indexOf(textEditLocal))
            del self.commentStyleDict[textEditLocal]
            
            # try:
                
            # except KeyError,e: # not all documents will have lexer
                # pass
            self.removeEditor(textEditLocal)
            # del self.fileDict[textEditLocal]
            
            if self.editTab.currentWidget() in self.textChangedHandlers:    
                del self.textChangedHandlers[textEditLocal]
            
    def foldAll(self):
        editor= self.editTab.currentWidget()
        editor.foldAll(True) 
        # editor.foldAll()

    def wrapLines(self,_flag):        
        editor= self.editTab.currentWidget()
        if not editor:
            return
            
        if not _flag:
            editor.setWrapMode(QsciScintilla.WrapNone)        
        else:
            if sys.platform.startswith('darwin'):
                if not self.configuration.setting("DontShowWrapLinesWarning"):   
                    msgBox=QMessageBox(QMessageBox.Warning,"Wrap Lines Warning","<b>Wrap Line operation on OS X may take a long time<\b>")
                    dontAskCheckBox=QCheckBox("Do not display this warning again",msgBox)
                    dontAskCheckBox.blockSignals(True)
                    msgBox.addButton(dontAskCheckBox,QMessageBox.ActionRole)
                    # msgBox.setTitle("Wrap Lines Warning")
                    
                    # msgBox.setText("<b>Wrap Line operation on OS X may take a long time<\b>");
                    msgBox.setInformativeText("Proceed?")
                    msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No )
                    msgBox.setDefaultButton(QMessageBox.No)
                    ret = msgBox.exec_()
                    
                    if ret==QMessageBox.Yes :
                        self.configuration.setSetting("DontShowWrapLinesWarning",dontAskCheckBox.isChecked())
                    else:    
                        self.configuration.setSetting("DontShowWrapLinesWarning",dontAskCheckBox.isChecked())
                        return

            editor.setWrapMode(QsciScintilla.WrapWord)

        
    def showWhitespaces(self,_flag):
        editor= self.editTab.currentWidget()
        if not editor:
            return
            
        if _flag:
            editor.setWhitespaceVisibility(QsciScintilla.SCWS_VISIBLEALWAYS)
        else:
            editor.setWhitespaceVisibility(QsciScintilla.SCWS_INVISIBLE)
            
    def showEOL(self,_flag):
        editor= self.editTab.currentWidget()
        if not editor:
            return
            
        editor.setEolVisibility(_flag)    
       
    def showTabGuidelines(self,_flag):
        editor= self.editTab.currentWidget()
        if not editor:
            return
        editor.setIndentationGuides(_flag)    
        
    def showLineNumbers(self,_flag):
        editor= self.editTab.currentWidget()    
        editor.setMarginLineNumbers(0, _flag)
        editor.setMarginWidth(0,QString('0'*8*int(_flag)))     
    
    def zoomIn(self):
        # editor=self.editTab.currentWidget()
        self.zoomRange+=1
        self.configuration.setSetting("ZoomRange",self.zoomRange)
        for editor in self.getEditorList():            
            editor.zoomIn()

        
    def zoomOut(self):
        self.zoomRange-=1
        self.configuration.setSetting("ZoomRange",self.zoomRange)
        for editor in self.getEditorList():            
            editor.zoomOut()    
           
    def save(self):
        
        editor=self.editTab.currentWidget()
        fileName=''
        if editor in self.getEditorList():
            fileName=self.getEditorFileName(editor)
            
        if fileName:
            return self.saveFile(fileName)

        return self.saveAs()

    def saveAs(self,suggestedName=None):
        # self.deactivateChangeSensing=True
        currentFilePath=None
        currentExtension=""
        try:
            # currentFilePath=self.fileDict[self.editTab.currentWidget()][0] 
            currentFilePath=self.getEditorFileName(self.editTab.currentWidget())             
        except KeyError:
            pass
            
        if currentFilePath:
            fileSplit=os.path.splitext(str(currentFilePath))
            currentExtension=fileSplit[1]                    
            # currentFilePath=os.path.dirname(str(currentFilePath))
            
            self.lastFileOpenPath=currentFilePath
        else:
            currentFilePath=self.lastFileOpenPath
            
        dbgMsg("suggestedName=",suggestedName)
        fileName=""
        if suggestedName is None or  isinstance(suggestedName, bool) : # saveAs is called by default with False bool type argument and we need to make sure that it is not converted to int index

            currentFilterString=self.getCurrentFilterString(currentExtension)
            dbgMsg("currentFilterString=",currentFilterString)
            # currentFilterString="Text file (*.txt)"
            # behavior of file dialog is different on OSX appending preferred filter at the top does not really work , so we do not and the behavior is OK
            if sys.platform=='darwin':            
                fileName=QtGui.QFileDialog.getSaveFileName(self,"Save File",currentFilePath,self.fileDialogFilters)
            else:
                fileName=QtGui.QFileDialog.getSaveFileName(self,"Save File",currentFilePath,currentFilterString+";;"+self.fileDialogFilters)            
            dbgMsg("SAVE FILE NAME is:",fileName)
            if fileName=="":
                return False
            
                
        else:          
            dbgMsg("")
            fileName = QtGui.QFileDialog.getSaveFileName(self,"Save File",suggestedName)
            if fileName=="":
                return False            
            
        fileName=os.path.abspath(str(fileName)) # "normalizing" file name to make sure \ and / are used in a consistent manner 
            
        if fileName:
            returnCode = self.saveFile(fileName)        
            if returnCode:
                lexer=self.guessLexer(fileName)
                if lexer[0]:
                    self.editTab.currentWidget().setLexer(lexer[0])             
                    self.editTab.currentWidget().setBraceMatching(lexer[3])
                    if self.configuration.setting("FoldText"):
                        self.editTab.currentWidget().setFolding(QsciScintilla.BoxedTreeFoldStyle)
                    else:
                        self.editTab.currentWidget().setFolding(QsciScintilla.NoFoldStyle)                
                    self.editTab.currentWidget().setWhitespaceVisibility(self.configuration.setting("DisplayWhitespace"))
                    self.editTab.currentWidget().setIndentationGuidesForegroundColor(self.indendationGuidesColor)
                    self.editTab.currentWidget().setIndentationGuides(self.configuration.setting("TabGuidelines"))  	
                else:# lexer could not be guessed - use default lexer
                    self.editTab.currentWidget().setLexer(None)
                    
                tabIndex=self.editTab.indexOf(self.editTab.currentWidget())
                self.editTab.setTabText(tabIndex,self.strippedName(fileName))
                self.commentStyleDict[self.editTab.currentWidget()]=[lexer[1],lexer[2]] # associating comment style with the lexer
                currentEncoding=self.getEditorFileEncoding(self.editTab.currentWidget())
                self.setPropertiesInEditorList(self.editTab.currentWidget(),fileName,os.path.getmtime(str(fileName)),currentEncoding)
            return returnCode

        return False

    def saveAll(self):
       
        unnamedFiles={}    
        
        for editor in self.getEditorList():            
            if not self.getEditorFileName(editor)=='':
                index=self.editTab.indexOf(editor)
                self.editTab.setCurrentIndex(index)
                if self.editTab.currentWidget().isModified():
                    self.save()
                else:
                    self.editTab.setTabIcon(index,QtGui.QIcon(':/icons/document-clean.png'))
            else:
                index=self.editTab.indexOf(editor)
                unnamedFiles[editor]=self.editTab.tabText(index)   
        # dealing with unnamed files:
        for editor in unnamedFiles.keys():
            if editor==self.defaultEditor: #we will not attempt to save content of the default editor. This editor should be removed anyway the moment we open any new file 
                continue
            index=self.editTab.indexOf(editor)
            self.editTab.setCurrentIndex(index)
            self.saveAs(unnamedFiles[editor])
        
    def about(self):
        QtGui.QMessageBox.about(self, "About Twedit++ - ver. %s.%s.%s"%(VERSION_MAJOR,VERSION_MINOR,VERSION_BUILD),
                "The <b>Twedit++</b>  editor is a free Open-Source programmers editor\n"
                "Originally it was meant to be editor for Twitter and we limitted number of characters to 144\n"
                "However, after feedback from our users we were surprised to learn that people need more 144 characters to\n"
                "write software. We have since removed the limitation on number of characters... \n"
                "As a courtesy to our users no code written in this editor is catalogued by Google or any other data-mining company.\n"
                "<br><br>"
                "Copyright: Maciej Swat, <b>Swat International Productions, Inc.</b><br><br>"
                "Version %s.%s.%s"%(VERSION_MAJOR,VERSION_MINOR,VERSION_BUILD)
                )

    def documentWasModified(self):
        self.setWindowModified(self.textEdit.document().isModified())

    def createActions(self):
    
        
        self.newAct = QtGui.QAction(QtGui.QIcon(':/icons/document-new.png'), "&New",
                self, shortcut=QtGui.QKeySequence.New,
                statusTip="Create a new file", triggered=self.newFile)

        am.addAction(self.newAct)               
        
        self.openAct = QtGui.QAction(QtGui.QIcon(':/icons/document-open.png'),
                "&Open...", self, shortcut=QtGui.QKeySequence.Open,
                statusTip="Open an existing file", triggered=self.open)

        am.addAction(self.openAct)                               
        
        self.saveAct = QtGui.QAction(QtGui.QIcon(':/icons/document-save.png'),
                "&Save", self, shortcut=QtGui.QKeySequence.Save,
                statusTip="Save the document to disk", triggered=self.save)
                
        am.addAction(self.saveAct)        

        self.saveAsAct = QtGui.QAction(QtGui.QIcon(':/icons/document-save-as.png'),"Save &As...", self,
                shortcut=QtGui.QKeySequence.SaveAs,
                statusTip="Save the document under a new name",
                triggered=self.saveAs)
                
        am.addAction(self.saveAsAct)
        
        self.saveAllAct = QtGui.QAction(QtGui.QIcon(':/icons/document-save-all.png'),"Save All", self,
                shortcut="Ctrl+Shift+S",
                statusTip="Save all documents",
                triggered=self.saveAll)                

        am.addAction(self.saveAllAct)        
        
        self.printAct = QtGui.QAction(QtGui.QIcon(':/icons/document-print.png'),"Print...", self,shortcut="Ctrl+P",statusTip="Print current document",triggered=self.printCurrentDocument)                
        am.addAction(self.printAct)        
        
          

        
        self.closeAllAct = QtGui.QAction("Close All Tabs", self,statusTip="Close all tabs",triggered=self.__closeAll)                        
        am.addAction(self.closeAllAct)            
        
        self.closeAllButCurrentAct = QtGui.QAction("Close All But Current Tab", self,statusTip="Close all tabs except current one",triggered=self.__closeAllButCurrent)                        
        am.addAction(self.closeAllButCurrentAct)            
        
        self.renameAct = QtGui.QAction("Rename...", self,statusTip="Rename current document",triggered=self.__rename)                        
        am.addAction(self.renameAct)            

        
        self.deleteDocAct = QtGui.QAction("Delete from disk", self,statusTip="Delete current document from disk",triggered=self.__deleteCurrentDocument)                
        am.addAction(self.deleteDocAct)            
        
        
        self.exitAct = QtGui.QAction(QtGui.QIcon(':/icons/application-exit.png'),"E&xit", self, shortcut="Ctrl+Q",
                statusTip="Exit the application", triggered=self.close)

        am.addAction(self.exitAct)        
        
        self.closeTabAct = QtGui.QAction(QtGui.QIcon(':/icons/tab-close.png'),"Close Tab", self, shortcut="Ctrl+W",
                statusTip="Close Current Tab", triggered=self.closeTab)
                
        am.addAction(self.closeTabAct)                

        self.zoomInAct = QtGui.QAction(QtGui.QIcon(':/icons/zoom-in.png'),"Zoom In", self, shortcut="Ctrl+Shift+=",
                statusTip="Zoom In", triggered=self.zoomIn)  
        
        am.addAction(self.zoomInAct)                
        
        self.zoomOutAct = QtGui.QAction(QtGui.QIcon(':/icons/zoom-out.png'),"Zoom Out", self, shortcut="Ctrl+-",
                statusTip="Zoom Out", triggered=self.zoomOut)                  
        am.addAction(self.zoomOutAct)
        
        self.foldAllAct = QtGui.QAction("Toggle Fold All", self, statusTip="Fold document at all folding points", triggered=self.foldAll)  
        am.addAction(self.foldAllAct)
        
        self.wrapLinesAct = QtGui.QAction("Wrap Lines", self, statusTip="Wrap Lines in a current document")  
        self.wrapLinesAct.setCheckable(True)
        am.addAction(self.wrapLinesAct)
        
        self.connect(self.wrapLinesAct,    SIGNAL('triggered(bool)'),  self.wrapLines)
        
        self.showWhitespacesAct = QtGui.QAction("Show Whitespaces", self, statusTip="Show whitespaces in a current document")  
        self.showWhitespacesAct.setCheckable(True)
        am.addAction(self.showWhitespacesAct)
        
        self.connect(self.showWhitespacesAct,    SIGNAL('triggered(bool)'),  self.showWhitespaces)

        self.showEOLAct = QtGui.QAction("Show EOL", self, statusTip="Show EOL in a current document")  
        self.showEOLAct.setCheckable(True)
        am.addAction(self.showEOLAct)
        
        self.connect(self.showEOLAct,    SIGNAL('triggered(bool)'),  self.showEOL)


        self.showTabGuidelinesAct = QtGui.QAction("Show Tab Guidelines", self, statusTip="Show Tab guidelines in a current document")  
        self.showTabGuidelinesAct.setCheckable(True)
        am.addAction(self.showTabGuidelinesAct)
        
        self.connect(self.showTabGuidelinesAct,    SIGNAL('triggered(bool)'),  self.showTabGuidelines)

        self.showLineNumbersAct = QtGui.QAction("Show Line Numbers", self, statusTip="Show line numbers in a current document")  
        self.showLineNumbersAct.setCheckable(True)
        am.addAction(self.showLineNumbersAct)
        
        self.connect(self.showLineNumbersAct,    SIGNAL('triggered(bool)'),  self.showLineNumbers)
        
          
        self.showFindInFilesDockAct=QtGui.QAction("Show Find in Files Results", self, statusTip="Show Find in Files Results", triggered=self.toggleFindInFilesDock)
       
        self.showFindInFilesDockAct.setCheckable(True)
        am.addAction(self.showFindInFilesDockAct)
        
        self.blockCommentAct = QtGui.QAction("Block Comment", self, shortcut="Ctrl+D",
                statusTip="Block Comment", triggered=self.blockComment)
       
        am.addAction(self.blockCommentAct)
        
        self.blockUncommentAct = QtGui.QAction("Block Uncomment", self, shortcut="Ctrl+Shift+D",
                statusTip="Block Uncomment", triggered=self.blockUncomment)  

        am.addAction(self.blockUncommentAct)        
                
                
        self.findAct = QtGui.QAction(QtGui.QIcon(':/icons/edit-find.png'),"Find...", self, shortcut="Ctrl+F",
                statusTip="Find...", triggered=self.find)  
        
        am.addAction(self.findAct)        
        
        self.findNextAct = QtGui.QAction("Find Next", self, shortcut="F3",
                statusTip="Find Next", triggered=self.findNextSimple)  
                
        am.addAction(self.findNextAct)        
        
        self.toggleBookmarkAct = QtGui.QAction(QtGui.QIcon(':/icons/flag.png'),"Toggle Bookmark", self, shortcut="Ctrl+F2",
                statusTip="Toggle Text Bookmark", triggered=self.toggleBookmark)  
        
        am.addAction(self.toggleBookmarkAct)        
        
        self.goToNextBookmarkAct = QtGui.QAction("Go To Next Bookmark", self, shortcut="F2",
                statusTip="Go To Next Bookmark", triggered=self.goToNextBookmark)  
                
        am.addAction(self.goToNextBookmarkAct)        
        
        self.goToPreviousBookmarkAct = QtGui.QAction("Go To Previous Bookmark", self, shortcut="Shift+F2",
                statusTip="Go To Previous Bookmark", triggered=self.goToPreviousBookmark)  

        am.addAction(self.goToPreviousBookmarkAct)        
        
        self.deleteAllBookmarksAct = QtGui.QAction("Delete All Bookmarks", self, shortcut="",
                statusTip="Delete All Bookmarks", triggered=self.deleteAllBookmarks) 
                
        am.addAction(self.deleteAllBookmarksAct)        
        
        self.goToLineAct = QtGui.QAction("Go To Line...", self, shortcut="Ctrl+G",
                statusTip="Go To Line", triggered=self.goToLineShow) 
                
        am.addAction(self.goToLineAct)        
                
        self.goToMatchingBraceAct = QtGui.QAction("Go To Matching Brace", self, shortcut="Ctrl+]",
                statusTip="Go To Matching Brace", triggered=self.goToMatchingBrace)  
                
        am.addAction(self.goToMatchingBraceAct)        
        
        self.selectToMatchingBraceAct = QtGui.QAction("Select To Matching Brace", self, shortcut="Ctrl+Shift+]",
                statusTip="Select To Matching Brace", triggered=self.selectToMatchingBrace)  
                
        am.addAction(self.selectToMatchingBraceAct)                
        
        self.cutAct = QtGui.QAction(QtGui.QIcon(':/icons/edit-cut.png'), "Cu&t",
                self, shortcut=QtGui.QKeySequence.Cut,
                statusTip="Cut the current selection's contents to the clipboard",
                triggered=self.cut)
                
        am.addAction(self.cutAct)                
        
        self.copyAct = QtGui.QAction(QtGui.QIcon(':/icons/edit-copy.png'),
                "&Copy", self, shortcut=QtGui.QKeySequence.Copy,
                statusTip="Copy the current selection's contents to the clipboard",
                triggered=self.copy)
                
        am.addAction(self.copyAct)                
        
        self.pasteAct = QtGui.QAction(QtGui.QIcon(':/icons/edit-paste.png'),
                "&Paste", self, shortcut=QtGui.QKeySequence.Paste,
                statusTip="Paste the clipboard's contents into the current selection",
                triggered=self.paste)
                
        am.addAction(self.pasteAct)                
        
        self.increaseIndentAct = QtGui.QAction(QtGui.QIcon(':/icons/format-indent-more.png'),"Increase Indent", self, shortcut="Tab",
                statusTip="Increase Indent", triggered=self.increaseIndent)  
        am.addAction(self.increaseIndentAct)                        
                
        self.decreaseIndentAct = QtGui.QAction(QtGui.QIcon(':/icons/format-indent-less.png'),"Decrease Indent", self, shortcut="Shift+Tab",
                statusTip="Decrease Indent", triggered=self.decreaseIndent)  
        am.addAction(self.decreaseIndentAct)                                
                
        self.upperCaseAct=QtGui.QAction("Convert to UPPER case", self, shortcut="Ctrl+Shift+U",
                statusTip="Convert To Upper Case", triggered=self.convertToUpperCase)
        am.addAction(self.upperCaseAct)                                        
                
        self.lowerCaseAct=QtGui.QAction("Convert to lower case", self, shortcut="Ctrl+U",
                statusTip="Convert To Lower Case", triggered=self.convertToLowerCase)                
        am.addAction(self.lowerCaseAct)                                                
         
        self.convertEOLAct=QtGui.QAction("Convert EOL", self,statusTip="Convert End of Line Character")
        self.convertEOLWinAct=QtGui.QAction("Windows EOL", self,statusTip="Convert End of Line Character to Windows Style",triggered=self.convertEolWindows) 
        am.addAction(self.convertEOLWinAct)                                                
        self.convertEOLUnixAct=QtGui.QAction("Unix EOL", self,statusTip="Convert End of Line Character to Unix Style",triggered=self.convertEolUnix) 
        am.addAction(self.convertEOLUnixAct)
        self.convertEOLMacAct=QtGui.QAction("Mac EOL", self,statusTip="Convert End of Line Character to Mac Style",triggered=self.convertEolMac)        
        am.addAction(self.convertEOLMacAct)
        
        self.undoAct= QtGui.QAction(QtGui.QIcon(':/icons/edit-undo.png'),"Undo", self, shortcut="Ctrl+Z",
                statusTip="Undo", triggered=self.__undo)                   
                
        am.addAction(self.undoAct)        
        
        self.redoAct= QtGui.QAction(QtGui.QIcon(':/icons/edit-redo.png'),"Redo", self, shortcut="Ctrl+Y",
                statusTip="Redo", triggered=self.__redo)                   
        am.addAction(self.redoAct)                
        
        self.configurationAct = QtGui.QAction(QtGui.QIcon(':/icons/configure.png'),"Configure...", self, shortcut="",
                statusTip="Configuration...", triggered=self.configurationUpdate)  
        am.addAction(self.configurationAct)                
        
        self.keyboardShortcutsAct = QtGui.QAction("Keyboard Shortcuts...", self, shortcut="",
                statusTip="Reassign keyboard shortcuts", triggered=self.keyboardShortcuts)  
        am.addAction(self.keyboardShortcutsAct)                
        
                
        self.aboutAct = QtGui.QAction("&About", self,
                statusTip="Show the application's About box",
                triggered=self.about)
        am.addAction(self.aboutAct)                
        
        self.aboutQtAct = QtGui.QAction("About &Qt", self,
                statusTip="Show the Qt library's About box",
                triggered=QtGui.qApp.aboutQt)
        am.addAction(self.aboutQtAct)                
        
        self.editTab.currentChanged.connect(self.tabIndexChanged) # connects tab changed signal to appropriate slot 
        self.editTab.tabCloseRequested.connect(self.closeTabIndex)     
        
        keyboardShortcutsDict=self.configuration.keyboardShortcuts()
        
        for actionName, keyboardShortcutText in keyboardShortcutsDict.iteritems():
            am.setActionKeyboardShortcut(actionName,QKeySequence(keyboardShortcutText))
        
        
        
    def createMenus(self):
        self.fileMenu = self.menuBar().addMenu("&File")
        self.fileMenu.addAction(am.actionDict["New"])
        self.fileMenu.addAction(am.actionDict["Open..."])
        self.fileMenu.addAction(am.actionDict["Save"])
        self.fileMenu.addAction(am.actionDict["Save As..."])
        self.fileMenu.addAction(am.actionDict["Save All"])
        self.fileMenu.addSeparator()
        
        #---------------------------        
        self.fileMenu.addAction(am.actionDict["Rename..."])
        self.fileMenu.addAction(am.actionDict["Close Tab"])
        self.fileMenu.addAction(am.actionDict["Close All Tabs"])
        self.fileMenu.addAction(am.actionDict["Close All But Current Tab"])
        
        self.fileMenu.addAction(am.actionDict["Delete from disk"])
        self.fileMenu.addSeparator()
        #---------------------------        
        
        self.fileMenu.addAction(am.actionDict["Print..."])
        
        self.fileMenu.addSeparator();
        #---------------------------        
        self.fileMenu.addAction(am.actionDict["Exit"])

        self.editMenu = self.menuBar().addMenu("&Edit")
        
        
        self.editMenu.addAction(am.actionDict["Copy"])
        self.editMenu.addAction(am.actionDict["Paste"])
        self.editMenu.addAction(am.actionDict["Cut"])
        
        self.editMenu.addSeparator()
        self.editMenu.addAction(am.actionDict["Block Comment"])        
        self.editMenu.addAction(am.actionDict["Block Uncomment"])        
        
        
        self.editMenu.addAction(am.actionDict["Increase Indent"])
        self.editMenu.addAction(am.actionDict["Decrease Indent"])
        self.editMenu.addSeparator()
        self.editMenu.addAction(am.actionDict["Convert to UPPER case"])
        self.editMenu.addAction(am.actionDict["Convert to lower case"])
        
        self.convertEOLMenu=self.editMenu.addMenu("Convert EOL")
        self.convertEOLMenu.addAction(am.actionDict["Windows EOL"])
        self.convertEOLMenu.addAction(am.actionDict["Unix EOL"])
        self.convertEOLMenu.addAction(am.actionDict["Mac EOL"])
        
        self.editMenu.addSeparator()
        
        self.editMenu.addAction(am.actionDict["Undo"])
        self.editMenu.addAction(am.actionDict["Redo"])
        
        self.searchMenu = self.menuBar().addMenu("&Search")
        self.searchMenu.addAction(am.actionDict["Find..."])
        
        self.searchMenu.addAction(am.actionDict["Find Next"])
        
        self.searchMenu.addSeparator()
        self.searchMenu.addAction(am.actionDict["Toggle Bookmark"])
        self.searchMenu.addAction(am.actionDict["Go To Next Bookmark"])
        self.searchMenu.addAction(am.actionDict["Go To Previous Bookmark"])
        self.searchMenu.addAction(am.actionDict["Delete All Bookmarks"])
        self.searchMenu.addSeparator()
        self.searchMenu.addAction(am.actionDict["Go To Line..."])
        self.searchMenu.addAction(am.actionDict["Go To Matching Brace"])
        self.searchMenu.addAction(am.actionDict["Select To Matching Brace"])
        
        
        
        

        
        self.viewMenu = self.menuBar().addMenu("&View")
        self.viewMenu.addAction(am.actionDict["Close Tab"])
        self.viewMenu.addAction(am.actionDict["Zoom In"])
        self.viewMenu.addAction(am.actionDict["Zoom Out"])
        self.viewMenu.addSeparator()
        #---------------------------
        self.viewMenu.addAction(am.actionDict["Wrap Lines"])  
        self.viewMenu.addAction(am.actionDict["Show Whitespaces"])
        self.viewMenu.addAction(am.actionDict["Show EOL"])
        self.viewMenu.addAction(am.actionDict["Show Tab Guidelines"])
        self.viewMenu.addAction(am.actionDict["Show Line Numbers"])        
        self.viewMenu.addSeparator()
        #---------------------------        
        self.viewMenu.addAction(am.actionDict["Toggle Fold All"])    
        self.viewMenu.addSeparator()
        #---------------------------
        self.viewMenu.addAction(am.actionDict["Show Find in Files Results"])
        
        
        self.languageMenu=self.menuBar().addMenu("&Language") # initialized in LanguageManager
        
        
        self.configurationMenu=self.menuBar().addMenu("&Configuration")
        self.configurationMenu.addAction(am.actionDict["Configure..."])
        self.configurationMenu.addAction(am.actionDict["Keyboard Shortcuts..."])
        
        self.menuBar().addSeparator()

        self.helpMenu = self.menuBar().addMenu("&Help")
        self.helpMenu.addAction(self.aboutAct)
        # self.helpMenu.addAction(self.aboutQtAct)

    def createToolBars(self):
        self.toolBar={}
        self.toolBar["File"] = self.addToolBar("File")
        self.toolBar["File"].addAction(am.actionDict["New"])
        self.toolBar["File"].addAction(am.actionDict["Open..."])
        self.toolBar["File"].addAction(am.actionDict["Save"])
        self.toolBar["File"].addAction(am.actionDict["Save As..."])
        self.toolBar["File"].addAction(am.actionDict["Save All"])

        self.toolBar["Edit"] = self.addToolBar("Edit")
        self.toolBar["Edit"].addAction(am.actionDict["Copy"])
        self.toolBar["Edit"].addAction(am.actionDict["Paste"])
        self.toolBar["Edit"].addAction(am.actionDict["Cut"])
        self.toolBar["Edit"].addAction(am.actionDict["Increase Indent"])
        self.toolBar["Edit"].addAction(am.actionDict["Decrease Indent"])

        self.toolBar["Search"] = self.addToolBar("Search")
        self.toolBar["Search"].addAction(am.actionDict["Find..."])
        self.toolBar["Search"].addAction(am.actionDict["Toggle Bookmark"])
        
        self.toolBar["Configuration"] = self.addToolBar("Configurartion")
        self.toolBar["Configuration"].addAction(am.actionDict["Configure..."])
        
        
        
    def createStatusBar(self):
        self.statusBar().showMessage("Ready")

    def toggleFindInFilesDock(self, _flag=False):
        dbgMsg("FLAG=",_flag)
        dbgMsg("self.showFindInFilesDockAct.isChecked():",self.showFindInFilesDockAct.isChecked())
        if self.findDock.isHidden():
            self.findDock.show()
        else:
            self.findDock.hide()

            
    def keyboardShortcuts(self):
        # if not self.keyboardShortcutDlg:
        self.keyboardShortcutDlg=KeyboardShortcutsDlg(self,self)    
            
        self.keyboardShortcutDlg.initializeShortcutTables()    
        
        ret=self.keyboardShortcutDlg.exec_()    
        
        if ret:            
            self.keyboardShortcutDlg.reassignNewShortcuts()
        
    def maybeSave(self,_editor=None):
        dbgMsg("slot maybeSave")
        # return True
        editor=None
        if not _editor:
            editor=self.editTab.currentWidget()
        else:
            editor=_editor
        dbgMsg("editor=",editor," isModified()=",editor.isModified())
        if editor.isModified():
            fileName=''
            if self.getEditorFileName(editor)!='':
                fileName = self.getEditorFileName(editor)
            else:
                index = self.editTab.indexOf(editor)
                fileName = self.editTab.tabText(index)        
        
            message="The document "+fileName+" has been modified.\nDo you want to save changes?"
            
            ret = QtGui.QMessageBox.warning(self, "Save Modification",
                    message,
                    QtGui.QMessageBox.Save | QtGui.QMessageBox.Discard |
                    QtGui.QMessageBox.Cancel)
            if ret == QtGui.QMessageBox.Save:
                return self.save()
            elif ret == QtGui.QMessageBox.Cancel:
                return False
        return True
    
    def __undo(self):
        editor=self.editTab.currentWidget()
        editor.undo()
        self.checkActions()
        
    def __redo(self):
        editor=self.editTab.currentWidget()
        
        editor.redo()
        self.checkActions()
         

    def __closeAll(self):
        self.__closeAllButCurrent()
        self.closeTab()
        
        
    def __closeAllButCurrent(self):
        currentEditor=self.getCurrentEditor()        
        numberOfDocuments=self.editTab.count()
        
        removedTabs=0
        for i in  range(numberOfDocuments):
            editor=self.editTab.widget(i-removedTabs)
            
            if editor!=currentEditor:
                self.closeTab(i-removedTabs)
                removedTabs+=1
        
    def __rename(self):
        fileName=self.getCurrentDocumentName()
        
        ret=self.saveAs()
        if ret:
            self.deleteDocument(fileName,False) # don't display warning
            
            
        
    def deleteDocument(self,fileName, warningFlag=True):
        if fileName=="":
            return
        fileName=os.path.abspath(fileName) # normalize file name - jist in case
        if warningFlag:
            message="You are about to completely delete "+fileName+" from disk.<br> "+"Proceed?"
            ret = QtGui.QMessageBox.information(self, "Delete from disk",
                    message,
                    QtGui.QMessageBox.Yes | QtGui.QMessageBox.No )
                
            if ret==QtGui.QMessageBox.No:
                return 
            
        try:
            os.remove(fileName)
            self.closeTab()            
        except: 
            message="The document "+fileName+" cannot be deleted. Check if you have the right permissions."
            ret = QtGui.QMessageBox.information(self, "Delete from disk",
                    message,
                    QtGui.QMessageBox.Ok )
        
    def __deleteCurrentDocument(self):
        fileName=self.getCurrentDocumentName()
        self.deleteDocument(fileName)
    
    def fileNameToClipboard(self):
        clipboard=QApplication.clipboard()
        clipboard.setText(self.getCurrentDocumentName())

    def fileDirToClipboard(self):
        clipboard=QApplication.clipboard()
        clipboard.setText(os.path.dirname(self.getCurrentDocumentName()))
    
        
    
    def printCurrentDocument(self):
        editor=self.editTab.currentWidget()
        printer=PrinterTwedit()
        printDialog=QPrintDialog(printer,self)
        if printDialog.exec_()==QDialog.Accepted:
            dbgMsg("Paper size=", printer.paperSize())
            printer.setDocName(self.getCurrentDocumentName())
            printer.printRange(editor) 	
        dbgMsg("THIS IS PRINT CURRENT DOCUMENT")
        
    def convertToUpperCase(self):
        editor=self.editTab.currentWidget()        
        editor.SendScintilla(QsciScintilla.SCI_UPPERCASE)
        
    def convertToLowerCase(self):
        editor=self.editTab.currentWidget()        
        editor.SendScintilla(QsciScintilla.SCI_LOWERCASE)

    def convertEolWindows(self):
        editor=self.editTab.currentWidget()        
        editor.setEolMode(QsciScintilla.EolWindows)
        editor.convertEols(QsciScintilla.EolWindows)
        
    def convertEolUnix(self):
        editor=self.editTab.currentWidget()        
        editor.setEolMode(QsciScintilla.EolUnix)
        editor.convertEols(QsciScintilla.EolUnix)
        
    
    def convertEolMac(self):
        editor=self.editTab.currentWidget()        
        editor.setEolMode(QsciScintilla.EolMac)
        editor.convertEols(QsciScintilla.EolMac)
        
    def checkActions(self):
        editor=self.editTab.currentWidget()
        if editor:
            self.undoAct.setEnabled(editor.isUndoAvailable())
            self.redoAct.setEnabled(editor.isRedoAvailable())
            if editor.wrapMode()==QsciScintilla.WrapNone:
                self.wrapLinesAct.setChecked(False)
            else:
                self.wrapLinesAct.setChecked(True)
            
            if editor.whitespaceVisibility()==QsciScintilla.SCWS_INVISIBLE:
                self.showWhitespacesAct.setChecked(False)
            else:
                self.showWhitespacesAct.setChecked(True)
                
            if editor.eolVisibility():
                self.showEOLAct.setChecked(True)            
            else:
                self.showEOLAct.setChecked(False)       

            if editor.indentationGuides():
                self.showTabGuidelinesAct.setChecked(True)            
            else:
                self.showTabGuidelinesAct.setChecked(False)            
                
            if editor.marginWidth(0): # checking the width of margin 0
                self.showLineNumbersAct.setChecked(True)            
            else:
                self.showLineNumbersAct.setChecked(False)            
                
            
    def __modificationChanged(self, m):
        """
        Private slot to handle the modificationChanged signal. 
        
        @param m modification status
        """
        dbgMsg(" INSIDE MODIFICATIONCHANGED SLOT")
        self.setWindowModified(m)
        self.checkActions()
        
    def maybeReload(self,tab):
        dbgMsg("slot maybeReload")
        message="The document "+self.getEditorFileName(tab)+" has been modified by external program.\nDo you want to reload?"
        ret = QtGui.QMessageBox.warning(self, "Reload",
                message,
                QtGui.QMessageBox.Yes | QtGui.QMessageBox.No )
                
        if ret == QtGui.QMessageBox.Yes:
            
            return self.reloadFile(tab,self.getEditorFileName(tab))  
            
        elif ret == QtGui.QMessageBox.No:
            return False
        return False


    def reloadFile (self, editor,fileName):
        file=None    
        
        try:    
            file = open(fileName, 'rb')
        except:
            QtGui.QMessageBox.warning(self, "Twedit++",
                    "Cannot read file %s:\n%s." % (fileName, "Check if the file is accessible"))
            return     
        QtGui.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        # have to disconnect signal which looks for text changes
        # editor.textChanged.disconnect(self.textChangedHandlers[editor].handleChangedText) 
        editor.modificationChanged.disconnect(self.textChangedHandlers[editor].handleModificationChanged)
        editor.textChanged.disconnect(self.textChangedHandlers[editor].handleChangedText)
        editor.cursorPositionChanged.disconnect(self.handleCursorPositionChanged)
      
        
        
        # txt=file.read()
        # file.close()
        # editor.setText(txt)
        
        # txt, encoding = Encoding.decode(file.read())
        # dbgMsg("encoding=",encoding        )
        # file.close()
        # editor.setText(txt)
        
        import codecs

        # txt, encoding = Encoding.decode(file.read())
        txt, encoding = Encoding.decode(file)
        dbgMsg("RELOAD FILE encoding=",encoding,"\n\n\n")
        file.close()               
        # add re-read option to avoid duplicate reads in all cases?

        fh=codecs.open(fileName,'rb',Encoding.normalizeEncodingName(encoding))
        txt=fh.read()                
        fh.close()
        
        editor.setText(txt)        
        
        # restore text-change watcher signal
        # editor.textChanged.connect(self.textChangedHandlers[editor].handleChangedText)
        editor.modificationChanged.connect(self.textChangedHandlers[editor].handleModificationChanged)
        editor.textChanged.connect(self.textChangedHandlers[editor].handleChangedText)
        editor.cursorPositionChanged.connect(self.handleCursorPositionChanged) 
        
        # self.fileDict[editor]=[os.path.abspath(fileName),os.path.getmtime(fileName),encoding] # "normalizing" file name to make sure \ and / are used in a consistent manner 
        self.setPropertiesInEditorList(editor,os.path.abspath(str(fileName)),os.path.getmtime(str(fileName)),encoding)# "normalizing" file name to make sure \ and / are used in a consistent manner 
                
        editor.setModified(False)
        
        self.updateTextSizeLabel()
        self.updateEncodingLabel()
        
        
        
        QtGui.QApplication.restoreOverrideCursor()
        return True
        
    def loadFiles(self, fileNames):
        for i in range(fileNames.count()):
            self.loadFile(os.path.abspath(str(fileNames[i])))# "normalizing" file name to make sure \ and / are used in a consistent manner
            
        
    def loadFile(self, fileName,_restoreFlag=False):        
        fileName=str(fileName)
        fileName=os.path.abspath(fileName)# "normalizing" file name to make sure \ and / are used in a consistent manner
        
        
        fileName=string.rstrip(fileName) # remove extra trailing spaces - just in case
        # file = QtCore.QFile(fileName)
        
        # openFileDict={}
        # for key in self.fileDict.keys():
            # if self.fileDict[key][0]!='':
                # openFileDict[self.fileDict[key][0]]=key
        openFileDict=self.getFileNameToEditorWidgetMap()        
                
        if fileName in  openFileDict.keys():
            #make tab with open file active
            try:
                self.editTab.setCurrentWidget(openFileDict[fileName])
            except KeyError,e:
                pass
                # self.editTab.setCurrentWidget("STRANGE FILE")
            return
            
        file=None    
        
        try:
            
            file = open(fileName, 'r')
        except:
            if not _restoreFlag:
                QtGui.QMessageBox.warning(self, "Twedit++",
                        "Cannot read file %s:\n%s." % (fileName, "Check if the file is accessible"))
            return 
            
            
        # if not file.open(QtCore.QFile.ReadOnly | QtCore.QFile.Text):
            # if _restoreFlag:
                # return
            # QtGui.QMessageBox.warning(self, "Application",
                    # "Cannot read file %s:\n%s." % (fileName, file.errorString()))
            # return 

        # inf = QtCore.QTextStream(file)
        QtGui.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        
        
        
        lexer=self.guessLexer(fileName)
        textEditLocal=None
        encoding=None
        
        # dbgMsg("self.editTab.count()=",self.editTab.count())
        if self.editTab.count()==1:
            # have to disconnect signal while opening document in first tab while new text is read in
            # self.editTab.widget(0).textChanged.disconnect(self.textChangedHandlers[textEditLocal].handleChangedText)  
            textEditLocal = self.editTab.currentWidget()
            if not textEditLocal.isModified() and not textEditLocal.length():
                # it is better to create new QScintilla object than reuse old one
                # because reused editor tab had bookmar problems
                self.editTab.removeTab(0)
                textEditLocal=QsciScintillaCustom()
                self.editTab.addTab(textEditLocal,QtGui.QIcon(':/icons/document-clean.png'),self.strippedName(fileName))            
                textEditLocal=self.editTab.currentWidget()
            
                # dbgMsg("textLocalIs Modified=",textEditLocal.isModified())
                # if not file:
                    # dbgMsg("file=",file)
                    
                    
                # txt=file.read()                                  
                # file.close()                 
                # textEditLocal.setText(txt)   
                import codecs                
                # textTmp=file.read()
                # if textTmp.startswith(codecs.BOM_UTF16_BE):
                    # dbgMsg("\n\n\nGOT BOM BE\n\n\n")
                # else:
                    # dbgMsg("\n\n\n DID NOT GET BOM BE\n\n\n")
                # passing file.read() to decode causes improper detection of encoding
                # we have to first store file content localy and then pass the string to decode fcn
                # txt, encoding = Encoding.decode(file.read()) 
                # txt, encoding = Encoding.decode(textTmp) 
                # file.seek(0)
                txt, encoding = Encoding.decode(file) 
                dbgMsg("section 1 encoding=",encoding,"\n\n\n")
                file.close()
                # add re-read option to avoid duplicate reads in all cases?
                
                fh=codecs.open(fileName,'rb',Encoding.normalizeEncodingName(encoding))
                txt=fh.read()
                fh.close()
                # if encoding not in []
                textEditLocal.SendScintilla(QsciScintilla.SCI_SETCODEPAGE, QsciScintilla.SC_CP_UTF8)
                textEditLocal.setText(txt)

                
                # textEditLocal.setText(inf.readAll())
                self.editTab.setTabText(0,self.strippedName(fileName))    
                # self.setEditorProperties(textEditLocal)                
                if lexer[0]:
                    textEditLocal.setLexer(lexer[0])
                    self.editTab.currentWidget().setBraceMatching(lexer[3])
                    
                    if self.configuration.setting("FoldText"):
                        textEditLocal.setFolding(QsciScintilla.BoxedTreeFoldStyle)
                    else:
                        textEditLocal.setFolding(QsciScintilla.NoFoldStyle)

             
            else:
                textEditLocal=QsciScintillaCustom()
                self.editTab.addTab(textEditLocal,QtGui.QIcon(':/icons/document-clean.png'),self.strippedName(fileName))
                self.setCurrentFile(fileName)
                # textEditLocal.setText(inf.readAll())
                # txt, self.encoding = self.decode(file.read())
                # file.close()
                # txt,encoding=self.decode(file.read())
                
                
                # txt=file.read()
                # file.close()
                # textEditLocal.setText(txt)
                import codecs
                # textTmp=file.read()
                # if textTmp.startswith(codecs.BOM_UTF16_BE):
                    # dbgMsg("\n\n\nGOT BOM BE\n\n\n")
                # else:
                    # dbgMsg("\n\n\n DID NOT GET BOM BE\n\n\n")
                
                # txt, encoding = Encoding.decode(file.read()) 
                txt, encoding = Encoding.decode(file)
                dbgMsg("section 2 encoding=",encoding,"\n\n\n"               )
                file.close()                 
                # add re-read option to avoid duplicate reads in all cases?
                fh=codecs.open(fileName,'rb',Encoding.normalizeEncodingName(encoding))
                txt=fh.read()                
                fh.close()
                textEditLocal.SendScintilla(QsciScintilla.SCI_SETCODEPAGE, QsciScintilla.SC_CP_UTF8)
                textEditLocal.setText(txt)
                
                
                # self.setEditorProperties(textEditLocal)
                if lexer[0]:
                    textEditLocal.setLexer(lexer[0])
                    self.editTab.currentWidget().setBraceMatching(lexer[3])                    
                    if self.configuration.setting("FoldText"):
                        textEditLocal.setFolding(QsciScintilla.BoxedTreeFoldStyle)
                    else:
                        textEditLocal.setFolding(QsciScintilla.NoFoldStyle)

            self.editTab.setTabIcon(0,QtGui.QIcon(':/icons/document-clean.png'))
            # enable textChangedSignal        
            # self.editTab.widget(0).textChanged.connect(self.textChangedHandlers[textEditLocal].handleChangedText)    
        else:
            textEditLocal=QsciScintillaCustom()
            self.editTab.addTab(textEditLocal,QtGui.QIcon(':/icons/document-clean.png'),self.strippedName(fileName))
            self.setCurrentFile(fileName)
            
            # textEditLocal.setText(inf.readAll()) 
            # txt, self.encoding = self.decode(file.read())
            
            # txt=file.read()
            # file.close()
            # textEditLocal.setText(txt)
            import codecs

            # txt, encoding = Encoding.decode(file.read())
            txt, encoding = Encoding.decode(file)
            dbgMsg("section 3 encoding=",encoding,"\n\n\n")
            file.close()               
            # add re-read option to avoid duplicate reads in all cases?

            fh=codecs.open(fileName,'rb',Encoding.normalizeEncodingName(encoding))
            txt=fh.read()                
            fh.close()
            textEditLocal.SendScintilla(QsciScintilla.SCI_SETCODEPAGE, QsciScintilla.SC_CP_UTF8)
            textEditLocal.setText(txt)
            
            
            
            
            if lexer[0]:
                textEditLocal.setLexer(lexer[0])        
                self.editTab.currentWidget().setBraceMatching(lexer[3])
                if self.configuration.setting("FoldText"):
                    textEditLocal.setFolding(QsciScintilla.BoxedTreeFoldStyle)
                else:
                    textEditLocal.setFolding(QsciScintilla.NoFoldStyle)
            
            
        self.setEditorProperties(textEditLocal)                
        
        # editor=self.editTab.currentWidget()
        editor=textEditLocal
        self.editTab.setCurrentWidget(editor)        
        editor.setModified(False) # loading document modifies its content but since no new text has been typed we set modified to false
        
        editor.setWhitespaceVisibility(self.configuration.setting("DisplayWhitespace"))
        editor.setIndentationGuidesForegroundColor(self.indendationGuidesColor)
        editor.setIndentationGuides(self.configuration.setting("TabGuidelines"))  
        
        self.checkActions()
        
        #editor.zoomTo(self.zoom)
        
        # zoomRange=self.configuration.setting("ZoomRange")
        
        # dbgMsg("THIS IS ZOOM RANGE=",zoomRange,"\n\n\n\n\n")
        editor.zoomTo(self.zoomRange)
        
        # zoomRange=self.configuration.setting("ZoomRange")
        # if zoomRange>0:
            # editor.zoomIn(zoomRange)
        # else:
            # editor.zoomOut(-1*zoomRange)
        
        self.commentStyleDict[editor]=[lexer[1],lexer[2]] # associating comment style with the lexer
        
        
        # self.textEdit.setPlainText(inf.readAll())
        QtGui.QApplication.restoreOverrideCursor()

        self.setCurrentFile(fileName)
        # self.fileDict[editor]=[os.path.abspath(fileName),os.path.getmtime(fileName),encoding] # file is associated with the tab,  "normalizing" file name to make sure \ and / are used in a consistent manner 
        
        self.setPropertiesInEditorList(editor,os.path.abspath(str(fileName)),os.path.getmtime(str(fileName)),encoding)# file is associated with the tab,  "normalizing" file name to make sure \ and / are used in a consistent manner 
        
        # adding text Changed Handler
        self.textChangedHandlers[editor]=ChangedTextHandler(editor,self)
        editorIndex=self.editTab.indexOf(editor)
        dbgMsg("CONNECTING EDITOR INDEX=",editorIndex)
        # self.editTab.widget(editorIndex).textChanged.connect(self.textChangedHandlers[editor].handleChangedText)  
        self.editTab.widget(editorIndex).modificationChanged.connect(self.textChangedHandlers[editor].handleModificationChanged)
        self.editTab.widget(editorIndex).textChanged.connect(self.textChangedHandlers[editor].handleChangedText)
        self.editTab.widget(editorIndex).cursorPositionChanged.connect(self.handleCursorPositionChanged)        
        
        # self.editTab.widget(editorIndex).modificationChanged.connect(self.textChangedHandlers[editor].modificationChangedSlot)
        
        self.updateTextSizeLabel()
        self.updateEncodingLabel()        
        dbgMsg(" SETTING fileName=",fileName," os.path.getmtime(fileName)=",os.path.getmtime(str(fileName)))
        self.statusBar().showMessage("File loaded", 2000)
        
        # lexer=editor.lexer()
        # if lexer:
            # lexer.setFont(self.baseFont)    
        
        
        # editor.convertEols(QsciScintilla.EolMac)
            
    def tabIndexChanged(self,_index):
        editorTab=self.editTab.widget(_index)
        # dbgMsg("self.fileDict=",self.fileDict)
        self.checkActions()
        self.updateTextSizeLabel()
        self.updateEncodingLabel()
        if editorTab in self.getEditorList(): # have to do this check becaue adding tab triggers this slot but fileDict dictionary has not been initialized yet 
            self.setCurrentFile(self.getEditorFileName(editorTab))
            
        
    def guessLexer(self,_fileName):
        extension=''
        fileSplit=os.path.splitext(str(_fileName))
        try:
            extension=fileSplit[1]
        except IndexError:
            pass
        # dbgMsg("EXTENSION=",extension)
        
        if extension in self.extensionLanguageMap.keys():
            
            try:
                return self.languageManager.languageLexerDictionary[self.extensionLanguageMap[extension]]    
            except KeyError:
                pass
        # return format [lexer,begin comment, end comment, brace matching (0- nor matching, 1 matching), codeFolding]

            
        if os.path.basename(str(_fileName)).lower()=="cmakelists.txt": 
            try:
                return self.languageManager.languageLexerDictionary["CMake"]        
            except KeyError:     
                pass
            
        if os.path.basename(str(_fileName)).lower()=="makefile":
            try:
                return self.languageManager.languageLexerDictionary["Makefile"]        
            except KeyError:     
                pass
            
        return [None,'',None,0,0,QsciScintilla.SCWS_INVISIBLE]
        

        

    def saveFile(self, _fileName,_editor=None):
    
        self.deactivateChangeSensing=True
    
        QtGui.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        textEditLocal=None
        if _editor:
            textEditLocal=_editor
        else:
            textEditLocal=self.editTab.currentWidget()
    
        encoding='utf-8'
        txt = unicode(textEditLocal.text())
        # work around glitch in scintilla: always make sure, 
        # that the last line is terminated properly
        # eol = self.getLineSeparator()
        # if eol:
            # if len(txt) >= len(eol):
                # if txt[-len(eol):] != eol:
                    # txt += eol
            # else:
                # txt += eol
                
        try:
            fileNameToEditorMap=self.getFileNameToEditorWidgetMap()  
            

            editorLocal=None
            try:
                editorLocal=fileNameToEditorMap[_fileName]
            except:
                dbgMsg("COULD NOT FIND EDITOR FOR FILE NAME=",_fileName)
                
            try:    
                encoding=self.getEditorFileEncoding(textEditLocal)                    
                # encoding=self.fileDict[textEditLocal][2]                    
            except:            
                dbgMsg("COULD NOT FIND ENCODING")
                
            # encoding='ucs-2'    
            txt, encoding = Encoding.encode(txt, encoding)
        except Encoding.CodingError, e:
            QtGui.QMessageBox.warning(self, "Twedit++",
                    "Cannot write file %s:\n%s." % (_fileName, repr(e)))
            self.deactivateChangeSensing=False            
            return False        
            
        # now write text to the file fn
        try:
            dbgMsg("SAVE - ENCODING = ",encoding,"\n\n\n\n\n")
            
            import codecs
            fh=codecs.open(_fileName, 'wb',Encoding.normalizeEncodingName(encoding))
            
            # fh=open(_fileName, 'wb')
            Encoding.writeBOM(fh,encoding)
            fh.write(txt)
            fh.close()
            # f = open(_fileName, 'wb')
            # f.write(txt)
            # f.close()
            # file = QtCore.QFile(_fileName)
            
            # if not file.open(QtCore.QFile.WriteOnly ):
                # QtGui.QMessageBox.warning(self, "Twedit++",
                        # "Cannot write file %s:\n%s." % (_fileName, file.errorString()))
                # self.deactivateChangeSensing=False            
                # return False            
                
            # # txt=textEditLocal.text()
            # byteArray=QByteArray(txt)
            # file.write(byteArray)        
            # file.close()            
            # if createBackup and perms_valid:
                # os.chmod(fn, permissions)
            # return True
        except IOError, why:
            QtGui.QMessageBox.warning(self, "Twedit++",
                    "Cannot write file %s:\n%s." % (_fileName, why))                    
            self.deactivateChangeSensing=False
            return False
            
            
        QtGui.QApplication.restoreOverrideCursor()   

        dbgMsg("SAVE FILE EDITOR=",_editor,"\n\n\n\n")
        if _editor:
            # self.fileDict[_editor]=[_fileName,os.path.getmtime(_fileName),encoding] # saving new name and new modification time
            self.setPropertiesInEditorList(_editor,_fileName,os.path.getmtime(str(_fileName)),encoding)# saving new name and new modification time
        else:    
            self.setCurrentFile(_fileName)
            # self.fileDict[self.editTab.currentWidget()]=[_fileName,os.path.getmtime(_fileName),encoding] # saving new name and new modification time    
            self.setPropertiesInEditorList(self.editTab.currentWidget(),_fileName,os.path.getmtime(str(_fileName)),encoding)# saving new name and new modification time            
        self.statusBar().showMessage("File saved", 2000)
        if _editor:
            textEditLocal.setModified(False)
            
            index=self.editTab.indexOf(textEditLocal)
            self.editTab.setTabIcon(index,QtGui.QIcon(':/icons/document-clean.png'))            
        else :
            self.editTab.currentWidget().setModified(False)
            
            index=self.editTab.indexOf(self.editTab.currentWidget())
            self.editTab.setTabIcon(index,QtGui.QIcon(':/icons/document-clean.png'))        
        self.deactivateChangeSensing=False
        return True 
        
    def setCurrentFile(self, fileName):
        self.curFile = fileName
        # self.textEdit.document().setModified(False)
        self.setWindowModified(False)

        if self.curFile:
            # shownName = self.strippedName(self.curFile)
            shownName = self.curFile
        else:
            shownName = 'untitled.txt'

        self.setWindowTitle("[*]%s - Twedit++" % shownName) # [*] is a placeholder for window modification flag - here it is positionwed before window title so that it is visible when windows has been modified

    def strippedName(self, fullFileName):
        return QtCore.QFileInfo(fullFileName).fileName()
        
    def __createDockWindow(self, name):
        """
        Private method to create a dock window with common properties.
        
        @param name object name of the new dock window (string or QString)
        @return the generated dock window (QDockWindow)
        """
        dock = QDockWidget(self)
        dock.setObjectName(name)
        #dock.setFeatures(QDockWidget.DockWidgetFeatures(QDockWidget.AllDockWidgetFeatures))
        return dock
        
    def __setupDockWindow(self, dock, where, widget, caption, showFlag=False):
        """
        Private method to configure the dock window created with __createDockWindow().
        
        @param dock the dock window (QDockWindow)
        @param where dock area to be docked to (Qt.DockWidgetArea)
        @param widget widget to be shown in the dock window (QWidget)
        @param caption caption of the dock window (string or QString)
        """
        if caption is None:
            caption = QString()
        self.addDockWidget(where, dock)
        dock.setWidget(widget)
        dock.hide()
        dock.setWindowTitle(caption)
        if showFlag:
            dock.show()

