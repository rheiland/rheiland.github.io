package actor;

import grid.Grid;
import grid.Location;
import java.awt.Color;
import java.util.Random;
import world.RatBotWorld;

/**
 * The BlackCat is the evil villain in this edition of RatBots
 * @author Spock 3-23-13
 */
public class BlackCat extends RatBotActor
{
    private final int RANDOM_PERCENT = 10;
    private final int STOP_AT_MOVE = 200;
    public static final int PENALTY_VALUE = 100;
    
    private Random randy = new Random();
    
    /**
     * Default constructor - sets color to Black.
     */
    public BlackCat()
    {
        setColor(Color.BLACK);
    }
    /**
     * Constructs a BlackCat that is a copy of another BlackCat.
     * @param in the BlackCat to be copied.
     */
    public BlackCat(BlackCat in)
    {
        super(in);
    }
    
     /**
     * A BlackCat moves in the same direction most of the time, however it 
     * will change directions a small percentage of the time; the BlackCat
     * always stops after 200 moves.  
     */
    public void act()
    {
        //Stop after round 200
        if(RatBotWorld.getMoveNum() < STOP_AT_MOVE)
        {
            //Occasionally be a RandomRat
            if(randy.nextInt(100) < RANDOM_PERCENT)
                setDirection(randy.nextInt(4)*90);
            
            //Make sure the location in front of the BlackCat is valid.
            Grid<RatBotActor> gr = getGrid();
            if (gr == null)
                return;
            Location loc = getLocation();
            Location next = loc.getAdjacentLocation(getDirection());
            if (!gr.isValid(next))
                return;
        
            RatBotActor neighbor = gr.get(next);
            if((neighbor == null) || (neighbor instanceof Tail))
            {   // ok to move into empty location or onto a Tail
                moveTo(next);
                Tail tailPiece = new Tail(new Color(255,255,255));
                tailPiece.destroy(); //Always leave a tail that is dying.  
                tailPiece.makeUnlucky();
                tailPiece.putSelfInGrid(gr, loc);
            }
        }
    }
    @Override
    public RatBotActor getClone()
    {
        RatBotActor clone = new BlackCat(this);
        return clone;
    }

    @Override
    public String toString()
    {
        return "BlackCat ";        
    }
       
}
