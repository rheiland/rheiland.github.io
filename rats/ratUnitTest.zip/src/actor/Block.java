package actor;

import java.awt.Color;

/**
 * A <code>Block</code> is an actor that does nothing. It is commonly used to
 * block other actors from moving. <br />
 */

public class Block extends RatBotActor
{  
    
    private static final Color DEFAULT_COLOR = Color.BLACK;

    /**
     * Constructs a black block.
     */
    public Block()
    {
        setColor(DEFAULT_COLOR);
    }
    /**
     * Constructs a block that is a copy of another block.
     * @param in the block to be copied.
     */
    public Block(Block in)
    {
        super(in);
    }

    /**
     * Overrides the <code>act</code> method in the <code>Actor</code> class
     * to do nothing.
     */
    @Override
    public void act()
    {
    }
    
    @Override
    public RatBotActor getClone()
    {
        RatBotActor clone = new Block(this);
        return clone;
    }

    @Override
    public String toString()
    {
        return "Block ";        
    }
}
