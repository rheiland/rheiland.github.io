package actor;

import grid.Grid;
import grid.Location;
import grid.RatBotsGrid;
import java.awt.Color;
import java.util.ArrayList;


/**
 * Rats are the competitors in the RatBots game.  Every Rat has a RatBot 
 * that acts as its 'brain' by making decisions for its actions.  
 * @author Spock
 */
public class Rat extends RatBotActor
{       
    private RatBot ratBot; 
    
    private int score;
    private int maxTailSize;
    private int penalties;
    private int roundsWon;
    private int matchesWon;
    private int matchesTied;
    private int matchesLost;
    private int totalScore = 0;
    
    private ArrayList<Tail> tails = new ArrayList<Tail>();
    
    /**
     * Constructs a red Rat with a generic RatBot.  
     */
    public Rat()
    {
        setColor(Color.RED);
        ratBot = new RatBot();
        initialize();
    }
    /**
     * Constructs a Rat with the given color and given RatBot for its 'brain'.
     * All rats have a RatBot that chooses their action each turn.  
     * @param rb the RatBot that makes decisions for this Rat.
     * @param ratColor the color of this Rat.
     */
    public Rat(RatBot rb, Color ratColor)
    {
        ratBot = rb;
        setColor(ratColor);
        initialize();
    }
    /**
     * Constructs a copy of this Rat (that does not include the RatBot.)
     * @param in the Rat being copied.
     */
    public Rat(Rat in)
    {
        super(in);
        this.setScore(in.getScore());
    }

    /**
     * Overrides the <code>act</code> method in the <code>Actor</code> class
     * to act based on what the RatBot decides.
     */
    @Override
    public void act()
    {
        //Ask the RatBot what to do. 
        giveDataToRatBot();
        int choice = ratBot.chooseAction();
        turn(ratBot.getDesiredHeading());
        
        switch(choice)
        {
            case RatBot.REST :
                break;
            case RatBot.MOVE :
                move(); 
                break;
            case RatBot.BUILD_BLOCK :
                buildBlock(getLocation().getAdjacentLocation(ratBot.getDesiredHeading())); 
                break;
            case RatBot.BUILD_WALL :
                buildBlock(getLocation().getAdjacentLocation(ratBot.getDesiredHeading())); 
                buildBlock(getLocation().getAdjacentLocation(ratBot.getDesiredHeading()-45)); 
                buildBlock(getLocation().getAdjacentLocation(ratBot.getDesiredHeading()+45)); 
        }       
    }
    
    /**
     * Turns the Rat
     * @param newDirection the direction to turn to.   
     */
    public void turn(int newDirection)
    {
        setDirection(newDirection);
    }

    /**
     * Moves the rat forward, putting a Tail into the location it previously
     * occupied.
     */
    public void move()
    {        
        Grid<RatBotActor> gr = getGrid();
        if (gr == null)
            return;

        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (!gr.isValid(next))
            return;
        
        RatBotActor neighbor = gr.get(next);
        if((neighbor == null) || (neighbor instanceof Tail))
        {   // ok to move into empty location or onto a Tail
            if(neighbor instanceof Tail)
            {
                Tail t = (Tail)neighbor;
                if(t.isUnlucky())
                {   //Penalize player for crossing path of Black Cat
                    penalties++;
                }
            }
            moveTo(next);
            Tail tailPiece = new Tail(getColor());
            tailPiece.putSelfInGrid(gr, loc);
            tails.add(tailPiece);
        }
    }
    
    /**
     * 
     */
    public void cleanUpDeadTailsAndUpdateScore()
    {
        boolean foundIt = false;
        Grid<RatBotActor> gr = getGrid();
        for(int z=tails.size()-1;z>=0;z--)
        {
            if(tails.get(z).getLocation() == null) //This tail has been removed from the Grid.
                foundIt = true;

            if(foundIt)
                tails.get(z).destroy();
            if(!tails.get(z).isAlive())
                tails.remove(z);            

        }     
        
        //Update max Tail length and score
        if(tails.size() > maxTailSize)
            maxTailSize = tails.size();
        
        score = 2*tails.size() + maxTailSize - penalties*BlackCat.PENALTY_VALUE;
    }
    
    /**
     * Builds a block. 
     * @param site the location where the block will be built.  
     */
    public void buildBlock(Location site)
    {
        Grid<RatBotActor> gr = getGrid();        
        if(gr.isValid(site))
            if( (gr.get(site) == null) || (gr.get(site) instanceof Tail))
        {
            Block b = new Block();
            b.putSelfInGrid(gr, site);
        }
    }
        
    @Override
    public void putSelfInGrid(Grid<RatBotActor> gr, Location loc)
    {
        super.putSelfInGrid(gr,loc);
//        if(this.getRatBot() != null)
//            RatBotsScoreBoard.add(this);
    }
    @Override
    public void removeSelfFromGrid()
    {
        super.removeSelfFromGrid();
//        RatBotsScoreBoard.remove(this);
    }
    
    @Override
    public String toString()
    {
        return ratBot.getName();
    }

    /**
     * Updates the most recent data (location, grid and status)
     * information to the RatBot.  This allows the RatBot to make a decision
     * based on current data every turn.  
     */
    public final void giveDataToRatBot()
    {
        RatBotsGrid<RatBotActor> old = (RatBotsGrid)getGrid();
        Grid<RatBotActor> newGrid = new RatBotsGrid<RatBotActor>(old.getNumCols(),old.getNumRows());
        
        /*
         * A Rat can see until it sees a wall in the four main directions. 
         * It can also see all neighboring spaces (including diagonals.)
         * Finally, it can 'see' all other Rats.
         */
        for(int direction = Location.NORTH; direction < 360; direction+=90)
        {
            Location loc = getLocation(); //Start from the Rat's location.
            do
            {
                if(old.isValid(loc.getAdjacentLocation(direction)))
                {   //Make sure next Location is on Grid. 
                    loc = new Location(loc.getAdjacentLocation(direction).getRow(),
                                    loc.getAdjacentLocation(direction).getCol() );
                    RatBotActor actor = old.get(loc);
                    if(actor != null)
                    {
                        RatBotActor clone = actor.getClone();
                        clone.putSelfInGrid(newGrid, actor.getLocation());
                    }        
                } //Stop looking if at edge or Block
            } while(old.isValid(loc.getAdjacentLocation(direction)) && 
                  !(old.get(loc.getAdjacentLocation(direction)) instanceof Block) );
        }
        //Seeing all neighbors.
        ArrayList<RatBotActor> neighbors = old.getNeighbors(getLocation());
        for(RatBotActor a : neighbors)
        {
            RatBotActor clone = a.getClone();
            clone.putSelfInGrid(newGrid, a.getLocation());           
        }
        //Seeing all Rats
        ArrayList<Rat> rats = old.getAllRats();
        for(Rat r : rats)
        {
            RatBotActor clone = r.getClone();
            clone.putSelfInGrid(newGrid, r.getLocation());           
        }
       
             
        ratBot.setSensorGrid(newGrid);
        
        ratBot.setDirection(getDirection());
        ratBot.setLocation(getLocation());
        ratBot.setScore(score);
    }

    /**
     * Accessor method to get the RatBot from a Rat.
     * @return the RatBot 'brain' of this RatBot.
     */
    public RatBot getRatBot()
    {
        return ratBot;
    }
    

    /**
     * Gets the current score (from this round).  
     * @return the score
     */
    public int getScore() { return score; }
    /**
     * Sets the current score of this Rat.
     * @param in the score
     */
    public void setScore(int in) { score = in; }
    /**
     * Adds the given amount to score of this Rat.  
     * @param add the amount to add
     */
    public void addToScore(int add) { score += add; }
    /**
     * Gets the total points scored over all rounds in this match for this Rat.
     * @return the total score
     */
    public int getTotalScore() { return totalScore; }

    /**
     * Gets the number of rounds won by this Rat in the match.
     * @return the rounds won
     */
    public int getRoundsWon() { return roundsWon; }
    public int getMatchesWon() { return matchesWon; }
    public int getMatchesTied() { return matchesTied; }
    public int getMatchesLost() { return matchesLost; }
    /**
     * Sets the number of rounds won by this Rat in the match.
     * @param in the rounds won
     */
    public void setRoundsWon(int in) { roundsWon = in; }
    /**
     * Increases the number of rounds won in this match by this Rat by one.
     */
    public void increaseRoundsWon() { roundsWon++; }
    public void increaseMatchesWon() { matchesWon++; }
    public void increaseMatchesTied() { matchesTied++; }
    public void increaseMatchesLost() { matchesLost++; }
    
    public int getMaxTailSize() { return maxTailSize; }
    public void addPenalty() { penalties++; }
    /**
     * Initializes this Rat for a new round.  
     */
    public final void initialize()
    {
        totalScore += score;
        score = 0;
        maxTailSize = 0;
        penalties = 0;
        ratBot.initForRound();
    }

    @Override
    public RatBotActor getClone()
    {
        RatBotActor clone = new Rat(this);
        return clone;
    }
    
}