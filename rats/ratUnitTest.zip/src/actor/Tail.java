package actor;

import java.awt.Color;

/**
 * A <code>Tail</code> is an actor that darkens over time. Rats leave a tail
 * as they move. <br />
 */

public class Tail extends RatBotActor
{
    private static final Color DEFAULT_COLOR = Color.PINK;
    private static final double DARKENING_FACTOR = 0.30;
    private static final int LIMIT = 10;
    
    private boolean alive;
    private boolean unlucky;

    // lose 5% of color value in each step

    /**
     * Constructs a pink tail.
     */
    public Tail()
    {
        setColor(DEFAULT_COLOR);
        alive = true;
        unlucky = false;
    }

    /**
     * Constructs a tail of a given color.
     * @param initialColor the initial color of this tail
     */
    public Tail(Color initialColor)
    {
        setColor(initialColor);
        alive = true;
        unlucky = false;
    }

    /**
     * Constructs a copy of this Tail.
     * @param in the Rat being copied.
     */
    public Tail(Tail in)
    {
        super(in);
        alive = in.isAlive();
        unlucky = in.isUnlucky();
        setColor(in.getColor());
    }
    /**
     * Causes the color of this tail to darken.
     */
    @Override
    public void act()
    {
        if (!alive || unlucky)
            fadeOut();
    }
    
    public void darken()
    {
        Color c = getColor();
        int red = (int) (c.getRed() * (1 - DARKENING_FACTOR));
        int green = (int) (c.getGreen() * (1 - DARKENING_FACTOR));
        int blue = (int) (c.getBlue() * (1 - DARKENING_FACTOR));

        setColor(new Color(red, green, blue));
        
        if(red < LIMIT && green < LIMIT && blue < LIMIT)
            removeSelfFromGrid();        
    }
    public void fadeOut()
    {
        Color c = getColor();
        Color base = Color.LIGHT_GRAY;
        int red = (int) (c.getRed() - (c.getRed()-base.getRed()) * (DARKENING_FACTOR));
        int green = (int) (c.getGreen() - (c.getGreen()-base.getGreen()) * (DARKENING_FACTOR));
        int blue = (int) (c.getBlue() - (c.getBlue()-base.getBlue()) * (DARKENING_FACTOR));

        setColor(new Color(red, green, blue));
        
        if(Math.abs(c.getRed()-base.getRed()) < LIMIT && 
                Math.abs(c.getGreen()-base.getGreen()) < LIMIT && 
                Math.abs(c.getBlue()-base.getBlue()) < LIMIT)
            removeSelfFromGrid();        
    }
    
    /**
     * Once a Tail has been run over, this method is called. 
     * RatBots should never call this method.  
     * (It would be futile, since RatBots only have access to a cloned Grid.)
     */
    public void destroy()
    {
        alive = false;
    }
    /**
     * Responds whether or not this Tail is in the process of fading away.
     * @return true if the Tail is fading away (no longer worth points.)
     */
    public boolean isAlive()
    {
        return alive;
    }
    /**
     * Only BlackCats have unlucky Tails.
     */
    public void makeUnlucky()
    {
        unlucky = true;
    }
    /**
     * This method will return true when the Tail was placed by a BlackCat. 
     * Running over such a tail would cause a penalty :-( 
     * @return true if running over this Tail would cause a penalty.  
     */
    public boolean isUnlucky()
    {
        return unlucky; 
    }
    
    public String toString()
    {
        return "Tail";
    }
    
    @Override
    public RatBotActor getClone()
    {
        RatBotActor clone = new Tail(this);
        return clone;
    }

}
