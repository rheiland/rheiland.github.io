package main;

import java.util.Random;

import actor.RatBot;

/**
 * @author Spock
 * RandomRat chooses a random move each turn.
 */
public class RandomRat extends RatBot
{
    Random randy = new Random();
    
    public RandomRat()
    {
        setName("RandomRat");
    }
    
    @Override
    public int chooseAction()
    {        
        setDesiredHeading(randy.nextInt(4)*90);
        return MOVE;
    }
    
}
