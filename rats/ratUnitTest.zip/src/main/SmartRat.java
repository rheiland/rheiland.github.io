package main;

import java.util.Random;

import actor.RatBot;

/**
 * @author Spock
 * SmartRat chooses a random move each turn, but doesn't run into walls!
 */
public class SmartRat extends RatBot
{
    Random randy = new Random();
    
    public SmartRat()
    {
        setName("SmartRat");
    }
    
    @Override
    public int chooseAction()
    {        
        int loopCount = 0;
        do
        {
            loopCount++;
            setDesiredHeading(randy.nextInt(4)*90);
        } while(!canMove() && loopCount<10);
        
        return MOVE;
    }
    
}
