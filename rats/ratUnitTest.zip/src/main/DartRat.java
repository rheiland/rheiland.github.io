package main;

import java.util.Random;

import actor.RatBot;

/**
 * @author Spock
 * DartRat chooses to keep going the same direction as long as possible.
 */
public class DartRat extends RatBot
{
    Random randy = new Random();
    
    public DartRat()
    {
        setName("DartRat");
        setDesiredHeading(randy.nextInt(4)*90);
    }
    
    @Override
    public int chooseAction()
    {     
        if(!this.canMove()) //Only change directions when needed.
            setDesiredHeading(randy.nextInt(4)*90);
        //Always move!
        return MOVE;
    }
    
}
