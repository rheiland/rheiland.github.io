package main;

import actor.RatBot;
import actor.RatBotActor;
import actor.Tail;
import grid.Location;
import java.util.Random;
/**
 * @author Spock
 * LuckyRat chooses to keep going the same direction as long as possible.
 * LuckyRat never runs over a BlackCat's Tail!
 */
public class LuckyRat extends RatBot
{
    Random randy = new Random();
    
    public LuckyRat()
    {
        setName("LuckyRat");
        setDesiredHeading(randy.nextInt(4)*90);
    }
    
    @Override
    public int chooseAction()
    {     
        if(!this.canMove()) //Only change directions when needed.
            setDesiredHeading(randy.nextInt(4)*90);
        
        //Move only if not moving onto a BlackCat Tail.
        if(blackCatTailAhead())
            return REST;
        else
            return MOVE;
    }
    
    private boolean blackCatTailAhead()
    {
        Location next = getLocation().getAdjacentLocation(getDesiredHeading());
        if(getSensorGrid().isValid(next))
        {
            RatBotActor a = getSensorGrid().get(next);
            if(a != null && a instanceof Tail)
            {
                Tail t = (Tail)a;
                if(t.isUnlucky())
                    return true;
            }
        }
        return false;
    }
}
