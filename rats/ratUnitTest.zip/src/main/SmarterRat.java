package main;

import actor.RatBot;
import actor.RatBotActor;
import actor.Tail;
import grid.Location;
import java.util.Random;
/**
 * @author Spock
 * SmarterRat chooses a random move each turn, but doesn't run into walls!
 * It also doesn't run over it's own Tail, which is very useful.  
 */
public class SmarterRat extends RatBot
{
    Random randy = new Random();
    
    public SmarterRat()
    {
        setName("SmarterRat");
    }
    
    @Override
    public int chooseAction()
    {        
        int loopCount = 0;
        do
        {
            loopCount++;
            setDesiredHeading(randy.nextInt(4)*90);
            
        } while( (!canMove() || movingOntoTail()) && loopCount<10);
        
        return MOVE;
    }
    
    public boolean movingOntoTail()
    {
        Location next = getLocation().getAdjacentLocation(getDesiredHeading());
        if(getSensorGrid().isValid(next))
        {
            RatBotActor a = getSensorGrid().get(next);
            if(a instanceof Tail)
            {
                return true;
            }
        }
        return false;        
    }
}
