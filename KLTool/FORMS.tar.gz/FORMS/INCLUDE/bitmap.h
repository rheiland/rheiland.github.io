/************   Object Class: Bitmap       ************/

/***** Class    *****/

#define FL_BITMAP		3

/***** Types    *****/

#define FL_NORMAL_BITMAP	0

/***** Defaults *****/

#define FL_BITMAP_BOXTYPE	FL_NO_BOX
#define FL_BITMAP_COL1		0
#define FL_BITMAP_COL2		FL_COL1
#define FL_BITMAP_LCOL		FL_LCOL
#define FL_BITMAP_ALIGN		FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_BITMAP_MAXSIZE	128*128
#define FL_BITMAP_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT 	*fl_create_bitmap(int, float, float, float, float, char []);
FL_OBJECT 	*fl_add_bitmap(int, float, float, float, float, char []);

void		fl_set_bitmap(FL_OBJECT *, int, int, char *);


