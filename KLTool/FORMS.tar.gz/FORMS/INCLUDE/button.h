/************   Object Class: Button       ************/

/***** Class    *****/

#define FL_BUTTON			11

/***** Types    *****/

#define FL_NORMAL_BUTTON	0
#define FL_PUSH_BUTTON		1
#define FL_RADIO_BUTTON		2
#define FL_HIDDEN_BUTTON	3
#define FL_TOUCH_BUTTON		4
#define FL_INOUT_BUTTON		5
#define FL_RETURN_BUTTON	6
#define FL_HIDDEN_RET_BUTTON	7

/***** Defaults *****/

#define FL_BUTTON_BOXTYPE	FL_UP_BOX
#define FL_BUTTON_COL1		FL_COL1
#define FL_BUTTON_COL2		FL_COL1
#define FL_BUTTON_LCOL		FL_LCOL
#define FL_BUTTON_ALIGN		FL_ALIGN_CENTER

/***** Others   *****/

#define FL_BUTTON_MCOL1		FL_MCOL
#define FL_BUTTON_MCOL2		FL_MCOL
#define FL_BUTTON_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_button(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_button(int, float, float, float, float, char []);

int	fl_get_button(FL_OBJECT *);
void	fl_set_button(FL_OBJECT *, int);

void	fl_set_button_shortcut(FL_OBJECT *, char []);

