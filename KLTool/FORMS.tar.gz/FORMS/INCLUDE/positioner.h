/************   Object Class: Positioner   ************/

/***** Class    *****/

#define FL_POSITIONER		23

/***** Types    *****/

#define FL_NORMAL_POSITIONER	0

/***** Defaults *****/

#define FL_POSITIONER_BOXTYPE	FL_DOWN_BOX
#define FL_POSITIONER_COL1	FL_COL1
#define FL_POSITIONER_COL2	1
#define FL_POSITIONER_LCOL	FL_LCOL
#define FL_POSITIONER_ALIGN	FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_POSITIONER_BW	FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_positioner(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_positioner(int, float, float, float, float, char []);

void 	fl_set_positioner_xvalue(FL_OBJECT *, float);
float 	fl_get_positioner_xvalue(FL_OBJECT *);
void 	fl_set_positioner_xbounds(FL_OBJECT *, float, float);
void 	fl_get_positioner_xbounds(FL_OBJECT *, float *, float *);
void 	fl_set_positioner_yvalue(FL_OBJECT *, float);
float 	fl_get_positioner_yvalue(FL_OBJECT *);
void 	fl_set_positioner_ybounds(FL_OBJECT *, float, float);
void 	fl_get_positioner_ybounds(FL_OBJECT *, float *, float *);
void    fl_set_positioner_xstep(FL_OBJECT *, float);
void    fl_set_positioner_ystep(FL_OBJECT *, float);


void 	fl_set_positioner_return(FL_OBJECT *, int);
