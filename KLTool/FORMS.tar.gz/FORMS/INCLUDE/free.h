/************   Object Class: Free         ************/

/***** Class    *****/

#define FL_FREE			101

/***** Types    *****/

#define FL_NORMAL_FREE		1
#define FL_SLEEPING_FREE	2
#define FL_INPUT_FREE		3
#define FL_CONTINUOUS_FREE	4
#define FL_ALL_FREE		5

/***** Defaults *****/

/***** Others   *****/

/***** Routines *****/

FL_OBJECT 	*fl_create_free(int, float, float, float, float, char [], FL_HANDLEPTR);
FL_OBJECT 	*fl_add_free(int, float, float, float, float, char [], FL_HANDLEPTR);

