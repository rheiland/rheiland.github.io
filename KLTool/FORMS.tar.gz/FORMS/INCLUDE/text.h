/************   Object Class: Text         ************/

/***** Class    *****/

#define FL_TEXT			2

/***** Types    *****/

#define FL_NORMAL_TEXT		0

/***** Defaults *****/

#define FL_TEXT_BOXTYPE		FL_NO_BOX
#define FL_TEXT_COL1		FL_COL1
#define FL_TEXT_LCOL		FL_LCOL
#define FL_TEXT_ALIGN		FL_ALIGN_LEFT

/***** Others   *****/

#define FL_TEXT_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT 	*fl_create_text(int, float, float, float, float, char []);
FL_OBJECT 	*fl_add_text(int, float, float, float, float, char []);

