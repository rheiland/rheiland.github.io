/************   Object Class: Lightbutton  ************/

/***** Class    *****/

#define FL_LIGHTBUTTON		12

/***** Types    *****/

    /* Same types as for buttons */

/***** Defaults *****/

#define FL_LIGHTBUTTON_BOXTYPE	FL_UP_BOX
#define FL_LIGHTBUTTON_COL1	39
#define FL_LIGHTBUTTON_COL2	3
#define FL_LIGHTBUTTON_LCOL	FL_LCOL
#define FL_LIGHTBUTTON_ALIGN	FL_ALIGN_CENTER

/***** Others   *****/

#define FL_LIGHTBUTTON_TOPCOL	FL_COL1
#define FL_LIGHTBUTTON_MCOL	FL_MCOL
#define FL_LIGHTBUTTON_BW1	FL_BOUND_WIDTH
#define FL_LIGHTBUTTON_BW2	FL_BOUND_WIDTH/2.0
#define FL_LIGHTBUTTON_MINSIZE	12.0

/***** Routines *****/

FL_OBJECT  *fl_create_lightbutton(int, float, float, float, float, char []);
FL_OBJECT  *fl_add_lightbutton(int, float, float, float, float, char []);

