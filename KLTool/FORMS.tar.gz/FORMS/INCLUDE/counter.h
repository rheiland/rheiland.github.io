/************   Object Class: Counter       ************/

/***** Class    *****/

#define FL_COUNTER		25

/***** Types    *****/

#define FL_NORMAL_COUNTER	0
#define FL_SIMPLE_COUNTER	1

/***** Defaults *****/

#define FL_COUNTER_BOXTYPE	FL_UP_BOX
#define FL_COUNTER_COL1		FL_COL1
#define FL_COUNTER_COL2		4
#define FL_COUNTER_LCOL		FL_LCOL
#define FL_COUNTER_ALIGN	FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_COUNTER_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_counter(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_counter(int, float, float, float, float, char []);

void 	fl_set_counter_value(FL_OBJECT *, float);
void 	fl_set_counter_bounds(FL_OBJECT *, float, float);
void 	fl_set_counter_step(FL_OBJECT *, float, float);
void	fl_set_counter_precision(FL_OBJECT *, int);
float 	fl_get_counter_value(FL_OBJECT *);

void	fl_set_counter_return(FL_OBJECT *, int);
