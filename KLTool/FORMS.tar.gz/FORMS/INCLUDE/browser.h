/************   Object Class: Browser      ************/

/***** Class    *****/

#define FL_BROWSER		71

/***** Types    *****/

#define FL_NORMAL_BROWSER	0
#define FL_SELECT_BROWSER	1
#define FL_HOLD_BROWSER		2
#define FL_MULTI_BROWSER	3

/***** Defaults *****/

#define FL_BROWSER_BOXTYPE	FL_DOWN_BOX
#define FL_BROWSER_COL1		FL_COL1
#define FL_BROWSER_COL2		3
#define FL_BROWSER_LCOL		FL_LCOL
#define FL_BROWSER_ALIGN	FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_BROWSER_SLCOL	FL_COL1
#define FL_BROWSER_BW		FL_BOUND_WIDTH
#define FL_BROWSER_LINELENGTH	128
#define FL_BROWSER_MAXLINE	512

/***** Routines *****/

FL_OBJECT	*fl_create_browser(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_browser(int, float, float, float, float, char []);

void 	fl_set_browser_topline(FL_OBJECT *, int);
void 	fl_clear_browser(FL_OBJECT *);
void 	fl_add_browser_line(FL_OBJECT *, char []);
void 	fl_addto_browser(FL_OBJECT *, char []);
void 	fl_insert_browser_line(FL_OBJECT *, int , char []);
void 	fl_delete_browser_line(FL_OBJECT *, int );
void 	fl_replace_browser_line(FL_OBJECT *, int , char []);
char	*fl_get_browser_line(FL_OBJECT *, int);
int 	fl_load_browser(FL_OBJECT *, char []);
int	fl_get_browser_maxline(FL_OBJECT *);
void 	fl_select_browser_line(FL_OBJECT *, int );
void 	fl_deselect_browser_line(FL_OBJECT *, int );
void 	fl_deselect_browser(FL_OBJECT *);
int 	fl_isselected_browser_line(FL_OBJECT *, int );
int 	fl_get_browser(FL_OBJECT *);
void 	fl_set_browser_fontsize(FL_OBJECT *, float);
void 	fl_set_browser_fontstyle(FL_OBJECT *, int);
void 	fl_set_browser_specialkey(FL_OBJECT *, char);
