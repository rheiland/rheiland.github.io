/************   Object Class: Choice       ************/

/***** Class    *****/

#define FL_CHOICE		42

/***** Types    *****/

#define FL_NORMAL_CHOICE	0

/***** Defaults *****/

#define FL_CHOICE_BOXTYPE	FL_DOWN_BOX
#define FL_CHOICE_COL1		FL_COL1
#define FL_CHOICE_COL2		FL_LCOL
#define FL_CHOICE_LCOL		FL_LCOL
#define FL_CHOICE_ALIGN		FL_ALIGN_LEFT

/***** Others   *****/

#define FL_CHOICE_BW		FL_BOUND_WIDTH
#define FL_CHOICE_MCOL		FL_MCOL
#define FL_CHOICE_MAXITEMS	128
#define FL_CHOICE_MAXSTR	64

/***** Routines *****/

FL_OBJECT 	*fl_create_choice(int ,float ,float ,float ,float ,char []);
FL_OBJECT 	*fl_add_choice(int ,float ,float ,float ,float ,char []);

void 	fl_clear_choice(FL_OBJECT *);
void 	fl_addto_choice(FL_OBJECT *, char []);
void 	fl_replace_choice(FL_OBJECT *, int , char []);
void 	fl_delete_choice(FL_OBJECT *, int );
void 	fl_set_choice(FL_OBJECT *, int );
int 	fl_get_choice(FL_OBJECT *);
char	*fl_get_choice_text(FL_OBJECT *);
void	fl_set_choice_fontsize(FL_OBJECT *, float);
void	fl_set_choice_fontstyle(FL_OBJECT *, int);


