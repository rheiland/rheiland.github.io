/************   Object Class: Input        ************/

/***** Class    *****/

#define FL_INPUT		31

/***** Types    *****/

#define FL_NORMAL_INPUT		0
#define FL_FLOAT_INPUT		1
#define FL_INT_INPUT		2
#define FL_HIDDEN_INPUT		3
#define FL_MULTILINE_INPUT	4
#define FL_SECRET_INPUT		5

/***** Defaults *****/

#define FL_INPUT_BOXTYPE	FL_DOWN_BOX
#define FL_INPUT_COL1		13
#define FL_INPUT_COL2		5
#define FL_INPUT_LCOL		FL_LCOL
#define FL_INPUT_ALIGN		FL_ALIGN_LEFT

/***** Others   *****/

#define FL_INPUT_TCOL		FL_LCOL
#define FL_INPUT_CCOL		4
#define FL_INPUT_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_input(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_input(int, float, float, float, float, char []);

void	fl_set_input(FL_OBJECT *, char []);
void	fl_set_input_color(FL_OBJECT *, int, int);
char	*fl_get_input(FL_OBJECT *);
void	fl_set_input_return(FL_OBJECT *, int);

