/************   Object Class: Box          ************/

/***** Class    *****/

#define FL_BOX			1

/***** Types    *****/

/* See the bouding boxes */

/***** Defaults *****/

#define FL_BOX_BOXTYPE		FL_UP_BOX
#define FL_BOX_COL1		FL_COL1
#define FL_BOX_LCOL		FL_LCOL
#define FL_BOX_ALIGN		FL_ALIGN_CENTER

/***** Others   *****/

#define FL_BOX_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_box(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_box(int, float, float, float, float, char []);

