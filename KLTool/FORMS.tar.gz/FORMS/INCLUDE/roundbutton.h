/************   Object Class: Roundbutton  ************/

/***** Class    *****/

#define FL_ROUNDBUTTON		13

/***** Types    *****/

    /* Same types as for buttons */

/***** Defaults *****/

#define FL_ROUNDBUTTON_BOXTYPE	FL_NO_BOX
#define FL_ROUNDBUTTON_COL1	7
#define FL_ROUNDBUTTON_COL2	3
#define FL_ROUNDBUTTON_LCOL	FL_LCOL
#define FL_ROUNDBUTTON_ALIGN	FL_ALIGN_CENTER

/***** Others   *****/

#define FL_ROUNDBUTTON_TOPCOL	FL_COL1
#define FL_ROUNDBUTTON_MCOL	FL_MCOL
#define FL_ROUNDBUTTON_BW	FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT  *fl_create_roundbutton(int, float, float, float, float, char []);
FL_OBJECT  *fl_add_roundbutton(int, float, float, float, float, char []);


