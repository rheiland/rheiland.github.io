/************   Object Class: Clock        ************/

/***** Class    *****/

#define FL_CLOCK		61

/***** Types    *****/

#define FL_SQUARE_CLOCK		0
#define FL_ROUND_CLOCK		1

/***** Defaults *****/

#define FL_CLOCK_BOXTYPE	FL_UP_BOX
#define FL_CLOCK_COL1		37
#define FL_CLOCK_COL2		42
#define FL_CLOCK_LCOL		FL_LCOL
#define FL_CLOCK_ALIGN		FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_CLOCK_TOPCOL		FL_COL1
#define FL_CLOCK_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_clock(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_clock(int, float, float, float, float, char []);

void	fl_get_clock(FL_OBJECT *,int * ,int *, int *);

