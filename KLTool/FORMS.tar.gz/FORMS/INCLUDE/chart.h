/************   Object Class: Chart         ************/

/***** Class    *****/

#define FL_CHART		4

/***** Types    *****/

#define FL_BAR_CHART		0
#define FL_HORBAR_CHART		1
#define FL_LINE_CHART		2
#define FL_FILLED_CHART		3
#define FL_SPIKE_CHART		4
#define FL_PIE_CHART		5
#define FL_SPECIALPIE_CHART	6

/***** Defaults *****/

#define FL_CHART_BOXTYPE	FL_BORDER_BOX
#define FL_CHART_COL1		FL_COL1
#define FL_CHART_LCOL		FL_LCOL
#define FL_CHART_ALIGN		FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_CHART_BW		FL_BOUND_WIDTH
#define FL_CHART_MAX		128

/***** Routines *****/

FL_OBJECT	*fl_create_chart(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_chart(int, float, float, float, float, char []);

void	fl_clear_chart(FL_OBJECT *);
void	fl_add_chart_value(FL_OBJECT *, float, char [], int);
void	fl_insert_chart_value(FL_OBJECT *, int, float, char [], int);
void	fl_replace_chart_value(FL_OBJECT *, int, float, char [], int);
void	fl_set_chart_bounds(FL_OBJECT *, float, float);
void	fl_set_chart_maxnumb(FL_OBJECT *, int);
void	fl_set_chart_autosize(FL_OBJECT *, int);
