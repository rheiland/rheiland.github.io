/************   Object Class: Dial         ************/

/***** Class    *****/

#define FL_DIAL			22

/***** Types    *****/

#define FL_NORMAL_DIAL		0
#define FL_LINE_DIAL		1

/***** Defaults *****/

#define FL_DIAL_BOXTYPE		FL_NO_BOX
#define FL_DIAL_COL1		FL_COL1
#define FL_DIAL_COL2		37
#define FL_DIAL_LCOL		FL_LCOL
#define FL_DIAL_ALIGN		FL_ALIGN_BOTTOM

/***** Others   *****/

#define FL_DIAL_TOPCOL		FL_COL1
#define FL_DIAL_BW		FL_BOUND_WIDTH

/***** Routines *****/

FL_OBJECT	*fl_create_dial(int ,float, float, float, float, char []);
FL_OBJECT	*fl_add_dial(int ,float, float, float, float, char []);

void 	fl_set_dial_value(FL_OBJECT *, float);
float 	fl_get_dial_value(FL_OBJECT *);
void 	fl_set_dial_bounds(FL_OBJECT *, float, float);
void 	fl_get_dial_bounds(FL_OBJECT *, float *, float*);

void    fl_set_dial_step(FL_OBJECT *, float);
void 	fl_set_dial_return(FL_OBJECT *, int);
