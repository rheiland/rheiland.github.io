/************   Object Class: Timer        ************/

/***** Class    *****/

#define FL_TIMER		62

/***** Types    *****/

#define FL_NORMAL_TIMER		0
#define FL_VALUE_TIMER		1
#define FL_HIDDEN_TIMER		2

/***** Defaults *****/

#define FL_TIMER_BOXTYPE	FL_DOWN_BOX
#define FL_TIMER_COL1		FL_COL1
#define FL_TIMER_COL2		1
#define FL_TIMER_LCOL		FL_LCOL
#define FL_TIMER_ALIGN		FL_ALIGN_CENTER

/***** Others   *****/

#define FL_TIMER_BW		FL_BOUND_WIDTH
#define FL_TIMER_BLINKRATE	0.2

/***** Routines *****/

FL_OBJECT	*fl_create_timer(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_timer(int, float, float, float, float, char []);

void	fl_set_timer(FL_OBJECT *, float);
float	fl_get_timer(FL_OBJECT *);

