/************   Object Class: Menu         ************/

/***** Class    *****/

#define FL_MENU			41

/***** Types    *****/

#define FL_TOUCH_MENU		0
#define FL_PUSH_MENU		1

/***** Defaults *****/

#define FL_MENU_BOXTYPE		FL_BORDER_BOX
#define FL_MENU_COL1		55
#define FL_MENU_COL2		37
#define FL_MENU_LCOL		FL_LCOL
#define FL_MENU_ALIGN		FL_ALIGN_CENTER

/***** Others   *****/

#define FL_MENU_BW		FL_BOUND_WIDTH
#define FL_MENU_MAXITEMS	128
#define FL_MENU_MAXSTR		64

/***** Routines *****/

FL_OBJECT	*fl_create_menu(int, float, float, float, float, char []);
FL_OBJECT	*fl_add_menu(int, float, float, float, float, char []);

void	fl_clear_menu(FL_OBJECT *);
void	fl_set_menu(FL_OBJECT *, char []);
void	fl_addto_menu(FL_OBJECT *, char []);
void	fl_replace_menu_item(FL_OBJECT *, int, char []);
void	fl_delete_menu_item(FL_OBJECT *, int);

void	fl_set_menu_item_shortcut(FL_OBJECT *, int, char []);
void	fl_set_menu_item_mode(FL_OBJECT *, int, long);
void	fl_show_menu_symbol(FL_OBJECT *, int);

int	fl_get_menu(FL_OBJECT *);
char	*fl_get_menu_text(FL_OBJECT *);

