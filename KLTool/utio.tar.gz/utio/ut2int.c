 /* ut2int.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"

/* ------------------------------------------------------------------- */
/*  UT2INT - convert the data in SRC to integers and store in DEST.
 *  N values are converted.  Function returns N on success, a negative
 *  error code otherwise.
 */
int ut2int(dest, src, n, srctype)
caddr_t	dest, src;
int	n;
UTTYPE	srctype;
{
static char	*name = "ut2int";
int	*ip = (int *) dest;
	int	ret = n;
int	j;
static void	(*prev)(); 	/* previous signal handler */

	if(dest == NULL || src == NULL || n < 0)  {
		ret = UTDOMAIN;
		utseterr(UTDOMAIN);
	} else if(srctype == SHORTS) {	   /* int->short */
		short	 *sp = (short *) src;
		for(j = 0; j < n; j++)
			ip[j] = sp[j];
	} else if(srctype == INTS)  {	/* copy as needed */
		int	*source = (int *) src;
		if(ip != source)
			for(j = 0; j < n; j++)
				ip[j] = source[j];
	} else  {
		if(ut_usesignal)
			prev = signal(SIGFPE, utsighandle);
		if(setjmp(ut_env))  {			/* entry on overflow */
			ret = UTFPE;
			utseterr(UTFPE);
		} else if(srctype == DOUBLES) {		/* doubles->ints */
			double	*dp = (double *) src;
			for(j = 0; j < n; j++)
				ip[j] = dp[j];
		} else if(srctype == FLOATS)  {		/* floats->ints */
			float	*fp = (float *) src;
			for(j = 0; j < n; j++)
				ip[j] = fp[j];
		} else {
			ret = UTDOMAIN;
			utseterr(UTDOMAIN);
		}
		if(ut_usesignal)
			(void) signal(SIGFPE, prev);
	}
	return(ret);
}
