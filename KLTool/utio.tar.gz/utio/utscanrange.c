 /* utscanrange.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ------------------------------------------------------------------------- */
/* UTSCANRANGE - scan a range of integers and place the values in a
 * caller-supplied array.
 * Example:
 *	utscanrange("1-4,6", list, maxitems)
 * returns list[0] = 1, list[1] = 2, list[2] = 3, list[3] = 4, list[4] = 6.
 * The return value of the function is the number of elements assigned in
 * LIST, in this case 5.  The string may not contain blanks.
 * Up to MAXITEMS items in LIST are filled.
 * The function returns 0 if the string is null or maxitems < 1.
 * The function returns a negative number if an error occurs (bad string).
 */

#include <ctype.h>
#define MAXDIG 11 
#define ERROR -1

int utscanrange(string, list, n)
char	*string;
register int	*list;
register int	n;
{
	char	*s = string;
	int	lo, hi, skip;		/* SKIP < 0 indicates error */
	int	j = 0;

	while(j < n && *s != '\0')  {
		if((skip = utgetposint(s, &lo)) <= 0)
			break;
		s += skip;
		if(*s == '-')  {
			if((skip = utgetposint(s, &hi)) <= 0)  {   /* have "3-" */
				skip = -1;
				break;
			}
			s += skip;
			if(hi < lo)  {
				skip = -1;
				break;
			}
			while(j < n && lo <= hi)
				list[j++] = lo++;
		} else
			list[j++] = lo;
	}
	return(skip >= 0 ? j : ERROR);
}
/* ------------------------------------------------------------------------- */
/* GETPOSINT - get a positive integer from STRING.  Leading blanks, commas,
 * and hyphens are skipped.
 * The value is placed in *VAL and the return value of the function 
 * is the number of characters scanned in S or a negative error indicator 
 * otherwise.
 * Note: the number of digits allowed in NUMBER is 11.
 */

int utgetposint(string, val)
register char	*string;
int	*val;
{
	char	number[MAXDIG+1];
	int	j;
	char	*s = string;

	while(*s == ' ' || *s == ',' || *s == '-')
		s++;
	for(j = 0; isdigit((int) *s) && j < MAXDIG; j++)
		number[j] = *s++; 

	/* too many digits or bad character */

	if(j == MAXDIG && isdigit((int) *s)
	   || j < MAXDIG && *s != ',' && *s != '-' && *s != '\0' 
	   || j == 0)
			return(ERROR);
	number[j] = '\0';
	*val = atoi(number);
	return((int) (s - string));
}
