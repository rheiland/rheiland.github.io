 /* utperror.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* UTPERROR - print a message corresponding to the most recently detected
 * utio library error to the standard error.  
 * "String" is prepended to the message, followed by a colon.
 */
#include "utio.h"

extern void	perror();

void utperror(string)
char	*string;
{
static char	*ut_errlist[] = {
			"no error",
			"end of file reached",
			"illegal Fortran record",
			"Fortran sequential unformatted record too long",
			"error reading input",
			"length of input not a multiple of type length",
			"illegal argument value",
			"error writing output",
			"invalid numeric string",
			"overflow/underflow in data conversion",
			"error in number list",
			"non-ascii i/o on terminal device",
			"error allocating memory"
		};
	if(ut_error < 0 && ut_error >= -UTMAXMSGS)  {
		if((ut_error == UTRDSERR || ut_error == UTWRSERR) && errno != 0)
			perror(string);
		else
			fprintf(stderr, "%s: %s (detected by %s)\n", string,
			ut_errlist[-ut_error], ut_routine);
	}
	else if(ut_error == 0)
		(void) fprintf(stderr, "%s: no error\n", string);
	else
		(void) fprintf(stderr, "%s: invalid error number %d\n", string,
			ut_error);
	return;
}
