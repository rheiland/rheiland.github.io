 /* utgetdbl.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ------------------------------------------------------------------------- */
/* UTGETDBL - get a double precision number from STRING.
 * Exponents can be given as E, D, e, or d.
 * Leading blanks are skipped.  The number string can
 * be followed by a blank or any punctuation character except a dot, plus, or 
 * minus.
 * Result is returned in VAL.
 * Return code is 0 for success or a negative value otherwise.
 * 1.  Alters exponent letter if any to be 'e'.
 * 2.  No protection against overflow or underflow.
 */
#include "utio.h"
extern double	atof();

int utgetdbl(val, string)
double	*val;
char	*string;
{
	int	ret;		/* return code */
	int	before;		/* # digits before decimal */
	int	after = 0;	/* # digits after decimal */
	int	e;		/* # digits in exponent field */
	int	havexp = 0;	/* true if exponential notation is used */
register char	*s;		/* indexes string */
register int	c;
	char	*mark;
	char	*holdplace = NULL;	/* save exp letter */
	char	holdchar;
static char	*name = "utgetdbl";

	s = string;
	for(c = *s; isspace(c); s++)		/* skip blanks */
		c = *s;
	if(c == '+' || c == '-')		/* skip sign */
		s++;

	/* count digits before '.' */
	for(c = *s, mark = s; c = *s, isdigit(c); s++);

	before = (int) (s - mark);
	if(c == '.')  {				/* count digits after '.' */
		for(c = *++s, mark = s; c = *s, isdigit(c); s++);
		after = (int) (s - mark);
	}
	if(c == 'e' || c == 'E' || c == 'D' || c == 'd')  {  /* get exponent */
		holdplace = s;		/* save letter so string is returned */
		holdchar = c;		/* unchanged */
		*s++ = 'e';
		havexp = 1;
		if((c = *s) == '+' || c == '-')	   /* skip sign */
			s++;
		for(c = *s, mark = s; c = *s, isdigit(c); s++);
		e = (int) (s - mark);
	}
	c = *s;					/* get terminal character */
	if(before == 0 && after == 0 		/* no digits */
	   || havexp && (e < 1 || e > 3) 	/* wrong # digits in exponent */
	   || c != '\0' && !isspace(c) && 
	      !ispunct(c) || c == '.'
	      || c == '+' || c == '-')		/* bad terminal character */
			ret = UTNOTNBR;
	else {
		*val = atof(string);
		ret = 0;
	}
	if(ret != 0)
		utseterr(ret);
	if(holdplace != NULL)
		*holdplace = holdchar;
	return(ret);
}
