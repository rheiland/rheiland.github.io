 /* utaread.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ------------------------------------------------------------- UTAREAD */
/* UTAREAD - Read up to MAXELT elements from an NLDTEXT file 
 * and convert the data values as required.
 * Return value is the number of elements read or a negative error code
 * otherwise.
 */
#include "utio.h"

int utaread(p, ptype, maxelt, fp)
caddr_t	p;
UTTYPE	ptype;
int	maxelt;		/* max number of elements to read */
register UTFILE	*fp;
{
static char	*name = "utaread";
	caddr_t	buf;
	int	ret;

	if(maxelt < 0 || p == NULL || fp == NULL)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	if(ptype == DOUBLES)
		buf = p;
	else if((buf = 
	   (caddr_t) malloc((unsigned) maxelt * sizeof(double))) == NULL)  {
		utseterr(UTNOMEM);
		return(UTNOMEM);
	}
	ret = utscandbl((double *) buf, maxelt, fp->stream);
	if(ret > 0)  {
		if(buf != p) 
			ret = utconvert(p, buf, ret, DOUBLES, ptype);
	} else if(feof(fp->stream))  {
		ret = UTEOF;
		utseterr(UTEOF);
	} else if(ferror(fp->stream))  {
		ret = UTRDSERR;
		utseterr(UTRDSERR);
	}
	if(buf != p)
		free(buf);
	return(ret);
}
