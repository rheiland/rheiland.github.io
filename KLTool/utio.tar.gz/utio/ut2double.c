 /* ut2double.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"

/* ------------------------------------------------------------------- */
/*  UT2DOUBLE - convert the data in SRC to doubles and store in DEST.
 *  N values are converted.  Function returns N on success, a negative
 *  error code otherwise.
 */
int ut2double(dest, src, n, srctype)
caddr_t	dest, src;
int	n;
UTTYPE	srctype;
{
static char	*name = "ut2double";
double	*dp = (double *) dest;
	int	ret = n;
int	j;
static void	(*prev)(); 	/* previous signal handler */

	if(dest == NULL || src == NULL || n < 0)  {
		ret = UTDOMAIN;
		utseterr(UTDOMAIN);
	} else if(srctype == SHORTS) {	   /* short->double */
		short	*sp = (short *) src;
		for(j = 0; j < n; j++)
			dp[j] = sp[j];
	} else if(srctype == INTS) {	   /* int->double */
		int	*ip = (int *) src;
		for(j = 0; j < n; j++)
			dp[j] = ip[j];
	} else if(srctype == FLOATS) {	/* float -> double */
		if(ut_usesignal)
			prev = signal(SIGFPE, utsighandle);
		if(setjmp(ut_env))  {			/* entry on overflow */
			ret = UTFPE;
			utseterr(UTFPE);
		} else  {
			float	*fp = (float *) src;
			for(j = 0; j < n; j++)
				dp[j] = fp[j];
		}
		if(ut_usesignal)
			(void) signal(SIGFPE, prev);
	} else if(srctype == DOUBLES)  { /* copy */
		double	*source = (double *) src;
		if(dp != source)
			for(j = 0; j < n; j++)
				dp[j] = source[j];
	}  else  {
		ret = UTDOMAIN;
		utseterr(UTDOMAIN);
	}
	return(ret);
}
