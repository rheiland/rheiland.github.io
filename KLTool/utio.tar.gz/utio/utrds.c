 /* utrds.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* UTRDS - read in all the data from the file, converting the type as needed.
 * P->OFFSET is set to 0 on successful return, so a call to utwrite(p, 0, fp)
 * will write out all the data.
 * Return value is the number of values read in and converted and a negative
 * error code otherwise.
 */
#include "utio.h"

int utrds(p, fp)
register UTBUF	*p;
register UTFILE	*fp;
{
	int	total = 0;
	int	nrds;

	p->offset = 0;
	while((nrds = utread(p, 0, fp)) > 0)  {
		total += nrds;
		p->offset = total;
	}
	if(nrds == UTEOF)  {
		p->offset = 0;
		return(total);
	} else
		return(nrds);		/* contains error code */
}
