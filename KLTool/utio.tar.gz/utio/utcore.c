 /* utcore.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include <stdio.h>
#define UTHAVEXTERNS
#include "utio.h"

/* ------------------------------------------------------------ UTMORECORE */
/* UTMORECORE - add space if needed so that N additional elements 
 * can be appended to the buffer P starting at P->OFFSET.
 * Note:  It is an error if P->OFFSET > P->SIZE.  However, 
 * if P->OFFSET == P->SIZE, then the array is enlarged by N elements.
 * Returns p->data on success and NULL otherwise.
 */
caddr_t utmorecore(p, n)
register UTBUF	*p;
int	n;
{
static char	*name = "utmorecore";
	int	needed;		/* number of additional ELEMENTS needed */

	if(p == NULL || n < 1 || p->data != NULL && 
	   (p->size < 1 || p->offset < 0 || p->offset > p->size)
	   || p->typesize < 1)  {
		utseterr(UTDOMAIN);
		return(NULL);
	} else if(p->data == NULL)  {
		if((p->data = (caddr_t) malloc((unsigned) (n * p->typesize)))
		   == NULL)  {
			utseterr(UTNOMEM);
		}  else  {
			p->size = n;
			p->offset = 0;
		}
	} else if((needed = n - p->size + p->offset) > 0)  {
		p->size += needed;
		p->data = (caddr_t) realloc((char *) p->data, (unsigned)
			(p->size * p->typesize));
		if(p->data == NULL) {
			utseterr(UTNOMEM);
		}
	}
	return(p->data);
}
/* ------------------------------------------------------------ UTTRIMCORE */
/* UTTRIMCORE - trim the storage allocated to p->data to be exactly N
 * values.  If N = 0 then storage for p->data is freed.
 * Returns p->data if N > 0 and NULL otherwise, or if an error
 * occurred.
 */
caddr_t uttrimcore(p, n)
register UTBUF	*p;
int	n;
{
static char	*name = "uttrimcore";

	if(p == NULL || p->data == NULL || n < 0 || p->typesize < 1)  {
		utseterr(UTDOMAIN);
		return(NULL);
	} else if(n == 0)  {
		free(p->data);
		p->size = 0;
		p->data = NULL;
	} else if((p->data = (caddr_t) realloc((char *) p->data, (unsigned)
				(n * p->typesize))) == NULL) {
		utseterr(UTNOMEM);
	} else
		p->size = n;
	return(p->data);
}
