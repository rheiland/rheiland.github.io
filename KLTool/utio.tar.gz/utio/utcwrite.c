 /* utcwrite.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ----------------------------------------------------------------------- */
/* UTCWRITE - Write either a text or binary C record and convert
 * the data values as required.
 * Data are output starting from array index P->OFFSET and continuing
 * for MAXELT elements or until the end of the data, whichever occurs first.
 * Return value is the number of data values written or a negative error
 * code otherwise.  Note that 0 elements can be written if P->OFFSET == P->SIZE.
 */
#include "utio.h"
#define min(x,y) ((x) < (y) ? (x) : (y))

int utcwrite(p, maxelt, fp)
register UTBUF	*p;
int	maxelt;
register UTFILE	*fp;
{
static char	*name = "utcwrite";
	caddr_t	buf;
	caddr_t	startpos;
	int	ret;

	if(p == NULL || fp == NULL || p->size < p->offset)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	maxelt = min(maxelt, p->size - p->offset);
	if(p->type == fp->type)
		buf = p->data;
	else if((buf = (caddr_t) malloc((unsigned) (maxelt * fp->typesize)))
	   == NULL)  {
		utseterr(UTNOMEM);
		return(UTNOMEM);
	}
	startpos = (caddr_t) ((char *) p->data + p->offset * p->typesize);
	if(utconvert(buf, startpos, maxelt, p->type, fp->type) != maxelt)
		return(ut_error);
	if(fp->isbinary)  {
		if(isatty(fileno(fp->stream)))  {
			utseterr(UTNONASCII);
			ret = UTNONASCII;
		} else
			ret = fwrite((char *) buf, fp->typesize, maxelt,
				fp->stream);
	} else
		ret = utwrdbl((double *) buf, maxelt, fp->stream, fp->ndigits,
			fp->recl);
	if(buf != p->data)
		free(buf);
	return(ret);
}
