 /* utcread.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"
#define min(x, y) ((x) < (y) ? (x) : (y))

/* ---------------------------------------------------------------- UTREAD */
/* UTCREAD - read a C record and allocate storage as required, and convert
 * the data as needed.  The input can be binary or text.
 * N is the maximum number of values to retrieve.  If N == 0, then we read
 * a convenient number of values from the file.  Otherwise we read up to N.
 * Read starts at the (P->OFFSET)th entry in p->data.  On return, P->DATA
 * is trimmed so that P->SIZE == P->OFFSET and the next read starts at the
 * end of the existing data.  To overwrite the data if extension is not
 * required, set P->OFFSET = 0 before calling this routine.
 */
int utcread(p, n, fp)
register UTBUF	*p;
int	n;
UTFILE	*fp;
{
static char	*name = "utcread";
	int	left;			/* number of values left */
	int	chunk;			/* chunk size for processing */
	int	nrds = 0;		/* total number of values read so far */
	int	pindex;			/* index where read begins in p->data */
	int	lim;
	int	how;
	int	(*readfcn)();
	caddr_t	startpos;

	if(p == NULL || n < 0 || fp == NULL)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	if(n == 0)
		n = UTOPTRECL / fp->typesize;
	if(utmorecore(p, n) == NULL)
		return(ut_error);
	readfcn = (fp->isbinary ? utfread : utaread);
	chunk = (p->type == fp->type ? n : UTOPTRECL / fp->typesize);
	pindex = p->offset;
	for(left = n; left > 0; left -= chunk)  {
		lim = min(left, chunk);
		startpos = (caddr_t) ((char *) p->data + pindex * p->typesize);
		if((how = (*readfcn)(startpos, p->type, lim, fp)) < 0)
			break;
		nrds += how;
		pindex += how;
	}
	if(uttrimcore(p, pindex) == NULL)
		how = ut_error;
	return(nrds > 0 && (how >= 0 || how == UTEOF) ? nrds : how);
}
