 /* utawrite.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ---------------------------------------------------------------- UTAWRITE */
/* UTAWRITE - Write a text C record and convert the data values as required.
 * Return value is number of values written on success or 
 * a negative error code otherwise.  
 * Note: it is not an error to request that 0 values be written out.
 */
#include "utio.h"

int utawrite(p, ptype, maxelt, fp)
caddr_t	p;
UTTYPE	ptype;
int	maxelt;		/* number of elements to write */
register UTFILE	*fp;
{
static char	*name = "utawrite";
	caddr_t	buf;
	int	ret;

	if(maxelt < 0 || p == NULL || fp == NULL)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	if(ptype == DOUBLES)
		buf = p;
	else if((buf = (caddr_t) malloc((unsigned) maxelt * sizeof(double)))
	   == NULL)  {
		utseterr(UTNOMEM);
		return(UTNOMEM);
	} else if(utconvert(buf, p, maxelt, ptype, DOUBLES) != maxelt)
		return(ut_error);
	ret = utwrdbl((double *) buf, maxelt, fp->stream, fp->ndigits, fp->recl);
	if(buf != p)
		free(buf);
	return(ret);
}
