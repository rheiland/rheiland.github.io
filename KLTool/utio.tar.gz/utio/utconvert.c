 /* utconvert.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"
#include <memory.h>

/* UTCONVERT - convert the data in SRC to the type in DESTTYPE and
 * place into DEST, which is assumed to point to a location in memory
 * that is large enough to hold the result.
 * No conversion is done if DESTTYPE is BYTES: the data are copied to
 * DEST regardless of the type of SRC.
 * It is an error if SRCTYPE is BYTES and DESTTYPE is not BYTES.
 * Return value is N for success, a negative error code else.
 */
int utconvert(dest, src, n, srctype, desttype)
caddr_t	dest, src;
int	n;			/* number of values to be copied */
UTTYPE	srctype, desttype;
{
static char	*name = "utconvert";
	int	how;

	if(srctype == BYTES && desttype != BYTES)  {
		how = UTDOMAIN;
		utseterr(UTDOMAIN);
	} else  {
		switch(desttype)  {
		case DOUBLES:
			how = ut2double(dest, src, n, srctype);
			break;
		case FLOATS:
			how = ut2float(dest, src, n, srctype);
			break;
		case INTS:
			how = ut2int(dest, src, n, srctype);
			break;
		case SHORTS:
			how = ut2short(dest, src, n, srctype);
			break;
		case BYTES:
			(void) memcpy((caddr_t) dest, (caddr_t) src,
				n * utdatasize(srctype));
			how = n;
			break;
		default:
			how = UTDOMAIN;
			utseterr(UTDOMAIN);
		}
	}
	return(how);
}
