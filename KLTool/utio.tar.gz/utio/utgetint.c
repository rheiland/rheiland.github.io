 /* utgetint.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/*  UTGETINT - Get a decimal integer from string.  This routine checks for
 *  garbage characters and for numbers which are too large to be represented
 *  as ints.
 *  Leading spaces and zeroes are skipped.
 *  See ctype(3c) for definition of spaces.
 *  The number consists of digits 0-9, preceded by an optional sign.
 *  The number can be followed by any blank or punctuation character except '.'.
 *  On successful return, utgetint returns 0; otherwise, a negative error
 *  code is returned and ut_error is set to indicate the error.
 *  Programmer:  Eric Kostelich,  Center for Nonlinear Dynamics,
 *		 Dept. of Physics, UT Austin  78712.
 */
#include "utio.h"
#include <values.h>
extern double	atof();

int utgetint(val, string)
int	*val;		/* integer value goes here on return */
char	*string;	/* string to scan */
{
static char	*name = "utgetint";
	int	ret;		/* return code */
	int	isneg = 0;	/* true if number is negative */
	int	ndigit;		/* # digits before decimal */
register char	*s;		/* indexes string */
register int	c;
	char	*mark;
	double	x;

	s = string;
	while(c = *s, isspace(c))		/* skip blanks */
		s++;
	if(c == '+' || (isneg = (c == '-')))	/* skip sign */
		s++;
	while(*s == '0')			/* skip zeros */
		s++;
	for(mark = s; c = *s, isdigit(c); s++); /* count digits */
	ndigit = (int) (s - mark);
	if(ndigit == 0 || ndigit > UTMAXSIGDIGIT || 	/* check nondigit */
	   c != '\0' && !isspace(c) && !ispunct(c) || c == '.' || 
	   (x = atof(mark)) > MAXINT)  {
		ret = UTNOTNBR;
		utseterr(ret);
	} else {				/* convert value */
		*val = (int) (isneg ? -x : x);
		ret = 0;
	}
	return(ret);
}
