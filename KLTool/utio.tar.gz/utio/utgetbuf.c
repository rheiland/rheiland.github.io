 /* utgetbuf.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ---------------------------------------------------------------------- */
#include <stdio.h>
#include <setjmp.h>
#define UTHAVEGLOBALS
#include "utio.h"

/* Definitions of external variables used in the library. */
char	*ut_routine = NULL;	/* name of last routine to encounter error */
int 	ut_error = 0;		/* global error number  */
int	ut_usesignal = 1;	/* use utio signal handler in data conversion */
jmp_buf	ut_env;			/* stack state */

/* ---------------------------------------------------------------------- */
/* UTGETBUF - allocate and initialize an input buffer.
 * A type of ASCII is the same as DOUBLES.
 */
UTBUF *utgetbuf(type)
UTTYPE	type;
{
static char	*name = "utgetbuf";
	UTBUF	*p;

	ut_error = 0;
	if((p = (UTBUF *) malloc(sizeof(UTBUF))) != NULL)  {
		p->data = NULL;
		p->size = 0;
		p->offset = 0;
		if((p->type = uttypeof(type)) == UTNONE)  {
			utseterr(UTDOMAIN);
		} else
			p->typesize = utdatasize(p->type);
	} else {
		utseterr(UTNOMEM);
	}
	if(ut_error != 0)  {
		free(p);
		p = NULL;
	}
	return(p);
}
/* ---------------------------------------------------------------------- */
/* UTFREEBUF - free the storage in the buffer pointed to by the UTBUF pointer.
 * The actual data structure pointed to by P is not deallocated.
 */
void utfreebuf(p)
register UTBUF 	*p;
{
	if(p != NULL)  {
		if(p->data != NULL)  {
			free(p->data);
			p->data = NULL;
		}
		p->size = 0;
		p->offset = 0;
		p->typesize = 0;
		p->type = UTNONE;
	}
	return;
}
/* ---------------------------------------------------------------------- */
/* UTGETFILE - incorporate arguments into a pointer to a file structure
 * containing the same information.  Returns a UTFILE pointer on success
 * and NULL otherwise.
 * Note:  A file is marked as "isfortran" (i.e., containing sequential
 * records with markers) only if the file type is binary.
 * No record structure applies to ascii input (so 'a' and 'A' are identical).
 */
UTFILE	*utgetfile(stream, type)
FILE	*stream;
UTTYPE	type;
{
register UTFILE	*fp;
static char	*name = "utgetfile";

	ut_error = 0;
	if((fp = (UTFILE *) malloc(sizeof(UTFILE))) != NULL)  {
		if((fp->stream = stream) == NULL ||
		   (fp->type = uttypeof(type)) == UTNONE)  {
			utseterr(UTDOMAIN);
		} else {
			fp->typesize = utdatasize(fp->type);
			fp->isbinary = !utisascii(fp->type);
			fp->isfortran = (fp->isbinary ? utisfortran(type) : 0);
			fp->recl = 0;
			fp->partialok = 0;
			fp->ndigits = UTUSUALSIG;
		}
	} else {
		utseterr(UTNOMEM);
	}
	if(ut_error != 0)  {
		free(fp);
		fp = NULL;
	}
	return(fp);
}
