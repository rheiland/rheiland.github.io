 /* utscandbl.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* -------------------------------------------------------------------- */
/* UTSCANDBL - read ascii doubles from the indicated input file.
 * Return value is the number of values read on success or a negative
 * error code otherwise.
 * Values in DEST are always stored as doubles.  Storage for DEST is assumed
 * to be allocated already.
 * Note: not reentrant because PREV is statically allocated to make certain
 * it has a valid value if a signal is raised.
 */
#include <stdio.h>
#include <signal.h>
#include "utio.h"

int utscandbl(dest, n, stream)
register double	*dest;
register int	n;		/* number of values to read */
register FILE	*stream;
{
static char	*name = "utscandbl";
	int	how;
register int	j;
	char	buf[UTMAXNBRLEN];	/* holds individual numbers */
static	void	(*prev)();

	if(dest == NULL || n < 0 || stream == NULL)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	} 
	if(ut_usesignal)
		prev = signal(SIGFPE, utsighandle);
	if(setjmp(ut_env))  {		/* entry point on overflow */
		n = UTFPE;
		utseterr(UTFPE);
	}  else {
		for(j = 0; j < n && (how = utrdwd(buf, stream)) == 0; j++) {
			if(how = utgetdbl(dest++, buf))
				break;
		}
		if(how == UTEOF)
			n = (j == 0 ? UTEOF : j);
		else if(how < 0)			/* error reading */
			n = how;
		else
			n = j;				/* got something */
	}
	if(ut_usesignal)
		(void) signal(SIGFPE, prev);
	return(n);
}
