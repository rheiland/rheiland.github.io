 /* utmisc.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"
/* --------------------------------------------------------------------- */
/* UTTYPEOF - validate the type of the input. */
UTTYPE uttypeof(type)
UTTYPE type;
{
	char	*alltypes = "aAsSiIfFdDbB";
	char	*p;
	UTTYPE	c;

	for(p = alltypes; *p != '\0'; p++)
		if((c = *p) == type)
			break;
	if(*p == '\0')
		c = UTNONE;
	else if(isupper(c))
		c = tolower(c);
	return(c);
}
/* --------------------------------------------------------------------- */
/* UTDATASIZE - return the size in bytes of the data type given by the
 * argument letter.
 * If the routine returns successfully, it returns a positive integer
 *	whose value is the size in bytes of the data type specified by the
 *	input letter.
 * If the input is invalid, the routine returns a negative integer
 *	and sets uterror to indicate the error (UTDOMAIN).
 * Programmer:  Eric Kostelich, Center for Nonlinear Dynamics,
 *		Dept. of Physics, University of Texas, Austin 78712
 */
int utdatasize(type)
UTTYPE type;
{
static char *name = "utdatasize";

	switch(type) {
	case SHORTS:
	case SHORTF:
		return(sizeof(short));
	case INTS:
	case INTF:
		return(sizeof(int));
	case FLOATS:
	case FLOATF:
		return(sizeof(float));
	case DOUBLES:
	case DOUBLEF:
	case ASCII:	/* all ASCII data are converted to doubles */
		return(sizeof(double));
	case BYTES:
		return(sizeof(char));
	default:
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
}
/* ---------------------------------------------------------------- */
/* UTSIGHANDLE - handle floating point exceptions when doing data conversion */


void utsighandle()
{
	extern void	longjmp();
	longjmp(ut_env, 1);	/* return any nonzero value */
}
