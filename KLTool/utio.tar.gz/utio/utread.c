 /* utread.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ----------------------------------------------------------------------- */
/* UTREAD - read a single record from the indicated file, allocating
 * storage as needed and converting types as needed.
 * N    is the maximum number of elements of P to read if positive.
 *	Otherwise, if N is zero, a convenient number of elements is read.
 *	A negative value is an error.
 * The read starts at the (P->OFFSET)th entry in P->DATA.  On return, P->DATA
 * is trimmed so that it exactly holds the data (i.e., there is no leftover
 * space) and the next read starts at the
 * end of the existing data.  To overwrite the data if extension is not
 * required, set P->OFFSET = 0 before calling this routine.
 */
#include "utio.h"

int utread(p, n, fp)
register UTBUF	*p;
int	n;			/* if > 0, max number of elts to read */
register UTFILE	*fp;
{
static char	*name = "utread";
	int	nrds;		/* number of values read */
	int	recl;		/* Fortran record length in bytes */
	int	nval;		/* number of values in next record */
	int	how;		/* status of Fortran record markers */

	if(n < 0)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	} else if(fp->isfortran)  {	/* assumes a binary file */
		if((recl = utcheckrecl(0, fp)) < 0)  {	/* error */
			utseterr(recl);
			return(recl);
		} else if(recl % fp->typesize != 0)  {
			utseterr(UTWRONGTYPE);
			return(UTWRONGTYPE);
		}
		nval = recl / fp->typesize;
		if(n > 0 && nval > n)  {	/* for n==0 read the whole 
						 * record */
			utseterr(UTTOOLONG);
			return(UTTOOLONG);
		}
	} else if(n == 0)		/* read a convenient number of elts */
		nval = UTOPTRECL / fp->typesize;
	else
		nval = n;
	if((nrds = utcread(p, nval, fp)) >= 0 && fp->isfortran)  {
		if((how = utcheckrecl(recl, fp)) != 0)  {
			utseterr(how);
			nrds = how;
		}
	}
	return(nrds);
}
/* ----------------------------------------------------------------------- */
/* UTCHECKRECL - check the record length of the Fortran sequential unformatted
 * file attached to FP.
 * Arguments:
 * N    : If N == 0, then return the length of the next record in bytes.
 *	  A negative error code is returned if any error occurs.
 * 	  Otherwise if, N > 0, we check the next integer in the record
 *	  and verify whether its value equals N.  If so, we return 0.
 *	  Otherwise, we return a negative error code.
 * FP   : File pointer structure.
 */
int utcheckrecl(n, fp)
register int	n;
register UTFILE	*fp;
{
	register int	ret;
	int	recl;

	if(n < 0 || fp == NULL || fp->isfortran == 0 || fp->isbinary == 0)  {
		ret = UTDOMAIN;
	} else if(n == 0)  {	/* check next record marker */
		if(fread((char *) &recl, sizeof(recl), 1, fp->stream) != 1)  {
			if(feof(fp->stream))
				ret = UTEOF;
			else if(ferror(fp->stream))
				ret = UTRDSERR;
			else
				ret = UTILLREC;
		}
		else if(recl < 0)
			ret = UTILLREC;
		else if(recl > UTMAXRECLEN)
			ret = UTTOOLONG;
		else
			ret = recl;	/* ok */
	} else if(n > 0)  {	/* double check ending marker */
		if(fread((char *) &recl, sizeof(recl), 1, fp->stream) != 1)
			ret = (feof(fp->stream) ? UTILLREC : UTRDSERR);
		else if(recl != n)
			ret = UTILLREC;
		else
			ret = 0;	/* ok */
	}
	return(ret);
}
