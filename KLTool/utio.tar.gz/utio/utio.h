/* UTIO.H - UTIO library header file.
 * Copyright (c) 1990 by Eric J. Kostelich.
 */
#ifndef UTINCLUDED
#define UTINCLUDED
#include <stdio.h>
#include <sys/types.h>
#if u3b2 || u3b5 || u3b15 || u3b20d
typedef unsigned int size_t;    /* AT&T boxes don't define it */
#endif
#include <signal.h>
#include <malloc.h>
#include <ctype.h>

#ifndef UTHAVEALLOC
#define UTHAVEALLOC
extern int	errno;		/* in C library */
#endif /* UTHAVEALLOC */

#ifndef UTHAVEDEFS
#define UTHAVEDEFS
typedef int	UTTYPE;		/* type of input */

typedef struct  {
	caddr_t	data;		/* holds contents of input */
	int	size;		/* size in number of elements */
	int	offset;		/* offset in number of elements */
	size_t	typesize;	/* sizeof(type) */
	UTTYPE	type;		/* actual type of input */
} UTBUF;

typedef struct {
	FILE	*stream;
	size_t	typesize;	/* sizeof(type) */
	int	isfortran;	/* nonzero for Fortran record markers */
	int	isbinary;	/* nonzero unless a text file */
	int	recl;		/* in number of elements, if Fortran file */
	int	ndigits;	/* number of significant digits to print */
	int	partialok;	/* nonzero if Fortran records of fewer than
				 * RECL elements are allowed in a record */
	UTTYPE	type;		/* one of DOUBLES, FLOATS, INTS or SHORTS */
} UTFILE;

#define utseterr(s) {ut_error = (s); ut_routine = name;}

/* File is a sequence of bytes */
#define BYTES		'b'

/* File is a sequence of bytes as Fortran unformatted sequential records */
#define BYTEF		'B'

/* File contains ASCII characters (nldtext(7) file) */
#define ASCII		'a'

/*  C sequential file of short integers */
#define	SHORTS		's'

/*  Fortran sequential file of short integers */
#define SHORTF		'S'

/*  C sequential file of 32-bit integers */
#define	INTS		'i'

/*  Fortran sequential file of 32-bit integers */
#define INTF 	'I'

/*  C sequential file of single precisio nfloating point numbers */
#define FLOATS		'f'

/*  Fortran sequential file of single precision floating point numbers */
#define FLOATF	'F'

/*  C sequential file of double precision floating point numbers */
#define DOUBLES		'd'

/*  Fortran sequential file of double precision floating point numbers */
#define DOUBLEF	'D'

/* Undefined type */
#define UTNONE		'\0'

/*  A suggested optimum record length */
#define UTOPTRECL  4096

/*  Maximum number of significant figures to write out */
#define UTMAXSIGDIGIT	14

/* Usual number of significant figures */
#define UTUSUALSIG 6

/*  Maximum nmber of characters in a floating-point ASCII number */
#define UTMAXNBRLEN	48

/*  Maximum record length of a Fortran file in bytes */
#define UTMAXRECLEN	65536

/*  Is the file an ASCII file? */
#define utisascii(s)	((s) == ASCII || (s) == 'A')

/*  Is the file a Fortran sequential file? */
#define utisfortran(s)	((s) >= 'A' && (s) <= 'Z')

/* Does the file consist only of long or short integers? */
#define utisint(s)	(uttypeof(s) == INTS || uttypeof(s) == SHORTS)

/* Does the file consist only of floating point numbers? */
#define utisfloat(s)	(uttypeof(s) == DOUBLES || uttypeof(s) == FLOATS)

/* Is the character a valid file type specifier? */
#define utiospec(s)	(strchr("bBaAsSiIfFdD", (char) (s)) != NULL)
/* ----------------------------------------------------------------- */
/* List of UTLIB error codes */

/* We reached the end of file */
#define UTEOF		-1

/* Input is not a legal Fortran record */
#define UTILLREC	-2

/* Fortran record is longer than max number of elements on read/write */
#define UTTOOLONG	-3

/* Read error on input file */
#define UTRDSERR	-4

/* Length of input data is not an even multiple of the type length */
#define UTWRONGTYPE	-5

/* Illegal argument value to called procedure */
#define UTDOMAIN	-6

/* Error writing to output file */
#define UTWRSERR	-7

/* ASCII number is in the wrong form */
#define UTNOTNBR	-8

/* Overflow/underflow in numeric conversion */
#define UTFPE	-9

/* Error parsing number list */
#define UTNBRLISTERR	-10

/* Attempt to read/write non-ascii characters from/to a terminal device */
#define UTNONASCII	-11

/* Error allocating memory for arrays */
#define UTNOMEM		-12

/* Total number of errors defined in this file */
#define UTMAXMSGS	13

/* Special flag for errors detected by stdio */
#define UTFERROR -13
#endif /* UTHAVEDEFS */

#ifndef UTHAVEGLOBALS
#define UTHAVEGLOBALS
#include <setjmp.h>

extern char	*ut_routine;	/* name of last routine to encounter error */
extern int	ut_error;	/* error code */
extern int	ut_usesignal;	/* nonzero means use utio signal handler 
				 * in data conversion */
extern jmp_buf	ut_env;		/* stack state */
#endif /* UTHAVEGLOBALS */

/* Declarations of external variables useful for various routines in the 
 * library 
 */
#ifndef UTHAVEXTERNS
#define UTHAVEXTERNS
#ifdef __STDC__		/* extern declarations for ANSI C compilers */
extern int utdatasize(UTTYPE);
extern int ut2double(caddr_t, caddr_t, int, UTTYPE);
extern int ut2float(caddr_t, caddr_t, int, UTTYPE);
extern int ut2int(caddr_t, caddr_t, int, UTTYPE);
extern int ut2short(caddr_t, caddr_t, int, UTTYPE);
extern int ut2float(dest, src, n, srctype);
extern int utaread(caddr_t, UTTYPE, int, UTFILE *);
extern int utawrite(caddr_t, UTTYPE, int, UTFILE *);
extern int utconvert(caddr_t, caddr_t, int, UTTYPE, UTTYPE);
extern int utcread(UTBUF *, int, UTFILE *);
extern int utcwrite(UTBUF *, int, UTFILE *);
extern int utfread(caddr_t, UTTYPE, int, UTFILE *);
extern int utfwrite(caddr_t, UTTYPE, int, UTFILE *);
extern int utgetposint(char *, int *);
extern int utscandbl(double *, int, FILE *);
extern int utgetdbl(double *, char *);
extern int utgetint(int *, char *);
extern int utrdwd(char *, FILE *);
extern int utrds(UTBUF *, UTFILE *);
extern int utread(UTBUF *, int, UTFILE *);
extern int utscanrange(char *, int *, int);
extern int utwrdbl(double *, int, FILE *, int, int);
extern int utwrite(UTBUF *, int, UTFILE *);
extern UTTYPE uttypeof(UTTYPE);
extern UTBUF *utgetbuf(UTTYPE);
extern void utperror(char *);
extern void utfreebuf(UTBUF *);
extern void utsighandle();
extern caddr_t utmorecore(UTBUF *, int);
extern caddr_t uttrimcore(UTBUF *, int);
#else				/* extern declarations for old C's */
extern int	utdatasize(),
		ut2double(),
		ut2float(),
		ut2int(),
		ut2short(),
		utaread(),
		utawrite(),
		utconvert(),
		utcread(),
		utcwrite(),
		utfread(),
		utfwrite(),
		utgetposint(),
		utscandbl(),
		utgetdbl(),
		utgetint(),
		utrdwd(),
		utrds(),
		utread(), 
		utscanrange(),
		utwrdbl(),
		utwrite();
extern UTTYPE	uttypeof();
extern char	*strchr();
extern UTBUF	*utgetbuf();
extern void	utsighandle();
extern void	utperror();
extern void	utfreebuf();
extern UTFILE	*utgetfile();
extern caddr_t	utmorecore();
extern caddr_t	uttrimcore();
#endif  /* __STDC__ */
#endif  /* UTHAVEXTERNS */
#endif
