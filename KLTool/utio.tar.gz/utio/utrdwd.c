 /* utrdwd.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* UTRDWD - read a word from the indicated stream and copy into BUF.  
 * A word is defined as any sequence of nonblank characters, where a blank 
 * is defined according to isspace() in ctype(3c) - usually a tab, space,
 * carriage return, or newline.  Punctuation (defined according to ispunct()
 * in ctype(3c)) that is not a period, plus, or minus is converted to spaces.
 * Characters in the input following an unescaped '#'
 * are ignored up to and including the next newline.
 * Escaped characters are always copied literally, even if they are blanks
 * or punctuation as defined above.
 * Any character can be escaped by preceding it with a backslash (\); the
 * backslash itself is skipped.
 * The contents are copied into the space pointed to by BUF and terminated
 * with a NULL byte.  
 * Return value is 0 for success, UTEOF on end-of-file, UTRDSERR on error,
 * and UTDOMAIN for null pointers.
 */
#include "utio.h"
#define skippable(c) (isspace(c) || ispunct(c) && (c) != '.' && \
		(c) != '-' && (c) != '+' && (c) != '#')

int utrdwd(buf, stream)
register char	*buf;
register FILE	*stream;
{
register int	c;
register char 	*lim;		/* last available byte for data */
static char	*name = "utrdwd";

	if(buf == NULL || stream == NULL)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	lim = buf + UTMAXNBRLEN;
	do {
		do  {			/* skip punctuation and whitespace */
			c = getc(stream);
		} while(c != EOF && skippable(c));

		if(c == '#')		/* ignore to end of line */
			while((c = getc(stream)) != '\n' && c != EOF);
		else  {				/* copy to next blank or # */
			while((int) (lim - buf) && !skippable(c) && c != '#' 
			   && c != EOF)  {
				if(c == '\\' && (c = getc(stream)) != EOF)
					*buf++ = c;
				else if(c != EOF)
					*buf++ = c;
				c = getc(stream);
			}
			if(c == '#')		/* embedded # in text */
				(void) ungetc(c, stream);
			if(c != EOF)
				c = 0;
			goto quit;
		}
	} while(c != EOF);
	c = (ferror(stream) ? UTRDSERR : UTEOF);
quit:	*buf = '\0';
	return(c);
}
