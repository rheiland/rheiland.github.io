 /* utwrite.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* ----------------------------------------------------------------------- */
/* UTWRITE - write out N elements in the P->DATA array, converting the values
 * as needed.  If the output file is Fortran sequential unformatted, then
 * this routine may write more than one record.
 * Data are output starting from array index P->OFFSET and continuing
 * for N elements or until the end of the data, whichever occurs first.
 * If N == 0, try to write out all the elements if possible.
 * Negative N's are an error.
 * If the output file is a Fortran sequential unformatted file, then
 * records are written out in blocks of FP->RECL values.  If FP->RECL < 1,
 * then a convenient number of values is written in each record.
 * Return value is the number of data values written or a negative error
 * code otherwise.  Note that 0 elements can be written if P->OFFSET == P->SIZE.
 */
#include "utio.h"

int utwrite(p, n, fp)
register UTBUF	*p;
int	n;		/* max number of elements to write out */
register UTFILE	*fp;
{
static char	*name = "utwrite";
	int	nwrs = 0;	/* number of elements written this call */
	int	left;
	int	recl = fp->recl;
	int	how = 0;
	caddr_t	startpos;

	if(p == NULL || p->data == NULL || fp == NULL || fp->typesize < 1)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	left = p->size - p->offset;
	if(left < n || n == 0)
		n = left;
	else if(n < 0)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	if(!fp->isbinary)  {		/* text file */
		startpos = (caddr_t) ((char *) p->data + p->offset * p->typesize);
		nwrs = utawrite(startpos, p->type, n, fp);
	} else if(fp->isfortran)  {
		int	hold = p->offset;   /* original value of p->offset */
		if(recl < 1)  {		/* write out a convenient number */
			recl = UTOPTRECL / fp->typesize;
			fp->partialok = 1;
		}
		for(how = 0, left = n; left >= recl; left -= recl)  {
			if(how = utwrmarker(recl, fp))
				break;
			if((how = utcwrite(p, recl, fp)) != recl)
				break;
			if(how = utwrmarker(recl, fp))
				break;
			p->offset += recl;
			nwrs += recl;
		}
		/* Write leftover data into a short record if permitted */

		if(how >= 0 && left > 0 && fp->partialok &&
		    (how = utwrmarker(left, fp)) == 0 && 
		    (how = utcwrite(p, left, fp)) == left &&
		    (how = utwrmarker(left, fp)) == 0)  {
			nwrs += left;
		}
		p->offset = hold;
	} else
		nwrs = utcwrite(p, n, fp);
	return(how >= 0 ? nwrs : how);
}
/* ----------------------------------------------------------------------- */
/* UTWRMARKER - write a Fortran sequential record marker to the indicated
 * stream.  Return 0 on success and a negative error code otherwise.
 */
int utwrmarker(recl, fp)
int	recl;
register UTFILE	*fp;
{
static char	*name = "utwrmarker";
	int	nwrit;
	int	nbytes = recl * fp->typesize;

	if((nwrit = fwrite((char *) &nbytes, sizeof(nbytes), 1, fp->stream)) 
	   != 1) {
		utseterr(UTWRSERR);
		nwrit = UTWRSERR;
	} else
		nwrit = 0;
	return(nwrit);
}
