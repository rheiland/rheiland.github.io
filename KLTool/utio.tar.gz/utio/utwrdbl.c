 /* utwrdbl.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* UTWRDBL - write out the contents of the buffer, which consist of
 * double- or single-precision values, in ascii format to the
 * indicated stream with the requested number of significant figures.
 * Output is one value per line by default, in Fortran F-format where possible,
 * otherwise in E-format, with trailing zeroes suppressed.
 * Return code is number of values written out, otherwise a negative 
 * error code.
 */

#include "utio.h"
extern char	*gcvt();

int utwrdbl(buf, n, stream, ndigit, perline)
double	*buf;
int	n;
int	ndigit;
int	perline;
register FILE	*stream;
{
register char	*s;		/* indexes string */
register int	c;
register int	j;
	char	string[UTMAXNBRLEN];	/* work buffer */
	int	spacechar;	/* character separating numbers */
static char	*name = "utwrdbl";

	if(buf == NULL || n < 0 || stream == NULL || perline < 0)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	}
	if(ndigit < 3 || ndigit > UTMAXSIGDIGIT)
		ndigit = UTUSUALSIG;
	if(perline == 0)
		perline = 1;
	for(j = 0; j < n && !ferror(stream); j++)  {
		s = gcvt(*buf++, ndigit, string);
		for(c = *s; c != '\0'; c = *++s)
			putc(c, stream);
		spacechar = ((j+1) % perline == 0 || 
			j == n-1 ? '\n' : ' ');
		putc(spacechar, stream);
	}
	return(ferror(stream) ? UTWRSERR : j);
}
