 /* ut2float.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"

/* ------------------------------------------------------------------- */
/*  UT2FLOAT - convert the data in SRC to floats and store in DEST.
 *  N values are converted.  Function returns N on success, a negative
 *  error code otherwise.
 */
int ut2float(dest, src, n, srctype)
caddr_t	dest, src;
int	n;
UTTYPE	srctype;
{
static char	*name = "ut2float";
float	*fp = (float *) dest;
	int	ret = n;
int	j;
static void	(*prev)(); 	/* previous signal handler */

	if(dest == NULL || src == NULL || n < 0)  {
		ret = UTDOMAIN;
		utseterr(UTDOMAIN);
	} else if(srctype == SHORTS) {	   /* short->float */
		short	*sp = (short *) src;
		for(j = 0; j < n; j++)
			fp[j] = sp[j];
	} else if(srctype == INTS) {	   /* int->float */
		int	*ip = (int *) src;
		for(j = 0; j < n; j++)
			fp[j] = ip[j];
	} else if(srctype == DOUBLES)  {
		if(ut_usesignal)
			prev = signal(SIGFPE, utsighandle);
		if(setjmp(ut_env))  {			/* entry on overflow */
			ret = UTFPE;
			utseterr(UTFPE);
		} else {
			double	*dp = (double *) src;
			for(j = 0; j < n; j++)
				fp[j] = dp[j];
		}
		if(ut_usesignal)
			(void) signal(SIGFPE, prev);
	} else if(srctype == FLOATS)  {		/* just copy */
		float	*source = (float *) src;
		if(fp != source)
			for(j = 0; j < n; j++)
				fp[j] = source[j];
	} else {
		ret = UTDOMAIN;
		utseterr(UTDOMAIN);
	}
	return(ret);
}
