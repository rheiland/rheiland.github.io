 /* utfread.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* UTFREAD - Read a binary C record and convert the data values as required.
 * Return value is the number of elements read or a negative error code
 * otherwise.
 */
#include "utio.h"

int utfread(p, ptype, maxelt, fp)
register caddr_t	p;
UTTYPE	ptype;
int	maxelt;		/* max number of elements to read */
register UTFILE	*fp;
{
static char	*name = "utfread";
	caddr_t	buf;
	int	ret;

	if(maxelt < 0 || p == NULL || fp == NULL)  {
		utseterr(UTDOMAIN);
		return(UTDOMAIN);
	} else if(isatty(fileno(fp->stream)))  {
		utseterr(UTNONASCII);
		return(UTNONASCII);
	}
	if(ptype == fp->type)
		buf = p;
	else if((buf = (caddr_t) malloc((unsigned) (maxelt * fp->typesize))) == NULL)  {
		utseterr(UTNOMEM);
		return(UTNOMEM);
	}
	ret = fread((char *) buf, fp->typesize, maxelt, fp->stream);
	if(ret > 0)  {
		if(buf != p) 
			ret = utconvert(p, buf, ret, fp->type, ptype);
	} else if(feof(fp->stream))  {
		ret = UTEOF;
		utseterr(UTEOF);
	} else if(ferror(fp->stream))  {
		ret = UTRDSERR;
		utseterr(UTRDSERR);
	}
	if(buf != p)
		free(buf);
	return(ret);
}
