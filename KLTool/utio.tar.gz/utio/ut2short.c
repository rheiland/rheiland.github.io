 /* ut2short.c
 * Programmer:  Eric Kostelich, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *    Email:  eric@saddle.la.asu.edu
 *     Telephone:  602-965-5006
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
#include "utio.h"
#include <values.h>

/* ------------------------------------------------------------------- */
/*  UT2SHORT - convert data in the array pointed to by SRC
 *  to short integers, which are placed in the array pointed to by
 *  DEST.   N values are to be copied.
 *  Storage for D and S is provided by the caller.
 *  Return value is N if no error occurred and a negative error code else.
 */
int ut2short(dest, src, n, srctype)
caddr_t	dest, src;
int	n;
UTTYPE	srctype;
{
static char	*name = "ut2short";
	int	j;
	int	ret = 0;	/* return code */
static	void	(*prev)();	/* previous signal handler */
short	*sp = (short *) dest;

	if(src == NULL || dest == NULL || n < 0)  {
		ret = UTDOMAIN;
		utseterr(UTDOMAIN);
	} else {
		if(ut_usesignal)
			prev = signal(SIGFPE, utsighandle);
		if(setjmp(ut_env))  {			/* entry on overflow */
			ret = UTFPE;
			utseterr(UTFPE);
		} else if(srctype == DOUBLES) {	        /* doubles->shorts */
			double	*dp = (double *) src;
			double	val;
			for(j = 0; j < n && (val = *dp++) <= MAXSHORT &&
			   val > -MAXSHORT; j++)
				*sp++ = val;
		} else if(srctype == FLOATS)  {		/* floats->shorts */
			float	*fp = (float *) src;
			float	val;
			for(j = 0; j < n && (val = *fp++) <= MAXSHORT &&
			   val > -MAXSHORT; j++)
				*sp++ = val;
		} else if(srctype == INTS)  {		/* ints->shorts */
			int	*ip = (int *) src;
			int	val;
			for(j = 0; j < n && (val = *ip++) <= MAXSHORT &&
			   val > -MAXSHORT; j++)
				*sp++ = val;
		} else if(srctype == SHORTS)  {		/* copy as needed */
			short 	*source = (short *) src;
			if(sp != (short *) src)
			for(j = 0; j < n; j++)
				if(sp != (short *) src)
					sp[j] = source[j];
		} else  {
			ret = UTDOMAIN;
			utseterr(UTDOMAIN);
		}
		if(ut_usesignal)
			(void) signal(SIGFPE, prev);
	}
	if(ret == 0)
		ret = (j == n ? n : UTFPE);
	return(ret);
}
