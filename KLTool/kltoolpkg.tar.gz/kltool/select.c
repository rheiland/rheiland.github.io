/* select.c -  Select a region of data to process
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/get.h>
#include <device.h>
#include "kl_str.h"
#include "view_angle.h"
#include "disp_types.h"
#include "data_types.h"

static unsigned short curs[4] = {255,255,255,255};
short cursor_index = 1;

slider select_slider;

int map_xf(), map_tf(), map_xt(), map_xy(), map_yf();
int (*window_to_object[])() = {map_xf, map_tf, map_xt, map_xy, map_yf};

int init_select_xf(), init_select_tf(), init_select_xt(), init_select_xy(), 
	init_select_yf();
int (*init_select_params[])() = {init_select_xf, init_select_tf, 
			init_select_xt, init_select_xy, init_select_yf};

int update_select_xf(), update_select_tf(), update_select_xt(), 
		update_select_xy(), update_select_yf();
int (*update_select_params[])() = {update_select_xf, update_select_tf, 
			update_select_xt, update_select_xy, update_select_yf};
				 

int bounds_xf(), bounds_tf(), bounds_xt(), bounds_xy(), bounds_yf();
int (*select_op[])() = {bounds_xf, bounds_tf, bounds_xt, 
				bounds_xy, bounds_yf};

extern int	x_start,x_stop, y_start,y_stop, t_start,t_stop;
extern float	f_start,f_stop;
int	x_start_tmp,x_stop_tmp, y_start_tmp,y_stop_tmp, t_start_tmp,t_stop_tmp;
float	f_start_tmp,f_stop_tmp;

static char *select_msg1 = "Select region with sliders:";
static char msg_buf[80];


/*--------------------------------------------------------------------*/
define_select_cursor()
{
	int k;


	curstype(CCROSS);
	defcursor(cursor_index,curs);

	k = getgdesc(GD_CROSSHAIR_CINDEX);
	printf("\n------  crosshair index = %d\n\n", k);
/*	k = getgdesc(GD_XPMAX);
	printf("xpmax = %d\n", k); */
}
/*--------------------------------------------------------------------*/
select_handler()
{
    int loop,dev,k;
    int save_params_flag;
    char *msg1,*msg2;
    short val;
    float fx,fy;
static    short	sx,sy;
static    short	sx_old= 0;
static    short	sy_old= 0;
    int		proj_indx;
    int		x1,y1,x2,y2;
    int		mx1,my1,mx2,my2;
    FILE	*fp_data;
extern int dimension;
extern int cur_win;
extern win_struct data_win,select_win;
extern int	geom_win_color;
extern int 	ortho_view;
extern char *select_butn[];
extern char datafile[];
extern int data_type_flag;



	      /* Verify 1 of 3 orthogonal views displayed */

	   /* (future) Rather than use the "ortho_view" flag, rf. 'draw.c',
	      it would be nicer to simply extract the rotation matrix
	      at this time and see if it's orthogonal */
	if (data_type_flag != RECT) {
	   error_msg("Must be Rectangular data type."); 
	   return(-1);
	}
	if (!ortho_view) {
	   error_msg("Must be in 1 of 3 orthogonal views."); 
	   return(-1);
	}

	   /* Determine which projection is on the screen: */
	proj_indx = get_projection();
/*	printf("select_handler: proj_indx = %d\n", proj_indx); */

	(*init_select_params[proj_indx])();

	select_butn[0] = "Cancel";
	select_butn[1] = "Ok";
	(*select_op[proj_indx])();

	winset(data_win.id);

	init_select_sliders();
	draw_select_sliders();

        setcursor(cursor_index,1,1);
	if (geom_win_color == BLACK)
           setcursor_color(255,255,255);
	else
           setcursor_color(255,0,0);

    loop = 1;

    while(loop) {

    while(qtest()) {

        dev = qread(&val);

        switch(dev) {
        case INPUTCHANGE:
                /* user attaches/detaches input focus */
            cur_win = (int)val;
/*	    printf("select_handler: cur_win = %d\n", cur_win); */
	    if (geom_win_color == BLACK)
               setcursor_color(255,255,255);
    	    else
               setcursor_color(255,0,0);
            break;
        case REDRAW:
            redraw_window(val);
	    draw_select_sliders();
            break;
/*        case RIGHTMOUSE:
	    printf("RIGHTMOUSE: val= %d,  cur_win= %d\n", val,cur_win);
            if (val && (cur_win == data_win.id))
	       process_rightbutn(cur_win);
            break; */
/*	   Problems trying to allow for RIGHTMOUSE, get following:
	process_rightbutn:  data_win/dim=1...
	dopup: this can not be called from a menu function
	dopup(data_1d_menu) = -1
*/

        case LEFTMOUSE:
	    dev = qread(&sx);   /* Get X,Y entries on the queue regardless */
	    dev = qread(&sy);   /* (since MOUSEX/Y 'tie'd to LEFT button)  */
/*	    printf("select_handler/LEFTMOUSE: sx,sy = %d %d\n", sx,sy); */

            if (val) {		/* button down? */


		   /* What does the user want to do? */
		if (cur_win == select_win.id) {
		   screen_to_window(select_win.id,sx,sy,&fx,&fy);
		   printf("pushed button: fx,fy = %f %f\n", fx,fy);

		   if (fx > (0.7 - 0.15)) {
			(*update_select_params[proj_indx])();
			save_params_flag = 1;
		   }
		   else
			save_params_flag = 0;

	   	   loop = 0;
		}

		else if (cur_win == data_win.id) {

		  /* Has a slider been picked? */
		  /* If so, move it while user holds down mouse button */

		  if ( (k = pick_slider(sx,sy)) >= 0) {
		    if (k < 2) {		/* horiz slider */
		      while (getbutton(LEFTMOUSE)) {
			sx = getvaluator(MOUSEX);
			if (abs(sx-sx_old) > 1) {
			  if ((select_slider.ctr[1][0] -
			       select_slider.ctr[0][0]) > 0) {
			    screen_to_window(data_win.id,sx,sy,
					&select_slider.ctr[k][0],&fy);
			    if (select_slider.ctr[k][0] < -0.95)
			      select_slider.ctr[k][0] = -0.95;
			    draw_select_sliders();
			    (*window_to_object[proj_indx])(k);
			    (*select_op[proj_indx])();
			  }
			  sx_old = sx;
			}
		      }
		    }
		    else {		/* vertical slider */
		      while (getbutton(LEFTMOUSE)) {
			sy = getvaluator(MOUSEY);
			if (abs(sy-sy_old) > 1) {
			  screen_to_window(data_win.id,sx,sy,
					&fy,&select_slider.ctr[k][1]);
			  if (select_slider.ctr[k][1] < -0.95)
			      select_slider.ctr[k][1] = -0.95;
			  draw_select_sliders();
			  (*window_to_object[proj_indx])(k);
			  (*select_op[proj_indx])();
			  sy_old = sy;
			}
		     }
		   }
		 }
		}	/* end if (cur_win == data_win.id)  */
	    }
            break;
	    }	/* end switch */
	}	/* end while(qtest  */
	}	/* end while(loop   */


	winset(data_win.id);
	setcursor(0,1,1);
	clear_select_sliders();
	
/*	if (save_params_flag) {
	  msg1 = "Re-read data?";
	  select_butn[0] = "No";
	  select_butn[1] = "Yes";
	  if (user_select_reply(msg1,NULL,2) == 2) {
	     if((fp_data=fopen(datafile, "r")) == NULL)  {
		printf("ERROR--- can't open datafile %s\n",datafile);
		update_input_msg("ERROR--- can't open datafile");
	     }
	     read_datafile(fp_data);
	  }
	} */

	push_select();

	winset(data_win.id);

        setcursor_color(255,0,0);


	gconfig();	/* do this to return to double-buffer mode */

/*	redraw_data(); */

	if (save_params_flag)
	  input_handler();
}
/*--------------------------------------------------------------------*/
setcursor_color(r,g,b)
int r,g,b;
{
	drawmode(CURSORDRAW);
	mapcolor(1,r,g,b);
	drawmode(NORMALDRAW);
}
/*--------------------------------------------------------------------*/
get_projection()
{
	int proj_indx;
extern int	dimension;
extern int 	ortho_view;


	switch (dimension) {
	case 1:
	switch (ortho_view) {
	case FRONT:
		proj_indx = 0;
		break;
	case TOP:
		proj_indx = 2;
		break;
	case SIDE:
		proj_indx = 1;
		break;
	}
	break;

	case 2:
	switch (ortho_view) {
	case FRONT:
		proj_indx = 0;
		break;
	case TOP:
		proj_indx = 3;
		break;
	case SIDE:
		proj_indx = 4;
		break;
	}
	   /* Overrule if looking at Scalar function in time */
/*	proj_indx = 6; */

	break;
	}

	return(proj_indx);
}


/*--------------------------------------------------------------------*/
pick_slider(sx,sy)
short sx,sy;
{
	float fx,fy,rad;
	int k;
extern win_struct data_win;

	screen_to_window(data_win.id,sx,sy,&fx,&fy);

	rad = select_slider.rad;

	   /* horiz slider? */
	if ((fy < (select_slider.ctr[0][1] + rad)) &&
	    (fx > -0.95)) {
	   k=0;
	   if ( (fx > (select_slider.ctr[k][0] - rad)) &&
	       (fx < (select_slider.ctr[k][0] + rad)) )
	       return(k);
	   k=1;
	   if ((fx > (select_slider.ctr[k][0] - rad)) &&
	       (fx < (select_slider.ctr[k][0] + rad)) )
	       return(k);
	}
	   /* vert slider? */
	else if (fx < (select_slider.ctr[2][0] + rad)) {
	   k=2;
	   if ((fy > (select_slider.ctr[k][1] - rad)) &&
	       (fy < (select_slider.ctr[k][1] + rad)) )
	       return(k);
	   k=3;
	   if ((fy > (select_slider.ctr[k][1] - rad)) &&
	       (fy < (select_slider.ctr[k][1] + rad)) )
	       return(k);
	}
	return(-1);
}
/*--------------------------------------------------------------------*/
screen_to_window(wid,sx,sy,fx,fy)
int wid;
short sx,sy;
float *fx,*fy;
{
    long sx0,sy0,wwidth,wheight;

	winset(wid);
	getorigin(&sx0,&sy0);
/*	printf("(win origin)sx0,sy0 =  %d %d\n", sx0,sy0); */
	getsize(&wwidth,&wheight);
/*	printf("    wwidth,wheight =  %d %d\n", wwidth,wheight); */
	*fx = (sx-sx0)*2.0/wwidth - 1.0;
	*fy = (sy-sy0)*2.0/wheight - 1.0;
/*	printf("screen_to_window:  fx,fy = %f %f\n", *fx,*fy); */
}

/*--------------------------------------------------------------------*/
/*   (*window_to_object[proj_indx])(k); */
map_xf(k)
int k;
{
extern int res_x,res_y;
extern float ydiff;
	
	if (k==0) {	/* (left) horiz slider */
	   x_start_tmp = (select_slider.ctr[k][0] - (-0.9))*res_x/1.8;
	   x_start_tmp += x_start;
	}
	else if (k==1) {	/* (right) horiz slider */
	   x_stop_tmp =  (select_slider.ctr[k][0] - (-0.9))*res_x/1.8;
	   if (x_stop == 0)
	      x_stop = res_x;
	   if (x_stop_tmp > res_x)
	      x_stop_tmp = x_stop;
	   x_stop_tmp = x_stop - (res_x - x_stop_tmp);
	}
	else if (k==2) {	/* (bottom) vert slider */
	   f_start_tmp =  (select_slider.ctr[k][1] - (-0.9))*ydiff/1.8;
	}
	else if (k==3) {	/* (top) vert slider */
	   f_stop_tmp =  (select_slider.ctr[k][1] - (-0.9))*ydiff/1.8;
	}
}
map_tf(k)
int k;
{
extern int dimension,res_x,res_y;
extern int num_vecs;
extern float ydiff;
	
	if (k==0) {	/* (left) horiz slider */
	   t_start_tmp = (select_slider.ctr[k][0] - (-0.9))*(num_vecs-1)/1.8;
	   t_start_tmp += 2;
	}
	else if (k==1) {	/* (right) horiz slider */
	   t_stop_tmp = (select_slider.ctr[k][0] - (-0.9))*(num_vecs-1)/1.8;
	   t_stop_tmp++;
	}
	else if (k==2) {	/* (bottom) vert slider */
	   f_start_tmp = (select_slider.ctr[k][1] - (-0.9))*ydiff/1.8;
	}
	else if (k==3) {	/* (top) vert slider */
	   f_stop_tmp = (select_slider.ctr[k][1] - (-0.9))*ydiff/1.8;
	}
}
map_xt(k)
int k;
{
extern int dimension,res_x,res_y;
extern int num_vecs;
	
	if (k==0) {	/* (left) horiz slider */
	   x_start_tmp = (select_slider.ctr[k][0] - (-0.9))*res_x/1.8;
	   x_start_tmp += x_start;
	}
	else if (k==1) {	/* (right) horiz slider */
	   x_stop_tmp =  (select_slider.ctr[k][0] - (-0.9))*res_x/1.8;
	   if (x_stop == 0)
	      x_stop = res_x;
	   if (x_stop_tmp > res_x)
	      x_stop_tmp = x_stop;
	   x_stop_tmp = x_stop - (res_x - x_stop_tmp);
	}
	else if (k==2) {	/* (bottom) vert slider */
	   t_start_tmp =  (select_slider.ctr[k][1] - (-0.9))*num_vecs/1.8;
	   t_start_tmp += 2;
	}
	else if (k==3) {	/* (top) vert slider */
	   t_stop_tmp =  (select_slider.ctr[k][1] - (-0.9))*num_vecs/1.8;
	}
}
map_xy(k)
int k;
{
extern int dimension,res_x,res_y;
	
	if (k==0) {	/* (left) horiz slider */
	   x_start_tmp =  (select_slider.ctr[k][0] - (-0.9))*res_x/1.8;
	}
	else if (k==1) {	/* (right) horiz slider */
	   x_stop_tmp =  (select_slider.ctr[k][0] - (-0.9))*res_x/1.8;
	}
	else if (k==2) {	/* (bottom) vert slider */
	   y_start_tmp =  (select_slider.ctr[k][1] - (-0.9))*res_y/1.8;
	}
	else if (k==3) {	/* (top) vert slider */
	   y_stop_tmp =  (select_slider.ctr[k][1] - (-0.9))*res_y/1.8;
	}
}
map_yf(k)
int k;
{
extern int dimension,res_x,res_y;
extern float ydiff;
	
	if (k==0) {	/* (left) horiz slider */
	   y_start_tmp =  (select_slider.ctr[k][0] - (-0.9))*res_y/1.8;
	}
	else if (k==1) {	/* (right) horiz slider */
	   y_stop_tmp =  (select_slider.ctr[k][0] - (-0.9))*res_y/1.8;
	}
	else if (k==2) {	/* (bottom) vert slider */
	   f_start_tmp =  (select_slider.ctr[k][1] - (-0.9))*ydiff/1.8;
	}
	else if (k==3) {	/* (top) vert slider */
	   f_stop_tmp =  (select_slider.ctr[k][1] - (-0.9))*ydiff/1.8;
	}
}
/*--------------------------------------------------------------------*/
bounds_xf()
{
/*	sprintf(msg_buf,"x=[%d,%d], f=[%f,%f]\n", x_start_tmp,x_stop_tmp,
						  f_start_tmp,f_stop_tmp); */
	sprintf(msg_buf,"x=[%d,%d]", x_start_tmp,x_stop_tmp);
	select_feedback(select_msg1,msg_buf,2); 
}
bounds_tf()
{
/*	sprintf(msg_buf,"t=[%d,%d], f=[%f,%f]\n", t_start_tmp,t_stop_tmp,
						  f_start_tmp,f_stop_tmp); */
	sprintf(msg_buf,"t=[%d,%d]", t_start_tmp,t_stop_tmp);
	select_feedback(select_msg1,msg_buf,2); 
}
bounds_xt()
{
	sprintf(msg_buf,"x=[%d,%d], t=[%d,%d]", x_start_tmp,x_stop_tmp,
						  t_start_tmp,t_stop_tmp);
	select_feedback(select_msg1,msg_buf,2); 
}
bounds_xy()
{
	sprintf(msg_buf,"x=[%d,%d], y=[%d,%d]", x_start_tmp,x_stop_tmp,
						  y_start_tmp,y_stop_tmp);
	select_feedback(select_msg1,msg_buf,2); 
}
bounds_yf()
{
/*	sprintf(msg_buf,"y=[%d,%d], f=[%f,%f]\n", y_start_tmp,y_stop_tmp,
						  f_start_tmp,f_stop_tmp); */
	sprintf(msg_buf,"y=[%d,%d]", y_start_tmp,y_stop_tmp);
	select_feedback(select_msg1,msg_buf,2); 
}
/*--------------------------------------------------------------------*/
init_select_xf()
{
extern int res_x;
extern float ydiff;
	x_start_tmp = x_start;
	if (x_stop == 0) x_stop = res_x;
	x_stop_tmp  = x_stop;

	f_start =  (select_slider.ctr[2][1] - (-0.9))*ydiff/1.8;
	f_stop =  (select_slider.ctr[3][1] - (-0.9))*ydiff/1.8;
	f_start_tmp = f_start;
	f_stop_tmp  = f_stop;
}
init_select_tf()
{
extern int num_vecs;
extern float ydiff;
extern int res_x;
	t_start_tmp = t_start;
	if (x_stop == 0) x_stop = res_x;
	t_stop_tmp  = t_stop;

	f_start =  (select_slider.ctr[2][1] - (-0.9))*ydiff/1.8;
	f_stop =  (select_slider.ctr[3][1] - (-0.9))*ydiff/1.8;
	f_start_tmp = f_start;
	f_stop_tmp  = f_stop;
}
init_select_xt()
{
extern int res_x,num_vecs;
	x_start_tmp = x_start;
	if (x_stop == 0) x_stop = res_x;
	x_stop_tmp  = x_stop;

	t_start_tmp = t_start;
	t_stop_tmp  = t_stop;
	if (t_stop_tmp == 0) t_stop_tmp = num_vecs;
}
init_select_xy()
{
extern int res_x,res_y;
	x_start_tmp = x_start;
	if (x_stop == 0) x_stop = res_x;
	x_stop_tmp  = x_stop;

	y_start_tmp = y_start;
	y_stop_tmp  = y_stop;
	if (y_stop_tmp == 0) y_stop_tmp = res_y;
}
init_select_yf()
{
extern int res_y;
extern float ydiff;
	y_start_tmp = y_start;
	y_stop_tmp  = y_stop;
	if (y_stop_tmp == 0) y_stop_tmp = res_y;

	f_start =  (select_slider.ctr[2][1] - (-0.9))*ydiff/1.8;
	f_stop =  (select_slider.ctr[3][1] - (-0.9))*ydiff/1.8;
	f_start_tmp = f_start;
	f_stop_tmp  = f_stop;
}
/*--------------------------------------------------------------------*/
update_select_xf()
{
	x_start = x_start_tmp;
	x_stop  = x_stop_tmp;
	f_start = f_start_tmp;
	f_stop  = f_stop_tmp;
}
update_select_tf()
{
	t_start = t_start_tmp;
	t_stop  = t_stop_tmp;
	f_start = f_start_tmp;
	f_stop  = f_stop_tmp;
}
update_select_xt()
{
	x_start = x_start_tmp;
	x_stop  = x_stop_tmp;
	t_start = t_start_tmp;
	t_stop  = t_stop_tmp;
}
update_select_xy()
{
	x_start = x_start_tmp;
	x_stop  = x_stop_tmp;
	y_start = y_start_tmp;
	y_stop  = y_stop_tmp;
}
update_select_yf()
{
	y_start = y_start_tmp;
	y_stop  = y_stop_tmp;
	f_start = f_start_tmp;
	f_stop  = f_stop_tmp;
}
/*--------------------------------------------------------------------*/
swap_ints(i1,i2)
int *i1,*i2;
{
	int k;

	k = *i1;
	*i1 = *i2;
	*i2 = k;
}
/*--------------------------------------------------------------------*/
swap_floats(f1,f2)
float *f1,*f2;
{
	float f;

	f = *f1;
	*f1 = *f2;
	*f2 = f;
}
/*--------------------------------------------------------------------*/
draw_select_sliders()
{
	int rgb_mode;
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern int     select_slider_obj;
static short bluevec[3] = {0,0,255};
static short yellowvec[3] = {255,255,0};
extern win_struct data_win;

	winset(data_win.id);
	frontbuffer(1);

	pushmatrix();

 	/*				              near,far */
	ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);

	rgb_mode = 0;
	if (getdisplaymode() == DMRGBDOUBLE)
	   rgb_mode = 1;


	if (rgb_mode)
	   c3s(yellowvec);
	else
	   color(YELLOW);
	rectf(-1.,-1.,1.,-0.95);
	rectf(-1.,-1.,-0.95,1.);


	if (rgb_mode)
	   c3s(bluevec);
	else
	   color(RED);
	pushmatrix();
	translate(select_slider.ctr[0][0],select_slider.ctr[0][1],0.0);
	callobj(select_slider_obj);
	popmatrix();
	pushmatrix();
	translate(select_slider.ctr[1][0],select_slider.ctr[1][1],0.0);
	callobj(select_slider_obj);
	popmatrix();
	pushmatrix();
	translate(select_slider.ctr[2][0],select_slider.ctr[2][1],0.0);
        rotate(-900,'z');
        scale(1.3,1,1);
	callobj(select_slider_obj);
	popmatrix();
	pushmatrix();
	translate(select_slider.ctr[3][0],select_slider.ctr[3][1],0.0);
        rotate(-900,'z');
        scale(1.3,1,1);
	callobj(select_slider_obj);
	popmatrix();

    popmatrix();
}
/*--------------------------------------------------------------------*/
clear_select_sliders()
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;

	winset(data_win.id);
	frontbuffer(1);

	pushmatrix();

	ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);

	color(BLACK);
	rectf(-1.,-1.,1.,-0.95);
	rectf(-1.,-1.,-0.95,1.);
	popmatrix();
}
