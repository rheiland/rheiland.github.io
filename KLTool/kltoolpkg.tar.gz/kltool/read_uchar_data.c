/* read_uchar_data.c - Read in unsigned char data (e.g, Gorman's flame data)
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include "kl_str.h"

#define FILTVAL  200

/*int uchar_filter = 0;
int uchar_rad2 = 50000; */

/* for /flames/bchar data */
int uchar_filter = 200;
int uchar_rad2 = 14500;


/*--------------------------------------------------------------------*/
read_uchar_data(fp)
FILE *fp;
{
    int i,j,k,m,vec_size;
    float fval;
    char bval;
    double t0,tval,tdel;
    unsigned char *dp, *alloc_vector_uchar();
    vec_struct_uchar *vsp, *vsp2;
    char fname[80],msg[80];
    FILE *ifp;
extern int num_vecs;
extern int dimension,file_res_x,file_res_y;
extern int x_start,x_stop,y_start,y_stop;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern vec_struct_uchar *vec_root_uchar;



    printf("-----------------------  begin read_uchar_data  --------------------\n");


    empty_all_lists();

    vec_root_uchar = NEW(vec_struct_uchar,sizeof(vec_struct_uchar));
    vec_root_uchar->prev = NULL;
    vec_root_uchar->next = NULL;
    vsp = vec_root_uchar;


    num_vecs = 0;
    k = 0;
    t0 = tval = 0.0;
    tdel = 1.0;

    vec_size = file_res_x * file_res_y;
    printf("read_uchar_data:  vec_size = %d\n",vec_size);


    while (fscanf(fp,"%s",fname) != EOF) {
	printf("%s\n", fname);

        if ((ifp = fopen(fname,"r")) == NULL) {
	   printf("%s cannot open...(skipping)\n", fname);
	}
	else {

		dp = alloc_vector_uchar();
		vsp->dp = dp;

		if(fread(dp, sizeof(unsigned char), vec_size, ifp) != vec_size){
		    printf("read_uchar_data:  ERROR reading vector\n");
		    return(-1);
		}
		avg_scanlines(dp);
/*		edge_extract(dp); */

		vsp2 = NEW(vec_struct_uchar,sizeof(vec_struct_uchar));
		vsp2->next = NULL;
		vsp2->prev = vsp;
		vsp->next = vsp2;
		vsp = vsp2;

		num_vecs++;
		sprintf(msg,"%d vectors...",num_vecs);
		update_input_msg(msg);

		fclose(ifp);
	}
    }
    vsp->prev->next = NULL;

    zmin = 0.0;
    if (y_stop > 0) 
	   zmax = -y_stop + y_start;
    else
	   zmax = -file_res_y + y_start;

fini:
   printf("-----------------------  end read_uchar_data  --------------------\n");
}
/*--------------------------------------------------------------------*/
avg_scanlines(dp)
unsigned char *dp;
{
	int i,j,lx,xd,yd;
	unsigned char *p1,*p2,*p3;
extern int file_res_x,file_res_y;

	lx = file_res_x;

	   /* avg even scanlines */
/*	for (i=0; i<file_res_y; i+=2) { */
	   /* avg odd scanlines */
	for (i=1; i<file_res_y; i+=2) {
	   p1 = dp+(i+1)*lx;
	   p2 = dp+i*lx;
	   p3 = dp+(i+2)*lx;
	   for (j=0; j<file_res_x; j++) {
	      *(p1 + j) = (*(p2 + j) + *(p3 + j)) / 2;
	   }
	}

/*	minmax_uchar(dp); */

	   /* filter */
	for (i=0; i<file_res_y; i++) {
	   for (j=0; j<file_res_x; j++) {
	      p1 = dp+ i*file_res_x + j;
	      xd = abs(j-145);
	      yd = abs(i-133);
	      if ((xd*xd + yd*yd) > uchar_rad2)
		 *p1 = 0;
	      else if (*p1 < uchar_filter )
		 *p1 = 0;
	   }
	}
}
/*--------------------------------------------------------------------*/
edge_extract(dp)
unsigned char dp[265][290];
{
	int i,j,ix,iy;
	float r,theta,theta_del;
	FILE *fp;
extern int file_res_x,file_res_y;


	fp = fopen("polar.dat","w");

	theta_del = 2.0*M_PI/100;
	printf("	theta_del = %f\n", theta_del);

	for (theta=0.0; theta<2*M_PI; theta+=theta_del) {
	   r=0.0;
	   ix = 145 + (int)r*cos(theta);
	   iy = 133 + (int)r*sin(theta);
	   while (dp[iy][ix] > 10) {
	      r += 1.0;
	      ix = 145 + (int)r*cos(theta);
	      iy = 133 + (int)r*sin(theta);
	   }
	   printf("%f %f\n", theta,r);
	}
}
/*--------------------------------------------------------------------*/
minmax_uchar(dp)
unsigned char *dp;
{
	int i,j;
	unsigned char *p1;
	unsigned char minval,maxval;
extern int file_res_x,file_res_y;

	minval = 255;
	maxval = 0;
	for (i=0; i<file_res_y; i++) {
	   for (j=0; j<file_res_x; j++) {
	      p1 = dp+ i*file_res_x + j;
	      if (*p1 < minval ) minval = *p1;
	      if (*p1 > maxval ) maxval = *p1;
	   }
	}
	printf("(uchar)  minval, maxval = %d %d\n", minval,maxval);
}
