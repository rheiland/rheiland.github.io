/*-------------------------------------------------------------------
 *  kltool.c - KL tool (BEWARE all ye who modify this code)
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include "rgb_colors.h"
#include "data_types.h"

int	verbose = 0;

#define NKEYS 17
static char *keywords[NKEYS] = {"dir","file","format","ndim","dim1","dim2",
			        "x1","x2","y1","y2","t1","t2",
			        "rect","polar","complex","vec2d","contours"};

char	*cmplx_vec_spec[4] = {"real","imag","amplitude","phase"};

klt_(nargs,startup_file)
int *nargs;
char *startup_file;
{
extern int cmplx_flag;
extern char input_dir[];

double *cp[2];
int neq,kmax;
FILE *fplog,*fpin;
extern FILE *fpode, *fpode2;
/*
*/


        set_defaults();

	printf("klt: nargs = %d\n", *nargs);
	if (*nargs > 0) {
	   if (parse_startup_file(startup_file) < 0)
	      exit(-1);
	}
	get_device_info();
	init_graphics();
	init_session();
 	window_pos_handler(4);
/*	init_font(); */
	define_select_cursor();
	if (cmplx_flag)
	   hilite_cmplx_menu();

        fl_init(); 	/* Forms lib */
        fl_set_graphics_mode(0,0);

/*
neq=0;
kmax=1;
fplog=fopen("log.out","w");
fpin=fopen("ks.pde","r");
fpode = fopen("ode.sys","w");
fpode2 = fopen("ode2.sys","w");

parse_pde(cp,neq,&kmax,fplog,fpin);
*/


	interaction();
}
/*--------------------------------------------------*/
set_defaults()
{
extern char input_file[],input_dir[];
extern char input_format;
extern int file_res_x,file_res_y, dimension,res_x,res_y,res_xy;
extern int x_start,x_stop;
extern int cmplx_flag, vec_flag, ncontours;
extern int data_type_flag;
extern float polar_rmin,polar_rmax,polar_range, vec_scale;
extern char plot_scripts_dir[];


   strcpy(input_dir,"\0");
   strcpy(input_file,"\0");
   strcpy(plot_scripts_dir,"\0");


   if (getenv("KLPLOT") != NULL)
     strcpy(plot_scripts_dir,getenv("KLPLOT"));
   else 
     getwd(plot_scripts_dir);

   if (!getwd(input_dir) ) {
      printf("ERROR ---- Can't get working directory pathname");
   }

   dimension = 1;
   file_res_x = res_x = 0;
   file_res_y = res_y = 1;
   res_xy = res_x*res_y;
   x_start = 1;
   x_stop = 0;
/*   y_start = 1;
   y_stop = 0; */

   cmplx_flag = 0;
   vec_flag = 0;
   vec_scale = 0.1;
   polar_rmin = 0.0;
   polar_rmax = 1.0;
   polar_range = polar_rmax - polar_rmin;
   ncontours = 0;
   data_type_flag = RECT;
}
/*--------------------------------------------------*/
error_check_data_type(type)
int type;
{
  if (type < 0) {
    return 0;
  }
  else {
    printf("\n\n--------------------------\n");
    printf("  ERROR - conflicting data types specified:\n");
    printf("      rect/polar/complex/vec2d/contours  \n");
    printf("\n--------------------------\n\n");
    exit(-1);
  }
}
/*--------------------------------------------------*/
/* e.g.,
dir  .			# input data dir
file  foo.200		# input data filename
format integer		# data type (byte,integer,float,double)
ndim 2			# number of dims (1 or 2)
dim1 64			# dimension of axis 1 (x resolution)
dim2 64			# dimension of axis 2 (y resolution)
x1 1			# ranges
x2 64			#
y1 1			#
y2 64			#
t1 1			#
t2 100			#
rect			#
polar 0.0 1.0		# polar [rmin rmax]
complex amplitude	# real,imag,amplitude,phase
vec2d 0.1		#
contours 17		#

*/
parse_startup_file(startup_file)
char *startup_file;
{
	int i,key;
	FILE *fp;
	char *c, buf[120],keyword[80],value[80],value2[80];
extern char input_dir[],input_file[];
extern char input_format;
extern int file_res_x,file_res_y, dimension,res_x,res_y,res_xy;
extern int x_start,x_stop,y_start,y_stop,t_start,t_stop;
extern int data_type_flag;
extern int cmplx_flag, vec_flag, ncontours;
extern float polar_rmin,polar_rmax,polar_range;
extern float vec_scale;
extern int 	polar_flag;

   data_type_flag = -1;		/* invalidate flag */

	printf("startup_file:  = %s\n", startup_file);
	printf("    strlen(startup_file) = %d\n", strlen(startup_file));

	c = startup_file;
	for (i=0; i<1024; i++) {
/*	   printf("  %c\n", *c); */
	   c++;
	   if (*c == ' ') {
	      *c = '\0';
	      break;
	   }
	}
	if ((fp = fopen(startup_file,"r")) == NULL) {
	   printf("ERROR - cannot open startup_file\n");
	   return(-1);
	}

	cmplx_flag = 0;
	vec_flag = 0;

	while (get_line(fp,buf, 120) != 0) {
	   sscanf(buf,"%s %s %s", keyword,value,value2);
	   printf("keyword= %s\n", keyword);
	   printf("   value = %s,  value2 = %s\n",value,value2);

	   key = -1;
	   for(i=0; i<NKEYS; i++) {
	     if (!strcmp(keyword,keywords[i])) {
	       key = i;
	     }
	   }
	   if (key < 0) {
	     sprintf(buf,"Error: invalid keyword '%s'",keyword);
	     error_msg(buf);
	     printf("%s invalid\n", keyword);
	     printf("Following keywords are valid:\n");
	     for(i=0; i<NKEYS; i++) 
	       printf("      %s\n",keywords[i]);
	   }

	   switch(key) {

	   case 0:
	      printf("  input data dir= %s\n", value);
    	      if (!strcmp(value,".")) {
		getwd(input_dir);
	      }
	      else {
	        strcpy(input_dir,value);
	      }
	      break;
	   case 1:
	      printf("  input data file= %s\n", value);
	      strcpy(input_file,value);
	      break;
	   case 2:
	      input_format = value[0];
	      printf("  input data type= %c\n", input_format);
	      break;
	   case 3:
	      sscanf(value,"%d", &dimension);
	      printf("   dimension = %d\n", dimension);
	      break;
	   case 4:
	      sscanf(value,"%d", &file_res_x);
	      file_res_y = 1;
	      printf("   file_res_x = %d\n", file_res_x);
	      break;
	   case 5:
	      if (dimension == 1) {
		 printf("Error: dim2 specified for ndim 1\n");
		 return(-1);
	      }
	      sscanf(value,"%d", &file_res_y);
	      printf("   file_res_y = %d\n", file_res_y);
	      break;
	   case 6:
	      sscanf(value,"%d", &x_start);
	      printf("   x_start = %d\n", x_start);
	      break;
	   case 7:
	      sscanf(value,"%d", &x_stop);
	      printf("   x_stop = %d\n", x_stop);
	      break;
	   case 8:
	      sscanf(value,"%d", &y_start);
	      printf("   y_start = %d\n", y_start);
	      break;
	   case 9:
	      sscanf(value,"%d", &y_stop);
	      printf("   y_stop = %d\n", y_stop);
	      break;
	   case 10:
	      sscanf(value,"%d", &t_start);
	      printf("   t_start = %d\n", t_start);
	      break;
	   case 11:
	      sscanf(value,"%d", &t_stop);
	      printf("   t_stop = %d\n", t_stop);
	      break;
	   case 12:
	      error_check_data_type(data_type_flag);
	      data_type_flag = RECT;
	      break;
	   case 13:
	      error_check_data_type(data_type_flag);
	      data_type_flag = POLAR;
	      polar_flag = 1;
	      sscanf(value,"%f", &polar_rmin);
	      sscanf(value2,"%f", &polar_rmax);
	      printf("   rmin,max = %f %f\n", polar_rmin,polar_rmax);
	      polar_range = polar_rmax - polar_rmin;
	      break;
	   case 14:
	      error_check_data_type(data_type_flag);
	      for (i=0; i<4; i++) {
		 if (!strcmp(value,cmplx_vec_spec[i])) cmplx_flag = i+1;
	      }
	      if (!cmplx_flag) {
		 printf("\n\nERROR--- Invalid complex vector type specification\n");
		 printf("     setting to 'real'\n\n\n");
		 cmplx_flag = 1;
	      }
	      data_type_flag = COMPLEX;
	      printf("   complex flag = %d\n", cmplx_flag);
	      break;
	   case 15:
	      error_check_data_type(data_type_flag);
	      data_type_flag = VEC2D;
	      vec_flag = 1;
	      sscanf(value,"%f", &vec_scale);
	      printf("   vec_scale = %f\n", vec_scale);
	      break;
	   case 16:
	      error_check_data_type(data_type_flag);
	      data_type_flag = CONTOURS;
	      sscanf(value,"%d", &ncontours);
	      printf("   ncontours = %d\n", ncontours);
	      break;
	   }	/* end switch */

	   strcpy(value,"\0");
	   strcpy(value2,"\0");
	}


/*	res_x = x_stop = file_res_x; */
	res_x = file_res_x;
	res_y = file_res_y;
	res_xy = res_x * res_y;

	if (data_type_flag < 0) 
	  data_type_flag = RECT;

	return(1);
}

/*******************************************************************************/
get_line(fp,s,lim)
FILE *fp;
char 	s[];
int	lim;
{
    int	c, i;

    for (i=0; i<=lim-1 && (c=getc(fp))!=EOF && c!='\n'; ++i)
	s[i]=c;
    s[i]='\0';
    return(i);
}
