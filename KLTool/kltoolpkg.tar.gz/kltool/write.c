/* write_handler.c - Write files
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <gl.h>
#include "kl_str.h"

#define STRINGLEN 128


/*--------------------------------------------------------------------*/
write_handler(item)
int item;
{
	switch(item) {
	case 1:			/* data */
	   write_data();
	   break;
	case 2:			/* mean */
	   write_mean();
	   break;
	case 3:			/* eiginfo */
	   write_eiginfo();
	   break;
	case 4:			/* appx */
	   write_appx();
	   break;
	case 5:			/* current Fourier vec eigfn */
	   write_cur_fv();
	   break;
	case 6:
	   write_cur_2def();
	   break;
	case 7:
	   write_pix_img();
	   break;
	}
}
/*--------------------------------------------------------------------*/
write_data()
{
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
	FILE *fpout;
	int k;
	char buf[STRINGLEN];
	float *fp, *alloc_vector_float();
	double *dp, *drp,*dip;
extern vec_struct *vec_root;
extern cmplx_vec_struct *cmplx_vec_root;
extern int res_xy;
extern int cmplx_flag;


	if (vec_root == NULL) {
	    error_msg("No data exists.");
	   return(-1);
	}

	k = get_string("Enter data output filename: ",buf,STRINGLEN);
        if((fpout=fopen(buf, "w")) == NULL)  {
	    error_msg("Can't open file.");
	    return(-1);
        }

	res_xy = vec_resolution();

	fp = alloc_vector_float();

	pop_feedback();

	write_header(fpout);

	   /* Write out all data vectors */
	k=0;
	if (!cmplx_flag) {
	TRACE(vsp,vec_root) {
	   k++;
	   sprintf(buf,"writing out data vec %d\n", k);
	   feedback_msg(buf);

	   dp = vsp->dp;

	   copy_double_to_float(dp,fp,res_xy);

	   fwrite(fp,sizeof(float),res_xy,fpout);
	}
	}
	else {
	TRACE(cvsp,cmplx_vec_root) {
	   k++;
	   sprintf(buf,"writing out data vec %d\n", k);
	   feedback_msg(buf);

	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   copy_double_to_float(drp,fp,res_xy);
	   fwrite(fp,sizeof(float),res_xy,fpout);

	   copy_double_to_float(dip,fp,res_xy);
	   fwrite(fp,sizeof(float),res_xy,fpout);
	}
	}

	fclose(fpout);

	free(fp);
	push_feedback();
}
/*--------------------------------------------------------------------*/
write_mean()
{
	int i,j;
	FILE *fp;
	char buf[STRINGLEN];
extern double *mean_ptr, *mean_ptr_real,*mean_ptr_imag;
extern float *mean_ptr_float;
extern int res_xy;
extern char input_format;
extern int cmplx_flag;


	if (input_format == 'b') {
	   if (mean_ptr_float == NULL) {
	      error_msg("Must compute mean first.");
	      return(-1);
	   }
	}
	else {
	if (mean_ptr == NULL) {
	   error_msg("Must compute mean first.");
	   return(-1);
	}
	}

	i = get_string("Enter mean output filename: ",buf,STRINGLEN);
	printf("buf --> %s\n",buf);
	printf("strlen(buf) = %d\n",i);
        if((fp=fopen(buf, "w")) == NULL)  {
	    error_msg("Can't open file.");
	    return(-1);
        }

	res_xy = vec_resolution();

	write_header(fp);

/*	if (input_format == 'b')
	   fwrite(mean_ptr_float,sizeof(float),res_xy,fp);
	else */

	if (!cmplx_flag)
	   fwrite(mean_ptr,sizeof(double),res_xy,fp);
	else {
	   fwrite(mean_ptr_real,sizeof(double),res_xy,fp);
	   fwrite(mean_ptr_imag,sizeof(double),res_xy,fp);
	}

	fclose(fp);
}
/*--------------------------------------------------------------------*/
write_eiginfo()
{
	FILE *fp;
	int i,k;
	char buf[STRINGLEN];
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int num_eig, num_vecs;
extern double sum_eigvals;
extern double *wrp, *eigvals;
extern vec_struct *u_root;
extern cmplx_vec_struct *cmplx_u_root;
extern int res_xy;
extern int cmplx_flag;

/*	printf("write_eiginfo called...num_eig = %d\n",num_eig); */

	if (eigvals == NULL) {
	    error_msg("No eigenvalues computed.");
	    return(-1);
	}

	i = get_string("Enter eiginfo output filename: ",buf,STRINGLEN);
        if((fp=fopen(buf, "w")) == NULL)  {
	    error_msg("Error opening file.");
	    return(-1);
        }

        pop_feedback();
	feedback_msg("Writing out eigenvalues...");

	fwrite(&sum_eigvals,sizeof(double),1,fp);
	printf("sum_eigvals = %f\n",sum_eigvals);

	fwrite(&num_eig,sizeof(int),1,fp);

	   /* eigvals in ascending order */
/*	for (i=num_vecs-1; i>=num_vecs-num_eig; i--) {
	   fwrite(wrp+i,sizeof(double),1,fp);
	   printf("eigval = %f\n",*(wrp+i));
	} */
	printf("----eigvals-----\n");
	for (i=0; i<num_eig; i++) {
	   fwrite(eigvals+i,sizeof(double),1,fp);
	   printf("%d)  %f\n",i,*(eigvals+i));
	}


	if (u_root == NULL) {
	    error_msg("No eigenfns computed.");
	    fclose(fp);
	    return(-1);
	}

	res_xy = vec_resolution();

	write_header(fp);

	feedback_msg("Writing out eigenfunctions...");

	   /* Write out num_eig eigfns */
	k=0;
	if (!cmplx_flag) {
	  TRACE(vsp,u_root) {
	     k++;
	     if (k > num_eig) break;
	     printf("writing out eigfn %d\n", k);
	     fwrite(vsp->dp,sizeof(double),res_xy,fp);
	  }
	}
	else {
	  TRACE(cvsp,cmplx_u_root) {
	     k++;
	     if (k > num_eig) break;
	     printf("writing out eigfn %d\n", k);
	     fwrite(cvsp->drp,sizeof(double),res_xy,fp);
	     fwrite(cvsp->dip,sizeof(double),res_xy,fp);
	  }
	}

	fclose(fp);
        push_feedback();
}
/*--------------------------------------------------------------------*/
write_appx()
{
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
	FILE *fpout;
	int k;
	float *fp, *alloc_vector_float();
	double *dp, *drp,*dip;
	char buf[STRINGLEN];
extern vec_struct *appx_root;
extern cmplx_vec_struct *cmplx_appx_root;
extern int res_xy;
extern int cmplx_flag;
extern int num_eig_appx;


	if (appx_root == NULL) {
	   error_msg("No appx computed.");
	   return(-1);
	}

	k = get_string("Enter appx output filename: ",buf,STRINGLEN);
        if((fpout=fopen(buf, "w")) == NULL)  {
	    error_msg("Can't open file.");
	    return(-1);
        }

	res_xy = vec_resolution();

	fp = alloc_vector_float();

	write_header(fpout);
	fwrite(&num_eig_appx,sizeof(int),1,fpout);

        pop_feedback();

	   /* Write out all appx vectors */
	k=0;
	if (!cmplx_flag) {
	TRACE(vsp,appx_root) {
	   k++;
	   sprintf(buf,"writing out appx %d\n", k);
	   feedback_msg(buf);

	   dp = vsp->dp;

	   copy_double_to_float(dp,fp,res_xy);

	   fwrite(fp,sizeof(float),res_xy,fpout);
	}
	}

	else {
	TRACE(cvsp,cmplx_appx_root) {
	   k++;
	   sprintf(buf,"writing out appx %d\n", k);
	   feedback_msg(buf);

	   drp = cvsp->drp;
	   dip = cvsp->dip;

		/* Copy to floats */
	   copy_double_to_float(drp,fp,res_xy);
	   fwrite(fp,sizeof(float),res_xy,fpout);

	   copy_double_to_float(dip,fp,res_xy);
	   fwrite(fp,sizeof(float),res_xy,fpout);
	}
	}
	fclose(fpout);

	free(fp);
        push_feedback();
}
/*--------------------------------------------------------------------*/
/*--------------------------------------------------------------------*/
write_cur_fv()
{
	int count,i;
	double *dp;
	vec_struct *vsp;
	FILE *fp;
extern int	cur_eigfn;
extern int 	res_x;
extern vec_struct *u_root;


	if (!eigfns_exist()) return(-1);

	   printf("output current FV eigfn (--> fv.dat):\n");

	count=0;
	TRACE(vsp,u_root) {
	   count++;
	   if (count == cur_eigfn) break;
	}
	dp = vsp->dp;

	fp = fopen("fv.dat","w");

	   /* Write real,imag parts */
	for (i=0; i<res_x; i+=2)
	   fprintf(fp,"%e %e\n", *(dp+i), *(dp+i+1));

/*	for (i=0; i<res_x; i++)
	   fprintf(fp,"%e\n", *(dp+i)); */
	fclose(fp);
}
/*--------------------------------------------------------------------*/
write_cur_2def()
{
	int count,i,j;
	double *dp;
	vec_struct *vsp;
	FILE *fp;
	float v[3];
extern int	cur_eigfn;
extern int 	res_x,res_y;
extern vec_struct *u_root;


	if (!eigfns_exist()) return(-1);
	   printf("output current 2D eigfn (--> front/side.bin):\n");

	count=0;
	TRACE(vsp,u_root) {
	   count++;
	   if (count == cur_eigfn) break;
	}
	dp = vsp->dp;

	fp = fopen("front.bin","w");
	for (j=0; j>(-res_y); j--) {
	v[2] = j;
	for (i=0; i<res_x; i++) {
/*	   printf("%d) %e %e\n", i,*(dp+i), *(dp+i+1)); */
	   v[0] = i;
	   v[1] = *dp++;
	   fwrite(v,sizeof(float),2,fp);
	}
	}
	fclose(fp);

	dp = vsp->dp;
	fp = fopen("side.bin","w");
	for (i=0; i<res_x; i++) {
	for (j=0; j<res_y; j++) {
	    v[0] = -j;
	    v[1] = *(dp+j*res_x);
	    fwrite(v,sizeof(float),2,fp);
	}
	dp++;
	}
	fclose(fp);
}
/*--------------------------------------------------------------------*/
write_pix_img()
{
	long wwidth,wheight;
	unsigned long *pix;
	int pixsize;
	FILE *outfp;
extern int	transform_win;


	winset(transform_win);
	getsize(&wwidth,&wheight);
	printf("save_img:    wwidth,wheight =  %d %d\n", wwidth,wheight);
	pix = NEW(unsigned long,sizeof(unsigned long)*wwidth*wheight);
	lrectread(0,0,wwidth-1,wheight-1,pix);

	outfp = fopen("pix.img","w");
	fwrite(pix,sizeof(unsigned long),wwidth*wheight,outfp);
	fclose(outfp);
	free(pix);
}
/*--------------------------------------------------------------------*/
write_header(fp)
FILE *fp;
{
extern int res_x,res_y;
extern float xmin,xmax,ymin,ymax,zmin,zmax;

	printf("------------------------\n");
	printf("    write_header:  res_x,res_y = %d %d\n", res_x,res_y);
	fwrite(&res_x,sizeof(int),1,fp);
	fwrite(&res_y,sizeof(int),1,fp);

	printf("    write_header:  xmin,xmax = %f %f\n", xmin,xmax);
	fwrite(&xmin,sizeof(float),1,fp);
	fwrite(&xmax,sizeof(float),1,fp);
	fwrite(&ymin,sizeof(float),1,fp);
	fwrite(&ymax,sizeof(float),1,fp);
	fwrite(&zmin,sizeof(float),1,fp);
	fwrite(&zmax,sizeof(float),1,fp);
	printf("------------------------\n");
}
/*--------------------------------------------------------------------*/
copy_double_to_float(dp,fp,n)
double *dp;
float *fp;
int n;
{
	int i;

	for (i=0; i<n; i++)
	      *(fp+i) = *(dp+i);
}
