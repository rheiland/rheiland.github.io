/* file_io.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

/*int stat (const char *path, struct stat *buf) */
/*  "man stat" for info  */


file_exist0(char *fname)
{
  struct stat *buf;

  if (stat(fname,buf) < 0) 
    return 0;
  else
    return 1;

}
file_exist(char *fname)
{
  if (fopen(fname,"r") == NULL) 
    return 0;
  else
    return 1;
}

main()
{
  char fname[128];

  printf("enter filename: ");
  scanf("%s",fname);

  if(!file_exist(fname)) 
    printf("file doesn't exist\n");
  else
    printf("file exists\n");
}
