 /* utreadvec.c
 * Author:  Randy Heiland, Department of Mathematics,
 *    Arizona State University, Tempe, AZ  85287-1804.
 *
 *    Copyright (c) 1990 by Eric J. Kostelich.
 */
/* UTREADVEC- read in a vector of data from the file, converting the 
 * type as needed.
 * Return value is the number of values read in and converted and a negative
 * error code otherwise.
 */
#include "utio.h"

int utreadvec(p, veclen, fp)
register UTBUF	*p;
int veclen;
register UTFILE	*fp;
{
	int	total = 0;
	int	nrds;

	if (fp->isfortran) {
	   p->offset = 0;
	   while((nrds = utread(p, 0, fp)) > 0)  {
		total += nrds;
/*		printf("total= %d\n", total); */
		p->offset = total;
		if (veclen == total) {
		   nrds = total;
		   break;
		}
	   }
	}
	else 
	   nrds = utread(p, veclen, fp);

	return(nrds);		/* contains error code */
}
