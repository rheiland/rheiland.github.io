/* viewing.c - dynamic viewing (via middlemouse rotation); dials
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include <gl.h>
#include <device.h>
#include "kl_str.h"
#include "view_angle.h"


extern short	oldx,oldy, newx,newy;
extern int 	dx,dy,dz;
extern float  	cur_mtx[4][4],ident_mtx[4][4];
float  	rot_mtx[4][4];
extern int	dialflg;
extern int	cur_win,transform_win;

int 	ortho_view=1;



/*--------------------------------------------------------------------*/
/* Perform rotation of geometry by holding down on middle mouse 
   button while moving it.  */
process_middlemouse(button_down)
short button_down;
{

    if (button_down) {
        oldx = (short)getvaluator(MOUSEX);
        oldy = (short)getvaluator(MOUSEY);
        reorient_geom();
    }
}
/*--------------------------------------------------------------------*/
reorient_geom()
{
extern win_struct data_win,mean_win,eigfn_win,appx_win,error_win;
extern int cur_eigfn;

/*	printf("reorient_geom: cur_win, = %d\n", cur_win); */


	if (transform_win == data_win.id)
	while (getbutton(MIDDLEMOUSE)) {
	   newx = (short)getvaluator(MOUSEX);
	   newy = (short)getvaluator(MOUSEY);
	      /* Positive rotation is CCW on Iris using the right-hand rule. */
	      /* Moving cursor to right -> CCW rotation about y */
	   dx = -(newx-oldx) % 3600;
	      /* Moving cursor up -> CW rotation about x */
	   dy = -(newy-oldy) % 3600;
	   oldx = newx;
	   oldy = newy;
	   dialflg = 2;
	   redraw_data();
	}
	else if (transform_win == mean_win.id)
	while (getbutton(MIDDLEMOUSE)) {
	   newx = (short)getvaluator(MOUSEX);
	   newy = (short)getvaluator(MOUSEY);
	      /* Positive rotation is CCW on Iris using the right-hand rule. */
	      /* Moving cursor to right -> CCW rotation about y */
	   dx = -(newx-oldx) % 3600;
	      /* Moving cursor up -> CW rotation about x */
	   dy = -(newy-oldy) % 3600;
	   oldx = newx;
	   oldy = newy;
	   dialflg = 2;
	   redraw_mean();
	}
	else if (transform_win == eigfn_win.id)
	while (getbutton(MIDDLEMOUSE)) {
	   newx = (short)getvaluator(MOUSEX);
	   newy = (short)getvaluator(MOUSEY);
	      /* Positive rotation is CCW on Iris using the right-hand rule. */
	      /* Moving cursor to right -> CCW rotation about y */
	   dx = -(newx-oldx) % 3600;
	      /* Moving cursor up -> CW rotation about x */
	   dy = -(newy-oldy) % 3600;
	   oldx = newx;
	   oldy = newy;
	   dialflg = 2;
	   redraw_eigfn(cur_eigfn);
	}
	else if (transform_win == appx_win.id)
	while (getbutton(MIDDLEMOUSE)) {
	   newx = (short)getvaluator(MOUSEX);
	   newy = (short)getvaluator(MOUSEY);
	      /* Positive rotation is CCW on Iris using the right-hand rule. */
	      /* Moving cursor to right -> CCW rotation about y */
	   dx = -(newx-oldx) % 3600;
	      /* Moving cursor up -> CW rotation about x */
	   dy = -(newy-oldy) % 3600;
	   oldx = newx;
	   oldy = newy;
	   dialflg = 2;
	   redraw_appx();
	}
	else if (transform_win == error_win.id)
	while (getbutton(MIDDLEMOUSE)) {
	   newx = (short)getvaluator(MOUSEX);
	   newy = (short)getvaluator(MOUSEY);
	      /* Positive rotation is CCW on Iris using the right-hand rule. */
	      /* Moving cursor to right -> CCW rotation about y */
	   dx = -(newx-oldx) % 3600;
	      /* Moving cursor up -> CW rotation about x */
	   dy = -(newy-oldy) % 3600;
	   oldx = newx;
	   oldy = newy;
	   dialflg = 2;
	   redraw_error();
	}
}
/*--------------------------------------------------------------------*/
viewing_angle(angle)
int angle;
{
	ortho_view = angle;

	switch(angle) {
	case FRONT:	/* front */
		loadmatrix(ident_mtx);
		break;
	case TOP:	/* top */
		loadmatrix(ident_mtx);
		rot(90.0,'x');
		break;
	case SIDE:	/* side */
		loadmatrix(ident_mtx);
		rot(-90.0,'y');
		break;
	}
	getmatrix(cur_mtx);
/*	getmatrix(rot_mtx); */
/*	print_rot_mtx(); */
}
/*--------------------------------------------------------------------*/
print_rot_mtx()
{
	int i;

/*	getmatrix(rot_mtx); */
	printf("------   rot_mtx  ------\n");
	for (i=0; i<4; i++){
	   printf("%f %f %f %f\n", rot_mtx[i][0],rot_mtx[i][1],rot_mtx[i][2],rot_mtx[i][3]);
	}
}
