
#include <stdio.h>
#include <gl.h>
#include <device.h>

main()
{
    int max_xpix,max_ypix;
    long i;

	max_xpix = getgdesc(GD_XPMAX);
	max_ypix = getgdesc(GD_YPMAX);
	printf("max_xpix,max_ypix = %d %d\n", max_xpix,max_ypix);

	winopen("foo");
	i = getplanes();
	printf("bitplanes = %d\n",i);
	sleep(5);
}
