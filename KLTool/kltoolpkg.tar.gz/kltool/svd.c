/* svd.c - Singular value decomposition 
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include "kl_str.h"
#include "macros.h"

#define FILE_EIGVALS "eigvals.dat"

double *xm = NULL;


/*--------------------------------------------------------------------*/
svd_handler()
{
	char *prompt, *butn[3],msg[80];
	vec_struct *list1_root;
	int choice;
extern vec_struct *caric_root,*vec_root,*error_root;
extern vec_struct *list2_root;
extern int cmplx_flag;


	if (cmplx_flag) {
	   sprintf(msg,"SVD not available for complex data");
	   feedback_msg(msg);
	   return(-1);
	}

	if (error_root != NULL) {
	   prompt = "Decompose Data or Error?";
	   butn[0] = "Data";
	   butn[1] = "Error";
	   butn[2] = "CANCEL";
	   choice = get_prompt_msg(prompt,3,butn);
	   printf("choice = %d\n", choice);
	   switch(choice) {
	   case 1:
		list1_root = caric_root;
		list2_root = vec_root;
		break;
	   case 2:
		list1_root = error_root;
		list2_root = error_root;
		break;
	   case 3:
		return(-1);
		break;
	   default:
		printf("kl_handler: no valid button press\n");
		list1_root = caric_root;
		list2_root = vec_root;
		break;
	   }
	}
	else {
	   list1_root = caric_root;
	   list2_root = vec_root;
	}


	if (svd_decompose_handler(list1_root) < 0)
	   return(-1);

	if (yes_no("Compute eigenfunctions?"))
	   kl_efns_handler(list2_root);
}

/*--------------------------------------------------------------------*/
svd_decompose_handler(list_root)
vec_struct *list_root;
{

	if (svd_mtx(list_root) < 0) 
	   return(-1);

	svd_compute_eig();

	update_eigvals_win();
	return(1);
}
/*--------------------------------------------------------------------*/
svd_mtx(list_root)
vec_struct *list_root;
{
	int i,j,m;
	vec_struct *vsp;
	double *dp, *vmean;
	double *xmp, *xmp_save, temp;
	char msg[80];
extern double mean_ptr;
extern int num_vecs, res_xy;


	if (mean_ptr == NULL) {
	   notify_user("Must compute mean first");
	   return(-1);
	}

/*	printf("svd: num_vecs = %d\n", num_vecs);
	printf("     res = %d\n", res_xy); */

	if (xm != NULL)
	   free(xm);

	xm = (double *)malloc(sizeof(double)*res_xy*num_vecs);
	xmp = xm;
	xmp_save = xm;

	pop_feedback();
	m=0;

	   /* Matrix = vectors in columns (nrows = res_xy) */

	   /* 'list_root' is 'caric_root' or 'error_root' */
	TRACE(vsp,list_root) {
	   dp = vsp->dp;

	   for (i=0; i<res_xy; i++) {
		*xmp = *(dp+i);
	        xmp++;
	   }

	   m++;
	   sprintf(msg,"Computing matrix... %d of %d", m,num_vecs);
	   feedback_msg(msg);
	}

/*	print_dmtx(xmp_save,res_xy,num_vecs); */

	push_feedback();
	return(1);
}
/*--------------------------------------------------------------------*/
print_dmtx(mp,nr,nc)
double *mp;
int nr,nc;
{
	int i,j;

	printf("\n-----------  matrix  ---------\n");
	for (i=0; i<nr; i++) {
	  for (j=0; j<nc; j++) {
	     printf("%f ", *(mp+j*nr+i));
	  }
	  printf("\n");
	}
}
/*--------------------------------------------------------------------*/
/* Compute eigenvalues/vectors of the SVD (~covariance) matrix */
svd_compute_eig()
{
	int i,n_sv,max_rc, n_eig;
	int *iv1;
	double *work,*e;
	double *singvals;
	double eigval;
	int ldx,ldu,ldv,nrows,ncols,job,info;
	FILE *fp;
extern double *eigvals;
static	double *u = NULL;
static	double *v = NULL;

extern int num_vecs, res_xy;
extern double sum_eigvals;
extern double *eigvecs;		/* right (or,left) singular vectors of xm */

/*   notify_user_ok("NB! Linpack (DSVDC) not available.");
   return(-1); */


	printf("------------------begin svd_compute_eig -------------------\n");

	printf("svd_compute_eig: num_vecs=%d, res=%d\n", num_vecs,res_xy);

	if (u != NULL) {
	   free(u);
	   free(v);
	}

	nrows = res_xy;
	ncols = num_vecs;

		/* usual:  # vecs < vec_resolution */
/*	if (nrows >= ncols) { */

	   /* A bit confusing:  it seems the correct thing to do is
		always compute right singular vectors.
	    */

		/* compute only right singular vecs */
	   ldu = 1;
	   ldv = ncols;
	   u = (double *)malloc(sizeof(double)*ldu);
	   v = (double *)malloc(sizeof(double)*ldv*ldv);
	   job = 01;
	   eigvecs = v;
/*	} */
		/* compute only left singular vecs */
/*	else {
	   ldu = nrows;
	   ldv = 1;
	   u = (double *)malloc(sizeof(double)*ldu*ldu);
	   v = (double *)malloc(sizeof(double)*ldv);
	   job = 20;
	   eigvecs = u;
	} */

	n_sv = MIN(nrows+1,ncols);
	max_rc = MAX(nrows,ncols);
	
	singvals = (double *)malloc(sizeof(double)*n_sv);
	work = (double *)malloc(sizeof(double)*max_rc);
	e = (double *)malloc(sizeof(double)*ncols);

	pop_feedback();
	feedback_msg("computing singular values/vectors ...");

	ldx = nrows;

	   /* from Linpack (double-prec) */
	dsvdc_(xm,&ldx,&nrows,&ncols, singvals,e, u,&ldu, v,&ldv, work,&job,&info);
	printf("\n\n");
	printf("info (from dsvdc) = %d\n", info);
	printf("\n\n");
	system("date");

	   /* What should be done here? */
/*	if (info != 0)
	   notify_user_ok("Warning: error from dsvdc"); */

	feedback_msg("writing singular values/vectors to files...");

	fp = fopen(FILE_EIGVALS,"w");

	if (eigvals) free(eigvals);
	eigvals = (double *)malloc(sizeof(double)*n_sv);

	sum_eigvals = 0.0;
/*	printf("--  singular vals:\n"); */
	for (i=0; i<n_sv; i++) {
/*	   printf("%f\n", *(singvals+i)); */
	   eigval = *(singvals+i) *  *(singvals+i);
	   sum_eigvals += eigval;
	   *(eigvals+i) = eigval;
	   fprintf(fp,"%f %f\n", eigval, 0.0);	/* real, imag */
	}
	fclose(fp);
	printf("svd_compute_eig:  sum eigenvals  = %f\n", sum_eigvals);

	push_feedback();

	default_num_eig(n_sv);
	printf("------------------end svd_compute_eig -------------------\n");
}
