/* contour.c - display contour mesh of data
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 *
 *   cc -c -cckr contour.c
 */

#include <gl.h>
#include <math.h>
#include "kl_str.h"
#include "contour_type.h"



#define X 0
#define Y 1
#define Z 2

double f_min,f_diff;
double error_min,error_diff;

/* 
/* extern float ymin,ydiff; */

int contour_type=1;

/*--------------------------------------------------------------------*/
contour_type_handler(type)
int type;
{
	contour_type = type;
	printf("contour_type_handler: contour_type = %d\n", contour_type);
}

/*--------------------------------------------------------------------*/
contour_2d_eigfn(vec_root,vec_num)
vec_struct *vec_root;
int vec_num;
{
	int i;
	double *vp,vmin,vmax;
	vec_struct *vsp;
extern int cur_win;
extern win_struct data_win,appx_win,error_win,mean_win,eigfn_win;
extern float ymin,ymax;

	i = 0;
	TRACE(vsp,vec_root) {
	   vp = vsp->dp;
	   i++;
	   if (i==vec_num) break;
	}
	vec_minmax(vp,&vmin,&vmax);
	f_min = vmin;
	f_diff = vmax - vmin;


	if (contour_type == CONTOUR_HEIGHT)
/*	      contour_mesh_2d_height(vec_root,vec_num); */
	      contour_mesh_2d_height(vp);
	else if (contour_type == CONTOUR_LAPLACE)
	      contour_mesh_2d_laplace(vp);
}
/*--------------------------------------------------------------------*/
contour_mesh(vec_root,vec_num)
vec_struct *vec_root;
int vec_num;
{
	int i;
	double *dp;
	vec_struct *vsp;
extern int dimension;
extern int cur_win;
extern win_struct data_win,appx_win,error_win,mean_win,eigfn_win;
extern float ymin,ymax;

	if (dimension == 1) {
	   f_min = ymin;
/*	   f_diff = ydiff; */
	   f_diff = ymax - ymin;
	   contour_mesh_1d(vec_root);
	}
	else if (dimension == 2) {
	   i=0;
	   TRACE(vsp,vec_root) {
	      i++;
	      if (i == vec_num) break;
	   }
	   dp = vsp->dp;

	   f_min = ymin;
	   f_diff = ymax - ymin;

	   if (contour_type == CONTOUR_HEIGHT)
	      contour_mesh_2d_height(dp);
	   else if (contour_type == CONTOUR_LAPLACE)
	      contour_mesh_2d_laplace(dp);
	}
}
/*--------------------------------------------------------------------*/
contour_uchar(vec_root,vec_num)
vec_struct_uchar *vec_root;
int vec_num;
{
	int i;
	unsigned char *dp;
	vec_struct_uchar *vsp;
extern float ymin,ymax;

	   i=0;
/*   printf("contour_uchar: vec=%d\n", vec_num); */
	   TRACE(vsp,vec_root) {
	      i++;
	      if (i == vec_num) break;
	   }
	   dp = vsp->dp;

	   f_min = ymin;
	   f_diff = ymax - ymin;
/*   printf("contour_uchar: ymin,ymax = %f %f\n", ymin,ymax); */

	   contour_uchar_2d(dp);
}
/*--------------------------------------------------------------------*/
contour_2d_mean()
{
extern double	*mean_ptr;
extern float ymin,ymax;

	f_min = ymin;
	f_diff = ymax - ymin;

	if (contour_type == CONTOUR_HEIGHT)
	      contour_mesh_2d_height(mean_ptr);
	else if (contour_type == CONTOUR_LAPLACE)
	      contour_mesh_2d_laplace(mean_ptr);
}
/*--------------------------------------------------------------------*/
contour_2d_mean_float()
{
extern float	*mean_ptr_float;
extern float ymin,ymax;

	f_min = ymin;
	f_diff = ymax - ymin;

	if (contour_type == CONTOUR_HEIGHT)
	      contour_float_2d(mean_ptr_float);
}
/*--------------------------------------------------------------------*/
contour_error_mesh(vec_root,vec_num)
vec_struct *vec_root;
int vec_num;
{
	int i;
	double vmin,vmax,*dp;
	vec_struct *vsp;
extern int dimension;

	f_min = error_min;
	f_diff = error_diff;

	if (dimension == 1) {
	   contour_mesh_1d(vec_root);
	}
	else if (dimension == 2) {
	   i=0;
	   TRACE(vsp,vec_root) {
	      i++;
	      if (i == vec_num) break;
	   }
	   dp = vsp->dp;

	   if (contour_type == CONTOUR_HEIGHT)
	      contour_mesh_2d_height(dp);
	   else if (contour_type == CONTOUR_LAPLACE)
	      contour_mesh_2d_laplace(dp);
	}
}
/*--------------------------------------------------------------------*/
veclist_minmax(vec_root,vmin,vmax)
vec_struct *vec_root;
double *vmin,*vmax;
{
	vec_struct *vsp;
	double lo,hi;

	*vmin = *vmax = *(vec_root->dp);

	TRACE(vsp,vec_root) {
	   vec_minmax(vsp->dp,&lo,&hi);
	   if (lo < *vmin) *vmin = lo;
	   if (hi > *vmax) *vmax = hi;
	}
}

/*--------------------------------------------------------------------*/
contour_mesh_1d(vec_root)
vec_struct *vec_root;
{
    int i,odd,offset;
    int row,col;
    float v[3],c[3];
    float xdel,ydel;
    vec_struct *vsp;
    double val,*dp, *ndp;
    extern int res_x;

/*	printf("contour_mesh_1d called...........\n");
	printf("	res_x = %d\n", res_x); */

    row = 0;
    bgntmesh();
    TRACE(vsp,vec_root) {
	if (NEXT(vsp) == NULL) break;

	dp = vsp->dp;
	ndp = NEXT(vsp)->dp;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	swaptmesh();
	row--;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
contour_mesh_2d_height(dp)
double *dp;
{
    int i,odd,offset;
    int row,col;
    float v[3],c[3];
    float xdel,ydel;
    vec_struct *vsp;
    double val, *ndp;
extern int res_x,res_y;

/*	printf("contour_mesh_2d_height called...........\n");
	printf("	res_x= %d, res_y= %d\n", res_x,res_y);
	printf("	vec_num= %d\n", vec_num); */

/*	i=0;
	TRACE(vsp,vec_root) {
	   i++;
	   if (i == vec_num) break;
	}
	dp = vsp->dp; */


	bgntmesh();
	for (row=0; row>-(res_y-1); row--) {

	ndp = dp + res_x;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	swaptmesh();
	dp = ndp;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
contour_uchar_2d(dp)
unsigned char *dp;
{
    int i;
    int row,col;
    long v[3],c[3];
extern int res_x,res_y;

/*	minmax_uchar(dp); */

	v[Y] = 0;
	bgnpoint();
	for (row=0; row>-(res_y-1); row--) {

	   for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     c[0] = c[1] = c[2] = *(dp+i);
             c3i(c);
             v3i(v);
	   }
	   dp = dp + res_x;
	}
    endpoint();
}
/*--------------------------------------------------------------------*/
contour_uchar_2dmesh(dp)
unsigned char *dp;
{
    int i,odd,offset;
    int row,col;
    long v[3],c[3];
    float xdel,ydel;
    double val;
    unsigned char *ndp;
extern int res_x,res_y;


	v[Y] = 0;
	bgntmesh();
	for (row=0; row>-(res_y-1); row--) {

	ndp = dp + res_x;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     c[0] = c[1] = c[2] = *(dp+i);
             c3i(c);
             v3i(v);

	     v[Z] = row-1;
	     c[0] = c[1] = c[2] = *(ndp+i);
             c3i(c);
             v3i(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
/*	     val = *(dp+i); */
	     c[0] = c[1] = c[2] = *(dp+i);
             c3i(c);
             v3i(v);

	     v[Z] = row-1;
/*	     val = *(ndp+i); */
	     c[0] = c[1] = c[2] = *(ndp+i);
             c3i(c);
             v3i(v);
	}
	}
	swaptmesh();
	dp = ndp;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
contour_uchar_2dcolor(dp)
unsigned char *dp;
{
    int i,odd,offset;
    int row,col;
    float v[3],c[3];
    float xdel,ydel;
    double val;
    unsigned char *ndp;
extern int res_x,res_y;


     v[Y] = 0.0;

	bgntmesh();
	for (row=0; row>-(res_y-1); row--) {

	ndp = dp + res_x;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	swaptmesh();
	dp = ndp;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
contour_byte_2d(dp)
char *dp;
{
    int i,odd,offset;
    int row,col;
    float v[3],c[3];
    float xdel,ydel;
    double val;
    char *ndp;
extern int res_x,res_y;

/*	printf("contour_mesh_2d_height called...........\n");
	printf("	res_x= %d, res_y= %d\n", res_x,res_y);
	printf("	vec_num= %d\n", vec_num); */


     v[Y] = 0.0;

	bgntmesh();
	for (row=0; row>-(res_y-1); row--) {

	ndp = dp + res_x;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	swaptmesh();
	dp = ndp;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
contour_float_2d(dp)
float *dp;
{
    int i,odd,offset;
    int row,col;
    float v[3],c[3];
    float xdel,ydel;
    double val;
    float *ndp;
extern int res_x,res_y;


     v[Y] = 0.0;

	bgntmesh();
	for (row=0; row>-(res_y-1); row--) {

	ndp = dp + res_x;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
/*	     v[Y] = val; */
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	swaptmesh();
	dp = ndp;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
contour_mesh_2d_laplace(dp)
double *dp;
{
    int i,j,k,odd,offset;
    int row,col;
    float min_val,max_val,val_range;
    float v[3],c[3];
    float xdel,ydel;
    vec_struct *vsp;
    double val,lval, *ndp;
    double *ldp, *alloc_vector();
extern int res_x,res_y;

/*	printf("contour_mesh_2d_laplace called...........\n");
	printf("	res_x= %d, res_y= %d\n", res_x,res_y);
	printf("	vec_num= %d\n", vec_num); */


	ldp = alloc_vector();


	   /* 1st pass, find extrema */
	   /* Compute extrema for each frame */
	min_val = HUGE;
	max_val = -HUGE;

	   /* Just do the interior mesh pts for now; do borders later */
	dp += res_x;
	for (j=1; j<res_y; j++) {
	   k = j*res_x;
	   dp = vsp->dp + k + 1;

	   for (i=1; i<res_x; i++) {
		val = *(dp+i);
/*		lval  = 0.25*() - val; */
		*(ldp+k+i)  = lval;
	   	if (lval < min_val) min_val = lval;
	   	if (lval > max_val) max_val = lval;
	    }
    	}
	printf("min,max laplacian = %f %f\n", min_val,max_val);
	val_range = max_val-min_val;



	   /* 2nd pass, compute colors */

	dp = vsp->dp;

	bgntmesh();
	for (row=0; row>-(res_y-1); row--) {

	ndp = dp + res_x;

	if (!(row%2)) {		/* even row */
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     laplacian(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     laplacian(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	else {			/* odd row */
	for (i=res_x-1; i>=0; i--) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     laplacian(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     laplacian(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	}
	swaptmesh();
	dp = ndp;
    }
    endtmesh();
}
/*--------------------------------------------------------------------*/
/* old way, no doubt slower */
contour_mesh2()
{
    int i,odd,offset;
    int row,col;
    float v[3],c[3];
    float xdel,ydel;
    vec_struct *vsp;
    double val,*dp, *ndp;

vec_struct *vec_root;
extern int res_x;


    row = 0;
    TRACE(vsp,vec_root) {
	if (NEXT(vsp) == NULL) break;

	dp = vsp->dp;
	ndp = NEXT(vsp)->dp;

	bgntmesh();
	for (i=0; i<res_x; i++) {
	     v[X] = i;
	     v[Z] = row;
	     val = *(dp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);

	     v[Z] = row-1;
	     val = *(ndp+i);
	     v[Y] = val;
	     rainbow(val,&c[0],&c[1],&c[2]);
             c3f(c);
             v3f(v);
	}
	endtmesh();
	row--;
    }
}
/*--------------------------------------------------------------------*/

#define		MIN(a,b)		((a)<(b)?(a):(b))
#define		MAX(a,b)		((a)>(b)?(a):(b))

#define		CLAMPIT(foo, min, max)\
	foo = MAX(min, MIN(max, foo))
	
rainbow(v, r, g, b)
double v ;
float *r, *g, *b ;
{
/*extern float ymin,ydiff; */

    /* [min,max] --> [0,1]  */
  v = (v-f_min) / f_diff;

  if (v > 0.5) {
    if (v > 0.75) {
      v = (v - 0.75) * 4.0 ;
      *r = 1.0 ;
      *g = (1.0-v) * 0.365 ;
      *b = (1.0-v) * .039 ;
    } else {
      v = (v - 0.5) * 4.0 ;
      *r = 1.0 ;
      *g = 1.0 - v * 0.635 ;
      *b = v * .039 ;
    }
  } else {
    if (v > 0.25) {
      v = (v - 0.25) * 4.0 ;
      *r = v ;
      *g = 0.5 + v / 2.0 ;
      *b = 0.0 ;
    } else {
      v *= 4.0 ;
      *r = 0.0 ;
      *g = v / 2.0 ;
      *b = (1.0-v) ;
    }
  }

  CLAMPIT(*r, 0.0, 1.0) ;
  CLAMPIT(*g, 0.0, 1.0) ;
  CLAMPIT(*b, 0.0, 1.0) ;
}
/*--------------------------------------------------------------------*/
laplacian(v, r, g, b)
double v ;
float *r, *g, *b ;
{
}
