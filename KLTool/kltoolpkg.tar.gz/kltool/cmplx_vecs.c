/* 
 * cmplx_vecs.c - update all displayed data when user selects
 *		a different representation form for complex vectors
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include "kl_str.h"

/*--------------------------------------------------------------------*/
cmplx_vec_handler(mode)
int mode;
{
extern int cmplx_flag;

  cmplx_flag = mode;
  update_cmplx_data();
}
/*--------------------------------------------------------------------*/
update_cmplx_data()
{
extern cmplx_vec_struct *cmplx_vec_root,*cmplx_u_root,*cmplx_appx_root,
	*cmplx_error_root,*cmplx_datacoef_root,*cmplx_appxcoef_root;
extern double *mean_ptr_real;
extern int cur_eigfn;


    if (cmplx_vec_root != NULL) {
	update_cmplx_data_form();
        redraw_data();
    }
    if (mean_ptr_real != NULL) {
	update_cmplx_mean_form();
	redraw_mean();
    }
    if (cmplx_u_root != NULL) {
        update_cmplx_eigfn_form();
        setup_eigfn_win(cur_eigfn);
        redraw_eigfn(cur_eigfn);
    }
    if (cmplx_appx_root != NULL) {
	update_cmplx_appx_form();
        redraw_appx();
    }
    if (cmplx_error_root != NULL) {
	update_cmplx_error_form();
        redraw_error();
    }
    if (cmplx_datacoef_root != NULL)  {
	update_cmplx_datacoef_form();
        redraw_datacoef();
    }
    if (cmplx_appxcoef_root != NULL)  {
	update_cmplx_appxcoef_form();
        redraw_appxcoef();
    }
}
/*--------------------------------------------------------------------*/
hilite_cmplx_menu()
{
extern int cmplx_flag;
extern int menu8;
extern int cmplx_vec_handler();


    freepup(menu8);
    if (cmplx_flag == 1)
       menu8 = defpup("Complex %t %F|real *|imag|amplitude|phase",
		cmplx_vec_handler);
    else if (cmplx_flag == 2)
       menu8 = defpup("Complex %t %F|real|imag *|amplitude|phase",
		cmplx_vec_handler);
    else if (cmplx_flag == 3)
       menu8 = defpup("Complex %t %F|real|imag|amplitude *|phase",
		cmplx_vec_handler);
    else if (cmplx_flag == 4)
       menu8 = defpup("Complex %t %F|real|imag|amplitude|phase *",
		cmplx_vec_handler);

}
/*--------------------------------------------------------------------*/
update_cmplx_data_form()
{
	int i;
	double *drp,*dip,*dp, *dptmp;
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int cmplx_flag;
extern int res_xy;
extern cmplx_vec_struct *cmplx_vec_root;
extern vec_struct *vec_root;
extern float ymin,ymax;



    cvsp = cmplx_vec_root;

    ymin = HUGE;
    ymax = -HUGE;

	/* --------------  Update the data vectors representation */
    TRACE(vsp,vec_root) {

	dp = vsp->dp;
	dptmp = dp;

	if (cmplx_flag == 1) {		/* real */
	   drp = cvsp->drp;

	   for (i=0; i<res_xy; i++) {
	      *dp = *drp;
	      dp++; drp++;;
	   }
/*	   extrema_vec(dptmp,res_xy); */
	}
	else if (cmplx_flag == 2) {		/* imag */
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = *dip;
	      dp++; dip++;
  	   }
/*	   extrema_vec(dptmp,res_xy); */
	}
	else if (cmplx_flag == 3) {		/* amplitude */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = sqrt(*drp * *drp + *dip * *dip);
	      dp++; drp++; dip++;
  	   }
/*	   extrema_vec(dptmp,res_xy); */
	}
	else if (cmplx_flag == 4) {		/* phase */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      if (*drp == 0.0) {
		 if (*dip == 0) *dp = 0;
		 else if (*dip > 0) *dp = M_PI_2;
		 else *dp = -M_PI_2;
	      }
	      else
	         *dp = atan(*dip / *drp);
	      dp++; drp++; dip++;
	   }
/*	   extrema_vec(dptmp,res_xy); */
	}
        cvsp = NEXT(cvsp);
    }
    cmplx_extrema(vec_root);
    data_extrema();
}
/*--------------------------------------------------------------------*/
update_cmplx_mean_form()
{
	int i;
	double rpart,ipart;
extern int cmplx_flag;
extern int res_xy;
extern double *mean_ptr, *mean_ptr_real,*mean_ptr_imag;


	switch(cmplx_flag) {
	case 1:
	   for (i=0; i<res_xy; i++)
	      *(mean_ptr+i) = *(mean_ptr_real+i);
	   break;
	case 2:
	   for (i=0; i<res_xy; i++)
	      *(mean_ptr+i) = *(mean_ptr_imag+i);
	   break;
	case 3:
	   for (i=0; i<res_xy; i++) {
		 /* rf. Num. Recipes for a better calculation */
	      rpart = *(mean_ptr_real+i);
	      ipart = *(mean_ptr_imag+i);
	      *(mean_ptr+i) = sqrt(rpart*rpart + ipart*ipart);
	   }
	   break;
	case 4:
	   for (i=0; i<res_xy; i++) {
	      rpart = *(mean_ptr_real+i);
	      ipart = *(mean_ptr_imag+i);
	      if (rpart == 0.0) {
	        if (ipart == 0.0) *(mean_ptr+i) = 0.0;
	        else if (ipart > 0.0) *(mean_ptr+i) = M_PI_2;
	        else *(mean_ptr+i) = -M_PI_2;
	      }
	      else
	        *(mean_ptr+i) = atan(ipart/rpart);
	   }
	   break;
	}
}
/*---------------------------------------------------------*/
update_cmplx_eigfn_form()
{
	int i;
	double *drp,*dip,*dp;
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int cmplx_flag;
extern int res_xy;
extern int cur_eigfn;
extern cmplx_vec_struct *cmplx_u_root;
extern vec_struct  *u_root;



	/* -------------- Update the eigfns representation */
    cvsp = cmplx_u_root;

		/* copy eigfn into desired representation for display */
    TRACE(vsp,u_root) {

	dp = vsp->dp;

	if (cmplx_flag == 1) {		/* real */
	   drp = cvsp->drp;

	   for (i=0; i<res_xy; i++) {
	      *dp = *drp;
	      dp++; drp++;;
	   }
	}
	else if (cmplx_flag == 2) {		/* imag */
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = *dip;
	      dp++; dip++;
  	   }
	}
	else if (cmplx_flag == 3) {		/* amplitude */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = sqrt(*drp * *drp + *dip * *dip);
	      dp++; drp++; dip++;
	   }
	}
	else if (cmplx_flag == 4) {		/* phase */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      if (*drp == 0.0) {
		 if (*dip == 0) *dp = 0;
		 else if (*dip > 0) *dp = M_PI_2;
		 else *dp = -M_PI_2;
	      }
	      else
	         *dp = atan(*dip / *drp);
	      dp++; drp++; dip++;
	   }
	}
        cvsp = NEXT(cvsp);
    }
}
/*--------------------------------------------------------------------*/
update_cmplx_appx_form()
{
	int i;
	double *drp,*dip,*dp,*dptmp;
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int cmplx_flag;
extern int res_xy;
extern cmplx_vec_struct *cmplx_appx_root, *cmplx_vec_root;
extern vec_struct  *appx_root;
extern float ymin,ymax;



	/* -------------- Update the appx representation */
    cvsp = cmplx_appx_root;

		/* copy appx into desired representation for display */
    TRACE(vsp,appx_root) {

	dp = vsp->dp;
	dptmp = dp;

	if (cmplx_flag == 1) {		/* real */
	   drp = cvsp->drp;

	   for (i=0; i<res_xy; i++) {
	      *dp = *drp;
	      dp++; drp++;;
	   }
/*	   if (cmplx_vec_root == NULL) extrema_vec(dptmp,res_xy); */
	}
	else if (cmplx_flag == 2) {		/* imag */
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = *dip;
	      dp++; dip++;
  	   }
/*	   if (cmplx_vec_root == NULL) extrema_vec(dptmp,res_xy); */
	}
	else if (cmplx_flag == 3) {		/* amplitude */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = sqrt(*drp * *drp + *dip * *dip);
	      dp++; drp++; dip++;
	   }
/*	   if (cmplx_vec_root == NULL) extrema_vec(dptmp,res_xy); */
	}
	else if (cmplx_flag == 4) {		/* phase */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      if (*drp == 0.0) {
		 if (*dip == 0) *dp = 0;
		 else if (*dip > 0) *dp = M_PI_2;
		 else *dp = -M_PI_2;
	      }
	      else
	         *dp = atan(*dip / *drp);
	      dp++; drp++; dip++;
	   }
/*	   if (cmplx_vec_root == NULL) extrema_vec(dptmp,res_xy); */
	}
        cvsp = NEXT(cvsp);
    }

    if (cmplx_vec_root == NULL) {
       cmplx_extrema(appx_root);
       data_extrema();
    }
}
/*--------------------------------------------------------------------*/
update_cmplx_error_form()
{
	int i;
	double *drp,*dip,*dp;
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int cmplx_flag;
extern int res_xy;
extern cmplx_vec_struct *cmplx_error_root;
extern vec_struct  *error_root;
extern int scan_error_win;
extern int cur_error;
extern int num_eig_error;


	/* -------------- Update the error representation */
    cvsp = cmplx_error_root;

		/* copy error into desired representation for display */
    TRACE(vsp,error_root) {

	dp = vsp->dp;

	if (cmplx_flag == 1) {		/* real */
	   drp = cvsp->drp;

	   for (i=0; i<res_xy; i++) {
	      *dp = *drp;
	      dp++; drp++;;
	   }
	}
	else if (cmplx_flag == 2) {		/* imag */
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = *dip;
	      dp++; dip++;
  	   }
	}
	else if (cmplx_flag == 3) {		/* amplitude */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      *dp = sqrt(*drp * *drp + *dip * *dip);
	      dp++; drp++; dip++;
	   }
	}
	else if (cmplx_flag == 4) {		/* phase */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<res_xy; i++) {
	      if (*drp == 0.0) {
		 if (*dip == 0) *dp = 0;
		 else if (*dip > 0) *dp = M_PI_2;
		 else *dp = -M_PI_2;
	      }
	      else
	         *dp = atan(*dip / *drp);
	      dp++; drp++; dip++;
	   }
	}
        cvsp = NEXT(cvsp);
    }
}
/*--------------------------------------------------------------------*/
update_cmplx_datacoef_form()
{
	int i;
	double *drp,*dip,*dp;
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int cmplx_flag;
extern int num_vecs;
extern cmplx_vec_struct *cmplx_datacoef_root;
extern vec_struct  *datacoef_root;
extern int cur_datacoef;



	/* -------------- Update the coef representation */
    cvsp = cmplx_datacoef_root;

		/* copy appx into desired representation for display */
    TRACE(vsp,datacoef_root) {

	dp = vsp->dp;

	if (cmplx_flag == 1) {		/* real */
	   drp = cvsp->drp;

	   for (i=0; i<num_vecs; i++) {
	      *dp = *drp;
	      dp++; drp++;;
	   }
	}
	else if (cmplx_flag == 2) {		/* imag */
	   dip = cvsp->dip;

	   for (i=0; i<num_vecs; i++) {
	      *dp = *dip;
	      dp++; dip++;
  	   }
	}
	else if (cmplx_flag == 3) {		/* amplitude */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<num_vecs; i++) {
	      *dp = sqrt(*drp * *drp + *dip * *dip);
	      dp++; drp++; dip++;
	   }
	}
	else if (cmplx_flag == 4) {		/* phase */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<num_vecs; i++) {
	      if (*drp == 0.0) {
		 if (*dip == 0) *dp = 0;
		 else if (*dip > 0) *dp = M_PI_2;
		 else *dp = -M_PI_2;
	      }
	      else
	         *dp = atan(*dip / *drp);
	      dp++; drp++; dip++;
	   }
	}
        cvsp = NEXT(cvsp);
    }
}
/*--------------------------------------------------------------------*/
update_cmplx_appxcoef_form()
{
	int i;
	double *drp,*dip,*dp;
	vec_struct *vsp;
	cmplx_vec_struct *cvsp;
extern int cmplx_flag;
extern int num_vecs;
extern cmplx_vec_struct *cmplx_appxcoef_root;
extern vec_struct  *appxcoef_root;



	/* -------------- Update the coef representation */
    cvsp = cmplx_appxcoef_root;

		/* copy appx into desired representation for display */
    TRACE(vsp,appxcoef_root) {

	dp = vsp->dp;

	if (cmplx_flag == 1) {		/* real */
	   drp = cvsp->drp;

	   for (i=0; i<num_vecs; i++) {
	      *dp = *drp;
	      dp++; drp++;;
	   }
	}
	else if (cmplx_flag == 2) {		/* imag */
	   dip = cvsp->dip;

	   for (i=0; i<num_vecs; i++) {
	      *dp = *dip;
	      dp++; dip++;
  	   }
	}
	else if (cmplx_flag == 3) {		/* amplitude */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<num_vecs; i++) {
	      *dp = sqrt(*drp * *drp + *dip * *dip);
	      dp++; drp++; dip++;
	   }
	}
	else if (cmplx_flag == 4) {		/* phase */
	   drp = cvsp->drp;
	   dip = cvsp->dip;

	   for (i=0; i<num_vecs; i++) {
	      if (*drp == 0.0) {
		 if (*dip == 0) *dp = 0;
		 else if (*dip > 0) *dp = M_PI_2;
		 else *dp = -M_PI_2;
	      }
	      else
	         *dp = atan(*dip / *drp);
	      dp++; drp++; dip++;
	   }
	}
        cvsp = NEXT(cvsp);
    }
}
