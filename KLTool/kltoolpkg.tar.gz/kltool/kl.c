/* kl.c - perform Karhunen-Loeve decomposition
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */
#include <stdio.h>
#include <math.h>
#include "kl_str.h"
#include "macros.h"

#define X	0
#define Y	1
#define Z	2

#define DPCT 0.95

   /* NB! if change, also change in eigpct.h */
#define MAXEFN 	50

double *cov_mtx = NULL;			/* covariance matrix */
double *eigvecs = NULL;			/* eigenvectors of cov_mtx */
double *wrp = NULL;
double *wip = NULL;
double *fv1 = NULL;
double *fv2 = NULL;
int *iv1 = NULL;

double *eigvals = NULL;
double sum_eigvals;
int num_eig;

float *pct_table = NULL;
float *pctsum_table = NULL;

int	interp_eigfn_flag = 0;
int	decompose_method = 1;

vec_struct *u_root;		/* to eigenfns */

vec_struct *list2_root;
cmplx_vec_struct *cmplx_list2_root;


/*--------------------------------------------------------------------*/
decompose_method_handler()
{
  decompose_method = 3 - decompose_method;
}
/*--------------------------------------------------------------------*/
decompose_handler()
{
	if (decompose_method == 1)
	   kl_handler();
	else if (decompose_method == 2)
	   svd_handler();
}
/*--------------------------------------------------------------------*/
kl_handler()
{
	char *prompt, *butn[3];
	vec_struct *list1_root;
	int choice;
/* rf. input.c, mean.c */
extern vec_struct *caric_root,*vec_root,*error_root;
extern double *mean_ptr;
extern int window_pos_mode;
extern int cmplx_flag;

	if (cmplx_flag) {
	    return( cmplx_kl_handler() );
	}

	if (error_root != NULL) {
	   prompt = "Decompose Data or Error?";
	   butn[0] = "Data";
	   butn[1] = "Error";
	   butn[2] = "CANCEL";
	   choice = get_prompt_msg(prompt,3,butn);
	   switch(choice) {
	   case 1:
		list1_root = caric_root;
		list2_root = vec_root;
		break;
	   case 2:
		list1_root = error_root;
		list2_root = error_root;
		break;
	   case 3:
		return(-1);
		break;
	   default:
		printf("kl_handler: no valid button press\n");
		list1_root = caric_root;
		list2_root = vec_root;
/*	printf("vec_root= %d,  list2_root= %d\n",vec_root,list2_root); */
		break;
	   }
	}
	else {
	   list1_root = caric_root;
	     /* If doing K-L on original data, not caric */
	   if (mean_ptr == NULL)
	      list1_root = vec_root;
	   list2_root = vec_root;
	}


	if (kl_decompose_handler(list1_root) < 0)
	   return(-1);

	if (yes_no("Compute eigenfunctions?"))
	   kl_efns_handler(list2_root);

	window_pos_handler(window_pos_mode);
}
/*--------------------------------------------------------------------*/
kl_decompose_handler(list_root)
vec_struct *list_root;
{
	if (compute_cov(list_root) < 0) 
	   return(-1);

	if (kl_compute_eig() >= 0) {
	   update_eigvals_win();
	   return(1);
	}
	else
	   return(-1);
}
/*--------------------------------------------------------------------*/
/* This routine also called from svd.c */
kl_efns_handler(list_root)
vec_struct *list_root;
{
extern int	cur_eigfn;
extern win_struct	eigfn_win;

/*	printf("----------------- kl_efns_handler -----------\n"); */
	cur_eigfn = 1;

	kl_compute_eigfns(num_eig,list_root);

	   /* determine if the window is already displayed */
	if (eigfn_win.id < 0) 
	   create_eigfn_win();

	setup_eigfn_win(cur_eigfn);

	redraw_eigfn(cur_eigfn);
}
/*------------------------------------------------------------*/
interp_eigfn_handler()
{
	int neig;
	char buf[80];
extern int	cur_eigfn;
extern win_struct	eigfn_win;
extern int	scan_eigfn_win;

	   /* toggle it */
	interp_eigfn_flag = 1 - interp_eigfn_flag;
	if (!interp_eigfn_flag)
	   return(1);

/*	create_interp_pts(); */

	neig = get_pos_integer("Enter # of eigfns (currently): ",num_eig);

	   /* Compute lookup table for Bernstein basis fns */
/*	cbbf(); */

	redraw_eigfn(cur_eigfn);
}
/*------------------------------------------------------------*/
/* Changing the maximum # of eigenvalues (fns) to compute & use
   (menu item in Eigvals window)  */
max_num_eig_handler()
{
	int neig,num_eigfns;
extern int	cur_eigfn;
extern int	scan_eigfn_win;
extern int	cmplx_flag;
extern int	num_vecs;
extern win_struct	eigfn_win;

	neig = get_pos_integer("Enter # of eigenvalues: ",0);

	if (neig > num_vecs) {
	   error_msg("Exceeds dim of covariance matrix.");
	   return(1);
	}

	num_eigfns = count_eigfns();

	/* Does this # exceed the number of eigfns already computed? */
	if (neig > num_eigfns) {

	   redraw_eigvals(neig);

	   if (yes_no("Compute eigenfunctions?")) {

	      if (cmplx_flag)
	         cmplx_kl_compute_eigfns(neig,cmplx_list2_root);
	      else
	         kl_compute_eigfns(neig,list2_root);

	      cur_eigfn = 1;

	        /* determine if the window is already displayed */
	      if (eigfn_win.id < 0) 
	         create_eigfn_win();

	      setup_eigfn_win(cur_eigfn);
	      redraw_eigfn(cur_eigfn);

	      if (scan_eigfn_win > 0)
		redraw_window(scan_eigfn_win);

	      num_eig = neig;
	   }
/*	   else {
	      if (eigfn_win.id > 0) {
	         cur_eigfn = neig;
	         setup_eigfn_win(cur_eigfn);
	         redraw_eigfn(cur_eigfn);
	         draw_scan_eigfn_win(cur_eigfn);
	      }
	   } */
	}
	else if (neig > 0) {

	   redraw_eigvals(neig);

	   cur_eigfn = 1;

	        /* determine if the window is already displayed */
	   if (eigfn_win.id < 0) 
	      create_eigfn_win();

	   setup_eigfn_win(cur_eigfn);
	   redraw_eigfn(cur_eigfn);

	   if (scan_eigfn_win > 0)
	      redraw_window(scan_eigfn_win);

	   num_eig = neig;
	}

/*	num_eig = neig;
	num_eig_max = neig; */
}
/*--------------------------------------------------------------------*/
/* Compute the covariance matrix:  typically done on caricatures */
compute_cov(list_root)
vec_struct *list_root;
{
	int res,i,m;
	vec_struct *vsp, *vsp2;
	double sum, *dp,*dp2, *Cp;
	double vec_dotprod();
	char msg[80];
extern int num_vecs;
extern int res_xy;
extern double *mean_ptr;


/*	if (mean_ptr == NULL) {
	   notify_user("Must compute Mean first");
	   return(-1);
	} */

/*	printf("------------------ begin compute_cov -------------------\n");

	printf("compute_cov: num_vecs= %d, res= %d\n", num_vecs,res_xy); */


	   /* NB!  Assuming num_vecs < vector resolution */

	if (cov_mtx != NULL) 
	   free(cov_mtx);

	cov_mtx = (double *)malloc(sizeof(double)*num_vecs*num_vecs);
	if (cov_mtx == NULL) alloc_fail();
	Cp = cov_mtx;

	pop_feedback();
	m=0;
	TRACE(vsp,list_root) {
	   dp = vsp->dp;

	   TRACE(vsp2,list_root) {
		dp2 = vsp2->dp;

		sum = vec_dotprod(dp,dp2);

		*Cp = sum;
		Cp++;
	   }
	   m++;
	   sprintf(msg,"Computing matrix... %d of %d", m,num_vecs);
	   feedback_msg(msg);
	}
/*	check_sym(cov_mtx,num_vecs); */
	push_feedback();
	return(1);
}
/*--------------------------------------------------------------------*/
/* debugging routine... */
check_sym(c,n)
double c[50][50];
{
   static double eps=0.0000001;
   int i,j;

   printf("checking symmetry of C (n=%d):-------\n",n);
   for (i=0; i<n; i++) {
   for (j=0; j<i; j++) {
      if ((c[i][j] - c[j][i]) > eps) {
	 printf("not %d,%d\n",i,j);
      }
   }
   }
}
/*--------------------------------------------------------------------*/
/* Compute eigenvalues/vectors of the (real) covariance matrix 
 *
 *  NB!  Assumes # of vectors < vector resolution
 */
kl_compute_eig()
{
	int i,n,ierr;
	double *ev;
	FILE *fp;
extern int num_vecs;

  printf("------------------ begin kl_compute_eig -------------------\n");

	if (eigvecs != NULL) {
	   free(eigvecs);
	   free(wrp);
/*	   free(wip); */
	   free(fv1);
	   free(fv2);
/*	   free(iv1); */
	}

	wrp = (double *)malloc(sizeof(double)*num_vecs);
	fv1 = (double *)malloc(sizeof(double)*num_vecs);
	fv2 = (double *)malloc(sizeof(double)*num_vecs);
	eigvecs = (double *)malloc(sizeof(double)*num_vecs*num_vecs);
	if (eigvecs == NULL) alloc_fail();


	pop_feedback();
	feedback_msg("computing eigenvalues/vectors of covariance...");

	n = num_vecs;
	   /* symm C -> real eigvals (hence, wi=0) */

		/* if using 'rg' in eispack (eig.f) */
	   /* eigenvalues returned in descending order */
/*	wip = (double *)malloc(sizeof(double)*num_vecs);
	iv1 = (int *)malloc(sizeof(int)*num_vecs);
	eig_(&n,cov_mtx,eigvecs,wrp,wip,iv1,fv1,&ierr); */

		/* if using 'rs' in eispack (eig2.f) */
	   /* eigenvalues returned in ascending order */
	eig_(&n,cov_mtx,eigvecs,wrp,fv1,fv2,&ierr);

	printf("kl_compute_eig:  ierr (from eigenval/vec calc) = %d\n", ierr);


	sum_eigvals = 0.0;
	for (i=0; i<num_vecs; i++) {
	   sum_eigvals += *(wrp+i);
/*	   printf("%d) %f\n", i,*(wrp+i)); */
	}
	if (sum_eigvals == 0.0) {
	   error_msg("You seem to have a steady-state case.");
	   return(-1);
	}

	eigvals = (double *)malloc(sizeof(double)*num_vecs);
	printf("     malloc'd eigvals...\n");
	ev = eigvals;
	  /* if ascending, reverse order to put largest eigvals at top */
	for (i=num_vecs-1; i>=0; i--) {
	  /* if descending... */
/*	for (i=0; i<num_vecs; i++) { */
	   *ev = *(wrp+i);
	   ev++;
	}

/*	printf("(double)evecs --> evecs.bin\n");
	fp = fopen("evecs.bin","w");
	fwrite(eigvecs,sizeof(double),num_vecs*num_vecs,fp);
	fclose(fp); */

	push_feedback();

	default_num_eig(num_vecs);
}
/*------------------------------------------------------------*/
kl_compute_eigfns(nefns,list_root)
int nefns;
vec_struct *list_root;
{
	int i,k,m;
	double *zp,vmin,vmax,factor;
	double vec_dotprod();
	char msg[80];
	FILE *fp;
	vec_struct *vsp, *usp, *usp2;
	double *vdp, *udp, *alloc_vector();
extern int res_xy;
extern int polar_flag;
extern int num_vecs;
extern int decompose_method;
extern int vec_flag;


	if (eigvecs == NULL) {
	   notify_user("Must do decomposition first(kl_compute_eigfns)");
	   return(-1);
	}
	if (list_root == NULL) {
	    printf("kl_compute_eigfns: ERROR - list_root = NULL(kl_compute_eigfns)\n");
	    return(-1);
	}

/*	printf("-----------------begin kl_compute_eigfns ------------------\n");
	printf("nefns = %d\n", nefns);
	printf("num_vecs = %d\n", num_vecs);
	printf("res_xy = %d\n", res_xy); */

	k=0;
	TRACE(usp,u_root) {
	   free(usp->dp);
	   free(usp);
	   k++;
	}
	printf("  freed %d records\n", k);

	printf(" vec_resolution = %d\n", res_xy);

	pop_feedback();

/*	fp = fopen("efns.bin","w"); */


	   /* Compute desired number of efns */
	for (k=0; k<nefns; k++) {

	   if (k==0) {
		usp = NEW(vec_struct,sizeof(vec_struct));
		u_root = usp;
		u_root->prev = NULL;
		u_root->next = NULL;
	   }
	   else {
		usp2 = NEW(vec_struct,sizeof(vec_struct));
		usp2->next = NULL;
		usp->next = usp2;
		usp = usp2;
	   }
		   /* allocate space for eigenfunction */
	   udp = alloc_vector();
	   usp->dp = udp;


		/* pointer to eigenvectors of covariance mtx */
		/* (or, singular vector from SVD)           */

	   if (decompose_method == 1)	/* K-L */
	      /* using 'rg' which semisorts eigvals/vecs in descending order */
/*	      zp = eigvecs + k*num_vecs; */
	      /* using 'rs' which sorts eigvals/vecs in ascending order */
	      zp = eigvecs + (num_vecs-1-k)*num_vecs;
	   else if (decompose_method == 2)	/* SVD */
	      zp = eigvecs + k*num_vecs;


	      /* zero the eigenfn */
	   vec_zero(udp);

		/* zero eigenvalue -> zero eigfn ? */
	   if (*(eigvals+k) < 0.00001)
	      continue;

/*	   minmax_d(zp,num_vecs,&vmin,&vmax);
	   printf("%d) evec min,max = %.6e %.6e\n", k,vmin,vmax); */

	      /* Compute the eigenfn: SUM(m=1,M): vec[m] * phi[m]  */

		/*---- Should we normalize??? -----*/
		/* if so, do it one time on eigvecs */
/*	   minmax_d(zp,num_vecs,&vmin,&vmax);
	   printf("evec min,max = %.6e %.6e\n", vmin,vmax);
	   normalize_vd(zp,num_vecs);
	   minmax_d(zp,num_vecs,&vmin,&vmax);
	   printf("norm'd evec min,max = %.6e %.6e\n", vmin,vmax); */

	   sprintf(msg,"Computing eigenfn #%d", k+1);
	   feedback_msg(msg);

	   m=0;
/*	   printf("  list_root->dp= %d\n", list_root->dp); */
	   TRACE(vsp,list_root) {	/* for all vectors in data */
/*	      printf("m= %d,  vsp= %d\n", m,vdp); */
	      vdp = vsp->dp;
	      if (vdp == NULL) {
		 printf("ERROR ---vdp = NULL!!!\n");
		 return(-1);
	      }
/*	      printf("vdp= %d\n", vdp); */


		/* ----------------------------------------------
		   The eigenfunction:
		   the computation we've all been waiting for!!!
		   ---------------------------------------------- */
	      factor = *(zp+m);

	      if (!vec_flag)
	        for (i=0; i<res_xy; i++) 
	 	  *(udp+i) +=  *(vdp+i) * factor;
	      else
	        for (i=0; i<res_xy*2; i++) 
	 	  *(udp+i) +=  *(vdp+i) * factor;
	      m++;
	   }

		/* To write out eigfns to a file (as default?) */
/*	   file_eigfns(udp,fp); */
/*	   if (polar_flag) {
	   map01_vd(udp,res_xy);
	   vec_minmax(udp,&vmin,&vmax);
	   printf("   efn %d min,max = %.4e %.4e\n", k+1,vmin,vmax);
	   } */
	}

/*	fclose(fp); */

	push_feedback();
}
/*------------------------------------------------------------*/
default_num_eig(nvals)
int nvals;
{
	int i;
	float pct;
	double er,ei, pctsum;


	printf("default_num_eig:------- nvals = %d -------------\n",nvals);
	num_eig = 1;
	pctsum = 0.0;

	if (pct_table != NULL) free(pct_table);
	if (pctsum_table != NULL) free(pctsum_table);

	pct_table = (float *)malloc(sizeof(float)*nvals);
	pctsum_table = (float *)malloc(sizeof(float)*nvals);

	if (eigvals == NULL) {
	  printf("    ERROR: eigvals = NULL, exiting...\n");
	  exit(-1);
	}

	for (i=0; i<nvals; i++) {
	   er = *(eigvals+i);
	   pct = er/sum_eigvals;
	   pctsum += pct;
	   if (i < MAXEFN) {
	      *(pct_table+i) = pct;
	      *(pctsum_table+i) = pctsum;
	   }
	   if (pctsum < DPCT) {
	      num_eig++;
	      if (num_eig < 20)
	        printf("%3d) %15.2f, %6.4f     %3.0f\n", i+1,er,ei,pctsum*100);
	   }
	}

/*	num_eig_max = num_eig; */

	printf("num_eig (for %3.0f%%) = %d\n", DPCT*100,num_eig);
	printf("------------------------\n");
}
/*------------------------------------------------------------*/
file_eigfns(efp,fp)
double *efp;
FILE *fp;
{
	int i,j;
	double *v,p[3];
extern int dimension,res_x,res_y;

	if (dimension == 1)
	   fwrite(efp,sizeof(double),res_x,fp);
	else {
	   v = efp;
	   for (j=0; j>(-res_y); j--) {
	   p[Z] = j;
	   for (i=0; i<res_x; i++) {
		p[X] = i;
		p[Y] = *v;
		fwrite(p,sizeof(double),3,fp);
	   	v++;
	   }
	   }
	}
}
/*------------------------------------------------------------*/
check_orthog()
{
	vec_struct *usp,*vsp;
	double vec_dotprod();
	double dotp;
	int i,j;
extern int cmplx_flag;

	if (cmplx_flag) {
	   printf("not available for complex vecs...\n");
	   return(-1);
	}

	i = 0;
	printf("dot_prod of eigfns --------------\n");
	TRACE(usp,u_root) {
	   j=0;
	   printf("---------\n");
	   TRACE(vsp,u_root) {
	      dotp = vec_dotprod(usp->dp,vsp->dp);
	      printf(" <%d,%d>= %e\n",i,j,dotp);
	      j++;
	   }
	   i++;
	}
}
/*------------------------------------------------------------*/
alloc_fail()
{
	printf("memory allocation failure!!!\n");
	exit(1);
}
