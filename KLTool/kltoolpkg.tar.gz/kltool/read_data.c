/* read_data.c - handle reading of initial dataset
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include "kl_str.h"
#include "utio.h"


UTFILE	*utin;
UTTYPE	intype = FLOATS;	/* type of input file - default float */


/*--------------------------------------------------------------------*/
read_all_data(fp)
FILE *fp;
{
    int i,j,nvals;
    double t0,tval,tdel;
    double *s, *dp, *alloc_vector();
    vec_struct *vsp, *vsp2;
    char msg[80];
    UTBUF	*buf;		/* input buffer */
extern int num_vecs;
extern int dimension,res_xy,file_res_y;
extern int x_start,x_stop,y_start,y_stop;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern vec_struct *vec_root;
extern int cmplx_flag, vec_flag, ncontours;


    if (cmplx_flag) {
       i = read_all_cmplx_data(fp);
       return(i);
    }
    if (vec_flag) {
       i = read_all_vec_data(fp);
       return(i);
    }
    if (ncontours) {
       i = read_all_contour_data(fp);
       return(i);
    }

    ymin = HUGE;
    ymax = -HUGE;

/*    printf("-----------------  begin read_all_data  -------------\n"); */
    printf("res_xy = %d\n", res_xy);

    empty_all_lists();

    vec_root = NEW(vec_struct,sizeof(vec_struct));
    vec_root->prev = NULL;
    vec_root->next = NULL;
    vsp = vec_root;

    dp = alloc_vector();

    vsp->dp = dp;

    num_vecs = 0;
    t0 = tval = 0.0;
    tdel = 1.0;


    set_utio_data_type();

    utin = utgetfile(fp, intype);
    buf = utgetbuf(DOUBLES);

    pop_feedback();

    switch (dimension) {
    case 1:

	nvals = 1;
	while (nvals > 0) {

	   nvals = utreadvec(buf, res_xy, utin);
/*	   printf("nvals = %d\n", nvals); */

	   if (nvals < 0)
	      break;
	   else if (nvals != res_xy) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;
/*	   printf("s = %d\n", s); */

	   if (num_vecs > 0) {
	    vsp2 = NEW(vec_struct,sizeof(vec_struct));
	    vsp2->next = NULL;
	    vsp2->prev = vsp;
	    vsp->next = vsp2;
	    vsp = vsp2;
	    dp = alloc_vector();
	    vsp->dp = dp;
	   }

	   for (i=0; i<res_xy; i++) {
	      *(dp+i) = *(s+i);
	   }
	   extrema_vec(dp,res_xy);

	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);

	   tval -= tdel;	/* for Landscape display of 1-D vectors */
	}

	tval += tdel;
/*	printf("tval = %f\n", tval); */

	zmin = t0;
	zmax = tval;

	break;


    case 2:

	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, res_xy, utin);

	   if (nvals < 0)
	      break;
	   else if (nvals != res_xy) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	      vsp2 = NEW(vec_struct,sizeof(vec_struct));
	      vsp2->next = NULL;
	      vsp2->prev = vsp;
	      vsp->next = vsp2;
	      vsp = vsp2;
	      dp = alloc_vector();
	      vsp->dp = dp;
   	   }
	   for (i=0; i<res_xy; i++) {
	      *(dp+i) = *(s+i);
	   }
	   extrema_vec(dp,res_xy);

	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	}

	zmin = 0.0;
	if (y_stop > 0) 
	   zmax = -y_stop + y_start;
	else
	   zmax = -file_res_y + y_start;

	break;

    }	/* end switch */



    if (num_vecs == 0) {
	read_error(2);
/*	notify_user("Error - read 0 vectors."); */
	return(-1);
    }

/*    printf("%d vecs...\n", num_vecs); */
exit:
    push_feedback();
    fclose(fp);
}

/*--------------------------------------------------------------------*/
read_all_cmplx_data(fp)
FILE *fp;
{
    int i,j,k,m,nvals;
    double t0,tval,tdel;
    double *s,*dp,*drp,*dip, *alloc_vector();
    cmplx_vec_struct *cvsp, *cvsp2;
    vec_struct *vsp,*vsp2;
    char msg[80];
    UTBUF	*buf;		/* input buffer */
extern int num_vecs;
extern int dimension,res_xy,file_res_y;
extern int x_start,x_stop,y_start,y_stop;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern vec_struct *vec_root;
extern int cmplx_flag;
extern cmplx_vec_struct *cmplx_vec_root;


    empty_all_lists();

    vec_root = NEW(vec_struct,sizeof(vec_struct));
    vec_root->prev = NULL;
    vec_root->next = NULL;
    vsp = vec_root;
    dp = alloc_vector();
    vsp->dp = dp;


    cmplx_vec_root = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
    cmplx_vec_root->prev = NULL;
    cmplx_vec_root->next = NULL;
    cvsp = cmplx_vec_root;

    drp = alloc_vector();
    cvsp->drp = drp;
    dip = alloc_vector();
    cvsp->dip = dip;


    num_vecs = 0;
    k = 0;
    t0 = tval = 0.0;
    tdel = 1.0;


    set_utio_data_type();

    utin = utgetfile(fp, intype);
    buf = utgetbuf(DOUBLES);

    pop_feedback();

    switch (dimension) {
    case 1:

	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, res_xy*2, utin);
/*	   printf("nvals = %d\n", nvals); */

	   if (nvals < 0)
	      break;
	   else if (nvals != res_xy*2) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	    vsp2 = NEW(vec_struct,sizeof(vec_struct));
	    vsp2->next = NULL;
	    vsp2->prev = vsp;
	    vsp->next = vsp2;
	    vsp = vsp2;
	    dp = alloc_vector();
	    vsp->dp = dp;

	    cvsp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	    cvsp2->next = NULL;
	    cvsp2->prev = cvsp;
	    cvsp->next = cvsp2;
	    cvsp = cvsp2;
	    drp = alloc_vector();
	    cvsp->drp = drp;
	    dip = alloc_vector();
	    cvsp->dip = dip;
	   }

	   for (i=0; i<res_xy; i++) {
	      *(drp+i) = *s;
	      s++;
	      *(dip+i) = *s;
	      s++;
/*	      if (num_vecs==0) printf("%d) %f %f\n", i,*(drp+i),*(dip+i)); */
	   }
	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);

	   tval -= tdel;	/* for Landscape display of 1-D vectors */
	}

	tval += tdel;

	zmin = t0;
	zmax = tval;

	break;


    case 2:
	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, res_xy*2, utin);

	   if (nvals < 0)
	      break;
	   else if (nvals != res_xy) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	    vsp2 = NEW(vec_struct,sizeof(vec_struct));
	    vsp2->next = NULL;
	    vsp2->prev = vsp;
	    vsp->next = vsp2;
	    vsp = vsp2;
	    dp = alloc_vector();
	    vsp->dp = dp;

	    cvsp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	    cvsp2->next = NULL;
	    cvsp2->prev = cvsp;
	    cvsp->next = cvsp2;
	    cvsp = cvsp2;
	    drp = alloc_vector();
	    cvsp->drp = drp;
	    dip = alloc_vector();
	    cvsp->dip = dip;
	   }

	   for (i=0; i<res_xy; i++) {
	      *(drp+i) = *s;
	      s++;
	      *(dip+i) = *s;
	      s++;
	   }
	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	}

	zmin = 0.0;
	if (y_stop > 0) 
	   zmax = -y_stop + y_start;
	else
	   zmax = -file_res_y + y_start;

	break;

    }	/* end switch */

    update_cmplx_data_form();

exit:
    push_feedback();
    fclose(fp);
}
/*--------------------------------------------------------------------*/
cmplx_extrema(root)
vec_struct *root;
{
	int i,j,k;
	vec_struct *vsp;
	double *dp;
extern float ymin,ymax;
extern vec_struct *vec_root;
extern int res_xy;

	k=0;
	ymin = HUGE;
	ymax = -HUGE;
	TRACE(vsp,root) {
	     extrema_vec(vsp->dp,res_xy);
	}
}
/*--------------------------------------------------------------------*/
read_all_vec_data(fp)
FILE *fp;
{
    int i,j,nvals,vecsize;
    double t0,tval,tdel;
    double *s, *dp, *alloc_vector();
    vec_struct *vsp, *vsp2;
    char msg[80];
    UTBUF	*buf;		/* input buffer */
extern int num_vecs;
extern int dimension,res_xy,file_res_y;
extern int x_start,x_stop,y_start,y_stop;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern vec_struct *vec_root;

/*    printf("-----------------  begin read_all_vec_data  -------------\n");
    printf("res_xy = %d\n", res_xy); */


/*    ymin = HUGE;
    ymax = -HUGE; */

    ymin = 0.0;
    if (y_stop > 0) 
	   ymax = y_stop - y_start;
    else
	   ymax = file_res_y - y_start;

    empty_all_lists();

    vec_root = NEW(vec_struct,sizeof(vec_struct));
    vec_root->prev = NULL;
    vec_root->next = NULL;
    vsp = vec_root;

    dp = alloc_vector();

    vsp->dp = dp;

    num_vecs = 0;
    t0 = tval = 0.0;
    tdel = 1.0;

    set_utio_data_type();

    utin = utgetfile(fp, intype);
    buf = utgetbuf(DOUBLES);

    pop_feedback();

    switch (dimension) {
    case 1:

	error_msg("Vector data only for 2D data.");
	goto exit;
	break;

    case 2:

	vecsize = res_xy*2;
	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, vecsize, utin);

	   if (nvals < 0)
	      break;
	   else if (nvals != vecsize) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	      vsp2 = NEW(vec_struct,sizeof(vec_struct));
	      vsp2->next = NULL;
	      vsp2->prev = vsp;
	      vsp->next = vsp2;
	      vsp = vsp2;
	      dp = alloc_vector();
	      vsp->dp = dp;
   	   }
	   for (i=0; i<vecsize; i++) {
	      *(dp+i) = *(s+i);
	   }
/*	   extrema_vec(dp,res_xy); */

	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	}

	zmin = 0.0;
	if (y_stop > 0) 
	   zmax = -y_stop + y_start;
	else
	   zmax = -file_res_y + y_start;

	break;

    }	/* end switch */



    if (num_vecs == 0) {
	read_error(2);
	notify_user("Error - read 0 vectors.");
	return(-1);
    }

/*    printf("%d vecs...\n", num_vecs); */
exit:
    push_feedback();
    fclose(fp);
}
/*--------------------------------------------------------------------*/
read_all_contour_data(fp)
FILE *fp;
{
    int i,j,k,m,nvals,vecsize;
    double t0,tval,tdel;
    double *s,*dp,*drp,*dip, *alloc_vector();
    vec_struct *vsp,*vsp2;
    char msg[80];
    UTBUF	*buf;		/* input buffer */
extern int num_vecs;
extern int dimension,res_x,res_xy,file_res_y;
extern int x_start,x_stop,y_start,y_stop;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern vec_struct *vec_root;
extern int ncontours;


    empty_all_lists();

    vec_root = NEW(vec_struct,sizeof(vec_struct));
    vec_root->prev = NULL;
    vec_root->next = NULL;
    vsp = vec_root;
    dp = alloc_vector();
    vsp->dp = dp;

    num_vecs = 0;
    k = 0;
    t0 = tval = 0.0;
    tdel = 1.0;


    set_utio_data_type();

    utin = utgetfile(fp, intype);
    buf = utgetbuf(DOUBLES);

    pop_feedback();

    switch (dimension) {
    case 1:
	vecsize = res_x*ncontours*2;
	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, vecsize, utin);

	   if (nvals < 0)
	      break;
	   else if (nvals != vecsize) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	      vsp2 = NEW(vec_struct,sizeof(vec_struct));
	      vsp2->next = NULL;
	      vsp2->prev = vsp;
	      vsp->next = vsp2;
	      vsp = vsp2;
	      dp = alloc_vector();
	      vsp->dp = dp;
   	   }
	   for (i=0; i<vecsize; i++) {
	      *(dp+i) = *(s+i);
	   }
	   extrema_contour_vec(dp,res_x*ncontours);

	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	}

	zmin = 0.0;
	if (y_stop > 0) 
	   zmax = -y_stop + y_start;
	else
	   zmax = -file_res_y + y_start;

	break;

    case 2:
	error_msg("Contours only for 1D data.");
	goto exit;
	break;

    }	/* end switch */

exit:
    push_feedback();
    fclose(fp);
}
/*--------------------------------------------------------------------*/
set_utio_data_type()
{
extern char input_format;


	switch(input_format) {
	case 'a':		/* ascii */
	   intype = ASCII;
	   break;

			/* binary */
	case 'b':		/* C bytes */
	   intype = BYTES;
	   break;
	case 's':		/* C shorts  */
	   intype = SHORTS;
	   break;
	case 'i':		/* C ints  */
	   intype = INTS;
	   break;
	case 'f':		/* C floats */
	   intype = FLOATS;
	   break;
	case 'd':		/* C doubles */
	   intype = DOUBLES;
	   break;

	case 'S':		/* Fortran Short */
	   intype = SHORTF;
	   break;
	case 'I':		/* Fortran Int */
	   intype = INTF;
	   break;
	case 'F':		/* Fortran Float */
	   intype = FLOATF;
	   break;
	case 'D':		/* Fortran Double */
	   intype = DOUBLEF;
	   break;
	}
}
/*--------------------------------------------------------------------*/
read_selected_data(fp)
FILE *fp;
{
    int i,j,x_last,y_last,vec_size,nvals;
    double t0,tval,tdel;
    double *s, *dp, *alloc_vector();
    vec_struct *vsp, *vsp2;
    char msg[80];
    UTBUF	*buf;		/* input buffer */
extern int num_vecs;
extern int dimension,file_res_x,file_res_y;
extern float ymin,ymax,zmin,zmax;
extern int x_start,x_stop,y_start,y_stop,t_start,t_stop;
extern int res_x,res_y,res_xy;
extern vec_struct *vec_root;
extern int cmplx_flag;
extern cmplx_vec_struct *cmplx_vec_root;


    printf("-----------  begin read_selected_data  ------------\n"); 
    printf("res_xy = %d\n", res_xy); 

    if (cmplx_flag) {
       i = read_selected_cmplx_data(fp);
       return(i);
    }

    ymin = HUGE;
    ymax = -HUGE;

    if (x_stop > file_res_x) {
	   notify_user("Error - (Selective) x1 > (Resolution) x.");
	   return(-1);
    }
    if ( (dimension > 1) && (y_stop > file_res_y) ) {
	   notify_user("Error - (Selective) y1 > (Resolution) y.");
	   return(-1);
    }

    empty_all_lists();

    vec_root = NEW(vec_struct,sizeof(vec_struct));
    vec_root->prev = NULL;
    vec_root->next = NULL;
    vsp = vec_root;

    dp = alloc_vector();

    vsp->dp = dp;

    num_vecs = 0;
    t0 = tval = 0.0;
    tdel = 1.0;


    if (x_stop == 0) 
	x_last = file_res_x;
    else 
	x_last = x_stop;
/*    printf("x_last = %d\n", x_last); */


    if (y_stop == 0)
	y_last = file_res_y;
    else
	y_last = y_stop;
/*    printf("y_last = %d\n", y_last); */


    vec_size = file_res_x * file_res_y;

    printf("vec_size = %d, t_start = %d\n", vec_size,t_start);


    set_utio_data_type();

    utin = utgetfile(fp, intype);
    buf = utgetbuf(DOUBLES);

    pop_feedback();

		/* ----- Skip over unwanted vectors (in time) ----- */
    for(i=1; i<t_start; i++) {
	   sprintf(msg,"skipping %d vectors...",i);
	   feedback_msg(msg);
	   nvals = utreadvec(buf, vec_size, utin);
	   if (nvals < 0)
	      break;
	   else if (nvals != vec_size) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }
    }



    switch (dimension) {
    case 1:

	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, vec_size, utin);
/*	   printf("nvals = %d\n", nvals); */

	   if (nvals < 0)
	      break;
	   else if (nvals != vec_size) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	      vsp2 = NEW(vec_struct,sizeof(vec_struct));
	      vsp2->next = NULL;
	      vsp2->prev = vsp;
	      vsp->next = vsp2;
	      vsp = vsp2;
	      dp = alloc_vector();
	      vsp->dp = dp;
	   }

		/* ----- Skip over unwanted portion (in space) ----- */
	   for (i=1; i<x_start; i++)
	      s++;

		/* ----- Save desired portion ----- */
	   for (i=x_start; i<=x_last; i++) {
	      *dp = *s;
	      dp++;
	      s++;
	   }
	   extrema_vec(vsp->dp,res_xy);

	   if ((t_stop > 0) && ((num_vecs+t_start) > t_stop)) {
	      vsp->prev->next = NULL;
	      break;
	   }
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	   num_vecs++;

	   tval -= tdel;
        }

	tval += tdel;

	zmin = t0;
	zmax = tval;

	break;

    case 2:
	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, vec_size, utin);

	   if (nvals < 0)
	      break;
	   else if (nvals != vec_size) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	      vsp2 = NEW(vec_struct,sizeof(vec_struct));
	      vsp2->next = NULL;
	      vsp2->prev = vsp;
	      vsp->next = vsp2;
	      vsp = vsp2;
	      dp = alloc_vector();
	      vsp->dp = dp;
	   }

		/* ----- Skip over unwanted portion (in space) ----- */
	   for (j=1; j<y_start; j++)
	      s += file_res_x;

	   for (j=y_start; j<=y_last; j++) {
	     for (i=1; i<x_start; i++)
	       s++;

		/* ----- Save desired portion ----- */
	     for (i=x_start; i<=x_last; i++) {
	       *dp = *s;
	       dp++;
	       s++;
	     }
	     for (i=x_last+1; i<=file_res_x; i++)
	       s++;
	   }
	   extrema_vec(vsp->dp, res_xy);

	   if ((t_stop > 0) && ((num_vecs+t_start) > t_stop)) {
	      vsp->prev->next = NULL;
	      break;
	   }
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	   num_vecs++;

	}	/* end while */

	break;

    }	/* end switch */



    if (num_vecs == 0) {
	read_error(7);
	notify_user("Error - read 0 vectors.");
    }

exit:
    printf("%d vecs...\n", num_vecs);
    push_feedback();
    fclose(fp);

    if (t_stop > num_vecs) 
      t_stop = num_vecs;
}
/*--------------------------------------------------------------------*/
read_selected_cmplx_data(fp)
FILE *fp;
{
    int i,j,k,m,nvals,x_last,y_last,vec_size;
    double t0,tval,tdel;
    double *s,*dp,*drp,*dip, *alloc_vector();
    cmplx_vec_struct *cvsp, *cvsp2;
    vec_struct *vsp,*vsp2;
    char msg[80];
    UTBUF	*buf;		/* input buffer */
extern int num_vecs;
extern int dimension,file_res_x,file_res_y,res_xy;
extern int x_start,x_stop,y_start,y_stop;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern int x_start,x_stop,y_start,y_stop,t_start,t_stop;
extern vec_struct *vec_root;
extern int cmplx_flag;
extern cmplx_vec_struct *cmplx_vec_root;



    ymin = HUGE;
    ymax = -HUGE;

    if (x_stop > file_res_x) {
	   notify_user("Error - (Selective) x1 > (Resolution) x.");
	   return(-1);
    }
    if ( (dimension > 1) && (y_stop > file_res_y) ) {
	   notify_user("Error - (Selective) y1 > (Resolution) y.");
	   return(-1);
    }

    empty_all_lists();


    if (x_stop == 0) 
	x_last = file_res_x;
    else 
	x_last = x_stop;

    if (y_stop == 0)
	y_last = file_res_y;
    else
	y_last = y_stop;


    vec_size = file_res_x * file_res_y * 2;


    vec_root = NEW(vec_struct,sizeof(vec_struct));
    vec_root->prev = NULL;
    vec_root->next = NULL;
    vsp = vec_root;
    dp = alloc_vector();
    vsp->dp = dp;


    cmplx_vec_root = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
    cmplx_vec_root->prev = NULL;
    cmplx_vec_root->next = NULL;
    cvsp = cmplx_vec_root;

    drp = alloc_vector();
    cvsp->drp = drp;
    dip = alloc_vector();
    cvsp->dip = dip;


    num_vecs = 0;
    k = 0;
    t0 = tval = 0.0;
    tdel = 1.0;


    set_utio_data_type();

    utin = utgetfile(fp, intype);
    buf = utgetbuf(DOUBLES);

    pop_feedback();

		/* ----- Skip over unwanted vectors (in time) ----- */
    for(i=1; i<t_start; i++) {
	   sprintf(msg,"skipping %d vectors...",i);
	   feedback_msg(msg);
	   nvals = utreadvec(buf, vec_size, utin);
	   if (nvals < 0)
	      break;
	   else if (nvals != vec_size) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }
    }

    switch (dimension) {
    case 1:

	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, vec_size, utin);
/*	   printf("nvals = %d\n", nvals); */

	   if (nvals < 0)
	      break;
	   else if (nvals != vec_size) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	    vsp2 = NEW(vec_struct,sizeof(vec_struct));
	    vsp2->next = NULL;
	    vsp2->prev = vsp;
	    vsp->next = vsp2;
	    vsp = vsp2;
	    dp = alloc_vector();
	    vsp->dp = dp;

	    cvsp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	    cvsp2->next = NULL;
	    cvsp2->prev = cvsp;
	    cvsp->next = cvsp2;
	    cvsp = cvsp2;
	    drp = alloc_vector();
	    cvsp->drp = drp;
	    dip = alloc_vector();
	    cvsp->dip = dip;
	   }

		/* ----- Skip over unwanted portion (in space) ----- */
	   for (i=1; i<x_start; i++) {
	      s++; s++;
	   }

		/* ----- Save desired portion ----- */
	   for (i=x_start; i<=x_last; i++) {
	      *drp = *s;
	      s++;
	      *dip = *s;
	      s++;
	      drp++;
	      dip++;
	   }

	   if ((t_stop > 0) && ((num_vecs+t_start) > t_stop)) {
	      cvsp->prev->next = NULL;
	      vsp->prev->next = NULL;
	      break;
	   }

	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);

	   tval -= tdel;	/* for Landscape display of 1-D vectors */
	}

	tval += tdel;

	zmin = t0;
	zmax = tval;

	break;


    case 2:
	nvals = 1;
	while (nvals > 0) {
	   nvals = utreadvec(buf, vec_size, utin);

	   if (nvals < 0)
	      break;
	   else if (nvals != vec_size) {
	      sprintf(msg,"read error %d (vector %d)",nvals,num_vecs);
	      error_msg(msg);
	      goto exit;
	   }

	   s = (double *)buf->data;

	   if (num_vecs > 0) {
	    vsp2 = NEW(vec_struct,sizeof(vec_struct));
	    vsp2->next = NULL;
	    vsp2->prev = vsp;
	    vsp->next = vsp2;
	    vsp = vsp2;
	    dp = alloc_vector();
	    vsp->dp = dp;

	    cvsp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	    cvsp2->next = NULL;
	    cvsp2->prev = cvsp;
	    cvsp->next = cvsp2;
	    cvsp = cvsp2;
	    drp = alloc_vector();
	    cvsp->drp = drp;
	    dip = alloc_vector();
	    cvsp->dip = dip;
	   }

		/* ----- Skip over unwanted portion (in space) ----- */
	   for (j=1; j<y_start; j++)
	      s += file_res_x*2;

	   for (j=y_start; j<=y_last; j++) {

	     for (i=1; i<x_start; i++) {
	       s++; s++;
	     }

		/* ----- Save desired portion ----- */
	     for (i=x_start; i<=x_last; i++) {
	       *drp = *s;
	       s++;
	       *dip = *s;
	       s++;
	       drp++;
	       dip++;
	     }

	     for (i=x_last+1; i<=file_res_x; i++) {
	       s++; s++;
	     }
	   }

	   if ((t_stop > 0) && ((num_vecs+t_start) > t_stop)) {
	      cvsp->prev->next = NULL;
	      vsp->prev->next = NULL;
	      break;
	   }

	   num_vecs++;
	   sprintf(msg,"%d vectors...",num_vecs);
	   feedback_msg(msg);
	}

	zmin = 0.0;
	if (y_stop > 0) 
	   zmax = -y_stop + y_start;
	else
	   zmax = -file_res_y + y_start;

	break;

    }	/* end switch */

exit:
    update_cmplx_data_form();
    push_feedback();
    fclose(fp);

    if (t_stop > num_vecs) 
      t_stop = num_vecs;
}
