/* banner.c -
 *
 */

#include <stdio.h>
#include <gl.h>
#include <fmclient.h>

fmfonthandle   smallfont, mediumfont, largefont;
Boolean foundfont=0;

banner_handler()
{
	char sbuf[80];
	float x,y,ydel;
	FILE *fp;
extern int banner_win;

	if ((fp = fopen("banner.text","r")) == NULL) {
	   printf("ERROR: banner.text not found\n");
	   return(-1);
	}

	create_banner_win();

/*	winset(banner_win); */
	color(BLACK);
	clear();

	color(WHITE);
/*	init_font(); */

/*	x = -0.5;
	y = 0.7;
	ydel = 0.3; */

	while (fscanf(fp,"%f %f %s",&x,&y,sbuf) != EOF) {
	   cmov2(x,y);
/*	   fmprstr(sbuf); */
	   charstr(sbuf);
	}
	fclose(fp);

	wait_for_mouse_button();
	color(BLACK);
	clear();
	winclose(banner_win);
}

/*-----------------------------------------------------------------*/
init_font()
{
    fminit();

    if ((smallfont=fmfindfont("TmsB")) == 0) {
        printf("Could not find font file\n");
        foundfont = 0;
    }
    else {
        foundfont = 1;
        largefont = fmscalefont(smallfont, 60.0); 
        mediumfont = fmscalefont(smallfont, 15.0); 
        fmsetfont(largefont);
    }
}
float fsqrt()
{}
