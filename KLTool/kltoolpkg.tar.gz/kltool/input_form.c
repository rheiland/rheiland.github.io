/* input_form.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdlib.h>
#include "kl_str.h"
#include "data_types.h"
#include "forms.h"

static FL_FORM *input_form;
static FL_OBJECT *data_type_obj[5],*complex_choice;
static FL_OBJECT *polar_rmin_obj,*polar_rmax_obj,
		 *vec_scale_obj,*contours_num_obj;
static FL_OBJECT *ascii_obj, *binary_obj;
static FL_OBJECT *binary_C,*binary_ftn;
static FL_OBJECT *oned_obj,*twod_obj, *yres_obj;
static FL_OBJECT *xstart_obj, *xstop_obj;
static FL_OBJECT *ystart_obj, *ystop_obj;
static FL_OBJECT *tstart_obj, *tstop_obj;
static FL_OBJECT *ok_obj, *cancel_obj;
static FL_OBJECT *save_obj;

static int color1 = 40;
static int color2 = 54;


  /* Declare globals */
char input_dir[256], input_file[128];
int dimension,file_res_x,file_res_y, res_x,res_y,res_xy;
int polar_flag, cmplx_flag, vec_flag, ncontours;
int data_type_flag;
float polar_rmin,polar_rmax,polar_range;
float vec_scale;
char input_format = 'f';

extern int x_start,x_stop,y_start,y_stop,t_start,t_stop;

/* rf. set_utio_data_type() in read_data.c  */
static char C_binary_types[] = {'s','i','f','d'};
static char ftn_binary_types[] = {'I','F','D'};
static char *binary_C_type[] = {"short","int","float","double"};
static char *binary_ftn_type[] = {"INTEGER","REAL","DOUBLE"};


/*------------------------------------------*/
void update_input_dir(FL_OBJECT *obj,long arg)
{
  strcpy(input_dir,fl_get_input(obj));
  printf("updating input_dir --> %s\n",input_dir);
}
/*------------------------------------------*/
void update_input_file(FL_OBJECT *obj,long arg)
{
  strcpy(input_file,fl_get_input(obj));
  printf("updating input_file --> %s\n",input_file);
}
/*------------------------------------------*/
void update_dim(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    dimension = 1;
    fl_hide_object(yres_obj);
    fl_hide_object(ystart_obj);
    fl_hide_object(ystop_obj);

    fl_show_object(data_type_obj[1]);	/* Polar */
    fl_set_button(data_type_obj[1],0);

    fl_show_object(data_type_obj[2]);	/* Complex */
    fl_set_button(data_type_obj[2],0);
  }
  else {
    dimension = 2;
    fl_show_object(yres_obj);
    fl_show_object(ystart_obj);
    fl_show_object(ystop_obj);

    fl_hide_object(data_type_obj[1]);	/* Polar */
    fl_hide_object(polar_rmin_obj);
    fl_hide_object(polar_rmax_obj);

    fl_hide_object(data_type_obj[2]);	/* Complex */
    fl_hide_object(complex_choice);
    if ((data_type_flag == POLAR) || (data_type_flag == COMPLEX)) {
      data_type_flag = RECT;
      fl_set_button(data_type_obj[data_type_flag],1);
      polar_flag = 0;
      cmplx_flag = 0;
    }
  }
}
/*------------------------------------------*/
void update_res(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    file_res_x = atoi(fl_get_input(obj));
    printf("updating file_res_x --> %d\n",file_res_x);
  }
  else {
    file_res_y = atoi(fl_get_input(obj));
    printf("updating file_res_y --> %d\n",file_res_y);
  }
}
/*------------------------------------------*/
void update_xrange(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    x_start = atoi(fl_get_input(obj));
    printf("updating x_start --> %d\n",x_start);
  }
  else {
    x_stop = atoi(fl_get_input(obj));
    printf("updating x_stop --> %d\n",x_stop);
  }
}
/*------------------------------------------*/
void update_yrange(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    y_start = atoi(fl_get_input(obj));
    printf("updating y_start --> %d\n",y_start);
  }
  else {
    y_stop = atoi(fl_get_input(obj));
    printf("updating y_stop --> %d\n",y_stop);
  }
}
/*------------------------------------------*/
void update_time_range(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    t_start = atoi(fl_get_input(obj));
  }
  else {
    t_stop = atoi(fl_get_input(obj));
  }
  printf("updating time range (vecs) --> [%d %d]\n",t_start,t_stop);
}
/*------------------------------------------*/
void update_data_type(FL_OBJECT *obj,long arg)
{

/*  printf("-------------------  update_data_type --------------\n"); */
  polar_flag = cmplx_flag = vec_flag = ncontours = 0;

  fl_hide_object(polar_rmin_obj);
  fl_hide_object(polar_rmax_obj);
  fl_hide_object(complex_choice);
  fl_hide_object(vec_scale_obj);
  fl_hide_object(contours_num_obj);

  if (arg == 0) {		/* rect */
    data_type_flag = RECT;
/*    fl_show_object(rect_scale); */
  }
  else if (arg == 1) {		/* polar */
    data_type_flag = POLAR;
    polar_flag = 1;
    fl_show_object(polar_rmin_obj);
    fl_show_object(polar_rmax_obj);
  }
  else if (arg == 2) {		/* complex */
    data_type_flag = COMPLEX;
    cmplx_flag = 1;
    fl_show_object(complex_choice);
  }
  else if (arg == 3) {		/* 2D vec */
    data_type_flag = VEC2D;
    vec_flag = 1;
    fl_show_object(vec_scale_obj);
  }
  else if (arg == 4) {		/* contours */
    data_type_flag = CONTOURS;
    ncontours = 1;
    if (dimension != 1) {
      dimension = 1;
      fl_set_button(oned_obj,1);
      fl_hide_object(yres_obj);
      fl_hide_object(ystart_obj);
      fl_hide_object(ystop_obj);
      fl_set_button(twod_obj,0);
    }
    fl_show_object(contours_num_obj);
  }
}
/*------------------------------------------*/
void update_complex_choice(FL_OBJECT *obj,long arg)
{
  cmplx_flag = fl_get_choice(complex_choice);
  printf("cmplx_flag = %d\n",cmplx_flag);
}
/*--------------------------------------------------------------------*/
set_binary_type()
{

  fl_set_choice(binary_ftn,0);
  fl_set_choice(binary_C,0);

  switch(input_format) {
	case 'a':	/* ascii */
	   break;

			/* binary */
	case 'b':		/* C bytes */
	   break;
	case 's':		/* C shorts  */
	   fl_set_choice(binary_C,1);
	   break;
	case 'i':		/* C ints  */
	   fl_set_choice(binary_C,2);
	   break;
	case 'f':		/* C floats */
	   fl_set_choice(binary_C,3);
	   break;
	case 'd':		/* C doubles */
	   fl_set_choice(binary_C,4);
	   break;

	case 'S':		/* Fortran Short */
	   break;
	case 'I':		/* Fortran Int */
	   fl_set_choice(binary_ftn,1);
	   break;
	case 'F':		/* Fortran Float */
	   fl_set_choice(binary_ftn,2);
	   break;
	case 'D':		/* Fortran Double */
	   fl_set_choice(binary_ftn,3);
	   break;
  }
}
/*------------------------------------------*/
void update_data_format(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    input_format = 'a';		/*  ascii */
    fl_hide_object(binary_C);
    fl_hide_object(binary_ftn);
  }
  else {				/* binary */
    fl_show_object(binary_C);
    fl_show_object(binary_ftn);
    if (input_format = 'a') input_format = 'f';
    set_binary_type();
  }
}
/*------------------------------------------*/
void update_binary_choice(FL_OBJECT *obj,long arg)
{
  int C_type,ftn_type;

  if (!arg) {
    C_type = fl_get_choice(binary_C);
    input_format = C_binary_types[C_type-1];
    fl_set_choice(binary_ftn,0);
  }
  else {
    ftn_type = fl_get_choice(binary_ftn);
    input_format = ftn_binary_types[ftn_type-1];
    fl_set_choice(binary_C,0);
  }
  printf("input_format = %c\n",input_format);
}
/*------------------------------------------*/
void update_polar_radii(FL_OBJECT *obj,long arg)
{

  if (!arg)
    polar_rmin = atof(fl_get_input(obj));
  else
    polar_rmax = atof(fl_get_input(obj));

  polar_range = polar_rmax - polar_rmin;
  data_extrema();
}
/*------------------------------------------*/
void update_vec_scale(FL_OBJECT *obj,long arg)
{
    vec_scale = atof(fl_get_input(obj));
    printf("vec_scale = %f\n",vec_scale);
}
/*------------------------------------------*/
void update_num_contours(FL_OBJECT *obj,long arg)
{
    ncontours = atoi(fl_get_input(obj));
}


/*--------------------------------------------------------------------*/
void make_input_form()
{
  FL_OBJECT *obj;
  FL_OBJECT *input_dir_obj;
  FL_OBJECT *input_file_obj;
  FL_OBJECT *xres_obj;
  FL_OBJECT *float_obj, *double_obj;
  float form_width,form_height;
  float yloc;
  char buffer[50];
  float ydel = 40.0;
  float height = 30.0;
  float x0,width,xsave[5],xdel;
extern char *cmplx_vec_spec[4];

  form_width = 650.0;
  form_height = 500.0;
  input_form = fl_bgn_form(FL_UP_BOX,form_width,form_height);

    yloc = form_height - 50.0;
    input_dir_obj = fl_add_input(FL_NORMAL_INPUT,100.0,yloc,500.0,height,
				"Input dir: ");
    fl_set_input(input_dir_obj,input_dir);
    fl_set_call_back(input_dir_obj,update_input_dir,0);
    fl_set_object_color(input_dir_obj,color1,color2);

    yloc -= ydel;
    input_file_obj = fl_add_input(FL_NORMAL_INPUT,100.0,yloc,500.0,height,
				"Input file:");
    fl_set_input(input_file_obj,input_file);
    fl_set_call_back(input_file_obj,update_input_file,0);
    fl_set_object_color(input_file_obj,color1,color2);

/*printf("      creating dim obj...\n"); */
    yloc -= ydel;
    fl_bgn_group();
/*      obj = fl_add_box(FL_UP_BOX,100.0,yloc,300.0,height,""); */
      obj = fl_add_box(FL_NO_BOX,100.0,yloc,300.0,height,"");
      fl_set_object_label(obj,"Dimension:");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
      oned_obj = fl_add_lightbutton(FL_RADIO_BUTTON,150.0,yloc,50.0,height,"1");
      twod_obj = fl_add_lightbutton(FL_RADIO_BUTTON,250.0,yloc,50.0,height,"2");
    fl_end_group();
    fl_set_call_back(oned_obj,update_dim,0);
    fl_set_call_back(twod_obj,update_dim,1);


/*printf("      creating res obj...\n"); */
    yloc -= ydel;
    x0 = 120.0;
    xdel = 110.0;
    xres_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,100.0,height,
				"Resolution:");
    if (file_res_x > 0) {
      sprintf(buffer,"%d",file_res_x);
    }
    else {
      sprintf(buffer,"");
    }
    fl_set_input(xres_obj,buffer);
    fl_set_object_color(xres_obj,color1,color2);
    fl_set_call_back(xres_obj,update_res,0);

    yres_obj = fl_add_input(FL_NORMAL_INPUT,x0+xdel,yloc,100.0,height,"");
    if (file_res_y > 0) 
      sprintf(buffer,"%d",file_res_y);
    else 
      sprintf(buffer,"");
    fl_set_input(yres_obj,buffer);
    fl_set_object_color(yres_obj,color1,color2);
    fl_set_call_back(yres_obj,update_res,1);

    yloc -= 4*ydel;
    fl_bgn_group();
      obj = fl_add_box(FL_NO_BOX,100.0,yloc+20,300.0,150.0,"");
      fl_set_object_label(obj,"Range:");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
    fl_end_group();

    yloc += 3*ydel;
    xstart_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,100.0,height,"");
      fl_set_object_label(xstart_obj,"x:");
      fl_set_object_color(xstart_obj,color1,color2);
      if (x_start > 0) 
        sprintf(buffer,"%d",x_start);
      else
        sprintf(buffer,"");
      fl_set_input(xstart_obj,buffer);
    fl_set_call_back(xstart_obj,update_xrange,0);

    xstop_obj = fl_add_input(FL_NORMAL_INPUT,x0+xdel,yloc,100.0,height,"");
      fl_set_object_color(xstop_obj,color1,color2);
      if (x_stop > 0) 
        sprintf(buffer,"%d",x_stop);
      else
        sprintf(buffer,"-");
/*      else {
        if (file_res_x > 0) 
          sprintf(buffer,"%d",file_res_x);
	else
          sprintf(buffer,"");
      } */
      fl_set_input(xstop_obj,buffer);
    fl_set_call_back(xstop_obj,update_xrange,1);

    yloc -= ydel;
    ystart_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,100.0,height,"");
      fl_set_object_label(ystart_obj,"y:");
      fl_set_object_color(ystart_obj,color1,color2);
      sprintf(buffer,"%d",y_start);
      fl_set_input(ystart_obj,buffer);

    ystop_obj = fl_add_input(FL_NORMAL_INPUT,x0+xdel,yloc,100.0,height,"");
      fl_set_object_color(ystop_obj,color1,color2);
      if (y_stop > 0) 
        sprintf(buffer,"%d",y_stop);
      else
        sprintf(buffer,"-");
/*      else {
        if (file_res_y > 0) 
          sprintf(buffer,"%d",file_res_y);
	else
          sprintf(buffer,"");
      } */
      fl_set_input(ystop_obj,buffer);

    yloc -= ydel;
    tstart_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,100.0,height,"");
      fl_set_object_label(tstart_obj,"t:");
      fl_set_object_color(tstart_obj,color1,color2);
      sprintf(buffer,"%d",t_start);
      fl_set_input(tstart_obj,buffer);
    fl_set_call_back(tstart_obj,update_time_range,0);

    tstop_obj = fl_add_input(FL_NORMAL_INPUT,x0+xdel,yloc,100.0,height,"");
      fl_set_object_color(tstop_obj,color1,color2);
      if (!t_stop)
        sprintf(buffer,"-");
      else 
        sprintf(buffer,"%d",t_stop);
      fl_set_input(tstop_obj,buffer);
    fl_set_call_back(tstop_obj,update_time_range,1);


/*printf("      creating data type obj...\n"); */
    yloc -= ydel;
    width = 90.0;
    xdel = 10.0;
    fl_bgn_group();
      obj = fl_add_box(FL_NO_BOX,100.0,yloc,300.0,height,"Data Type:  ");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
      x0 = 100.0;
      xsave[0] = x0;
      data_type_obj[0] = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"Rect");
      x0 += width + xdel;
      xsave[1] = x0;
      data_type_obj[1] = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"Polar");
      x0 += width + xdel;
      xsave[2] = x0;
      data_type_obj[2] = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"Complex");
      x0 += width + xdel;
      xsave[3] = x0;
      data_type_obj[3] = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"2D Vec");
      x0 += width + xdel;
      xsave[4] = x0;
      data_type_obj[4] = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"Contours");
    fl_end_group();

    fl_set_call_back(data_type_obj[0],update_data_type,0);
    fl_set_call_back(data_type_obj[1],update_data_type,1);
    fl_set_call_back(data_type_obj[2],update_data_type,2);
    fl_set_call_back(data_type_obj[3],update_data_type,3);
    fl_set_call_back(data_type_obj[4],update_data_type,4);


	/* row of info related to data type chosen */
/*printf("      creating info related to data type ...\n"); */

    yloc -= ydel;

    width = 100.0;
    x0 = xsave[1];
    polar_rmin_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,width,height,
				"min R:");
    sprintf(buffer,"%f",polar_rmin);
    fl_set_input(polar_rmin_obj,buffer);
    fl_set_object_color(polar_rmin_obj,color1,color2);
    fl_set_call_back(polar_rmin_obj,update_polar_radii,0);

    x0 = xsave[1] + width + 60.0;
    polar_rmax_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,width,height,
				"max R:");
    sprintf(buffer,"%f",polar_rmax);
    fl_set_input(polar_rmax_obj,buffer);
    fl_set_object_color(polar_rmax_obj,color1,color2);
    fl_set_call_back(polar_rmax_obj,update_polar_radii,1);

    x0 = xsave[2];
    complex_choice = fl_add_choice(FL_NORMAL_CHOICE,x0,yloc,80.0,height,"");
    fl_addto_choice(complex_choice,cmplx_vec_spec[0]);
    fl_addto_choice(complex_choice,cmplx_vec_spec[1]);
    fl_addto_choice(complex_choice,cmplx_vec_spec[2]);
    fl_addto_choice(complex_choice,cmplx_vec_spec[3]);

    fl_set_call_back(complex_choice,update_complex_choice,0);

    if (cmplx_flag)
      fl_set_choice(complex_choice,cmplx_flag);


    x0 = xsave[3];
    vec_scale_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,width,height,"scale:");
    sprintf(buffer,"%f",vec_scale);
    fl_set_input(vec_scale_obj,buffer);
    fl_set_object_color(vec_scale_obj,color1,color2);
    fl_set_call_back(vec_scale_obj,update_vec_scale,0);

    x0 = xsave[4];
    contours_num_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,80.0,height,"#:");
    sprintf(buffer,"%d",ncontours);
    fl_set_input(contours_num_obj,buffer);
    fl_set_object_color(contours_num_obj,color1,color2);
    fl_set_call_back(contours_num_obj,update_num_contours,0);


       /* only show approp data type info */
    fl_set_button(data_type_obj[data_type_flag],1);

    if (data_type_flag != POLAR) {
      fl_hide_object(polar_rmin_obj);
      fl_hide_object(polar_rmax_obj);
    }

    if (data_type_flag == COMPLEX)
      fl_set_choice(complex_choice,cmplx_flag);
    else
      fl_hide_object(complex_choice);

    if (data_type_flag != VEC2D) 
      fl_hide_object(vec_scale_obj);

    if (data_type_flag != CONTOURS) 
      fl_hide_object(contours_num_obj);




/*printf("      creating Format obj...\n"); */
    yloc -= ydel;
    width = 80.0;
    xdel = 10.0;
    printf("yloc(Format) = %f\n",yloc);
    fl_bgn_group();
      obj = fl_add_box(FL_NO_BOX,100.0,yloc,300.0,height,"Format:  ");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
      x0 = 100.0;
      ascii_obj = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"ascii");
      x0 += width + xdel;
      binary_obj = fl_add_lightbutton(FL_RADIO_BUTTON,x0,yloc,width,height,"binary");
    fl_end_group();

/* rf. set_utio_data_type() in read_data.c  */

    fl_set_call_back(ascii_obj,update_data_format,0);
    fl_set_call_back(binary_obj,update_data_format,1);


    x0 += width + 25.0;
    binary_C = fl_add_choice(FL_NORMAL_CHOICE,x0,yloc,width,height,"C");
    fl_addto_choice(binary_C,binary_C_type[0]);
    fl_addto_choice(binary_C,binary_C_type[1]);
    fl_addto_choice(binary_C,binary_C_type[2]);
    fl_addto_choice(binary_C,binary_C_type[3]);

    x0 += width + 40.0;
    binary_ftn = fl_add_choice(FL_NORMAL_CHOICE,x0,yloc,width,height,"Ftn");
    fl_addto_choice(binary_ftn,binary_ftn_type[0]);
    fl_addto_choice(binary_ftn,binary_ftn_type[1]);
    fl_addto_choice(binary_ftn,binary_ftn_type[2]);

    fl_set_call_back(binary_C,update_binary_choice,0);
    fl_set_call_back(binary_ftn,update_binary_choice,1);

    set_binary_type();


    width = 75.0;
    cancel_obj = fl_add_button(FL_NORMAL_BUTTON,50.,10.,width,height,"Cancel");
/*   save_obj = fl_add_button(FL_NORMAL_BUTTON,250.,10.,width,height,"Save"); */
    ok_obj = fl_add_button(FL_NORMAL_BUTTON,450.,10.,width,height,"OK");


    if (dimension == 1) {
      fl_set_button(oned_obj,1);
      fl_hide_object(yres_obj);
      fl_hide_object(ystart_obj);
      fl_hide_object(ystop_obj);
    }
    else if (dimension == 2) 
      fl_set_button(twod_obj,1);

    if (input_format == 'a') {
      fl_set_button(ascii_obj,1);
      fl_hide_object(binary_C);
      fl_hide_object(binary_ftn);
    }
    else {
      fl_set_button(binary_obj,1);
    }


  fl_end_form();

}
/*--------------------------------------------------------------------*/
int input_form_handler()
{
  FL_OBJECT *obj;

/*  foreground(); */
/*  fl_init(); */
  make_input_form();
  fl_show_form(input_form,FL_PLACE_CENTER,FALSE,NULL);

  do {
    obj = fl_do_forms(); 
  }
  while ((obj != ok_obj) && (obj != cancel_obj));

  fl_hide_form(input_form);

  if ((dimension == 2) && (file_res_y == 1)) dimension = 1;

  if (obj==ok_obj) {
/*    update_popup_objs(); */
    redraw_popups();
    return 1;
  }
  else 
    return 0;
  
}
