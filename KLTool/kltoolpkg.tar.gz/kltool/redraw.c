/* redraw.c - redraw windows
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <gl/gl.h>
#include "kl_str.h"


  /* Current vector # for SCANning */
int cur_vector = 1;
int cur_eigfn = 1;
int cur_appx = 1;
int cur_error = 1;
int cur_datacoef = 1;
int cur_appxcoef = 1;

int sync_data_flag=0;
float	fontscale = 25.0;

/*  For eye-pleasing colors (black background) */
int	data_color=		GREEN;
int	scan_win_color=		YELLOW;
int	eigvals_bar_color=	YELLOW;
int	geom_win_color=		BLACK;
int	mean_geom_color=	CYAN;
int	coef_geom_color=	CYAN;
int	eigfn_geom_color=	CYAN;
int	menu_bar_color=		BLUE;
int	menu_bar_text_color=	YELLOW;
int	select_win_color=	CYAN;

/*  For the black & white look (white background) */
/*
int	data_color=		BLACK;
int	scan_win_color=		WHITE;
int	eigvals_bar_color=	BLACK;
int	geom_win_color=		WHITE;
int	mean_geom_color=	BLACK;
int	coef_geom_color=	BLACK;
int	eigfn_geom_color=	BLACK;
int	menu_bar_color=		WHITE;
int	menu_bar_text_color=	BLACK;
*/


/*--------------------------------------------------------------------*/
redraw_popups()
{
	draw_popups_win();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_data()
{
	draw_data_win();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_mean()
{
	draw_mean_win();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_appx()
{
extern win_struct data_win;

	draw_appx_win();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_eigfn(n)
int n;
{
extern int display_coef_flag;

	draw_eigfn_win(n);
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_datacoef()
{
	draw_datacoef_geom();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_appxcoef()
{
	draw_appxcoef_geom();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_eigvals(n)
int n;
{
	draw_eigvals_win(n);
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_error()
{
        draw_error_win();
	swapbuffers();
}
/*--------------------------------------------------------------------*/
redraw_scan()
{
extern int scan_data_win,scan_eigfn_win,scan_appx_win,scan_error_win;
extern int scan_datacoef_win,scan_appxcoef_win;
extern int cur_win;
extern int sync_flag,sync_data_flag;
extern int num_eig_appx,num_eig_error;

/*	printf("redraw_scan:  cur_vector = %d\n", cur_vector); */

	if(cur_win == scan_data_win) {
/*	   printf("     cur_win = %d\n", cur_win); */
	   draw_scan_win(scan_data_win,cur_vector);
/*	   if (sync_data_flag) {
	      swapbuffers();
	      draw_scan_win2(scan_appx_win,cur_vector,num_eig_appx);
	   } */
	}
	else if(cur_win == scan_eigfn_win) {
	   draw_scan_eigfn_win(cur_eigfn);
	}
	else if(cur_win == scan_appx_win) {
	   draw_scan_win2(scan_appx_win,cur_appx,num_eig_appx);
/*	   if (sync_data_flag) {
	      swapbuffers();
	      draw_scan_win(scan_data_win,cur_vector);
	   } */
	}
	else if(cur_win == scan_error_win) {
	   draw_scan_win2(scan_error_win,cur_error,num_eig_error);
	}
	else if(cur_win == scan_datacoef_win) {
	   draw_scan_win(scan_datacoef_win,cur_datacoef);
	}
	else if(cur_win == scan_appxcoef_win) {
	   draw_scan_win(scan_appxcoef_win,cur_appxcoef);
	}
	swapbuffers();
}
/*--------------------------------------------------------------------*/
clear_c()
{
	color(geom_win_color);
	clear();
}
/*--------------------------------------------------------------------*/
clear_rgb()
{
static short blackvec[3] = {0,0,0};
static short whitevec[3] = {255,255,255};

	if (geom_win_color == WHITE)
	   c3s(whitevec);
	else
	   c3s(blackvec);
	clear();
}
/*--------------------------------------------------------------------*/
/* Redraw a particular graphics window */
redraw_window(gid)
int gid;
{
long	wwidth,wheight;
extern win_struct	data_win,mean_win,appx_win,error_win,eigfn_win,
			datacoef_win,appxcoef_win,select_win;
extern win_struct	eigvals_win;
extern int 	popups_win;
extern int 	scan_data_win,scan_eigfn_win,scan_appx_win,scan_error_win;
extern int 	scan_datacoef_win,scan_appxcoef_win;
extern int	cur_win;
extern int	num_eig,num_eig_appx,num_eig_error;
extern int	cur_datacoef,cur_appxcoef;
extern int	num_eigvals;

/*    printf("redraw_window>>>>>>>>>>>>>>>>> gid= %d\n", gid); */

	winset(gid);
	reshapeviewport();

	if (gid == popups_win)
           redraw_popups();
	else if (gid == select_win.id) {
           redraw_select();
	   set_win_bdr(&select_win);
	}
	else if (gid == data_win.id) {
           redraw_data();
/*	   pop_scan_win(gid); */
	}
	else if (gid == mean_win.id)
           redraw_mean();
	else if (gid == eigvals_win.id)
           redraw_eigvals(num_eigvals);
	else if (gid == eigfn_win.id) 
           redraw_eigfn(cur_eigfn);
	else if (gid == datacoef_win.id) 
           redraw_datacoef();
	else if (gid == appxcoef_win.id) 
           redraw_appxcoef();
	else if (gid == appx_win.id) 
           redraw_appx();
	else if (gid == error_win.id) 
           redraw_error();

	else if (gid == scan_data_win) {
	   draw_scan_win(scan_data_win,cur_vector);
	   swapbuffers();
	}
	else if (gid == scan_eigfn_win) {
	   draw_scan_eigfn_win(cur_eigfn);
	   getsize(&wwidth,&wheight);
/*	printf("    wwidth,wheight =  %d %d\n", wwidth,wheight); */
	   fontscale = (float)wheight/2.0;
	   swapbuffers();
	}
	else if (gid == scan_appx_win) {
	   draw_scan_win2(scan_appx_win,cur_appx,num_eig_appx);
	   swapbuffers();
	}
	else if (gid == scan_error_win) {
	   draw_scan_win2(scan_error_win,cur_error,num_eig_error);
	   swapbuffers();
	}
	else if (gid == scan_datacoef_win) {
	   draw_scan_win(scan_datacoef_win,cur_datacoef);
	   swapbuffers();
	}
	else if (gid == scan_appxcoef_win) {
	   draw_scan_win(scan_appxcoef_win,cur_appxcoef);
	   swapbuffers();
	}

	return(1);

/*	if(scan_data_win > 0) {
	   draw_scan_win(scan_data_win,cur_vector);
	   swapbuffers();
	}
	if(scan_eigfn_win > 0) {
	   draw_scan_win(scan_eigfn_win,cur_eigfn);
	   swapbuffers();
	}
	if(scan_appx_win > 0) {
	   draw_scan_win(scan_appx_win,cur_appx);
	   swapbuffers();
	}
	if(scan_error_win > 0) {
	   draw_scan_win(scan_error_win,cur_error);
	   swapbuffers();
	} */


/*    swapbuffers(); */
}
