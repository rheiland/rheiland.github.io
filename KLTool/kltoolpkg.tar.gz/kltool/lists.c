/* lists.c - list & ptr handler
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 *
 */

#include <stdio.h>
#include "kl_str.h"

extern vec_struct *vec_root;
extern vec_struct *caric_root;
extern vec_struct *u_root;
extern vec_struct *appx_root;
extern vec_struct *error_root;
extern vec_struct *datacoef_root;
extern vec_struct *appxcoef_root;
extern double *mean_ptr;

extern cmplx_vec_struct *cmplx_vec_root;
extern cmplx_vec_struct *cmplx_caric_root;
extern cmplx_vec_struct *cmplx_u_root;
extern cmplx_vec_struct *cmplx_appx_root;
extern cmplx_vec_struct *cmplx_error_root;
extern cmplx_vec_struct *cmplx_datacoef_root;
extern cmplx_vec_struct *cmplx_appxcoef_root;
extern double *mean_ptr_real,*mean_ptr_imag;

/*--------------------------------------------------------------------*/
empty_all_lists()
{
extern int cur_vector,cur_eigfn,cur_appx,cur_error,cur_datacoef,cur_appxcoef;
extern float ymin,ymax;
extern int 	num_eig;

	free_vec_list(vec_root);
	vec_root = NULL;
	free_vec_list(caric_root);
	caric_root = NULL;
	free_vec_list(u_root);
	u_root = NULL;
	free_vec_list(appx_root);
	appx_root = NULL;
	free_vec_list(error_root);
	error_root = NULL;
	free_vec_list(datacoef_root);
	datacoef_root = NULL;
	free_vec_list(appxcoef_root);
	appxcoef_root = NULL;

	if (mean_ptr != NULL) {
	   free(mean_ptr);
	   mean_ptr = NULL;
	}



	free_cmplx_vec_list(cmplx_vec_root);
	cmplx_vec_root = NULL;
	free_cmplx_vec_list(cmplx_caric_root);
	cmplx_caric_root = NULL;
	free_cmplx_vec_list(cmplx_u_root);
	cmplx_u_root = NULL;
	free_cmplx_vec_list(cmplx_appx_root);
	cmplx_appx_root = NULL;
	free_cmplx_vec_list(cmplx_error_root);
	cmplx_error_root = NULL;
	free_cmplx_vec_list(cmplx_datacoef_root);
	cmplx_datacoef_root = NULL;
	free_cmplx_vec_list(cmplx_appxcoef_root);
	cmplx_appxcoef_root = NULL;

	if (mean_ptr_real != NULL) {
	   free(mean_ptr_real);
	   mean_ptr_real = NULL;
	}
	if (mean_ptr_imag != NULL) {
	   free(mean_ptr_imag);
	   mean_ptr_imag = NULL;
	}

	cur_vector = 1;
	cur_eigfn = 1;
	cur_appx = 1;
	cur_error = 1;
	cur_datacoef = 1;
	cur_appxcoef = 1;

	num_eig = 0;
}
/*--------------------------------------------------------------------*/
free_vec_list(root)
vec_struct *root;
{
	vec_struct *vsp;

	if (root == NULL) return(1);
	TRACE(vsp,root) {
	   free(vsp->dp);
	   free(vsp);
	}
}
/*--------------------------------------------------------------------*/
free_cmplx_vec_list(root)
cmplx_vec_struct *root;
{
	cmplx_vec_struct *vsp;

	if (root == NULL) return(1);
	TRACE(vsp,root) {
	   free(vsp->drp);
	   free(vsp->dip);
	   free(vsp);
	}
}
