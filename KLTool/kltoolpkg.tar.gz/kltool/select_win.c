/* select_win.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <gl.h>
#include <device.h>
#include "kl_str.h"



static char *select_msg1;
static char *select_msg2;
char *select_butn[5];
int n_select_butns;


/*--------------------------------------------------------------------*/
select_feedback(char *msg1, char *msg2, int nbutns) 
{
extern int n_select_butns;
/*   printf("select_feedback: %s\n %s :: %d\n",msg1,msg2,n); */
        select_msg1 = msg1;
	select_msg2 = msg2;
	n_select_butns = nbutns;
	redraw_select();
}
/*--------------------------------------------------------------------*/
redraw_select()
{
	int i;

	pop_select();
	color(CYAN);
	clear();
	color(BLACK);
	if (select_msg1 != NULL) {
	   cmov2(-0.9,0.3);
	   charstr(select_msg1);
	}
	if (select_msg2 != NULL) {
	   cmov2(-0.9,0.0);
	   charstr(select_msg2);
	}

	if (n_select_butns > 0)
	   draw_select_butns();

/*	swapbuffers(); */
}
/*--------------------------------------------------------------------*/
draw_select_butns()
{
	int i,n;
	float xc,yc;
static float r1 = 0.15;
static float r2 = 0.12;
static float char_eps = 0.015;
static float butn_xdel = 0.4;


	  /* from right to left */
	xc = 0.7;
	yc = -0.7;
	pushmatrix();
	translate(xc,yc,0.0);
	rect(-r1,-r2,r1,r2);
	popmatrix();
	n = n_select_butns;
	n--;
	cmov2(xc-strlen(select_butn[n])*char_eps,yc-char_eps);
	charstr(select_butn[n]);

	for (i=1; i<n_select_butns; i++) {
	   xc -= butn_xdel;
	   pushmatrix();
	   translate(xc,yc,0.0);
	   rect(-r1,-r2,r1,r2);
	   popmatrix();
	   n--;
	   cmov2(xc-strlen(select_butn[n])*char_eps,yc-char_eps);
	   charstr(select_butn[n]);
	}
}
/*--------------------------------------------------------------------*/
pop_select()
{
extern win_struct select_win;

	if (select_win.id < 0) {
	   create_select_win();
/*   printf("---pop_select: select_win.id = %d\n",select_win.id); */
	}
	else {
	   winset(select_win.id);
	   winpop();
	}
}
/*--------------------------------------------------------------------*/
push_select()
{
extern win_struct select_win;

	if (select_win.id > 0) {
	   winclose(select_win.id);
	   select_win.id = -1;
	}
}
/*--------------------------------------------------------------------*/
get_select_butn(nbutn)
int nbutn;
{
    int	c,i,n;
    int dev;
    short val;
    short sx,sy;
    long sx0,sy0,wwidth,wheight;
    float fx,fy;
    int finished;
    int retval;
extern win_struct select_win;
extern int cur_win;

	static float r1 = 0.15;
	static float r2 = 0.12;
	static float char_eps = 0.013;
	static float butn_xdel = 0.4;
	float xc,yc;


	winset(select_win.id);

	  /* from right to left */
	xc = 0.7;
	yc = -0.7;

	for (i=1; i<nbutn; i++)
	   xc -= butn_xdel;

    finished=0;
    while(!finished) {
    while(qtest()) {

        dev = qread(&val);

        switch(dev) {
        case INPUTCHANGE:
                /* user attaches/detaches input focus */
            cur_win = (int)val;
            break;
        case REDRAW:
            redraw_window(val);
            break;
        case LEFTMOUSE:
	    dev = qread(&sx);   /* Get X,Y entries on the queue regardless */
	    dev = qread(&sy);   /* (since MOUSEX/Y 'tie'd to LEFT button)  */
/*	    printf("select_handler/LEFTMOUSE: sx,sy = %d %d\n", sx,sy); */

            if (val && (cur_win == select_win.id)) {	/* button down? */

		screen_to_window(select_win.id,sx,sy,&fx,&fy);
/*		printf("fx,fy = %f %f\n", fx,fy); */

		finished = 1;
	    }
        }
    }
    }
    retval = -1;
    for (i=1; i<=nbutn; i++) {
	if (fx > (xc-r1)) 
	   retval = i;
	xc += butn_xdel;;
    }

/*    push_select(); */
    return(retval);
}
/*--------------------------------------------------------------------*/
select_msg(msg)
char *msg;
{
	user_select(msg,NULL,0);
}
/*--------------------------------------------------------------------*/
user_select(msg1,msg2,nbutns)
char *msg1,*msg2;
int nbutns;
/*char **butns; */
{
	select_msg1 = msg1;
	select_msg2 = msg2;
	n_select_butns = nbutns;
	redraw_select();
}
/*--------------------------------------------------------------------*/
user_select_reply(msg1,msg2,nbutns)
char *msg1,*msg2;
int nbutns;
{
	int i;

	select_msg1 = msg1;
	select_msg2 = msg2;
	n_select_butns = nbutns;
	redraw_select();

	i = get_select_butn(nbutns);
/*	printf("user_select_reply: get_select_butn = %d\n", i); */
	return(i);
}

/*--------------------------------------------------------------------*/
notify_user_ok(msg)
char *msg;
{
	int i;

	select_butn[0] = "Ok";
	user_select(msg,NULL,1);

	i = get_select_butn(1);
/*	printf("notify_user_ok: get_select_butn = %d\n", i); */
	if (i == 1) {
	   push_select();
	   return(1);
	}
	else 
	   return(0);
}
