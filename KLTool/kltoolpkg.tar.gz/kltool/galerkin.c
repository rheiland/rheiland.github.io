/* galerkin.c - 
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */
#include <malloc.h>
#include <stdio.h>
#include <math.h>
#include "kl_str.h"


FILE *fpode,*fpode2;

#define EPS  .0000001


/* Galerkin system via Fourier Series expansion */
galerkin_fs()
{
	FILE *fpparse,*fp,*fp2,*fplog;
	int i,j,k,kmax,m,n;
	int loop;
	float *wsave,*r,azero,*a,*b;
	vec_struct *usp;
	double *dp;
	double aval,bval,dotpr,dotpi,*c,*cp[50];
	double sum[2];
	int length;
	char infile[120];
extern int dimension,res_x,res_y;
extern int	num_eig;
extern vec_struct *u_root;		/* to eigenfns */


int neq;

	printf("------------ begin galerkin_fs ---------\n");

/*
neq=0;
kmax=128;
fplog=fopen("log.out","w");
fpparse=fopen("ks.pde","r");
fpode = fopen("ode.sys","w");
fpode2 = fopen("ode2.sys","w");

parse_pde(cp,neq,&kmax,fplog,fpparse);
exit(-1);
*/


	  /* Get input file containing PDE for parsing */

/*	pop_feedback(); */

	if (u_root==NULL) {
	   error_msg("Decompose first (no eigenfns computed)");
	   return(-1);
	}

/*	length = get_string("Enter PDE filename: ",infile,80);
        if((fpparse=fopen(infile, "r")) == NULL)  { */
        if((fpparse=fopen("ks.pde", "r")) == NULL)  {
	  error_msg("ERROR - File not found");
	  return(-1);
        }

	printf("galerkin_fs:  fpparse = %d\n",fpparse);
/*	fscanf(fpparse,"%s",infile);
	printf("galerkin_fs:   = %s\n",infile);
	exit(-1); */

	if (!(res_x % 2))
	   kmax = res_x/2;
	else
	   kmax = (res_x-1)/2;

	printf("  kmax = %d\n",kmax);

	wsave = (float *)malloc(sizeof(float)*(3*res_x+15));
	a = (float *)malloc(sizeof(float)*kmax);
	b = (float *)malloc(sizeof(float)*kmax);
	r = (float *)malloc(sizeof(float)*res_x);

	usp = u_root;

	printf("num_eig = %d\n", num_eig);


	fp = fopen("fcoefs.dat","w");
	fprintf(fp,"%d\n", num_eig);
	fprintf(fp,"%d\n", kmax);

	   /* for use in fourier.m & galerkin.m (Mathematica) */
	fp2 = fopen("kl_fcoefs.dat","w");
	fprintf(fp2,"%d\n", num_eig);
	fprintf(fp2,"%d\n", kmax);


    for (loop=0; loop<num_eig; loop++) {

        printf("loop = %d\n",loop);
        printf("kmax = %d\n",kmax);
	   /* array only from k=0,KMAX since c(-k) = conj(c(k)) */
	   /* (we multiply by 2 since complex: real,imag)       */

	c = (double *)malloc(sizeof(double)*kmax*2+2);
	if (c == NULL) {
	  printf("galerkin_fs: Can't malloc for eigfn %d\n",loop);
	  exit(-1);
	}
        printf("c = %d\n",c);
	cp[loop] = c;
        printf("cp[loop] = %d\n",cp[loop]);

	dp = usp->dp;
        printf("dp = %d\n",dp);
/*	printf("-----\n"); */
	for (i=0; i<res_x; i++) {
	   r[i] = dp[i];
/*	   if (i<5) printf("%f\n",r[i]); */
	}

	ezffti_(&res_x,wsave);
	ezfftf_(&res_x,r,&azero,a,b,wsave);

/*        c(0) = azero
	do k=1,kmax
	   c(k) = 0.5 * cmplx(a(k), -b(k))
	   c(-k) = conjg(c(k))
	enddo
*/

/* debug */
/*azero=0.0; */

	fprintf(fp,"%e  0.0\n", azero);
	fprintf(fp2,"%f\n", azero);


	   /* For phi_dotp, put azero at beginning of array */
	*c++ = azero;
	*c++ = 0.0;
	for (k=0; k<kmax; k++) {
/*	   if ((a[k] > EPS) || (b[k] > EPS)) */
		aval = 0.5 * a[k];
		bval = -0.5 * b[k];
	      fprintf(fp,"%e  %e\n", aval, bval );
		/* NB: Mathematica doesn't recognize scientific notation, ie,
			1.23456e5  */
	      fprintf(fp2,"%.8f +  %.8f *I\n", aval, bval );
	      *c++ = aval;
	      *c++ = bval;
	}
	   /* otherwise, put azero at end of array */
/*	*c = azero; */

        usp = NEXT(usp);
	printf("usp = %d\n",usp);
    }
	
	fclose(fp);
	fclose(fp2);

	printf("------ using 'complex_dotprod' ------\n");
	for (i=0; i<num_eig; i++) {
	  complex_dotprod(cp[i],cp[0],5,&dotpr,&dotpi);
/*	  complex_dotprod(cp[i],cp[0],kmax,&dotpr,&dotpi); */
	  printf("<%d,0>/2Pi = %f %f\n", i,dotpr,dotpi);
	  for (j=1; j<num_eig; j++) {
	    complex_dotprod(cp[i],cp[j],kmax,&dotpr,&dotpi);
	    printf("  <%d,%d>/2Pi = %.8f %.8f\n", i,j,dotpr,dotpi);
	  }
	}

	printf("------ using 'phi_dotp' ------\n");
	for (m=0; m<5; m++) {
	  printf("  %d-th deriv\n", m);
	  for (i=0; i<num_eig; i++) {
	  for (j=0; j<num_eig; j++) {
	    phi_dotp_(cp[i],cp[j],&kmax,&m,sum);
	    printf("  <%d,%d>/n = %.8f %.8f\n", i,j,sum[0],sum[1]);
	  }
	  }
	}


	printf("\n\n----------  ODE  ----------\n");
	fpode = fopen("ode.sys","w");
	fpode2 = fopen("ode2.sys","w");
	fplog = fopen("parse.log","w");

/*
neq=0;
parse_pde(cp,neq,&kmax,fplog,fpparse);
exit(-1);
*/

	for (n=0; n<num_eig; n++) {
	  printf("galerkin_fs:  n=%d\n",n);
	   m=0;
	   phi_dotp_(cp[n],cp[n],&kmax,&m,sum);
	     /* res_x = 256 for K-S */
/*	   fprintf(fpode,"a%d * %.8f = ", n+1,res_x*sum[0]); */
	   fprintf(fpode,"a%d * %.8e = ", n+1,sum[0]);
	   fprintf(fpode2,"a%d * %.8f = ", n+1,sum[0]);

	printf("      fpparse = %d\n",fpparse);
	   parse_pde(cp,n,&kmax,fplog,fpparse);

	   fprintf(fpode,"\n\n");
	   fprintf(fpode2,"\n\n");

	   /* Let's be simple-minded and reparse for each eqn */
	   rewind(fpparse);
	}
	fclose(fpode);
	fclose(fpode2);
	fclose(fplog);
	fclose(fpparse);

/*	push_feedback(); */

/*	for (m=0; m<5; m++) {
	for (i=0; i<num_eig; i++) {
	  phi_dotp_(cp[i],cp[0],&kmax,&m,sum);
	  printf("<%d,0>/n = %f %f\n", i,sum[0],sum[1]);
	  for (j=1; j<num_eig; j++) {
	    phi_dotp_(cp[i],cp[j],&kmax,&m,sum);
	    printf("  <%d,%d>/n = %f %f\n", i,j,sum[0],sum[1]);
	  }
	}
	} */

	printf("------------ end galerkin_handler ---------\n");
}
/*------------------------------------------------------------*/
/* Compute dot product of Fourier coefs, c1,c2:  c1.conj(c2)  */
/* v[0:kmax-1]; v[kmax] = azero   */
complex_dotprod(c1,c2,kmax,cr,ci)
double c1[][2],c2[][2];
double *cr,*ci;
int kmax;
{
	int k;

	*cr = *ci = 0.0;

	   /* SUM[(a+bi)(c-di)] = SUM[ (ac+bd) + (-ad+bc)i ]   */
	for (k=0; k<kmax; k++) {
/*	   if (k<10) printf("c2= %f %f\n",c2[k][0],c2[k][1]); */
	   *cr = *cr + c1[k][0]*c2[k][0] + c1[k][1]*c2[k][1];
	   *ci = *ci - c1[k][0]*c2[k][1] + c1[k][1]*c2[k][0];
	}
	   /* for k=-kmax to -1, c = conj(c) */
	   /* SUM[(a-bi)(c+di)] = SUM[ (ac+bd) + (ad-bc)i ]   */
	for (k=0; k<kmax; k++) {
	   *cr = *cr + c1[k][0]*c2[k][0] + c1[k][1]*c2[k][1];
	   *ci = *ci + c1[k][0]*c2[k][1] - c1[k][1]*c2[k][0];
	}
	   /* k = 0 (azero) */
	*cr = *cr + c1[kmax][0]*c2[kmax][0];
/*	printf("   azeros = %f %f\n", c1[kmax][0],c2[kmax][0]); */
}
