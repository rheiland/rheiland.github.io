/* input.c -
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <gl.h>
#include <math.h>
#include "kl_str.h"
#include "macros.h"

#define X 0
#define Y 1
#define Z 2

float xmin = 1.e32;
float xmax = -1.e32;
float ymin = 1.e32;
float ymax = -1.e32;
float zmin,zmax;
float ydiff;
float scalef;


vec_struct *vec_root = NULL;
cmplx_vec_struct *cmplx_vec_root = NULL;
vec_struct_byte *vec_root_byte = NULL;
vec_struct_uchar *vec_root_uchar = NULL;

int num_vecs=0;


/*--------------------------------------------------------------------*/
/* Using the 'void' type specifier on a routine requires that the
   routine be defined before it is used.  */
void extrema3(f)
double *f;
{
	if(f[0] < xmin)
		xmin = f[0];
	if(f[0] > xmax)
		xmax = f[0];
	if(f[1] < ymin)
		ymin = f[1];
	if(f[1] > ymax)
		ymax = f[1];
	return;
}
/*--------------------------------------------------------------------*/
void extrema(f)
double *f;
{
	if(*f < ymin)
		ymin = *f;
	if(*f > ymax)
		ymax = *f;
	return;
}
/*--------------------------------------------------------------------*/
void extrema_vec(d,n)
double *d;
int n;
{
	int i;

	for (i=0; i<n; i++) {
	   if(*(d+i) < ymin)
		ymin = *(d+i);
	   if(*(d+i) > ymax)
		ymax = *(d+i);
	}
	return;
}
/*--------------------------------------------------------------------*/
void extrema_contour_vec(d,n)
double *d;
int n;
{
	int i;
	double *p;

	p = d;
	for (i=0; i<n; i++) {
	   if(*d < xmin)
		xmin = *d;
	   if(*d > xmax)
		xmax = *d;
	   d++;
	   if(*d < ymin)
		ymin = *d;
	   if(*d > ymax)
		ymax = *d;
	   d++;
	}
	d = p;
	return;
}
/*--------------------------------------------------------------------*/
read_datafile(fp)
FILE *fp;
{
extern int res_x,res_y,res_xy;
extern int x_start,x_stop,y_start,y_stop,t_start,t_stop;
extern int dimension,file_res_x,file_res_y;
extern char input_format;
extern int ncontours;

printf("------read_datafile: file_res_x/y = %d %d\n", file_res_x,file_res_y);
printf("               input_format = %c\n",input_format);

	   /* default */
	res_x = file_res_x;
	res_y = file_res_y;
	res_xy = res_x * res_y;

	if (res_xy <= 0) {
	  error_msg("ERROR - Vector resolution = 0");
	  return(-1);
	}

	if (input_format == 'b') {
/*	   read_weather_data(fp); */
	   read_uchar_data(fp);
	   ymin = 0.0;
	   ymax = 256.0;
	   data_extrema();
	   return(1);
	}

	if (dimension == 1) {
	   if ((t_start==1) && (t_stop==0) &&
	      (x_start==1) && ((x_stop==0) || (x_stop==file_res_x)) )
	      read_all_data(fp);
	   else {
	      if (x_stop==0) {
		 res_x = file_res_x - x_start + 1;
/*		 printf("read_datafile: file_res_x, x_start= %d %d\n",
				file_res_x,x_start); */
	      }
	      else
		 res_x = x_stop - x_start + 1;

	      res_xy = res_x * res_y;
	      read_selected_data(fp);
	   }
	}
	else if (dimension == 2) {
	   if ((t_start==1) && (t_stop==0) &&
	       (x_start==1) && ((x_stop==0) || (x_stop==file_res_x)) &&
	       (y_start==1) && ((y_stop==0) || (y_stop==file_res_y)) )
	         read_all_data(fp);

	   else {
	      if (x_stop==0)
		 res_x = file_res_x - x_start + 1;
	      else
		 res_x = x_stop - x_start + 1;

	      if (y_stop==0)
		 res_y = file_res_y - y_start + 1;
	      else
		 res_y = y_stop - y_start + 1;

	      res_xy = res_x * res_y;
	      read_selected_data(fp);

	      zmin = 0.0;
	      zmax = -res_y+1;
	   }
	}

/*	printf("------read_datafile: res_x,res_y = %d %d\n", res_x,res_y); */


/*	if (y_stop > 0) 
	   ymax = y_stop - y_start;
	else
	   ymax = file_res_y - y_start; */


	if (!ncontours)
	  data_extrema();
	else
	  contours_data_extrema();

	printf("read_datafile: xmin,xmax, ymin,ymax = %f %f %f %f\n", 
	   xmin,xmax, ymin,ymax);
}

/*--------------------------------------------------------------------*/
data_extrema()
{
    float max_range;
extern win_struct data_win;
extern int x_start,x_stop,y_start,y_stop;
extern int file_res_x;
extern int polar_flag;
extern float polar_rmax;


    xmin = 0.0;
    if (x_stop > 0) 
	   xmax = x_stop - x_start;
    else
	   xmax = file_res_x - x_start;

/*   printf(" xmin,xmax= %f %f\n ymin,ymax= %f %f\n",xmin,xmax, ymin,ymax);  */
/*   printf(" zmin,zmax= %f %f\n", zmin,zmax); */
	
    data_win.xmid = xmin + (xmax-xmin) / 2.0;

    ydiff = ymax - ymin;
    data_win.ymid = ymin + ydiff / 2.0;
/*    data_win.zmid = (tval-t0) / 2.0; */
    data_win.zmid = zmin + (zmax-zmin) / 2.0;
/*    printf("data_win.xmid,ymid,zmid = %f %f %f\n", data_win.xmid,data_win.ymid,data_win.zmid); */

    max_range = MAX((xmax-xmin),ydiff);
/*    printf("max_range = %f\n", max_range); */
    scalef = 2.0 / max_range;
/*    printf("scalef = %f\n", scalef); */

    data_win.xscale = 1.8 / (xmax-xmin);
    data_win.yscale = 1.8 / ydiff;

    if (polar_flag) {
/*        data_win.xscale = 0.9 / ydiff;
        data_win.yscale = 0.9 / ydiff; */
        data_win.xscale = 0.9 / polar_rmax;
        data_win.yscale = 0.9 / polar_rmax;
    }

    if (zmin == zmax) 
       data_win.zscale = 1.0;
    else
       data_win.zscale = -1.8 / (zmax-zmin);	/* sign change to prevent reflection */

/*    printf("data_win.xscale,yscale,zscale = %f %f %f\n",  
	    data_win.xscale,data_win.yscale,data_win.zscale); */

}
/*--------------------------------------------------------------------*/
contours_data_extrema()
{
    float max_range;
extern win_struct data_win;
extern int x_start,x_stop,y_start,y_stop;
extern int file_res_x;


    data_win.xmid = xmin + (xmax-xmin) / 2.0;

    ydiff = ymax - ymin;
    data_win.ymid = ymin + ydiff / 2.0;
    data_win.zmid = zmin + (zmax-zmin) / 2.0;

    max_range = MAX((xmax-xmin),ydiff);
    scalef = 2.0 / max_range;

    data_win.xscale = 1.8 / (xmax-xmin);
    data_win.yscale = 1.8 / ydiff;

    if (zmin == zmax) 
       data_win.zscale = 1.0;
    else
       data_win.zscale = -1.8 / (zmax-zmin);	/* sign change to prevent reflection */

    printf("data_win.xscale,yscale,zscale = %f %f %f\n",  
	    data_win.xscale,data_win.yscale,data_win.zscale);

}
/*--------------------------------------------------------------------*/
read_error(error_num)
int error_num;
{
	printf("read_error: error_num = %d\n", error_num);
}
/*--------------------------------------------------------------------*/
flame_filter()
{
extern int uchar_filter,uchar_rad2;

/*	uchar_filter = get_pos_integer("Enter filter value (0-255): ",0);
	uchar_rad2 = get_pos_integer("Enter radius^2: ",0); */
}
