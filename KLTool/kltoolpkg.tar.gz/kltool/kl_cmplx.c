/* kl_cmplx.c - perform complex Karhunen-Loeve decomposition
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */
#include <stdio.h>
#include <math.h>
#include "kl_str.h"

#define X	0
#define Y	1
#define Z	2

#define DPCT 0.95

   /* NB! if change, also change in eigpct.h */
#define MAXEFN 	50

extern double *wrp;
extern double *fv1,*fv2;

double *cov_mtx_r = NULL;			/* covariance matrix (real) */
double *cov_mtx_i = NULL;			/* covariance matrix (imag) */
double *fm1 = NULL;
double *eigvecs_r = NULL;
double *eigvecs_i = NULL;

extern double *eigvals;
extern int num_eig;

extern vec_struct *u_root;		/* to (displayed) eigenfns */

cmplx_vec_struct *cmplx_u_root;		/* to complex eigenfns */


/*--------------------------------------------------------------------*/
cmplx_kl_handler()
{
	char *prompt, *butn[3];
	cmplx_vec_struct *cmplx_list1_root;
	int choice;
/* rf. input.c, mean.c */
extern cmplx_vec_struct *cmplx_caric_root,*cmplx_vec_root,*cmplx_error_root;
extern double *mean_ptr_real, *mean_ptr_imag;
extern int window_pos_mode;
extern cmplx_vec_struct *cmplx_list2_root;


	cmplx_list1_root = cmplx_caric_root;

	     /* If doing K-L on original data, not caric */
	if (mean_ptr_real == NULL)
	   cmplx_list1_root = cmplx_vec_root;

	cmplx_list2_root = cmplx_vec_root;


	if (cmplx_kl_decompose_handler(cmplx_list1_root) < 0)
	   return(-1);

	if (yes_no("Compute eigenfunctions?"))
	   cmplx_kl_efns_handler(cmplx_list2_root);

	window_pos_handler(window_pos_mode);

	return(1);
}
/*--------------------------------------------------------------------*/
cmplx_kl_decompose_handler(list_root)
cmplx_vec_struct *list_root;
{

	if (compute_cov_cmplx(list_root) < 0) 
	      return(-1);

	if (cmplx_kl_compute_eig() >= 0) {
	   update_eigvals_win();
	   return(1);
	}
	else
	   return(-1);
}
/*--------------------------------------------------------------------*/
cmplx_kl_efns_handler(list_root)
cmplx_vec_struct *list_root;
{
extern int	cur_eigfn;
extern win_struct	eigfn_win;

/*	printf("----------------- cmplx_kl_efns_handler -----------\n"); */
	cur_eigfn = 1;

	cmplx_kl_compute_eigfns(num_eig,list_root);

	   /* determine if the window is already displayed */
	if (eigfn_win.id < 0) 
	   create_eigfn_win();

	setup_eigfn_win(cur_eigfn);

	redraw_eigfn(cur_eigfn);
}
/*--------------------------------------------------------------------*/
/* debugging routine... */
check_herm(cr,ci,n)
double cr[50][50],ci[50][50];
int n;
{
   static double eps=0.0000001;
   int i,j;

   printf("checking hermitian of C (n=%d):-------\n",n);
   printf("checking real part:-------\n");
   for (i=0; i<n; i++) {
   for (j=0; j<i; j++) {
      if ((cr[i][j] - cr[j][i]) > eps) {
	 printf("not %d,%d\n",i,j);
      }
   }
   }
   printf("checking imag part:-------\n");
   for (i=0; i<n; i++) {
   for (j=0; j<i; j++) {
      if ((ci[i][j] + ci[j][i]) > eps) {
	 printf("not %d,%d\n",i,j);
      }
   }
   }
}
/*--------------------------------------------------------------------*/
/* Compute the (complex Hermitian) covariance matrix:  
   typically done on caricatures */
compute_cov_cmplx(list_root)
cmplx_vec_struct *list_root;
{
	int res,i,m;
	cmplx_vec_struct *cvsp, *cvsp2;
	double *drp1,*dip1, *drp2,*dip2, *Cp_r,*Cp_i;
	char msg[80];
extern int num_vecs;
extern int res_xy;


/* printf("----------------- begin compute_cov_cmplx -----------------\n"); */

	printf("compute_cov_cmplx: num_vecs= %d, res= %d\n", num_vecs,res_xy);


	   /* NB!  Assuming num_vecs < vector resolution */

	if (cov_mtx_r != NULL) {
	   free(cov_mtx_r);
	   free(cov_mtx_i);
	}

	cov_mtx_r = (double *)malloc(sizeof(double)*num_vecs*num_vecs);
	cov_mtx_i = (double *)malloc(sizeof(double)*num_vecs*num_vecs);
	if (cov_mtx_i == NULL) alloc_fail();
	Cp_r = cov_mtx_r;
	Cp_i = cov_mtx_i;

	pop_feedback();
	m=0;
	TRACE(cvsp,list_root) {
	   drp1 = cvsp->drp;
	   dip1 = cvsp->dip;

	   TRACE(cvsp2,list_root) {
	      drp2 = cvsp2->drp;
	      dip2 = cvsp2->dip;

		/*   = <z1, conj(z2)>   */
	      cmplx_vec_dotprod(drp1,dip1, drp2,dip2, Cp_r,Cp_i);

	      Cp_r++;
	      Cp_i++;
	   }
	   m++;
	   sprintf(msg,"Computing matrix... %d of %d", m,num_vecs);
	   feedback_msg(msg);
	}
	push_feedback();
/*	check_herm(cov_mtx_r,cov_mtx_i,num_vecs); */
	return(1);
}
/*--------------------------------------------------------------------*/
/* Compute eigenvalues/vectors of the (complex) covariance matrix 
 *
 *  NB!  Assumes # of vectors < vector resolution
 */
cmplx_kl_compute_eig()
{
	int i,n,ierr;
	double *ev;
	FILE *fp;
extern int num_vecs;
extern double sum_eigvals;

/* printf("---------------- begin cmplx_kl_compute_eig ---------------\n"); */

	if (eigvecs_r != NULL) {
	   free(wrp);
	   free(fv1);
	   free(fv2);
	   free(fm1);
	   free(eigvecs_r);
	   free(eigvecs_i);
	}

	wrp = (double *)malloc(sizeof(double)*num_vecs);
	fv1 = (double *)malloc(sizeof(double)*num_vecs);
	fv2 = (double *)malloc(sizeof(double)*num_vecs);
	fm1 = (double *)malloc(sizeof(double)*num_vecs*2);
	eigvecs_r = (double *)malloc(sizeof(double)*num_vecs*num_vecs);
	eigvecs_i = (double *)malloc(sizeof(double)*num_vecs*num_vecs);
	if (eigvecs_i == NULL) alloc_fail();


	pop_feedback();
	feedback_msg("computing eigenvalues/vectors of covariance...");

	n = num_vecs;

	   /* Hermitian C -> real eigvals */
	eig_cmplx_(&n,cov_mtx_r,cov_mtx_i,wrp,eigvecs_r,eigvecs_i,
			fv1,fv2,fm1,&ierr);

        printf("cmplx_kl_compute_eig: ierr(eigenval/vec calc) = %d\n", ierr);

	   /* eigenvalues returned in ascending order */

	sum_eigvals = 0.0;
	for (i=0; i<num_vecs; i++) {
	   sum_eigvals += *(wrp+i);
	}
	if (sum_eigvals == 0.0) {
	   error_msg("You seem to have a steady-state case.");
	   return(-1);
	}

	eigvals = (double *)malloc(sizeof(double)*num_vecs);
	ev = eigvals;
	  /* reverse order to put largest eigvals at top */
	printf("(Hermitian) eigenvalues:\n");
	for (i=num_vecs-1; i>=0; i--) {
	   *ev = *(wrp+i);
/*	   printf("%d) %f\n", i,*ev); */
	   ev++;
	}

	push_feedback();

	default_num_eig(num_vecs);
}
/*------------------------------------------------------------*/
cmplx_kl_compute_eigfns(nefns,list_root)
int nefns;
cmplx_vec_struct *list_root;
{
	int i,k,m;
	double *zp_r,*zp_i,vmin,vmax;
	char msg[80];
	FILE *fp;
	vec_struct *usp,*usp2;
	double *udp, factor_r,factor_i;
	cmplx_vec_struct *cvsp, *cusp, *cusp2;
	double *vdrp,*vdip, *udrp,*udip, *alloc_vector();
	double rpart,ipart;
extern int res_xy;
extern int polar_flag;
extern int num_vecs;
extern int cmplx_flag;


	if (eigvecs_r == NULL) {
	   notify_user("Must do decomposition first(cmplx_kl_compute_eigfns)");
	   return(-1);
	}
	if (list_root == NULL) {
	    printf("ERROR - list_root = NULL(cmplx_kl_compute_eigfns)\n");
	    return(-1);
	}

/*	printf("-------------begin cmplx_kl_compute_eigfns ------------\n");
	printf("nefns = %d\n", nefns);
	printf("num_vecs = %d\n", num_vecs);
	printf("res_xy = %d\n", res_xy); */

	  /* free linked list of "displayed" eigfns */
	TRACE(usp,u_root) {
	   free(usp->dp);
	   free(usp);
	}

	  /* free linked list of actual computed eigfns */
	k=0;
	TRACE(cusp,cmplx_u_root) {
	   free(cusp->drp);
	   free(cusp->dip);
	   free(cusp);
	   k++;
	}
	printf("  freed %d records\n", k);

	printf(" vec_resolution = %d\n", res_xy);

	pop_feedback();


	   /* Compute desired number of efns */
	for (k=0; k<nefns; k++) {

	   if (k==0) {
		cusp = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
		cmplx_u_root = cusp;
		cmplx_u_root->prev = NULL;
		cmplx_u_root->next = NULL;

		usp = NEW(vec_struct,sizeof(vec_struct));
		u_root = usp;
		u_root->prev = NULL;
		u_root->next = NULL;
	   }
	   else {
		cusp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
		cusp2->next = NULL;
		cusp->next = cusp2;
		cusp = cusp2;

		usp2 = NEW(vec_struct,sizeof(vec_struct));
		usp2->next = NULL;
		usp->next = usp2;
		usp = usp2;
	   }
		   /* allocate space for eigenfunction (computed & displayed) */
	   udrp = alloc_vector();
	   udip = alloc_vector();
	   cusp->drp = udrp;
	   cusp->dip = udip;

	   udp = alloc_vector();
	   usp->dp = udp;


		/* recall eigvals/vecs sorted in ascending order */
	   zp_r = eigvecs_r + (num_vecs-1-k)*num_vecs;
	   zp_i = eigvecs_i + (num_vecs-1-k)*num_vecs;

	      /* zero the eigenfn */
	   vec_zero(udrp);
	   vec_zero(udip);

		/* zero eigenvalue -> zero eigfn ? */
	   if (*(eigvals+k) < 0.00001) {
	   printf("------zeroing this (%d) eigfn...\n",k);
	      vec_zero(udp);
	      continue;
	   }

	      /* Compute the eigenfn: SUM(m=1,M): vec[m] * phi[m]  */

	   sprintf(msg,"Computing eigenfn #%d", k+1);
	   feedback_msg(msg);

	   m=0;
	   TRACE(cvsp,list_root) {	/* for all vectors in data */
	      vdrp = cvsp->drp;
	      vdip = cvsp->dip;

	      if (vdip == NULL) {
		 printf("ERROR ---vdip = NULL!!!\n");
		 return(-1);
	      }

	      factor_r = *(zp_r + m);
	      factor_i = *(zp_i + m);

		  /* complex multiply */
	      for (i=0; i<res_xy; i++) {
		 *(udrp+i) +=  *(vdrp+i) * factor_r - *(vdip+i) * factor_i;
		 *(udip+i) +=  *(vdip+i) * factor_r + *(vdrp+i) * factor_i;
	      }
	      m++;
	   }

/*	   update_form */
		/* copy eigfn into desired representation for display */
	   switch(cmplx_flag) {
	   case 1:
	      for (i=0; i<res_xy; i++)
	         *(udp+i) = *(udrp+i);
	      break;
	   case 2:
	      for (i=0; i<res_xy; i++)
	         *(udp+i) = *(udip+i);
	      break;
	   case 3:
	      for (i=0; i<res_xy; i++) {
		 /* rf. Num. Recipes for a better calculation */
	         rpart = *(udrp+i);
	         ipart = *(udip+i);
	         *(udp+i) = sqrt(rpart*rpart + ipart*ipart);
	      }
	      break;
	   case 4:
	      for (i=0; i<res_xy; i++) {
	         rpart = *(udrp+i);
	         ipart = *(udip+i);
	         if (rpart == 0.0) {
	           if (ipart == 0.0) *(udp+i) = 0.0;
	           else if (ipart > 0.0) *(udp+i) = M_PI_2;
	           else *(udp+i) = -M_PI_2;
	         }
	         else
	           *(udp+i) = atan(ipart/rpart);
	      }
	      break;
	   }
	}
	push_feedback();
}
