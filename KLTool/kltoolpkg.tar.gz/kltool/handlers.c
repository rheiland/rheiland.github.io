/* handlers.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include "kl_str.h"
#include "data_types.h"

extern int 	menu1,menu2,menu3,menu4,menu5,menu6,menu7,menu8;
int	sync_flag = 0;

/*--------------------------------------------------------------------*/
popups_handler(xpick)
float xpick;
{
    int item;
    float xloc,fudge;
extern int cmplx_flag;
extern float popups_x0, popups_xdel;

/*	printf("popups_handler: xpick = %f\n",xpick); */
	fudge = popups_xdel/4.0;
	xloc  = popups_x0 + popups_xdel;
	for (item=1; item<10; item++) {
/*	   printf("xpick, xloc = %f %f\n", xpick,xloc); */
	   if (xpick < xloc-fudge) 
	      break;
	   else
	      xloc += popups_xdel;
	}
/*	printf("popups_handler: item = %d\n", item); */

	switch(item) {
	case 1:
/*	   printf("	dopup(menu1) = %d\n", dopup(menu1)); */
	   dopup(menu1);
	   break;
	case 2:
/*	   printf("	dopup(menu2) = %d\n", dopup(menu2)); */
	   dopup(menu2);
	   break;
	case 3:
/*	   printf("	dopup(menu3) = %d\n", dopup(menu3)); */
	   dopup(menu3);
	   break;
	case 4:
/*	   printf("	dopup(menu4) = %d\n", dopup(menu4)); */
	   dopup(menu4);
	   break;
	case 5:
/*	   printf("	dopup(menu5) = %d\n", dopup(menu5)); */
	   dopup(menu5);
	   break;
	case 6:
/*	   printf("	dopup(menu6) = %d\n", dopup(menu6)); */
	   dopup(menu6);
	   break;
	case 7:
/*	   printf("	dopup(menu7) = %d\n", dopup(menu7)); */
	   dopup(menu7);
	   break;
	case 8:
	   if (cmplx_flag) {
		dopup(menu8);
		hilite_cmplx_menu();
	   }
	   break;
	}
}

/*--------------------------------------------------------------------*/
dummy_handler()
{
	notify_user("Not yet implemented.");
}
/*--------------------------------------------------------------------*/
input_handler()
{
	FILE *fp_data;
extern char input_dir[];
extern char input_file[];
char datafile[1024];
char msg[256];

	if (!input_form_handler()) return;

	if (!strlen(input_file)) {
	  error_msg("ERROR - invalid input filename");  
	  return(-1);
	}
	printf("strlen(input_file) = %d\n",strlen(input_file));

	strcpy(datafile,input_dir);
	strcat(datafile,"/");
	strcat(datafile,input_file);
	printf("input_handler:  input_file = %s\n",input_file);
	printf("input_handler:  datafile = %s\n",datafile);
	if((fp_data=fopen(datafile, "r")) == NULL)  {
	  printf("ERROR--- can't open datafile %s\n",datafile);
/*	  update_input_msg("ERROR--- can't open datafile"); */
	  sprintf(msg,"Can't open datafile %s",datafile);
	  error_msg(msg);
	}
	else {
	  read_datafile(fp_data);
/*	  fclose(fp_data); */
	}
}
/*--------------------------------------------------------------------*/
flags_handler()
{
  if (!flags_form_handler()) return;
}
/*--------------------------------------------------------------------*/
viewangle_handler(angle)
int angle;
{

extern int	cur_win;
extern int	cur_eigfn;
extern win_struct data_win,mean_win,eigfn_win,appx_win,error_win;


	viewing_angle(angle);

	if (cur_win == data_win.id)
		redraw_data();
	else if(cur_win == mean_win.id)
		redraw_mean();
	else if(cur_win == eigfn_win.id)
		redraw_eigfn(cur_eigfn);
	else if(cur_win == appx_win.id)
		redraw_appx();
	else if(cur_win == error_win.id)
		redraw_error();
}
/*--------------------------------------------------------------------*/
scan_1d_eigfns()
{
extern win_struct eigfn_win;
extern int	cur_eigfn;

	winset(eigfn_win.id);
/*	cmode();
	gconfig(); */
	pop_scan();
	redraw_eigfn(cur_eigfn);
}
/*--------------------------------------------------------------------*/
wire_2d_eigfn(item)
int item;
{
extern win_struct eigfn_win;
extern int cur_eigfn;

	set_win_scan(&eigfn_win);
	pop_scan();
	dials_handler();
	redraw_eigfn(cur_eigfn);
}
/*--------------------------------------------------------------------*/
shade_2d_eigfn(item)
int item;
{
extern win_struct eigfn_win;
extern int cur_eigfn;

	set_win_contour(&eigfn_win,0);
	pop_scan();
	dials_handler();
	redraw_eigfn(cur_eigfn);
}
/*--------------------------------------------------------------------*/
scale_data_handler()
{
extern int scale_cur_vector;
	scale_cur_vector = 1 - scale_cur_vector;
	redraw_data();
}
/*--------------------------------------------------------------------*/
dials_handler()
{
extern int	cur_win,transform_win;
	transform_win = cur_win;
/*	printf("dials_handler:  transform_win = %d\n", transform_win); */
}
/*--------------------------------------------------------------------*/
sync_handler()
{
	   sync_flag = 1 - sync_flag;
}
/*--------------------------------------------------------------------*/
polar_handler()
{
extern int dimension;
extern int polar_flag;
extern int data_type_flag;

	if (dimension == 2) {
	  data_type_flag = RECT;
	  polar_flag = 0;
	}
	polar_flag = 1 - polar_flag;
	if (!polar_flag) {
          printf("polar_handler: setting data_type_flag = RECT\n");
	  data_type_flag = RECT;
        }
	else {
	  data_type_flag = POLAR;
          printf("polar_handler: setting data_type_flag = POLAR\n");
        }
	data_extrema();
}
