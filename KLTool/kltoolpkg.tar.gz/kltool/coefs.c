/* 
 * coefs.c - compute/display coefs (of data or appx) for eigfns.
 *	The coefs computed here are for display - as opposed to
 *	those computed in 'appx' which are most likely for the caricature
 *	vectors and used to compute the appx.
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include "kl_str.h"

double *disp_coef_ptr = NULL;
double *disp_cmplx_coef_ptr = NULL;

#define	MAX_EFN	100

vec_struct *datacoef_root = NULL;
vec_struct *appxcoef_root = NULL;

cmplx_vec_struct *cmplx_datacoef_root = NULL;
cmplx_vec_struct *cmplx_appxcoef_root = NULL;


/*--------------------------------------------------------------------*/
eigfn_data_coef_handler()
{
extern int cmplx_flag;
extern vec_struct *vec_root;
extern cmplx_vec_struct *cmplx_vec_root;
extern int cur_eigfn;
extern win_struct datacoef_win;


	if (cmplx_flag) {
	   if (cmplx_vec_root==NULL) {
	      notify_user("No Data available.");
	      return(-1);
	   }
	   free_cmplx_vec_list(cmplx_datacoef_root);
	   free_vec_list(datacoef_root);
	   cmplx_eigfn_coef(cmplx_vec_root,cmplx_datacoef_root);

	}
	else {
	   eigfn_coef(vec_root,datacoef_root);
	}

	   /* determine if the window is already displayed */
	if (datacoef_win.id < 0) 
	   create_datacoef_win();

	redraw_datacoef();
}
/*--------------------------------------------------------------------*/
eigfn_appx_coef_handler()
{
extern int cmplx_flag;
extern vec_struct *appx_root;
extern cmplx_vec_struct *cmplx_appx_root;
extern int cur_eigfn;
extern win_struct appxcoef_win;


	printf("eigfn_appx_coef_handler...\n");

	if (cmplx_flag) {
	   if (cmplx_appx_root==NULL) {
	      notify_user("No Appx computed.");
	      return(-1);
	   }
	   free_cmplx_vec_list(cmplx_appxcoef_root);
	   free_vec_list(appxcoef_root);
	   cmplx_eigfn_coef(cmplx_appx_root,cmplx_appxcoef_root);
	}
	else {
	   if (appx_root==NULL) {
	      notify_user("No Appx computed.");
	      return(-1);
	   }
	   eigfn_coef(appx_root,appxcoef_root);
	}

	   /* determine if the window is already displayed */
	if (appxcoef_win.id < 0) 
	   create_appxcoef_win();

	redraw_appxcoef();
}
/*--------------------------------------------------------------------*/
eigfn_coef(data_root,coef_root)
vec_struct *data_root, *coef_root;
{
	int m,n,i,j, count;
	double *cdp; 
	double denom[MAX_EFN];
	double vec_dotprod();
	vec_struct *vsp,*usp,*csp,*csp2;
	char buf[80];
extern vec_struct *vec_root,*appx_root,*u_root;
extern int num_vecs,num_eig;
extern int res_xy;


/*	printf("----------------eigfn_coef: num_eig = %d\n", num_eig);
	printf("eigfn_coef: data_root = %d\n", data_root);  */

	if (u_root==NULL) {
	   notify_user("No eigenfunctions present.");
	   return(-1);
	}

	   /* free any existing coef list */
	if (coef_root != NULL) {
	   printf("freeing coef_root...\n");
	   free_vec_list(coef_root);
	   printf("coef_root = %d\n", coef_root);
	}

	pop_feedback();


	if (num_eig > MAX_EFN) {
	   error_msg("Exceeded max # of eigfns...");
	   return(-1);
	}

	   /* Compute denominators one time only:  <u,u>  */
	m=0;
	TRACE(usp,u_root) {		/* for each eigfn  */
	   denom[m] = vec_dotprod(usp->dp,usp->dp);
/*	   printf("denom[%d] = %f\n", m,denom[m]); */
	   m++;
	}

	count = 0;

	/* We want a linked-list to be as long as the # of eigfns */
	TRACE(usp,u_root) {		/* for each eigfn  */

	   sprintf(buf,"Computing coefs for eigfn #%d...", count+1);
	   feedback_msg(buf);

	   if (count == 0) {
		csp = NEW(vec_struct,sizeof(vec_struct));
		coef_root = csp;
		coef_root->prev = NULL;
		coef_root->next = NULL;

		if (data_root == vec_root) 
		   datacoef_root = coef_root;
		else if (data_root == appx_root) 
		   appxcoef_root = coef_root;
	   }
	   else {
		csp2 = NEW(vec_struct,sizeof(vec_struct));
		csp2->next = NULL;
		csp->next = csp2;
		csp = csp2;
	   }
	   cdp = NEW(double,sizeof(double)*num_vecs);
	   csp->dp = cdp;

	   m=0;
	   TRACE(vsp,data_root) {	/* for each data vector (num_vecs) */

	   /* coef = a[m] = <u[m], v> / <u[m],u[m]> */

		*cdp = vec_dotprod(usp->dp,vsp->dp);
		*cdp /= denom[count];


		/* Debugging, cause I didn't believe results; but OK */
/*		*cdp = 0.0;
		for (i=0; i<res_xy; i++) {
		  *cdp += *(usp->dp+i) * *(vsp->dp+i);
		  if ((count==0)&&(m==0)) printf("%d) %f\n",i,*(vsp->dp+i));
		} */
/*		if (count==0) printf("%d) %f\n",m,*cdp);
		m++; */

		cdp++;
	   }
	   count++;
	}
	push_feedback();
	return(1);
}
/*--------------------------------------------------------------------*/
cmplx_eigfn_coef(data_root,coef_root)
cmplx_vec_struct *data_root, *coef_root;
{
	int m,n,i,j, count;
	double *cdrp,*cdip, *cdp; 
	double rval,ival;
	double rdenom[MAX_EFN],idenom[MAX_EFN];
	cmplx_vec_struct *cvsp,*cusp,*ccsp,*ccsp2;
	vec_struct *csp,*csp2;
	char buf[80];
extern cmplx_vec_struct *cmplx_vec_root,*cmplx_appx_root,*cmplx_u_root;
extern int num_vecs,num_eig;


	if (cmplx_u_root==NULL) {
	   notify_user("No eigenfunctions present.");
	   return(-1);
	}

	pop_feedback();

	if (num_eig > MAX_EFN) {
	   error_msg("Exceeded max # of eigfns...");
	   return(-1);
	}

	   /* Compute denominators one time only:  <u,u>  */
	m=0;
	TRACE(cusp,cmplx_u_root) {		/* for each eigfn  */
	   cmplx_vec_dotprod(cusp->drp,cusp->dip,cusp->drp,cusp->dip, 
			     &rdenom[m],&idenom[m]);
	   m++;
	}

	count = 0;
	TRACE(cusp,cmplx_u_root) {		/* for each eigfn  */

	   sprintf(buf,"Computing coefs for eigfn #%d...", count+1);
	   feedback_msg(buf);

	   ccsp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	   csp2 = NEW(vec_struct,sizeof(vec_struct));

	   if (count == 0) {
		ccsp2->next = NULL;
		ccsp2->prev = NULL;
		ccsp = ccsp2;

		csp2->next = NULL;
		csp2->prev = NULL;
		csp = csp2;

		if (data_root == cmplx_vec_root) {
		   cmplx_datacoef_root = ccsp;
		   datacoef_root = csp;
		}
		else if (data_root == cmplx_appx_root) {
		   cmplx_appxcoef_root = ccsp;
		   appxcoef_root = csp;
		}
	   }
	   else {
		ccsp2->next = NULL;
		ccsp2->prev = ccsp;
		ccsp->next = ccsp2;
		ccsp = ccsp2;

		csp2->next = NULL;
		csp2->prev = csp;
		csp->next = csp2;
		csp = csp2;
	   }
	   cdrp = NEW(double,sizeof(double)*num_vecs);
	   cdip = NEW(double,sizeof(double)*num_vecs);
	   ccsp->drp = cdrp;
	   ccsp->dip = cdip;

	   cdp = NEW(double,sizeof(double)*num_vecs);
	   csp->dp = cdp;

	   TRACE(cvsp,data_root) {	/* for each data vector (num_vecs) */

	       /* coef = a[m] = <u[m], v> / <u[m],u[m]> */

	       cmplx_vec_dotprod(cusp->drp,cusp->dip,cvsp->drp,cvsp->drp, 
				  cdrp,cdip);

	       complex_div(*cdrp,*cdip,rdenom[count],idenom[count],&rval,&ival);

	       *cdrp = rval;
	       *cdip = ival;

	       cdrp++;
	       cdip++;
	   }
	   count++;
	}
	push_feedback();

	   /* Display chosen form */
	if (data_root == cmplx_vec_root)
	   update_cmplx_datacoef_form();
	else if (data_root == cmplx_appx_root)
	   update_cmplx_appxcoef_form();

	return(1);
}
