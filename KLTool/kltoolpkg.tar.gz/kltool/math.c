/* math.c - math routines
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */
#include <math.h>


/*------------------------------------------------------------*/
zero_d(v,n)
double *v;
int n;
{
	while (n > 0) {
	   n--;
	   v[n] = 0.0;
	}
}
/*------------------------------------------------------------*/
negate_d(v,n)
double *v;
int n;
{
	while (n > 0) {
	   n--;
	   v[n] = -v[n];
	}
}
/*------------------------------------------------------------*/
minmax_d(v,n,vmin,vmax)
double *v;
int n;
double *vmin,*vmax;
{
/*	printf("minmax_d: n= %d\n", n); */
	*vmin= *vmax = *v;
/*	while (n > 0) {
	   if (*v < *vmin) *vmin = *v;
	   if (*v > *vmax) *vmax = *v;
	   n--;
	   v++;
	} */
	while (n > 0) {
	   n--;
	   if (v[n] < *vmin) *vmin = v[n];
	   if (v[n] > *vmax) *vmax = v[n];
	}
}
/*------------------------------------------------------------*/
minmax_contour(v,n,xmin,xmax,ymin,ymax)
double *v;
int n;
double *xmin,*xmax,*ymin,*ymax;
{
  double *p;

  p = v;
	*xmin= *xmax = *v;
	*ymin= *ymax = *v;
	while (n > 0) {
	   if (*v < *xmin) *xmin = *v;
	   if (*v > *xmax) *xmax = *v;
	   v++;
	   if (*v < *ymin) *ymin = *v;
	   if (*v > *ymax) *ymax = *v;
	   v++;
	   n--;
	}
  v = p;
}
/*------------------------------------------------------------*/
map01_vd(v,n)
double *v;
int n;
{
    double d,vmin,vmax,vrange;
    int i;

    minmax_d(v,n,&vmin,&vmax);
    vrange = vmax - vmin;
    for (i=0; i<n; i++)
       v[i] = (v[i] - vmin) / vrange;
}
/*------------------------------------------------------------*/
normalize_vd(v,n)
double *v;
int n;
{
    double d, norm_vd();
    int i;

/*    printf("--- normed v----\n"); */
    d = norm_vd(v,n);
    printf("norm = %e\n", d);
    for (i=0; i<n; i++)  {
       v[i] /= d;
    }
}

/*------------------------------------------------------------*/
double norm_vd(v,n)
double *v;
int n;
{
    double s;
    int i;

    s = 0.0;
    for (i=0; i<n; i++)
	s += v[i]*v[i];
    s = sqrt(s);
    return(s);
}
/*------------------------------------------------------------*/
normalize(v,n)
double *v;
int n;
{
	int i;
	double s, *temp;

	temp = v;
	s=0;
	for  (i=0; i<n; i++) {
	   s += (*v) * (*v);
	   v++;
	}
	s = sqrt(s);
	v = temp;
	while (n > 0) {
	   *v = (*v) / s;
	   n--;
	   v++;
	}
}
