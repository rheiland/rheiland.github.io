/* feedback_form.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdlib.h>
#include "forms.h"


char *feedback_msg1;
char *feedback_msg2;

static float height = 30.0;
static int color1 = 40;
static int color2 = 54;

static   FL_FORM *dynamic_msg_form;

/*static FL_OBJECT *ok_obj, *cancel_obj; */
static FL_OBJECT *dynamic_msg;

static   int integer_value;
static   float float_value;
static   char string_value[256];

/*------------------------------------------*/
void get_integer_obj(FL_OBJECT *obj,long arg)
{
    integer_value = atoi(fl_get_input(obj));
}
/*------------------------------------------*/
void get_string_obj(FL_OBJECT *obj,long arg)
{
  strcpy(string_value,"\0");
  strcpy(string_value,fl_get_input(obj));
  printf("string_value --> %s\n",string_value);
}

/*--------------------------------------------------------------------*/
int get_pos_integer(char *prompt,int n)
{
   FL_FORM *integer_form;
   FL_OBJECT *obj, *integer_obj;
   char buffer[128];
   float form_width,form_height;
FL_OBJECT *ok_obj, *cancel_obj;

   form_width = 500.0;
   form_height = 300.0;

  integer_form = fl_bgn_form(FL_UP_BOX,form_width,form_height);
    fl_add_text(FL_NORMAL_INPUT,100.0,250,0.0,0.0,prompt);
    integer_obj = fl_add_input(FL_NORMAL_INPUT,100.0,100,100.0,height,"");
    if (n > 0) 
      sprintf(buffer,"%d",n);
    else 
      sprintf(buffer,"");
    fl_set_input(integer_obj,buffer);
    fl_set_object_color(integer_obj,color1,color2);
    fl_set_call_back(integer_obj,get_integer_obj,0);

    cancel_obj = fl_add_button(FL_NORMAL_BUTTON,50.0,10.0,75.0,height,"Cancel");
    ok_obj = fl_add_button(FL_NORMAL_BUTTON,400.0,10.0,75.0,height,"OK");
  fl_end_form();

  fl_show_form(integer_form,FL_PLACE_CENTER,FALSE,NULL);

  do {
    obj = fl_do_forms(); 
  }

  while ((obj != ok_obj) && (obj != cancel_obj));

  fl_hide_form(integer_form);

  if (obj==ok_obj) 
    return integer_value;
  else
    return 0;

}
/*--------------------------------------------------------------------*/
feedback_wait_form()
{
   FL_FORM *form;
   FL_OBJECT *obj, *msgobj;
   float form_width,form_height;
FL_OBJECT *ok_obj, *cancel_obj;

  form_width = 500.0;
  form_height = 300.0;

  form = fl_bgn_form(FL_UP_BOX,form_width,form_height);
    if (feedback_msg1 != NULL) 
      fl_add_text(FL_NORMAL_TEXT,10.0,200.0,0.0,0.0,feedback_msg1);
    if (feedback_msg2 != NULL) 
      fl_add_text(FL_NORMAL_TEXT,10.0,150.0,0.0,0.0,feedback_msg2);

    ok_obj = fl_add_button(FL_NORMAL_BUTTON,400.0,10.0,75.0,height,"OK");
  fl_end_form();

  fl_show_form(form,FL_PLACE_CENTER,FALSE,NULL);

  do {
    obj = fl_do_forms(); 
  }
  while (obj != ok_obj) ;
/*  fl_hide_form(form); */
  fl_free_form(form);
}

/*--------------------------------------------------------------------*/
int get_string(prompt,buf,len)
char *prompt,buf[];
int len;
{
   FL_FORM *form;
   FL_OBJECT *obj, *string_obj;
   float form_width,form_height, x0,y0;
   int k;
FL_OBJECT *ok_obj, *cancel_obj;

  form_width = 500.0;
  form_height = 300.0;

  form = fl_bgn_form(FL_UP_BOX,form_width,form_height);

    x0 = 10.0;
    y0 = 250.0;
    fl_add_text(FL_NORMAL_TEXT,x0,y0,0.0,0.0,prompt);
    x0 = 10.0;
    y0 = 200.0;
    string_obj = fl_add_input(FL_NORMAL_INPUT,x0,y0,form_width-50,height,"");

/*    ok_obj = fl_add_button(FL_RETURN_BUTTON,400.0,10.0,100.0,height,"OK"); */
    ok_obj = fl_add_button(FL_NORMAL_BUTTON,400.0,10.0,75.0,height,"OK");
  fl_end_form();

/*  fl_set_input(input_dir_obj,input_dir); */
  fl_set_object_color(string_obj,color1,color2);
  fl_set_call_back(string_obj,get_string_obj,0);

  fl_show_form(form,FL_PLACE_CENTER,FALSE,NULL);

  do {
    obj = fl_do_forms(); 
  }
  while (obj != ok_obj) ;
  fl_hide_form(form);

/*  return string_value; */
  k = strlen(string_value);
  printf("  string_value --> %s\n",string_value);
	printf("  strlen(buf) = %d\n",k);
  strncpy(buf,string_value,len);
  return k;
/*  strcpy(buf,string_value); */
}
/*--------------------------------------------------------------------*/
nonexistent_data_msg()
{
  error_msg("Error: Data does not exist.");
}
/*--------------------------------------------------------------------*/
error_msg(char *msg)
{

  printf("error_msg:  msg = %s\n",msg);
  feedback_msg1 = msg;
  feedback_msg2 = NULL;
  feedback_wait_form();
}
/*--------------------------------------------------------------------*/
error_msg2(char *msg1, char *msg2)
{
  feedback_msg1 = msg1;
  feedback_msg2 = msg2;
  feedback_wait_form();
}
/*--------------------------------------------------------------------*/
notify_user(char *msg)
{
  printf("feedback.c/notify_user:  msg = %s\n",msg);
  feedback_msg1 = msg;
  feedback_msg2 = NULL;
  feedback_wait_form();
}
/*--------------------------------------------------------------------*/
feedback_msg0(char *msg)
{
  printf("feedback_msg0:  msg = %s\n",msg);
}
/*--------------------------------------------------------------------*/
dynamic_msg0(char *msg)
{
  printf("dynamic_msg:  msg = %s\n",msg);
}
/*--------------------------------------------------------------------*/
dynamic_msg_window(int on)
{
   FL_OBJECT *obj, *msgobj;
   float form_width,form_height;

   form_width = 500.0;
   form_height = 300.0;

  if (on) {
    dynamic_msg_form = fl_bgn_form(FL_UP_BOX,form_width,form_height);
      dynamic_msg = fl_add_box(FL_FLAT_BOX,10.0,200.0,400.0,height,"");
    fl_end_form();

    fl_show_form(dynamic_msg_form,FL_PLACE_CENTER,FALSE,NULL);
  }
  else
    fl_hide_form(dynamic_msg_form);
}
/*--------------------------------------------------------------------*/
update_dynamic_msg(char *msg)
{
   fl_set_object_label(dynamic_msg,msg);
}
/*--------------------------------------------------------------------*/
pop_feedback()
{
/*   printf("pop_feedback...\n"); */
  foreground();
   dynamic_msg_window(1);
}
/*--------------------------------------------------------------------*/
feedback_msg(char *msg)
{
/*   printf("feedback_msg: %s\n",msg); */
   update_dynamic_msg(msg);
}
/*--------------------------------------------------------------------*/
push_feedback()
{
/*   printf("pop_feedback...\n"); */
   dynamic_msg_window(0);
  foreground();
}
/*--------------------------------------------------------------------*/
int yes_no(char *prompt)
{
   FL_FORM *form;
   FL_OBJECT *obj;
   float form_width,form_height;
FL_OBJECT *ok_obj, *cancel_obj;

   form_width = 500.0;
   form_height = 300.0;

  form = fl_bgn_form(FL_UP_BOX,form_width,form_height);
    fl_add_text(FL_NORMAL_INPUT,100.0,150,0.0,0.0,prompt);

    cancel_obj = fl_add_button(FL_NORMAL_BUTTON,50.0,10.0,75.0,height,"No");
    ok_obj = fl_add_button(FL_NORMAL_BUTTON,400.0,10.0,75.0,height,"Yes");
  fl_end_form();

  fl_show_form(form,FL_PLACE_CENTER,FALSE,NULL);

  do {
    obj = fl_do_forms(); 
  }

  while ((obj != ok_obj) && (obj != cancel_obj));

  fl_hide_form(form);

  if (obj==ok_obj) 
    return 1;
  else
    return 0;
}
