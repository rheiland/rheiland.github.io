get_prompt_msg(msg,n,butn)
char *msg, *butn[];
int n;
{
  printf("\n\n\n    get_prompt_msg   called.....    \n\n\n");
}
