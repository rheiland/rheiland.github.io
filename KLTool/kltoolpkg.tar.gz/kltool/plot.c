/* plot.c - plotting
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include "kl_str.h"
#include "data_types.h"

char plot_scripts_dir[256];
static char script_file[256];
static char cmd[512];

/*------------------------------------------------------------*/
script_file_exists(char *fname)
{
  if (fopen(fname,"r") == NULL) {
    error_msg2("Cannot open plot file:",fname);
    return 0;
  }
  else
    return 1;
}
/*------------------------------------------------------------*/
int get_plot_dir()
{
  int k;

  if (getenv("KLPLOT") == NULL) {
    error_msg("'KLPLOT' env var not set.");
    k = get_string("Enter dir for plot scripts: ",plot_scripts_dir,256);
    if (!k) 
      return 0;
    else 
      return 1;
  }
  else {
    strcpy(plot_scripts_dir,getenv("KLPLOT"));
    return 1;
  }
}
/*------------------------------------------------------------*/
plot_eigvals()
{
	int i;
	FILE *ofp,*ofp2;
	double pct,pctsum;
	float p[5];
extern int num_eig;
extern double *eigvals, sum_eigvals;
extern char input_file[80];

/*	if (!get_plot_dir()) return(-1); */

	ofp = fopen("eigpct.plt","w");
	ofp2 = fopen("eigsum.plt","w");

	fprintf(ofp," 0.0 0.0\n");
	pctsum = 0.0;
	for (i=0; i<num_eig; i++) {
	   pct = *(eigvals+i)/sum_eigvals;
	   pctsum += pct;

	   if (i < 3) 
	      p[i] = pct*100.;

	   fprintf(ofp," %d %f\n", i,pct);
	   fprintf(ofp," %d %f\n", i+1,pct);
	   fprintf(ofp," %d %f\n", i+1,0.0);

	   fprintf(ofp2," %d %f\n", i,pctsum);
	   fprintf(ofp2," %d %f\n", i+1,pctsum);
	   fprintf(ofp2," %d %f\n", i+1,0.0);
	}
	fclose(ofp);
	fclose(ofp2);

	strcpy(script_file,plot_scripts_dir);
	strcat(script_file,"/plot_eig.sh");
	if (!script_file_exists(script_file))
	  return 0;

	sprintf(cmd,"%s %s %d %4.1f %4.1f %4.1f %4.1f",
             script_file,input_file,num_eig,pctsum*100.,
	     p[0],p[1],p[2]);
	system(cmd);
}
/*------------------------------------------------------------*/
plot_vector()
{
extern int	cur_win;
extern win_struct data_win,appx_win,error_win;


	if(cur_win == data_win.id) {
	   plot_data_vec();
	}
	else if(cur_win == appx_win.id) {
	   plot_appx_vec();
	}
	else if(cur_win == error_win.id) {
	   plot_error_vec();
	}
}
/*------------------------------------------------------------*/
plot_data_vec()
{
	int count;
	vec_struct *vsp;
	double *dp;
	FILE *fp;
	char *fname, label[20];
extern vec_struct *vec_root;
extern int dimension;
extern int cur_vector;

	count=0;
	TRACE(vsp,vec_root) {
	   count++;
	   if (count == cur_vector) break;
	}
	dp = vsp->dp;

	if (dimension == 1) {
	   fname = "vec1d.dat";
	}
	else {
	   fname = "vec2d.dat";
	}
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);

	vec_to_file(dp,fp);
	fclose(fp);

	sprintf(label,"[%d]",cur_vector);
	plot_file(fname,label);
}
/*------------------------------------------------------------*/
plot_mean_vec()
{
	FILE *fp;
	char *fname;
extern double *mean_ptr;
extern int dimension;


	if (dimension == 1) {
	   fname = "mean1d.dat";
	}
	else {
	   fname = "mean2d.dat";
	}
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);

	vec_to_file(mean_ptr,fp);
	fclose(fp);

	plot_file(fname,"");
}
/*------------------------------------------------------------*/
plot_eigfn_vec()
{
	int count;
	vec_struct *vsp;
	double *dp;
	FILE *fp;
	char *fname,label[20];
extern vec_struct *u_root;
extern int dimension;
extern int	cur_eigfn;

	count=0;
	TRACE(vsp,u_root) {
	   count++;
	   if (count == cur_eigfn) break;
	}
	dp = vsp->dp;

	if (dimension == 1) {
	   fname = "eigf1d.dat";
	}
	else {
	   fname = "eigf2d.dat";
	}
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);

	eigvec_to_file(dp,fp);
	fclose(fp);

	sprintf(label,"[%d]",cur_eigfn);
	plot_file(fname,label);
}
/*------------------------------------------------------------*/
plot_datacoef_vec()
{
	int count;
	vec_struct *csp;
	FILE *fp;
	char *fname;
extern vec_struct *datacoef_root;
extern int num_vecs;
extern int cur_datacoef;

	count=0;
	TRACE(csp,datacoef_root) {
	   count++;
	   if (count == cur_datacoef) break;
	}

	fname = "datacoefs.dat";
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);
	fwrite(csp->dp,sizeof(double),num_vecs,fp);
	fclose(fp);

	strcpy(script_file,plot_scripts_dir);
	strcat(script_file,"/plot1d.sh");
	if (!script_file_exists(script_file))
	  return 0;

	sprintf(cmd,"%s %s [%d]", script_file,fname,cur_datacoef);
	system(cmd);
}
/*------------------------------------------------------------*/
plot_appxcoef_vec()
{
	int count;
	vec_struct *csp;
	FILE *fp;
	char *fname;
extern vec_struct *appxcoef_root;
extern int num_vecs;
extern int cur_appxcoef;

	count=0;
	TRACE(csp,appxcoef_root) {
	   count++;
	   if (count == cur_appxcoef) break;
	}

	fname = "appxcoefs.dat";
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);
	fwrite(csp->dp,sizeof(double),num_vecs,fp);
	fclose(fp);

	strcpy(script_file,plot_scripts_dir);
	strcat(script_file,"/plot1d.sh");
	if (!script_file_exists(script_file))
	  return 0;

	sprintf(cmd,"%s %s [%d]", script_file,fname,cur_appxcoef);
	system(cmd);
}
/*------------------------------------------------------------*/
plot_appx_vec()
{
	int count;
	vec_struct *vsp;
	double *dp;
	FILE *fp;
	char *fname,label[20];
extern vec_struct *appx_root;
extern int dimension;
extern int cur_appx;

	count=0;
	TRACE(vsp,appx_root) {
	   count++;
	   if (count == cur_appx) break;
	}
	dp = vsp->dp;

	if (dimension == 1) {
	   fname = "appx1d.dat";
	}
	else {
	   fname = "appx2d.dat";
	}
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);

	vec_to_file(dp,fp);
	fclose(fp);

	sprintf(label,"[%d]",cur_appx);
	plot_file(fname,label);
}
/*------------------------------------------------------------*/
plot_error_vec()
{
	int count;
	vec_struct *vsp;
	double *dp;
	FILE *fp;
	char *fname,label[20];
extern vec_struct *error_root;
extern int dimension;
extern int cur_error;

	count=0;
	TRACE(vsp,error_root) {
	   count++;
	   if (count == cur_error) break;
	}
	dp = vsp->dp;

	if (dimension == 1) {
	   fname = "error1d.dat";
	}
	else {
	   fname = "error2d.dat";
	}
	fp = fopen(fname,"w");
	printf("plotting %s\n",fname);

	vec_to_file(dp,fp);
	fclose(fp);

	sprintf(label,"[%d]",cur_error);
	plot_file(fname,label);
}
/*------------------------------------------------------------*/
plot_file(fname,label)
char *fname,*label;
{
extern int dimension, polar_flag,vec_flag;
extern int data_type_flag;
extern float polar_rmax;
extern int res_x;

	if (dimension == 1) {
	  strcpy(script_file,plot_scripts_dir);
	  if ((data_type_flag == RECT) || (data_type_flag == COMPLEX))
	    strcat(script_file,"/plot1d.sh");
	  else if (data_type_flag == POLAR) 
	    strcat(script_file,"/plotpolar.sh");

	  if (!script_file_exists(script_file))
	      return 0;

	  if ((data_type_flag == RECT) || (data_type_flag == COMPLEX))
	    sprintf(cmd,"%s %s %s", script_file,fname,label);
	  else if (data_type_flag == POLAR) 
	    sprintf(cmd,"%s %s %s %f", script_file,fname,label,polar_rmax);

	  printf("cmd = %s\n",cmd);

	  system(cmd);
	}
	else if (dimension == 2) {
	   if (data_type_flag == VEC2D) {
	      strcpy(script_file,plot_scripts_dir);
	      strcat(script_file,"/plotvec2d.sh");
	      if (!script_file_exists(script_file))
	         return 0;
	      sprintf(cmd,"%s %s %s", script_file,fname,label);
	      system(cmd);
	   }
	   else {
/*	      error_msg("Plotting not possible for 2D data yet."); */
	      strcpy(script_file,plot_scripts_dir);
	      strcat(script_file,"/plot2d.sh");
	      if (!script_file_exists(script_file))
	         return 0;
	      sprintf(cmd,"%s %s %d %s", script_file,fname,res_x,label);
	      system(cmd);
	   }
	}
}
