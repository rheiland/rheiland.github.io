/* error.c - 
 *	Using the existing approximation, compute the error:
 * 		= data - appx
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include "kl_str.h"


static int debug = 0;


vec_struct *error_root = NULL;
cmplx_vec_struct *cmplx_error_root = NULL;
int num_eig_error;

/*--------------------------------------------------------------------*/
error_handler()
{
	double vmin,vmax;
extern int cmplx_flag;
extern double error_min,error_diff;
extern win_struct error_win;
extern int num_eig_appx;
extern int scan_error_win;
extern int cur_error;


	num_eig_error = num_eig_appx;

	if (cmplx_flag) {
	   if (compute_error_cmplx() < 0)
	      return(-1);
	}
	else {
	   if (compute_error() < 0)
	      return(-1);
	}

	   /* needed for color contours */
	veclist_minmax(error_root,&vmin,&vmax);
	error_min = vmin;
	error_diff = vmax - vmin;

	   /* determine if the window is already displayed */
	if (error_win.id < 0) 
	   create_error_win();

	redraw_error();
	draw_scan_win2(scan_error_win,cur_error,num_eig_error);
}
/*------------------------------------------------------------*/
compute_error()
{
	int count;
	double *alloc_vector();
	char msg[80];
	vec_struct *esp,*esp2,*vsp,*asp;
extern vec_struct *vec_root;
extern vec_struct *appx_root;


	if (vec_root == NULL) {
	   notify_user("Must read Data first.");
	   return(-1);
	}
	else if (appx_root == NULL) {
	   notify_user("Must compute Appx first.");
	   return(-1);
	}


	   /* free old list */
	TRACE(esp,error_root) {
	   free(esp->dp);
	   free(esp);
	}
	error_root = NULL;

	count = 0;

/*	pop_feedback(); */
	asp = appx_root;
	TRACE(vsp,vec_root) {		/* for each data vector */

	   esp2 = NEW(vec_struct,sizeof(vec_struct));
	      
	   if (error_root == NULL) {	/* Begin new list of error vectors */
		esp2->next = NULL;
		esp2->prev = NULL;
		esp = esp2;
		error_root = esp;
	   }
	   else {
		esp2->next = NULL;
		esp2->prev = esp;
		esp->next = esp2;
		esp = esp2;
	   }


	   esp->dp = alloc_vector();	/* alloc space for error vector */

	   vec_copy(vsp->dp,esp->dp);

	   vec_subtract(esp->dp,asp->dp);

	   count++;
	   asp = NEXT(asp);		/* get next Appx vector */

	   sprintf(msg,"Error vec #%d",count);
	   feedback_msg(msg);

	} /* end TRACE */
/*	push_feedback(); */

	return(1);
}
/*------------------------------------------------------------*/
compute_error_cmplx()
{
	int count;
	double *alloc_vector();
	char msg[80];
	cmplx_vec_struct *cesp,*cesp2,*cvsp,*casp;
	vec_struct *esp,*esp2;
extern cmplx_vec_struct *cmplx_vec_root;
extern cmplx_vec_struct *cmplx_appx_root;


	if (cmplx_vec_root == NULL) {
	   notify_user("Must read Data first.");
	   return(-1);
	}
	else if (cmplx_appx_root == NULL) {
	   notify_user("Must compute Appx first.");
	   return(-1);
	}


	   /* free old list */
	TRACE(cesp,cmplx_error_root) {
	   free(cesp->drp);
	   free(cesp->dip);
	   free(cesp);
	}
	cmplx_error_root = NULL;

	  /* also for displayed form (real,imag,etc.) */
	TRACE(esp,error_root) {
	   free(esp->dp);
	   free(esp);
	}
	error_root = NULL;

	count = 0;

/*	pop_feedback(); */
	casp = cmplx_appx_root;
	TRACE(cvsp,cmplx_vec_root) {		/* for each data vector */

	   cesp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	   esp2 = NEW(vec_struct,sizeof(vec_struct));
	      
	   if (cmplx_error_root == NULL) {
		cesp2->next = NULL;
		cesp2->prev = NULL;
		cesp = cesp2;
		cmplx_error_root = cesp;

		esp2->next = NULL;
		esp2->prev = NULL;
		esp = esp2;
		error_root = esp;
	   }
	   else {
		cesp2->next = NULL;
		cesp2->prev = cesp;
		cesp->next = cesp2;
		cesp = cesp2;

		esp2->next = NULL;
		esp2->prev = esp;
		esp->next = esp2;
		esp = esp2;
	   }


	   cesp->drp = alloc_vector();	/* alloc space for error vector */
	   cesp->dip = alloc_vector();

	   esp->dp = alloc_vector();

	   vec_copy(cvsp->drp,cesp->drp);
	   vec_copy(cvsp->dip,cesp->dip);

	   vec_subtract(cesp->drp,casp->drp);
	   vec_subtract(cesp->dip,casp->dip);

	   count++;
	   casp = NEXT(casp);		/* get next Appx vector */

	   sprintf(msg,"Error vec #%d",count);
	   feedback_msg(msg);

	} /* end TRACE */
/*	push_feedback(); */

	update_cmplx_error_form();

	return(1);
}
/*--------------------------------------------------------------------*/
max_error_handler()
{
	char msg[120];
	int i,kount,mvec,mpos;
	double diff,max_error, *vdp,*adp;
	vec_struct *vsp,*asp;
extern int res_xy;
extern int vec_flag;
extern vec_struct *vec_root;
extern vec_struct *appx_root;


	if (vec_flag) {
	  error_msg("Not available for 2D vector data yet");
	  return(-1);
	}

	if (vec_root == NULL) {
	   notify_user("Must read Data first.");
	   return(-1);
	}
	else if (appx_root == NULL) {
	   notify_user("Must compute Appx first.");
	   return(-1);
	}

	kount = 0;
	max_error = 0.0;

	asp = appx_root;
	TRACE(vsp,vec_root) {		/* for each data vector */

	   vdp = vsp->dp;
	   adp = asp->dp;

	   kount++;

	   for (i=0; i<res_xy; i++) {
	      diff = *vdp - *adp;
	      if (fabs(diff) > fabs(max_error)) {
	         max_error = diff;
		 mvec = kount;
		 mpos = i;
	      }
	      vdp++;
	      adp++;
	   }
	   asp = NEXT(asp);
	}

	mpos++;
	sprintf(msg,"max error(data-appx)= %.5f, vector %d, pos %d",
		max_error,mvec,mpos);
	notify_user(msg);
}
