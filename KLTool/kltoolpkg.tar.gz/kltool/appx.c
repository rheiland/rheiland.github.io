/* appx.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 *	1) Compute the coefficients for each vector in the dataset
 *	   using the original vectors, the mean, and the eigenfunctions.
 *
 *	   i.e,  a[n] = (u[n], v-mean)
 *		where the u[n] are eigenfns of the caricature (vector-mean)
 *
 *	2) Compute projection, i.e, approximation to actual dataset
 *
 */

#include <stdio.h>
#include <math.h>
#include "kl_str.h"


#define	MAX_EFN	100

static int debug = 0;


extern vec_struct *caric_root, *vec_root, *u_root;
extern cmplx_vec_struct *cmplx_caric_root, *cmplx_vec_root, *cmplx_u_root;
cmplx_vec_struct *cmplx_dummy_root;

double *coef_ptr = NULL;
double *cmplx_coef_ptr = NULL;
vec_struct *appx_root = NULL;
cmplx_vec_struct *cmplx_appx_root = NULL;
int num_eig_appx;


/*--------------------------------------------------------------------*/
appx_handler()
{
	char buf[120];
	int neig,num_eigfns;
extern int num_eig;
extern win_struct appx_win;
extern int cmplx_flag;
extern int scan_appx_win;
extern int cur_appx;

	neig = get_pos_integer("Enter # of eigfns to use: ",num_eig);

	num_eigfns = count_eigfns();

	if (neig > num_eigfns) {
	   sprintf(buf,"Cannot use more than # of eigfns computed(%d).",num_eigfns);
	   error_msg(buf);
	   return(-1);
	}
	else if (neig > 0) 
	   num_eig = neig;
/*	else {
	   error_msg("Invalid number.");
	   return(-1);
	} */

/*	push_feedback(); */


	num_eig_appx = num_eig;

	if (cmplx_flag) {
	   if(compute_coefs_cmplx() < 0) {
	      printf("appx_handler:  compute_coefs_cmplx() ERROR\n");
	      return(-1);
	   }
	   if (compute_appx_cmplx() < 0) 
	      return(-1);
	}
	else {
	   if (compute_coefs() < 0) {
	      printf("appx_handler:  compute_coefs() ERROR\n");
	      return(-1);
	   }
	   if (compute_appx() < 0) 
	      return(-1);
	}


	   /* determine if the window is already displayed */
	if (appx_win.id < 0) 
	   create_appx_win();

	redraw_appx();
	draw_scan_win2(scan_appx_win,cur_appx,num_eig_appx);
}
/*--------------------------------------------------------------------*/
count_eigfns()
{
	vec_struct *usp;
	int i;

	i=0;
	TRACE(usp,u_root) {
	   i++;
	}
	return(i);
}
/*--------------------------------------------------------------------*/
compute_coefs()
{
	int m,n,i,j, count;
	int save_flag;
	double *coef, *dp,*v,*u; 
	double denom[MAX_EFN];
	double vec_dotprod();
	double *alloc_vector();
	char buf[120];
	vec_struct *vsp,*usp;
	vec_struct *dummy_root;
extern int num_vecs;
extern int res_xy;
extern double *mean_ptr;
extern double *eigvals;
extern int num_eig;


	if (u_root==NULL) {
	   notify_user("No eigenfunctions present.");
	   return(-1);
	}

/*	printf("--------------- begin compute_coefs ---------------\n");
	printf("num_vecs= %d, num_eig= %d\n", num_vecs,num_eig);
	printf("res_xy= %d\n", res_xy); */

	count = 0;
	strcpy(buf,"coefs.dat");

	pop_feedback();
/*	save_flag = yes_no("Create coefs file (coefs.dat)?"); */


	  /*--------------------------------------------------
	     The "datastructure" for coefs goes as follows:
	       the coefs are in blocks of 'num_eig' long
	       and there are 'num_vecs' of these blocks smashed together
	   --------------------------------------------------*/
	if (coef_ptr != NULL) free(coef_ptr);
	coef_ptr = NEW(double,sizeof(double)*num_eig*num_vecs);
	coef = coef_ptr;

	if (num_eig > MAX_EFN) {
	   error_msg("Exceeded max # of eigfns...");
	   return(-1);
	}

	   /* Compute denominators one time only:  <u,u>  */
	usp = u_root;
	for (m=0; m<num_eig; m++) {
	   denom[m] = vec_dotprod(usp->dp,usp->dp);
	   usp = NEXT(usp);
	}

	if (mean_ptr == NULL) {
	   if (vec_root == NULL) {
	      error_msg("ERROR - Data list is empty.");
	      return(-1);
	   }
	   dummy_root = vec_root;
	}
	else {
	   if (caric_root == NULL) {
	      error_msg("ERROR - Caricature list is empty (compute Mean).");
	      return(-1);
	   }
	   dummy_root = caric_root;
	}

	TRACE(vsp,dummy_root) {		/* for each vector (num_vecs) */

	   sprintf(buf,"Computing coefs for vec #%d...", count+1);
	   feedback_msg(buf);

	    /* coef = a[m] = (dotprod(u[m], v-mean)) / dotprod(u[m],u[m]) */
	   usp = u_root;
	   for (m=0; m<num_eig; m++) {
		*coef = vec_dotprod(usp->dp,vsp->dp);

		if (denom[m] != 0.0)
		   *coef /= denom[m];

/*		if (count == 1) printf("vec %d) coef = %f\n", m,*coef); */

		coef++;

		usp = NEXT(usp);
	   }
	   count++;
	}
	push_feedback();

	return(1);
}
/*--------------------------------------------------------------------*/
compute_coefs_cmplx()
{
	int m,n,i,j, count;
	int save_flag;
	double *coef, *rcoef,*icoef; 
	double rdenom[MAX_EFN],idenom[MAX_EFN];
	double rval,ival;
	double *alloc_vector();
	char buf[120];
	cmplx_vec_struct *vsp,*usp;
	cmplx_vec_struct *dummy_root;
extern int num_vecs;
extern int res_xy;
extern double *mean_ptr_real,*mean_ptr_imag;
extern double *eigvals;
extern int num_eig;


	if (cmplx_u_root==NULL) {
	   notify_user("No eigenfunctions present.");
	   return(-1);
	}

/*	printf("------------ begin compute_coefs_cmplx ----------\n");
	printf("num_vecs= %d, num_eig= %d\n", num_vecs,num_eig);
	printf("res_xy= %d\n", res_xy); */

	count = 0;
	strcpy(buf,"cmplx_coefs.dat");

	pop_feedback();
/*	save_flag = yes_no("Create coefs file (cmplx_coefs.dat)?"); */


	   /* Alloc space for complex coefs */
	if (cmplx_coef_ptr != NULL) free(cmplx_coef_ptr);
	cmplx_coef_ptr = NEW(double,sizeof(double)*num_eig*num_vecs*2);
	coef = cmplx_coef_ptr;

	if (num_eig > MAX_EFN) {
	   error_msg("Exceeded max # of eigfns...");
	   return(-1);
	}

	   /* Compute denominators one time only:  <u,u>  */
	usp = cmplx_u_root;
	for (m=0; m<num_eig; m++) {
	   cmplx_vec_dotprod(usp->drp,usp->dip,usp->drp,usp->dip, 
			     &rdenom[m],&idenom[m]);
	   usp = NEXT(usp);
/*	   printf("%d) %f %f\n",m,rdenom[m],idenom[m]); */
	}


	if (mean_ptr_real == NULL) {		/* has mean been computed? */
	   if (cmplx_vec_root == NULL) {
	      error_msg("ERROR - Data list is empty.");
	      return(-1);
	   }
	   dummy_root = cmplx_vec_root;	  /* if not, do KL on orig data */
	}
	else {
	   if (cmplx_caric_root == NULL) {
	      error_msg("ERROR - Caricature list is empty (compute Mean).");
	      return(-1);
	   }
	   dummy_root = cmplx_caric_root;  /*if mean present, do KL on carics */
	}

/*	  printf("------ cmplx coefs -----\n"); */
	TRACE(vsp,dummy_root) {	/* for each vector (num_vecs) */

	   sprintf(buf,"Computing coefs for vec #%d...", count+1);
	   feedback_msg(buf);


	    /* coef = a[m] = <u[m], v> / <u[m],u[m]>   */
	   usp = cmplx_u_root;
	   for (m=0; m<num_eig; m++) {

		rcoef = coef;
		coef++;
		icoef = coef;
		coef++;
		cmplx_vec_dotprod(vsp->drp,vsp->dip,usp->drp,usp->dip, 
				  rcoef,icoef);

/*		complex_div(*rcoef,*icoef,rdenom[m],idenom[m], &rval,&ival); */
		if (rdenom[m] != 0.0) {
		   rval = *rcoef / rdenom[m];
		   ival = *icoef / rdenom[m];
		}

		*rcoef = rval;
		*icoef = ival;

		usp = NEXT(usp);
	   }
	   count++;
	}
	push_feedback();

	return(1);
}
/*------------------------------------------------------------*/
compute_appx()
{
	int m,n,i,j, count;
	double *a,*c,*u;
	double *alloc_vector();
	char msg[80];
	vec_struct *asp,*asp2,*vsp,*usp;
	vec_struct *dummy_root;
extern int res_xy;
extern double *mean_ptr;
extern int num_eig;
extern int num_vecs;
extern int vec_flag;


	if (coef_ptr == NULL) {
	   notify_user("No coefs computed");
	   printf("No coefs computed\n");
	   return(-1);
	}

/*	printf("num_vecs= %d, num_eig= %d\n", num_vecs,num_eig);
	printf("res_xy = %d\n", res_xy); */


	   /* free old list */
	TRACE(asp,appx_root) {
	   free(asp->dp);
	   free(asp);
	}
	appx_root = NULL;


	c = coef_ptr;		/* ptr to coefs */

	pop_feedback();
	count = 0;
	if (mean_ptr == NULL)
	   dummy_root = vec_root;
	else
	   dummy_root = caric_root;
/*	TRACE(vsp,caric_root) {  */		/* for each data vector */
	TRACE(vsp,dummy_root) {		/* for each data vector */
	   asp2 = NEW(vec_struct,sizeof(vec_struct));
	      
	   if (appx_root == NULL) {	/* Begin new list of appx vectors */
		asp2->next = NULL;
		asp2->prev = NULL;
		asp = asp2;
		appx_root = asp;
	   }
	   else {
		asp2->next = NULL;
		asp2->prev = asp;
		asp->next = asp2;
		asp = asp2;
	   }


	   asp->dp = alloc_vector();	/* alloc space for appx vector */

	   vec_zero(asp->dp);
	   a = asp->dp;

		/* appx_vec = mean + SUM(c[i]*u[i])   */

	   usp = u_root;
/*	   TRACE (usp,u_root) { */
	   m=0;
	   for (m=0; m<num_eig; m++) {

		u = usp->dp;

/*		vec_mult_scalar(u,*c,a); */   /* seems to not work */
		if (!vec_flag) {
		  for (i=0; i<res_xy; i++)
		    *(a+i) += *c * *(u+i);
		}
		else {
		  for (i=0; i<res_xy*2; i++)
		    *(a+i) += *c * *(u+i);
		}

		usp = NEXT(usp);

		c++;

		  /* NB!!! leave this in only if doing TRACE !! */
/*		m++; */
	   }

		/* Add on mean */
	   if (mean_ptr != NULL)
	      vec_add(asp->dp,mean_ptr);

	   count++;
	   sprintf(msg,"Appx vec #%d",count);
	   feedback_msg(msg);

	} /* end TRACE */
	push_feedback();

	return(1);
}
/*------------------------------------------------------------*/
compute_appx_cmplx()
{
	int m,n,i,j, count;
	double *ar,*ai, *c,cr,ci, *ur,*ui;
	double *alloc_vector();
	double vmin,vmax;
	char msg[80];
	cmplx_vec_struct *casp,*casp2,*cvsp,*cusp;
	vec_struct *asp,*asp2;
	cmplx_vec_struct *dummy_root;
extern int res_xy;
extern double *mean_ptr_real,*mean_ptr_imag;
extern int num_eig;
extern int num_vecs;



	if (cmplx_coef_ptr == NULL) {
	   notify_user("No coefs computed");
	   printf("No coefs computed\n");
	   return(-1);
	}

/*	printf("num_vecs= %d, num_eig= %d\n", num_vecs,num_eig);
	printf("res_xy = %d\n", res_xy); */


	   /* free old list */
	TRACE(casp,cmplx_appx_root) {
	   free(casp->drp);
	   free(casp->dip);
	   free(casp);
	}
	cmplx_appx_root = NULL;

	  /* also for displayed form (real,imag,etc.) */
	TRACE(asp,appx_root) {
	   free(asp->dp);
	   free(asp);
	}
	appx_root = NULL;


	c = cmplx_coef_ptr;		/* ptr to coefs */

	pop_feedback();
	count = 0;
	if (mean_ptr_real == NULL)
	   dummy_root = cmplx_vec_root;
	else
	   dummy_root = cmplx_caric_root;

	TRACE(cvsp,dummy_root) {		/* for each data vector */
	   casp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	   asp2 = NEW(vec_struct,sizeof(vec_struct));
	      
	   if (cmplx_appx_root == NULL) {  /* Begin new list of appx vectors */
		casp2->next = NULL;
		casp2->prev = NULL;
		casp = casp2;
		cmplx_appx_root = casp;

		asp2->next = NULL;
		asp2->prev = NULL;
		asp = asp2;
		appx_root = asp;
	   }
	   else {
		casp2->next = NULL;
		casp2->prev = casp;
		casp->next = casp2;
		casp = casp2;

		asp2->next = NULL;
		asp2->prev = asp;
		asp->next = asp2;
		asp = asp2;
	   }


	   asp->dp = alloc_vector();	/* alloc space for appx vector */

	   casp->drp = alloc_vector();
	   casp->dip = alloc_vector();

	   vec_zero(casp->drp);
	   vec_zero(casp->dip);
	   ar = casp->drp;
	   ai = casp->dip;

		/* appx_vec = mean + SUM(c[i]*u[i])   */

	   cusp = cmplx_u_root;
	   m=0;
	   for (m=0; m<num_eig; m++) {

		ur = cusp->drp;
		ui = cusp->dip;

		cr = *c;
		c++;
		ci = *c;
		c++;

		  /*  c*u = (cr*ur - ci*ui, cr*ui + ci*ur)  */
		for (i=0; i<res_xy; i++) {
		   *(ar+i) += cr * *(ur+i) - ci * *(ui+i);
		   *(ai+i) += cr * *(ui+i) + ci * *(ur+i);
		}

		cusp = NEXT(cusp);
	   }

		/* Add on mean */
	   if (mean_ptr_real != NULL) {
	      vec_add(casp->drp,mean_ptr_real);
	      vec_add(casp->dip,mean_ptr_imag);
	   }

	   count++;
	   sprintf(msg,"Appx vec #%d",count);
	   feedback_msg(msg);

	} /* end TRACE */
	push_feedback();

	update_cmplx_appx_form();

	return(1);
}
