
float laplacian[64][64];

/*--------------------------------------------------------------------*/
#define MSIZE 66
float p[MSIZE][MSIZE];
assign_vertex_colors()
{
    int i,j,k,mesh_size;
    int nbytes, maximize;
    FILE *meshfp, *fopen();
    int frame_count;
    float min_val, max_val, val_range;
    float pct;
    float rval,gval,bval, delta;


    free_memory();

    root = NEW(mesh_colors,sizeof(mesh_colors));
    root->next = NULL;
    mcp = root;

    if ( (meshfp = fopen(mesh_file, "r") ) == NULL) {
	printf("error opening mesh file\n");
	return(-1);
    }

    mesh_size = MSIZE*MSIZE;
    frame_count = -1;

    if (!color_flag)
	printf("assigning vertex colors (vorticity magnitude)...\n");
    else {
	printf("assigning vertex colors (Laplacian)...\n");
	printf("maximize intensity per pixel? (0/1) ");
	scanf("%d", &maximize);
    }

    num_frames=0;
    while ((nbytes=fread(p, sizeof(float), mesh_size, meshfp)) == mesh_size) {

	frame_count++;
	if (!(frame_count % modulo_frames)) {

	   num_frames++;

	   /* Compute extrema for each frame */
	min_val = HUGE;
	max_val = -HUGE;

	/* Laplacian */
		   /* 1st pass, find extrema */
		   /* Just do the interior mesh pts for now; do borders later */
		for (j=1; j<63; j++) {
		    for (i=1; i<63; i++) {
			laplacian[j][i] = 0.25*(p[j][i-1]+p[j][i+1]+p[j-1][i]+p[j+1][i]) - p[j][i];
	   		if (laplacian[j][i] < min_val) min_val = laplacian[j][i];
	   		if (laplacian[j][i] > max_val) max_val = laplacian[j][i];
		    }
    		}
/*		printf("min,max laplacian = %f %f\n", min_val,max_val); */
		val_range = max_val-min_val;

		   /* 2nd pass, compute colors */
		k = 0;

		if (maximize) {
		for (j=0; j<64; j++) {
		    for (i=0; i<64; i++) {
   			pct = (laplacian[j][i]-min_val)/val_range;

			   /* For a max intensity color scale according to Laplacian */
			if (pct >= .50) {
			    rval = 1.0;
			    gval = (1.0-pct)/pct;
			    bval = gval;
			}
			else {
			    rval = pct/(1.0-pct);
			    gval = 1.0;
			    bval = 1.0;
			}

	       	        mcp->vertex_rgb[k][0] = rval;
	       		mcp->vertex_rgb[k][1] = gval;
	       		mcp->vertex_rgb[k][2] = bval;
	   		k++;
		    }
    		}
    		}
		else {
		for (j=0; j<64; j++) {
		    for (i=0; i<64; i++) {
   			pct = (laplacian[j][i]-min_val)/val_range;
			   /* For a continuous color scale according to Laplacian */
			rval = pct;
			gval = 1.0-pct;
			bval = 1.0-pct;
			delta = 0.0;
/*			if (fabs(pct-.50) < .20) delta = .30;
			rval += delta;
			gval += delta;
			bval += delta; */

	       	        mcp->vertex_rgb[k][0] = rval;
	       		mcp->vertex_rgb[k][1] = gval;
	       		mcp->vertex_rgb[k][2] = bval;
	   		k++;
		    }
    		}
    		}

	tmp_mcp = NEW(mesh_colors,sizeof(mesh_colors));
	tmp_mcp->next = NULL;
	mcp->next = tmp_mcp;   /* connect previous node to this one */
	mcp = tmp_mcp;

    } /* end modulo frames */
    } /* end while */

    close(meshfp);
    printf("# of frames to show = %d\n", num_frames);
}
