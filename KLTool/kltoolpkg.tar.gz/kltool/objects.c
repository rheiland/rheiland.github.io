/* objects.c - graphical objects
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <gl.h>
#include "disp_types.h"
#include "data_types.h"
#include "kl_str.h"


int popup_obj,arrow_obj;
int     select_slider_obj;

int x_start = 1;
int x_stop = 0;
int y_start = 1;
int y_stop = 0;
int t_start = 1;
int t_stop = 0;
float f_start = 0.;
float f_stop = 1000.;

char formats[3][10] = {"f",
	"t,f",
	"t,x,f"};
char display_types[4][20] = {"Landscape",
	"Scan",
	"MinMax",
	"Contour"};


float popups_x0, popups_xdel;

create_objects()
{

	popup_obj = genobj();
	makeobj(popup_obj);
	closeobj();
	update_popup_objs();

	make_arrow();

	select_slider_obj = genobj();
	make_select_slider();
}
/*--------------------------------------------------------------------*/
init_select_sliders()
{
extern slider select_slider;

	select_slider.ctr[0][0] = -.95;
	select_slider.ctr[0][1] = -1.;
	select_slider.ctr[1][0] = 0.95;
	select_slider.ctr[1][1] = -1.;
	select_slider.ctr[2][0] = -1.;
	select_slider.ctr[2][1] = -0.95;
	select_slider.ctr[3][0] = -1.;
	select_slider.ctr[3][1] = 0.95;
}
/*--------------------------------------------------------------------*/
make_select_slider()
{
	float v[2];
extern slider select_slider;

	init_select_sliders();

	select_slider.rad = .05;

	makeobj(select_slider_obj);
/*	   color(BLUE); */
	   bgnpolygon();
	   v[0] = 0.0;
	   v[1] = select_slider.rad;
	   v2f(v);
	   v[0] = select_slider.rad;
	   v[1] = -select_slider.rad;
	   v2f(v);
	   v[0] = -select_slider.rad;
	   v[1] = -select_slider.rad;
	   v2f(v);
	   endpolygon();
	closeobj();
}
/*--------------------------------------------------------------------*/
make_arrow()
{
	arrow_obj = genobj();
	makeobj(arrow_obj);
	   color(BLACK);
	   rectf(0,0,1,1);
	   pmv(2.0,0.5,0.0);
	   pdr(1.0,1.5,0.0);
	   pdr(1.0,-0.5,0.0);
	   pclos();
	closeobj();
}
/*--------------------------------------------------------------------*/
update_input_msg(msg)
char *msg;
{
static char *blank = "                                                                                ";
	float x1,y1;
/*extern int input_win_color; */

	x1 = -0.8;
	y1 = -0.70;
/*	color(input_win_color); */
	rectf(x1,y1,x1+1.0,y1+0.04);
	color(BLACK);
	cmov2(x1,y1);
	charstr(msg);
}
/*--------------------------------------------------------------------*/
draw_butn(x1,y1,x2,y2, hilite,color1,color2)
float x1,y1,x2,y2;
int hilite,color1,color2;
{
	float radius,yc;

	radius = (y2 - y1)/2.0;
	yc = y1 + radius;

	if (!hilite) {
	   move2(x1,y1);
	   draw2(x2,y1);
	   move2(x1,y2);
	   draw2(x2,y2);
	   arc(x1,yc,radius, 900,2700);
	   arc(x2,yc,radius, 2700,900);
	}
	else {
	   color(color1);
	   rectf(x1,y1,x2,y2);
	   arcf(x1,yc,radius, 900,2700);
	   arcf(x2,yc,radius, 2700,900);
	   color(color2);
	}
}
/*--------------------------------------------------------------------*/
update_popup_objs()
{
	char string[50];
	float xpos,ypos;
	static float xdel = 0.20;
extern int menu_bar_text_color;
extern int cmplx_flag;

	popups_xdel = xdel;

	delobj(popup_obj);
	makeobj(popup_obj);
	  color(menu_bar_text_color);
	  popups_x0 = -0.97;
	  xpos = popups_x0;
	  ypos = -0.3;

	  cmov2(xpos,ypos);
	  charstr("kltool");

	  xpos += xdel;
	  cmov2(xpos,ypos);
	  charstr("Compute");

	  xpos += xdel;
	  cmov2(xpos,ypos);
	  charstr("Windows");

	  xpos += xdel;
	  cmov2(xpos,ypos);
	  charstr("Flags");

	  xpos += xdel;
	  cmov2(xpos,ypos);
	  charstr("Read");

	  xpos += xdel;
	  cmov2(xpos,ypos);
	  charstr("Write");

	  xpos += xdel;
	  cmov2(xpos,ypos);
	  charstr("Misc");

	  if (cmplx_flag) {
	     xpos += xdel;
	     cmov2(xpos,ypos);
	     charstr("Complex");
	  }
	closeobj();

        if (cmplx_flag) 
	  hilite_cmplx_menu();
}
