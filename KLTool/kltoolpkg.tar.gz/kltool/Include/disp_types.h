/* disp_types.h
 */

#define LANDSCAPE	0
#define SCAN		1
#define MINMAX		2
#define SHADED		3
