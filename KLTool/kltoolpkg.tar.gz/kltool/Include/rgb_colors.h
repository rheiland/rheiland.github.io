/* rgb_colors.h */

short redvec[3] = {255,0,0};
short greenvec[3] = {0,255,0};
short bluevec[3] = {0,0,255};
short cyanvec[3] = {0,255,255};
short blackvec[3] = {0,0,0};
short whitevec[3] = {255,255,255};
