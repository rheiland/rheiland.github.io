/* contour_type.h
 */

#define CONTOUR_HEIGHT	1
#define CONTOUR_LAPLACE	2
