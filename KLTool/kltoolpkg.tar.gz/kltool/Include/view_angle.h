/* view_angle.h
 */

#define FRONT	1
#define TOP	2
#define SIDE	3
