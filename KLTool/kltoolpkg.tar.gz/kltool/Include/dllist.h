/* dllist.h - macros for handling a doubly linked list */

#define NEW(structure,size)    (structure*)malloc(size)
#define NEXT(ptr)   ptr->next
#define PREV(ptr)   ptr->prev
#define TRACE(tptr,fptr)    for (tptr=fptr; tptr!=NULL; tptr=NEXT(tptr))
#define LAST(tptr,fptr)     for (tptr=fptr; NEXT(tptr)!=NULL; tptr=NEXT(tptr))
