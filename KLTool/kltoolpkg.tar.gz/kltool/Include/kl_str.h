/* kl_str.h  - KL structs
 *
 */

#include "dllist.h"

typedef struct vec_struct {
   struct vec_struct *prev;
   struct vec_struct *next;
   double *dp;
} vec_struct;

typedef struct cmplx_vec_struct {
   struct cmplx_vec_struct *prev;
   struct cmplx_vec_struct *next;
   double *drp;		/* real */
   double *dip;		/* imag */
} cmplx_vec_struct;

typedef struct vec_struct_byte {
   struct vec_struct_byte *prev;
   struct vec_struct_byte *next;
   char *dp;
} vec_struct_byte;

typedef struct vec_struct_uchar {
   struct vec_struct_uchar *prev;
   struct vec_struct_uchar *next;
   unsigned char *dp;
} vec_struct_uchar;

typedef struct vec_struct_float {
   struct vec_struct_float *prev;
   struct vec_struct_float *next;
   float *dp;
} vec_struct_float;


typedef struct win_struct {
   int id;
   float xmid,ymid,zmid;
   float xscale,yscale,zscale;
   int display_type;
   int rgb;
   int bdr[4];
} win_struct;

typedef struct input_box_struct {
   float y0,dy;
   float x0,dx;
   char label[8];
   int id;
} input_box_struct;

typedef struct slider {
   float ctr[4][2];
   float rad;
} slider;
