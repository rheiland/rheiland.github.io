
#define	input_win_color		CYAN
#define	scan_win_color		YELLOW
#define	eigvals_bar_color	YELLOW
#define	geom_win_color		BLACK
#define	mean_geom_color		CYAN
#define	coefs_geom_color	CYAN
