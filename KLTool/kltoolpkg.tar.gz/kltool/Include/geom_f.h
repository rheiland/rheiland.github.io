/* geom_f.h  - floating */

#include "dllist.h"

#define  VSIZE  256
/*#define  VSIZE  896 */

typedef struct poly_line {
   struct poly_line *next;
   int count;
   float pline[VSIZE][3];
} poly_line;

poly_line *pp_root, *pp, *pptmp;
