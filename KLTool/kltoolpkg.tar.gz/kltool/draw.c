/* draw.c - draw windows
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <gl/gl.h>
#include <gl/get.h>
#include <fmclient.h>
#include "kl_str.h"

#define X  0
#define Y  1
#define Z  2


  /* Current vector # for SCANning */
extern int cur_vector;
extern int cur_eigfn;
extern int cur_appx;
extern int cur_error;
extern int cur_datacoef;
extern int cur_appxcoef;

int scale_cur_vector = 0;

int clear_c(),clear_rgb();
int (*clear_geom[])() = {clear_c, clear_rgb};
int clear_c_ndx = 0;
int clear_rgb_ndx = 1;
/*int clear_ndx = clear_c_ndx; */

/*  For eye-pleasing colors (black background) */
extern int	data_color;
extern int	scan_win_color;
extern int	eigvals_bar_color;
extern int	geom_win_color;
extern int	mean_geom_color;
extern int	coef_geom_color;
extern int	eigfn_geom_color;
extern int	menu_bar_color;
extern int	menu_bar_text_color;


extern float	fontscale;
extern int 	vec_flag;

int num_eigvals;

/*--------------------------------------------------------------------*/
draw_data_win()
{
static short blackvec[3] = {0,0,0};
static short whitevec[3] = {255,255,255};
extern win_struct data_win;
extern char input_format;

	winset(data_win.id);
/*	reshapeviewport(); */

/*	switch (getdisplaymode()) {
	case DMDOUBLE:
	   color(BLACK);
	   break;
	case DMRGBDOUBLE:
	   c3s(blackvec);
	   break;
	default:
	   printf("draw_data_win: displaymode = ?\n");
	}
	clear(); */

/*nejib*/
/*	if (cur_vector == 1) */
	(*clear_geom[data_win.rgb])();

	if (input_format == 'b')
/*	   draw_weather(); */
	   draw_uchar_data();
	else {
	   if (!vec_flag)
	      draw_data_geom();
	   else
	      draw_data_vec2d_geom();
	}
}
/*--------------------------------------------------------------------*/
draw_mean_win()
{
extern win_struct mean_win;
extern char input_format;

/*  printf("draw_mean_win:       mean_win.id = %d\n", mean_win.id); */
	winset(mean_win.id);

	(*clear_geom[mean_win.rgb])();

	if (input_format == 'b')
	   draw_mean_geom_float();
	else {
	   if (!vec_flag)
	      draw_mean_geom();
	   else
	      draw_mean_vec2d_geom();
	}
}
/*--------------------------------------------------------------------*/
draw_eigfn_win(n)
int n;
{
extern win_struct eigfn_win;
extern char input_format;

	winset(eigfn_win.id);

	(*clear_geom[eigfn_win.rgb])();

	if (input_format == 'b')
	   draw_eigfn_geom_float();
	else {
	   if (!vec_flag)
	      draw_eigfn_geom(n);
	   else
	      draw_eigfn_vec2d_geom(n);
	}
}
/*--------------------------------------------------------------------*/
draw_appx_win()
{
extern win_struct appx_win;

/*	printf("-------------  draw_appx_win ------------\n");
	printf("       vec_flag = %d\n", vec_flag); */
	winset(appx_win.id);

	(*clear_geom[appx_win.rgb])();
	if (!vec_flag)
	   draw_appx_geom();
	else
	   draw_appx_vec2d_geom();
}
/*--------------------------------------------------------------------*/
draw_error_win()
{
extern win_struct error_win;
	static short blackvec[3] = {0,0,0};

	winset(error_win.id);

	(*clear_geom[error_win.rgb])();
	if (!vec_flag)
	   draw_error_geom();
	else
	   draw_error_vec2d_geom();
}
/*--------------------------------------------------------------------*/
draw_popups_win()
{
	extern int popups_win,popup_obj;

	winset(popups_win);
/*	reshapeviewport(); */
/*	color(menu_bar_color); */
	color(BLACK);
	clear();
	color(menu_bar_color);
	rectf(-.98,-1.0,.98,0.6);
	update_popup_objs();
	callobj(popup_obj);
}
/*--------------------------------------------------------------------*/
draw_scan_win(win,vecnum)
int win,vecnum;
{
extern int arrow_obj;
	char string[6];
	

/*	printf("draw_scan_win:  win = %d\n",win); */
/*	winset(scan_data_win); */
	winset(win);
/*	reshapeviewport(); */
	color(scan_win_color);
	clear();

	  /* To put left pointing arrow */
/*	pushmatrix();
        translate(0.4,0.,0.);
	scale(0.2,0.2,1.0);
	callobj(arrow_obj);
	popmatrix(); */

	color(BLACK);
	cmov2(-0.05,0.0);
	sprintf(string,"%d",vecnum);
	charstr(string);

	  /* To put right pointing arrow */
/*	pushmatrix();
        translate(-0.4,0.,0.);
        rotate(1800,'y');
	scale(0.2,0.2,1.0);
	callobj(arrow_obj);
	popmatrix(); */
}
/*--------------------------------------------------------------------*/
draw_scan_win2(win,vecnum,eignum)
int win,vecnum,eignum;
{
	char string[9];
	
	winset(win);
	color(scan_win_color);
	clear();

	color(BLACK);
	cmov2(-0.7,0.0);
	sprintf(string,"(%d) %d",eignum,vecnum);
	charstr(string);
}
/*--------------------------------------------------------------------*/
draw_scan_eigfn_win(vecnum)
int vecnum;
{
	int i;
	vec_struct *usp;
	double vmin,vmax;
	char string[6];
	fmfonthandle   fontsize;
	float x0;
extern fmfonthandle   smallfont;
extern int scan_eigfn_win;
extern float *pct_table,*pctsum_table;
extern vec_struct *u_root;
extern int	res_xy;
	

/*        fontsize = fmscalefont(smallfont, fontscale); 
        fmsetfont(fontsize); */

	winset(scan_eigfn_win);
	color(scan_win_color);
	clear();

	color(BLACK);
	x0 = -0.8;
	cmov2(x0,-0.3);
	sprintf(string,"%d",vecnum);
/*	fmprstr(string); */
	charstr(string);

	x0 = -0.3;
	cmov2(x0,0.2);
	sprintf(string,"%.2f",100.* *(pct_table+vecnum-1));
	charstr(string);

	cmov2(x0,-0.7);
	sprintf(string,"%.1f",100.* *(pctsum_table+vecnum-1));
	charstr(string);


	  /* get min/max of eigfn */
	i = 0;
	TRACE(usp,u_root) {
	   i++;
	   if (i==vecnum) break;
	}
	if (usp->dp == NULL) {
	   printf("(draw_scan_eigfn_win:  NULL usp->dp\n");
	   return(-1);
	}
	minmax_d(usp->dp,res_xy,&vmin,&vmax);

	x0 = 0.4;
	if (vmin < 0) cmov2(x0-0.1,0.2);
	else cmov2(x0,0.2);
	sprintf(string,"%.1f",vmin);
	charstr(string);

	cmov2(x0,-0.7);
	sprintf(string,"%.1f",vmax);
	charstr(string);
}
/*--------------------------------------------------------------------*/
/* rf. energy.c   */
draw_eigvals_win(neig)
int neig;
{
	float xdel, v[2], *vp;
	FILE *fp;
	int m,i,j;
	float pct;
	float x1,rl;
	float er,ei;
	double pctsum;
	char string[50];
extern win_struct eigvals_win;
extern double sum_eigvals;
extern double *eigvals;


/*	printf("-------------------  begin draw_eigvals_win------------\n");
	printf("  neig = %d\n", neig);
	printf("  sum_eigvals = %f\n", sum_eigvals); */

	num_eigvals = neig;

	winset(eigvals_win.id);
/*	reshapeviewport(); */
	color(geom_win_color);
	clear();

	ortho2(-0.1,1.1,-0.1,1.1);

	xdel = 1.0 / (neig+1);
	rl = xdel*.7;
	color(eigvals_bar_color);
	rect(0.0,0.0,1.0,1.0);

	pctsum = 0.0;
	for (i=0; i<neig; i++) {
	   er = *(eigvals+i);
	   pct = er/sum_eigvals;
/*	   printf("er,sum_eigvals = %f %f\n", er,sum_eigvals); */
	   pctsum += pct;

	   x1 = i*xdel+rl;
/*	   rectf(x1,0.0,x1+rl,pct); */
	   rect(x1,0.0,x1+rl,pct);

	   cmov2(x1,pct+.01);
	   sprintf(string,"%3.1f", pct*100);
	   charstr(string);
	}

	cmov2(0.5,1.05);
	sprintf(string,"%d for %d%%", neig,(int)(pctsum*100));
	charstr(string);

/*	printf("---------------------  end draw_eigvals_win------------\n"); */
}
/*--------------------------------------------------------------------*/
data_color_handler(color_item)
int color_item;
{
	switch (color_item) {
	case 1:
	    data_color = RED;
	    break;
	case 2:
	    data_color = GREEN;
	    break;
	case 3:
	    data_color = YELLOW;
	    break;
	case 4:
	    data_color = CYAN;
	    break;
	case 5:
	    data_color = WHITE;
	    break;
	}
	redraw_data();
}
/*--------------------------------------------------------------------*/
bkgd_color_handler(color_item)
int color_item;
{
	switch (color_item) {
	case 1:
		data_color=		GREEN;
		scan_win_color=		YELLOW;
		eigvals_bar_color=	YELLOW;
		geom_win_color=		BLACK;
		mean_geom_color=	CYAN;
		coef_geom_color=	CYAN;
		eigfn_geom_color=	CYAN;
		menu_bar_color=		BLUE;
		menu_bar_text_color=	YELLOW;
	    break;
	case 2:
		data_color=		BLACK;
		scan_win_color=		WHITE;
		eigvals_bar_color=	BLACK;
		geom_win_color=		WHITE;
		mean_geom_color=	BLACK;
		coef_geom_color=	BLACK;
		eigfn_geom_color=	BLACK;
		menu_bar_color=		WHITE;
		menu_bar_text_color=	BLACK;
	    break;
	}
/*	redraw_data(); */
}

/*--------------------------------------------------------------------*/
setup_eigfn_win(eigfn_num)
int eigfn_num;
{
	int i;
	vec_struct *usp;
	double vmin,vmax,vdiff;
	double x0,x1,y0,y1;
extern vec_struct *u_root;
extern int	res_xy;
extern win_struct	eigfn_win, data_win;
extern int 	polar_flag,ncontours;
extern float 	polar_rmin,polar_range;

	if (!eigfns_exist()) return(-1);
/*	if (u_root == NULL) {
	   printf("(setup_eigfn_win:  NULL u_root\n");
	   return(-1);
	} */

	i = 0;
	TRACE(usp,u_root) {
	   i++;
	   if (i==eigfn_num) break;
	}
	if (usp->dp == NULL) {
	   printf("(setup_eigfn_win:  NULL usp->dp\n");
	   return(-1);
	}

	minmax_d(usp->dp,res_xy,&vmin,&vmax);
/*	printf("setup_eigfn_win:   min,max = %f %f\n", vmin,vmax); */

	vdiff = vmax - vmin;
	eigfn_win.ymid = vmin + vdiff / 2.0;
	eigfn_win.xmid = data_win.xmid;
	eigfn_win.zmid = data_win.zmid;
	if (vdiff == 0.0)
	   eigfn_win.yscale = 1.0;
	else
	   eigfn_win.yscale = 1.6 / vdiff;
	eigfn_win.xscale = data_win.xscale;
	eigfn_win.zscale = data_win.zscale;

	if (polar_flag) {
	  eigfn_win.ymid = 0.0;
	  eigfn_win.xmid = 0.0;
	  eigfn_win.xscale = 0.9/(polar_rmin+polar_range);
	  eigfn_win.yscale = 0.9/(polar_rmin+polar_range);
	}

	if (ncontours) {
	  minmax_contour(usp->dp,res_xy*ncontours,&x0,&x1,&y0,&y1);
	  vdiff = x1 - x0;
  	  eigfn_win.xmid = x0 + vdiff / 2.0;
	  eigfn_win.xscale = 1.6 / vdiff;

	  vdiff = y1 - y0;
  	  eigfn_win.ymid = y0 + vdiff / 2.0;
	  eigfn_win.yscale = 1.6 / vdiff;

	  eigfn_win.zmid = data_win.zmid;
	  eigfn_win.zscale = data_win.zscale;
	}

/*	printf("           xscale,yscale,zscale = %f %f %f\n", 
			eigfn_win.xscale,eigfn_win.yscale,eigfn_win.zscale);
	printf("           xmid,ymid,zmid = %f %f %f\n", 
			eigfn_win.xmid,eigfn_win.ymid,eigfn_win.zmid); */
}
/*--------------------------------------------------------------------*/
flip_eigfn()
{
	int count,i;
	vec_struct *vsp;
	double *dp;
extern int res_xy;
extern vec_struct *u_root;

	if (!eigfns_exist()) return(-1);

	count=0;
	TRACE(vsp,u_root) {
	   count++;
	   if (count == cur_eigfn) break;
	}
	dp = vsp->dp;

	for (i=0; i<res_xy; i++)
	   *(dp+i) *= -1.0;

	redraw_eigfn(cur_eigfn);
}
/*--------------------------------------------------------------------*/
eigfns_exist()
{
extern vec_struct *u_root;

	if (u_root == NULL) {
	    notify_user("No eigenfns computed.");
	    return(0);
	}
	return(1);
}
