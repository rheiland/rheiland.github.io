/* flags_form.c - 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdlib.h>
#include "kl_str.h"
#include "forms.h"
#include "data_types.h"

static FL_FORM *flags_form;
static FL_OBJECT *sync_obj;
static FL_OBJECT *decomp_obj;
static FL_OBJECT *rect_type,*polar_type;
static FL_OBJECT *polar_rmin_obj,*polar_rmax_obj;
static FL_OBJECT *vec_scale_obj;
static FL_OBJECT *complex_choice;
static FL_OBJECT *ok_obj, *cancel_obj;

extern int sync_flag;
extern int decompose_method;
extern int polar_flag, cmplx_flag, vec_flag, ncontours;
extern float polar_rmin,polar_rmax,polar_range;
extern char plot_scripts_dir[];

extern void update_vec_scale(),update_polar_radii();

static int color1 = 40;
static int color2 = 54;

/*------------------------------------------*/
void update_sync_flag(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    sync_flag = 0;
  }
  else {
    sync_flag = 1;
  }
}
/*------------------------------------------*/
void update_decomp_flag(FL_OBJECT *obj,long arg)
{
  if (!arg) {
    decompose_method = 1;
  }
  else {
    decompose_method = 2;
  }
}
/*------------------------------------------*/
static void update_rect_polar(FL_OBJECT *obj,long arg)
{
extern int data_type_flag;

  if (arg == 0) {		/* rect */
    data_type_flag = RECT;
    fl_hide_object(polar_rmin_obj);
    fl_hide_object(polar_rmax_obj);
  }
  else if (arg == 1) {		/* polar */
    data_type_flag = POLAR;
    fl_show_object(polar_rmin_obj);
    fl_show_object(polar_rmax_obj);
  }
  polar_handler();
}
/*------------------------------------------*/
void update_complex_choice2(FL_OBJECT *obj,long arg)
{
  cmplx_flag = fl_get_choice(complex_choice);
  printf("cmplx_flag = %d\n",cmplx_flag);
}
/*------------------------------------------*/
void update_plot_dir(FL_OBJECT *obj,long arg)
{
  strcpy(plot_scripts_dir,fl_get_input(obj));
  printf("updating plot_scripts_dir --> %s\n",plot_scripts_dir);
}

/*--------------------------------------------------------------------*/
void make_flags_form()
{
  FL_OBJECT *obj;
  FL_OBJECT *sync_on,*sync_off;
  FL_OBJECT *kl_obj,*svd_obj;
  FL_OBJECT *plot_dir_obj;
  float yloc;
  char buffer[50];
  float ydel = 40.0;
  float height = 30.0;
  float x0,width,xdel,x1,x2;
  float form_width,form_height;
extern int data_type_flag;
extern char *cmplx_vec_spec[4];
extern float polar_rmin,polar_rmax, vec_scale;


  form_width = 650.0;
  form_height = 400.0;
  flags_form = fl_bgn_form(FL_UP_BOX,form_width,form_height);

  x0 = 100.0;
  x1 = 150.0;
  xdel = 20.0;
  width = 70.0;
  x2 = x1 + width + xdel;

    yloc = form_height - 50.0;
    fl_bgn_group();
      obj = fl_add_box(FL_NO_BOX,x0,yloc,300.0,height,"");
      fl_set_object_label(obj,"synchronize:");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
      sync_on = fl_add_lightbutton(FL_RADIO_BUTTON,x1,yloc,width,height,"on");
      sync_off = fl_add_lightbutton(FL_RADIO_BUTTON,x2,yloc,width,height,"off");
    fl_end_group();
    fl_set_call_back(sync_on,update_sync_flag,0);
    fl_set_call_back(sync_off,update_sync_flag,1);

    if (sync_flag)
      fl_set_button(sync_on,1);
    else
      fl_set_button(sync_off,1);


    yloc -= ydel;
    fl_bgn_group();
      obj = fl_add_box(FL_NO_BOX,x0,yloc,300.0,height,"");
      fl_set_object_label(obj,"decompose:");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
      kl_obj = fl_add_lightbutton(FL_RADIO_BUTTON,x1,yloc,width,height,"KL");
      svd_obj = fl_add_lightbutton(FL_RADIO_BUTTON,x2,yloc,width,height,"SVD");
    fl_end_group();
    fl_set_call_back(kl_obj,update_decomp_flag,0);
    fl_set_call_back(svd_obj,update_decomp_flag,1);

    if (decompose_method == 1)
      fl_set_button(kl_obj,1);
    else
      fl_set_button(svd_obj,1);

    yloc -= ydel;

  if ((data_type_flag == RECT) || (data_type_flag == POLAR)) {
     fl_bgn_group();
      obj = fl_add_box(FL_NO_BOX,x0,yloc,300.0,height,"");
      fl_set_object_label(obj,"data type:");
      fl_set_object_align(obj,FL_ALIGN_LEFT);
      rect_type = fl_add_lightbutton(FL_RADIO_BUTTON,x1,yloc,width,height,"rect");
      polar_type = fl_add_lightbutton(FL_RADIO_BUTTON,x2,yloc,width,height,"polar");
     fl_end_group();
     fl_set_call_back(rect_type,update_rect_polar,0);
     fl_set_call_back(polar_type,update_rect_polar,1);


    width = 100.0;
    polar_rmin_obj = fl_add_input(FL_NORMAL_INPUT,x2+120,yloc,width,height,
				"min R:");
    sprintf(buffer,"%f",polar_rmin);
    fl_set_input(polar_rmin_obj,buffer);
    fl_set_object_color(polar_rmin_obj,color1,color2);
    fl_set_call_back(polar_rmin_obj,update_polar_radii,0);

    polar_rmax_obj = fl_add_input(FL_NORMAL_INPUT,x2+270,yloc,width,height,
				"max R:");
    sprintf(buffer,"%f",polar_rmax);
    fl_set_input(polar_rmax_obj,buffer);
    fl_set_object_color(polar_rmax_obj,color1,color2);
    fl_set_call_back(polar_rmax_obj,update_polar_radii,1);


     if (data_type_flag == RECT) {
       fl_set_button(rect_type,1);
       fl_hide_object(polar_rmin_obj);
       fl_hide_object(polar_rmax_obj);
     }
     else {
       fl_set_button(polar_type,1);
     }
  }

  else if (data_type_flag == COMPLEX) {
     complex_choice = fl_add_choice(FL_NORMAL_CHOICE,x0,yloc,80.0,height,"Complex");
     fl_addto_choice(complex_choice,cmplx_vec_spec[0]);
     fl_addto_choice(complex_choice,cmplx_vec_spec[1]);
     fl_addto_choice(complex_choice,cmplx_vec_spec[2]);
     fl_addto_choice(complex_choice,cmplx_vec_spec[3]);

     fl_set_choice(complex_choice,cmplx_flag);

     fl_set_call_back(complex_choice,update_complex_choice2,0);
  }
  else if (data_type_flag == VEC2D) {
     vec_scale_obj = fl_add_input(FL_NORMAL_INPUT,x0,yloc,width,height,"scale:");
     sprintf(buffer,"%f",vec_scale);
     fl_set_input(vec_scale_obj,buffer);
     fl_set_object_color(vec_scale_obj,color1,color2);
     fl_set_call_back(vec_scale_obj,update_vec_scale,0);
  }
  else if (data_type_flag == CONTOURS) {
  }


    yloc = 50.0;
    plot_dir_obj = fl_add_input(FL_NORMAL_INPUT,100.0,yloc,500.0,height,
				"Plot dir: ");
    fl_set_input(plot_dir_obj,plot_scripts_dir);
    fl_set_call_back(plot_dir_obj,update_plot_dir,0);
    fl_set_object_color(plot_dir_obj,color1,color2);


/*    cancel_obj = fl_add_button(FL_NORMAL_BUTTON,50.0,10.0,75.0,height,"Cancel"); */
    ok_obj = fl_add_button(FL_NORMAL_BUTTON,450.0,10.0,75.0,height,"OK");




  fl_end_form();

}
/*--------------------------------------------------------------------*/
int flags_form_handler()
{
  FL_OBJECT *obj;

/*  foreground(); */
/*  fl_init(); */
  make_flags_form();
  fl_show_form(flags_form,FL_PLACE_CENTER,FALSE,NULL);

  do {
    obj = fl_do_forms(); 
  }
/*  while ((obj != ok_obj) && (obj != cancel_obj)); */
  while (obj != ok_obj);

  fl_hide_form(flags_form);

  if (obj==ok_obj) {
    if (cmplx_flag) {
/*    update_popup_objs(); */
      redraw_popups();
      cmplx_vec_handler(cmplx_flag);
      hilite_cmplx_menu();
    }
    return 1;
  }
  else {
    printf("returning 0 from flags_form_handler...\n");
    return 0;
  }
}
