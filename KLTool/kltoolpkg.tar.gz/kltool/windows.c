/* windows.c - make graphics windows
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */


#include <gl.h>
#include "kl_str.h"
#include "disp_types.h"


win_struct data_win,mean_win,eigvals_win,eigfn_win,appx_win,error_win,
		datacoef_win,appxcoef_win, select_win;

int scan_data_win,scan_eigfn_win,scan_appx_win,scan_error_win;
int scan_datacoef_win,scan_appxcoef_win;
int info_bdr[4],bar_bdr[4];
int popups_win;
int banner_win;

int popups_bdr[4];
int g_bdr[4][4];

extern int max_xpix,max_ypix;
extern int window_pos_mode;

int bdel = 8;
int hdel = 30;
int popups_height = 44;


#define MAX_FEEDBACK_BUTNS	5



/*--------------------------------------------------------------------*/
/* 2 modes: cmode() [default]; RGBmode()	*/
create_initial_windows()
{
extern int	transform_win;

	init_window_attr();

	calc_window_pos();

	create_data_win();

/*	doublebuffer();
	gconfig(); */

	create_popups_win();

	transform_win = data_win.id;
}
/*--------------------------------------------------------------------*/
init_window_attr()
{
	mean_win.id = -1;
	eigvals_win.id = -1;
	eigfn_win.id = -1;
	appx_win.id = -1;
	error_win.id = -1;
	datacoef_win.id = -1;
	appxcoef_win.id = -1;

	scan_data_win = -1;
	scan_eigfn_win = -1;
	scan_appx_win = -1;
	scan_error_win = -1;
	scan_datacoef_win = -1;
	scan_appxcoef_win = -1;

	select_win.id = -1;
	select_win.bdr[0] = 400;
	select_win.bdr[1] = 900;
	select_win.bdr[2] = 100;
	select_win.bdr[3] = 350;

	data_win.display_type = SCAN;
	data_win.rgb = 0;

	mean_win.display_type = SCAN;
	mean_win.rgb = 0;

	eigfn_win.display_type = SCAN;
	eigfn_win.rgb = 0;

	appx_win.display_type = SCAN;
	appx_win.rgb = 0;

	error_win.display_type = SCAN;
	error_win.rgb = 0;

	datacoef_win.display_type = SCAN;
	datacoef_win.rgb = 0;
	appxcoef_win.display_type = SCAN;
	appxcoef_win.rgb = 0;
}
/*--------------------------------------------------------------------*/
setup_for_2d()
{
	data_win.display_type = SCAN;
	   /* ??? */
	mean_win.display_type = SCAN;
	eigfn_win.display_type = SCAN;
	appx_win.display_type = SCAN;
	error_win.display_type = SCAN;
}
/*--------------------------------------------------------------------*/
create_popups_win()
{
extern int max_xpix,max_ypix;

printf("create_popups_win called\n");
    popups_bdr[0] = 0;
    popups_bdr[1] = max_xpix;
/*    popups_bdr[2] = 980; */
    popups_bdr[2] = max_ypix-popups_height;
    popups_bdr[3] = max_ypix;
    printf("popups_bdr = %d %d %d %d\n",
	popups_bdr[0],popups_bdr[1],popups_bdr[2],popups_bdr[3]);
    prefposition(popups_bdr[0],popups_bdr[1],popups_bdr[2],popups_bdr[3]);
    noborder();
    popups_win = winopen("");
    winconstraints();
    reshapeviewport();
    ortho2(-1.0,1.0,-1.0,1.0);
}
/*--------------------------------------------------------------------*/
create_banner_win()
{
extern int max_xpix,max_ypix;

	prefposition(0,max_xpix,0,max_ypix);
	noborder();
	banner_win = winopen("");
	winconstraints();
	reshapeviewport();
	ortho2(-1.0,1.0,-1.0,1.0);
	gconfig();
}
/*--------------------------------------------------------------------*/
create_data_win()
{
	if (data_win.id > 0)
	   winclose(data_win.id);
	data_win.id = create_g_win("Data");
/*	win_title(data_win,"data"); */
/*	printf("create_data_win: data_win.id =  %d\n", data_win.id); */

/*nejib (comment out doublebuffer for leaving all vecs during scan)*/
	doublebuffer();

	if (data_win.display_type == SHADED)
	   RGBmode();
	gconfig();

	if (data_win.display_type == SCAN) {
	   if (scan_data_win < 0) {
	      prefposition(0,1, 0,1);
	      scan_data_win = winopen("Data#");
	   }
	   pop_scan_win(data_win.id);
	}
}
/*--------------------------------------------------------------------*/
create_mean_win()
{
extern int dimension;

	if (mean_win.id > 0)
	   winclose(mean_win.id);

	mean_win.id = create_g_win("Mean");
/*	printf("create_mean_win: mean_win.id =  %d\n", mean_win.id); */
	doublebuffer();
	if ((dimension == 2) && (mean_win.display_type == SHADED))
	   RGBmode();
	gconfig();

	window_pos_handler(window_pos_mode);
}
/*--------------------------------------------------------------------*/
create_datacoef_win()
{

	if (datacoef_win.id > 0)
	   winclose(datacoef_win.id);

	datacoef_win.id = create_g_win("DCoefEigfn");
	doublebuffer();
	gconfig();
	window_pos_handler(window_pos_mode);

	if (scan_datacoef_win < 0) {
	   prefposition(0,1, 0,1);
	   scan_datacoef_win = winopen("DEigfn#");
	}
	pop_scan_win(datacoef_win.id);
}
/*--------------------------------------------------------------------*/
create_appxcoef_win()
{

	if (appxcoef_win.id > 0)
	   winclose(appxcoef_win.id);

	appxcoef_win.id = create_g_win("ACoefEigfn");
	doublebuffer();
	gconfig();
	window_pos_handler(window_pos_mode);

	if (scan_appxcoef_win < 0) {
	   prefposition(0,1, 0,1);
	   scan_appxcoef_win = winopen("AEigfn#");
	}
	pop_scan_win(appxcoef_win.id);
}
/*--------------------------------------------------------------------*/
create_eigvals_win()
{
/*	printf("create_eigvals_win: .id = %d\n", eigvals_win.id); */

	if (eigvals_win.id > 0)
	   winclose(eigvals_win.id);

	eigvals_win.id = create_g_win("Eigvals");
}
/*--------------------------------------------------------------------*/
create_eigfn_win()
{
extern int dimension;

	if (eigfn_win.id > 0)
	   winclose(eigfn_win.id);
	eigfn_win.id = create_g_win("Eigfns");
/*	printf("create_eigfn_win: eigfn_win.id = %d\n", eigfn_win.id); */
	doublebuffer();
	if ((dimension == 2) && (eigfn_win.display_type == SHADED))
	   RGBmode();
	gconfig();

	if (eigfn_win.display_type == SCAN) {
	   if (scan_eigfn_win < 0) {
	      prefposition(0,1, 0,1);
	      scan_eigfn_win = winopen("Eigfn#");
	   }
	   pop_scan_win(eigfn_win.id);
	}

	window_pos_handler(window_pos_mode);
}
/*--------------------------------------------------------------------*/
create_appx_win()
{
	if (appx_win.id > 0)
	   winclose(appx_win.id);
	appx_win.id = create_g_win("Approx");
/*	printf("create_appx_win: appx_win.id =  %d\n", appx_win.id); */
	doublebuffer();
	if (appx_win.display_type == SHADED)
	   RGBmode();
	gconfig();

	if (appx_win.display_type == SCAN) {
	   if (scan_appx_win < 0) {
	      prefposition(0,1, 0,1);
	      scan_appx_win = winopen("Appx#");
	   }
	   pop_scan_win(appx_win.id);
	}

	window_pos_handler(window_pos_mode);
}
/*--------------------------------------------------------------------*/
create_error_win()
{
	if (error_win.id > 0)
	   winclose(error_win.id);
	error_win.id = create_g_win("Error");
/*	printf("create_error_win: error_win.id =  %d\n", error_win.id); */
	doublebuffer();
	if (error_win.display_type == SHADED)
	   RGBmode();
	gconfig();

	if (error_win.display_type == SCAN) {
	   if (scan_error_win < 0) {
	      prefposition(0,1, 0,1);
	      scan_error_win = winopen("Error#");
	   }
	   pop_scan_win(error_win.id);
	}

	window_pos_handler(window_pos_mode);
}
/*--------------------------------------------------------------------*/
create_g_win(title)
char *title;
{
	long gid,bdr[4];
extern int max_xpix;

    bdr[0] = bdel;
    bdr[1] = max_xpix-bdel;
    bdr[2] = 0+bdel;
/*    bdr[3] = 490-hdel; */
/*    bdr[3] = 980-hdel; */
    bdr[3] = max_ypix-popups_height-hdel;
    prefposition(bdr[0],bdr[1],bdr[2],bdr[3]);
/*   printf("create_g_win: bdr= %d %d %d %d\n", bdr[0],bdr[1],bdr[2],bdr[3]); */
    gid = winopen(title);
    winconstraints();
    reshapeviewport();
    color(BLACK);
    clear();


    return(gid);
}
/*--------------------------------------------------------------------*/
create_select_win()
{
extern int select_win_color;

	prefposition(select_win.bdr[0],select_win.bdr[1],
		 select_win.bdr[2],select_win.bdr[3]);
/*	noborder(); */
	select_win.id = winopen(" ");
	winconstraints();
	reshapeviewport();
	ortho2(-1.0,1.0,-1.0,1.0);
	color(select_win_color);

/*	doublebuffer();
	gconfig(); */

	clear();
	color(BLACK);
}
/*--------------------------------------------------------------------*/
win_title(wid,title)
int wid;
char *title;
{
	winset(wid);
	wintitle(title);
}
/*--------------------------------------------------------------------*/
create_scan_win()
{
extern int	cur_win;

	pop_scan_win(cur_win);
	return(1);
}
/*--------------------------------------------------------------------*/
pop_scan_win(winid)
int winid;
{
	float r = 1.0;
	long sx0,sy0,wwidth,wheight;
	int width,height,xoff;
extern int cur_vector,cur_eigfn,cur_appx,cur_error;
extern int cur_datacoef,cur_appxcoef;
extern int num_eig_appx,num_eig_error;

	width = (int)(max_xpix * 0.078);
	height = (int)(max_ypix * 0.049);
	xoff = (int)(max_xpix * 0.07);

/*	if ((winid == data_win.id) && (scan_data_win > 0)) { */
	if (winid == data_win.id) {
	   if (scan_data_win > 0) 
	      winclose(scan_data_win);

	   winset(data_win.id);
	   getorigin(&sx0,&sy0);
	   getsize(&wwidth,&wheight);
	   prefposition(sx0+xoff,sx0+xoff+width,sy0+wheight-height,sy0+wheight);
	   scan_data_win = winopen("Data#");
	   winconstraints();
	   reshapeviewport();
	   ortho2(-r,r,-r,r);
	   draw_scan_win(scan_data_win,cur_vector);
	}
/*	if ((winid == eigfn_win.id) && (scan_eigfn_win > 0)) { */
	else if (winid == eigfn_win.id) {
	   if (scan_eigfn_win > 0)
	      winclose(scan_eigfn_win);

	   width = (int)(max_xpix * 0.20);

	   winset(eigfn_win.id);
	   getorigin(&sx0,&sy0);
	   getsize(&wwidth,&wheight);
	   prefposition(sx0+xoff,sx0+xoff+width,sy0+wheight-height,sy0+wheight);
	   scan_eigfn_win = winopen("Eigfn#");
	   winconstraints();
	   reshapeviewport();
	   ortho2(-r,r,-r,r);
	   draw_scan_eigfn_win(cur_eigfn);
	}
/*	if ((winid == appx_win.id) && (scan_appx_win > 0)) { */
	else if (winid == appx_win.id) {
	   if (scan_appx_win > 0)
	      winclose(scan_appx_win);

	   winset(appx_win.id);
	   getorigin(&sx0,&sy0);
	   getsize(&wwidth,&wheight);
	   prefposition(sx0+xoff,sx0+xoff+width,sy0+wheight-height,sy0+wheight);
	   scan_appx_win = winopen("Appx#");
	   winconstraints();
	   reshapeviewport();
	   ortho2(-r,r,-r,r);
	   draw_scan_win2(scan_appx_win,cur_appx,num_eig_appx);
	}
/*	if ((winid == error_win.id) && (scan_error_win > 0)) { */
	else if (winid == error_win.id) {
	   if (scan_error_win > 0)
	      winclose(scan_error_win);

	   winset(error_win.id);
	   getorigin(&sx0,&sy0);
	   getsize(&wwidth,&wheight);
	   prefposition(sx0+xoff,sx0+xoff+width,sy0+wheight-height,sy0+wheight);
	   scan_error_win = winopen("Error#");
	   winconstraints();
	   reshapeviewport();
	   ortho2(-r,r,-r,r);
	   draw_scan_win2(scan_error_win,cur_error,num_eig_error);
	}
	else if (winid == datacoef_win.id) {
	   if (scan_datacoef_win > 0)
	      winclose(scan_datacoef_win);

	   winset(datacoef_win.id);
	   getorigin(&sx0,&sy0);
	   getsize(&wwidth,&wheight);
	   prefposition(sx0+xoff,sx0+xoff+width,sy0+wheight-height,sy0+wheight);
	   scan_datacoef_win = winopen("DCoefEigfn#");
	   winconstraints();
	   reshapeviewport();
	   ortho2(-r,r,-r,r);
	   draw_scan_win(scan_datacoef_win,cur_datacoef);
	}
	else if (winid == appxcoef_win.id) {
	   if (scan_appxcoef_win > 0)
	      winclose(scan_appxcoef_win);

	   winset(appxcoef_win.id);
	   getorigin(&sx0,&sy0);
	   getsize(&wwidth,&wheight);
	   prefposition(sx0+xoff,sx0+xoff+width,sy0+wheight-height,sy0+wheight);
	   scan_appxcoef_win = winopen("ACoefEigfn#");
	   winconstraints();
	   reshapeviewport();
	   ortho2(-r,r,-r,r);
	   draw_scan_win(scan_appxcoef_win,cur_appxcoef);
	}
}

/*--------------------------------------------------------------------*/
pop_scan()
{
extern int cur_vector,cur_eigfn,cur_appx,cur_error;

	create_scan_win();
	return(1);

/*	if(cur_win == data_win.id) {
	   draw_scan_win(scan_data_win,cur_vector);
	}
	else if(cur_win == eigfn_win.id) {
	   draw_scan_win(scan_eigfn_win,cur_eigfn);
	}
	else if(cur_win == appx_win.id) {
	   draw_scan_win(scan_appx_win,cur_appx);
	}
	else if(cur_win == error_win.id) {
	   draw_scan_win(scan_error_win,cur_error);
	} */
/*	redraw_scan(); */
}
/*--------------------------------------------------------------------*/
push_scan()
{
extern int	cur_win;

	if(cur_win == data_win.id) {
	   winclose(scan_data_win);
	   scan_data_win = -1;
	}
	else if(cur_win == eigfn_win.id) {
	   winclose(scan_eigfn_win);
	   scan_eigfn_win = -1;
	}
	else if(cur_win == appx_win.id) {
	   winclose(scan_appx_win);
	   scan_appx_win = -1;
	}
	else if(cur_win == error_win.id) {
	   winclose(scan_error_win);
	   scan_error_win = -1;
	}
}
/*--------------------------------------------------------------------*/
pop_all_scan_windows()
{
	if(data_win.id > 0)
	   pop_scan_win(data_win.id);
	if(eigfn_win.id > 0)
	   pop_scan_win(eigfn_win.id);
	if(appx_win.id > 0)
	   pop_scan_win(appx_win.id);
	if(error_win.id > 0)
	   pop_scan_win(error_win.id);
	if(datacoef_win.id > 0)
	   pop_scan_win(datacoef_win.id);
	if(appxcoef_win.id > 0)
	   pop_scan_win(appxcoef_win.id);
}
/*--------------------------------------------------------------------*/
push_coefs_win()
{
	   winclose(datacoef_win.id);
	   datacoef_win.id = -1;
}
/*--------------------------------------------------------------------*/
update_eigvals_win()
{
extern int 	num_eig;

	   /* Somehow determine if the window is already displayed */
	if (eigvals_win.id < 0) 
	   create_eigvals_win();
	redraw_eigvals(num_eig);
}
/*--------------------------------------------------------------------*/
set_win_bdr(win)
win_struct *win;
{
	long x0,y0;
	long width,height;

	winset(win->id);
	getorigin(&x0,&y0);
	getsize(&width,&height);

	win->bdr[0] = x0;
	win->bdr[1] = win->bdr[0] + width - 1;
	win->bdr[2] = y0;
	win->bdr[3] = win->bdr[2] + height - 1;
}
