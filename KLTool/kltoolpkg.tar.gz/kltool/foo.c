#include <stdio.h>

main()
{
	char buf[80];
	int i;

	for (i=0; i<12; i++) {
	sprintf(buf,"img.%0.5d.rgb",i);
	printf("%s\n", buf);
	}
}
