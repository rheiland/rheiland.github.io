#include <stdio.h>

main()
{
  read_hdr();
}
read_hdr()
{
FILE *fp;
int res_x,res_y,res_xy;
int dimension,file_res_x,file_res_y;
float xmin,xmax,ymin,ymax,zmin,zmax;
char fname[50];

  printf("enter filename of eigfns: ");
  scanf("%s",fname);
  fp = fopen(fname,"r");

	printf("----------  read_header  --------\n");
	if (fread(&res_x,sizeof(int),1,fp) != 1) {
	   printf("ERROR reading header(res_x)");
	   return(-1);
	}
	if (fread(&res_y,sizeof(int),1,fp) != 1) {
	   printf("ERROR reading header(res_y)");
	   return(-1);
	}
	printf("  res_x,res_y = %d %d\n", res_x,res_y);

	if ((res_x <= 0) || (res_y <= 0))  {
	   printf("ERROR - Bad header information");
	   return(-1);
	}

	res_xy = res_x * res_y;

	file_res_x = res_x;
	file_res_y = res_y;

	dimension = 1;
	if (res_y > 1) dimension = 2;

	fread(&xmin,sizeof(float),1,fp);
	fread(&xmax,sizeof(float),1,fp);
	fread(&ymin,sizeof(float),1,fp);
	fread(&ymax,sizeof(float),1,fp);
	fread(&zmin,sizeof(float),1,fp);
	fread(&zmax,sizeof(float),1,fp);

	printf("  xmin,xmax = %f %f\n", xmin,xmax);
	printf("------------------------\n");
}
