/* mouse.c - handle mouse I/O
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include <gl.h>
#include <device.h>
#include "kl_str.h"
#include "disp_types.h"
#include "data_types.h"
#include "view_angle.h"

#define str_eq(a,b)	(!strcmp((a),(b)))

extern int dimension;

int 	quick_scan_data = 1;
int	quick_scan_eigfn = 1;
int	quick_scan_appx = 1;
int	quick_scan_error = 1;
int	quick_scan_datacoef = 1;
int	quick_scan_appxcoef = 1;

int	time_delay_delta0 = 30000;

char datafile[1024];

process_leftbutn(win_id,sx,sy)
int win_id;
short sx,sy;
{
    long sx0,sy0,wwidth,wheight;
    float fx,fy;
    short val;
extern int popups_win;
extern int scan_data_win,scan_eigfn_win,scan_appx_win,scan_error_win;
extern int scan_datacoef_win,scan_appxcoef_win;
extern int num_eig_appx;
extern int cur_vector,cur_eigfn,cur_appx,cur_error;
extern int cur_datacoef,cur_appxcoef;
extern int sync_flag,sync_data_flag;

/*	    printf("------------------------------\n");
	    printf("LEFTMOUSE: win_id=%d, sx,sy=%d %d\n", win_id,sx,sy); */

	    if (win_id==popups_win) {
		winset(popups_win);
		getorigin(&sx0,&sy0);
		getsize(&wwidth,&wheight);
		fx = (sx-sx0)*2.0/wwidth - 1.0;
/*		printf("fx = %f\n", fx); */
		popups_handler(fx);
	    }

		/* (rf. leftmouse.c for copy of this routine which
		    deals with old method of using left/right arrows 
		    in the Scan boxes) */

	    else if (win_id==scan_data_win) {
		   sync_data_flag = sync_flag;

		   cur_vector--;
		   if (cur_vector == 0) 
		        cur_vector=1;
		   redraw_data();
		   redraw_scan();
		   if (sync_flag) { 
		      cur_appx = cur_vector;
		      redraw_appx();
	              draw_scan_win2(scan_appx_win,cur_vector,num_eig_appx);
		   }
		   time_delay(time_delay_delta0);

		   if (quick_scan_data) {

		   while (getbutton(LEFTMOUSE)) {
		     cur_vector--;
		     if (cur_vector == 0) 
		        cur_vector=1;
		     redraw_data();
		     redraw_scan();
		     if (sync_flag) { 
		       cur_appx = cur_vector;
		       redraw_appx();
	               draw_scan_win2(scan_appx_win,cur_vector,num_eig_appx);
		     }
		   }
		   }
		   sync_data_flag = 0;
	    }
	    else if (win_id==scan_eigfn_win) {
		   cur_eigfn--;
		   if (cur_eigfn == 0) 
		        cur_eigfn=1;

		   setup_eigfn_win(cur_eigfn);
		   redraw_eigfn(cur_eigfn);
		   redraw_scan();

		   time_delay(time_delay_delta0);

		   if (quick_scan_eigfn) {
		   while (getbutton(LEFTMOUSE)) {
		     cur_eigfn--;
		     if (cur_eigfn == 0) 
		        cur_eigfn=1;
		     setup_eigfn_win(cur_eigfn);
		     redraw_eigfn(cur_eigfn);
		     redraw_scan();
		     time_delay(time_delay_delta0);
		   }
		   }
	    }
	    else if (win_id==scan_appx_win) {
		   sync_data_flag = sync_flag;

		   cur_appx--;
		   if (cur_appx == 0) 
		        cur_appx=1;
		   redraw_appx();
		   redraw_scan();
		   if (sync_flag) { 
		      cur_vector = cur_appx;
		      redraw_data();
	              draw_scan_win(scan_data_win,cur_vector);
		   }

		   time_delay(time_delay_delta0);

		   if (quick_scan_appx) {
		   while (getbutton(LEFTMOUSE)) {
		     cur_appx--;
		     if (cur_appx == 0) 
		        cur_appx=1;
		     redraw_appx();
		     redraw_scan();
		     if (sync_flag) { 
		       cur_vector = cur_appx;
		       redraw_data();
	               draw_scan_win(scan_data_win,cur_vector);
		     }
		   }
		   }
		   sync_data_flag = 0;
	    }
	    else if (win_id==scan_error_win) {
		   cur_error--;
		   if (cur_error == 0) 
		        cur_error=1;
		   redraw_error();
		   redraw_scan();

		   time_delay(time_delay_delta0);

		   if (quick_scan_error) {
		   while (getbutton(LEFTMOUSE)) {
		     cur_error--;
		     if (cur_error == 0) 
		        cur_error=1;
		     redraw_error();
		     redraw_scan();
		   }
		   }
	    }
	    else if (win_id==scan_datacoef_win) {
		   cur_datacoef--;
		   if (cur_datacoef == 0) 
		        cur_datacoef=1;
		   redraw_datacoef();
		   redraw_scan();

		   time_delay(time_delay_delta0);

		   if (quick_scan_datacoef) {
		   while (getbutton(LEFTMOUSE)) {
		     cur_datacoef--;
		     if (cur_datacoef == 0) 
		        cur_datacoef=1;
		     redraw_datacoef();
		     redraw_scan();
		   }
		   }
	    }
	    else if (win_id==scan_appxcoef_win) {
		   cur_appxcoef--;
		   if (cur_appxcoef == 0) 
		        cur_appxcoef=1;
		   redraw_appxcoef();
		   redraw_scan();

		   time_delay(time_delay_delta0);

		   if (quick_scan_appxcoef) {
		   while (getbutton(LEFTMOUSE)) {
		     cur_appxcoef--;
		     if (cur_appxcoef == 0) 
		        cur_appxcoef=1;
		     redraw_appxcoef();
		     redraw_scan();
		   }
		   }
	    }
}
/*--------------------------------------------------------------------*/
process_rightbutn(win_id)
int win_id;
{
    short sx,sy;
    float fx,fy;
    long sx0,sy0,wwidth,wheight;
    short val;
extern int popups_win;
extern win_struct data_win,mean_win,eigfn_win,eigvals_win;
extern win_struct appx_win,error_win,datacoef_win,appxcoef_win;
extern int scan_data_win,scan_eigfn_win,scan_appx_win,scan_error_win;
extern int scan_datacoef_win,scan_appxcoef_win;
extern int num_eig_appx;
extern int data_1d_menu,data_2d_menu;
extern int mean_1d_menu,mean_2d_menu;
extern int efn_1d_menu,efn_2d_menu;
extern int datacoef_menu, appxcoef_menu;
extern int eigvals_menu;
extern int dimension;
extern int cur_vector,cur_eigfn,cur_appx,cur_error;
extern int cur_datacoef,cur_appxcoef;
extern int num_vecs,num_eig;
extern int sync_flag,sync_data_flag;

/*	    printf("RIGHTMOUSE: win_id = %d\n", win_id); */

    if (win_id == popups_win) {
	winset(popups_win);
	sx = (short)getvaluator(MOUSEX);
/*	printf("(mouse)sx =  %d\n", sx); */
	getorigin(&sx0,&sy0);
	getsize(&wwidth,&wheight);
/*	printf("wwidth = %d\n", wwidth); */
	fx = (sx-sx0)*2.0/wwidth - 1.0;
/*	printf("fx = %f\n", fx); */
	popups_handler(fx);
    }
    else if (win_id==data_win.id) {
        winset(data_win.id);
	if (dimension == 1) {
/*	    printf("dopup(data_1d_menu) = %d\n", dopup(data_1d_menu)); */
	    dopup(data_1d_menu);
	}
	else
	    dopup(data_2d_menu);
    }
    else if (win_id==mean_win.id) {
	if (dimension == 1)
	    dopup(mean_1d_menu);
	else 
	    dopup(mean_2d_menu);
    }
    else if (win_id==eigfn_win.id) {
	if (dimension == 1)
	    dopup(efn_1d_menu);
        else 
	    dopup(efn_2d_menu);
    }
    else if (win_id==eigvals_win.id) {
        dopup(eigvals_menu);
    }
    else if (win_id==appx_win.id) {
        if (dimension == 1)
	    dopup(data_1d_menu);
        else 
	    dopup(data_2d_menu);
    }
    else if (win_id==datacoef_win.id) {
	dopup(datacoef_menu);
    }
    else if (win_id==appxcoef_win.id) {
	dopup(appxcoef_menu);
    }
    else if (win_id==error_win.id) {
	if (dimension == 1)
	  dopup(data_1d_menu);
	else 
	  dopup(data_2d_menu);
    }

    else if (win_id==scan_data_win) {
	if (!num_vecs) return;

	sync_data_flag = sync_flag;

	cur_vector++;
	if (cur_vector > num_vecs) 
	   cur_vector=num_vecs;
	redraw_data();
	redraw_scan();
	if (sync_flag) { 
	   cur_appx = cur_vector;
	   redraw_appx();
	   draw_scan_win2(scan_appx_win,cur_vector,num_eig_appx);
	}
	time_delay(time_delay_delta0);

	if (quick_scan_data) {
	   while (getbutton(RIGHTMOUSE)) {
	      cur_vector++;
	      if (cur_vector > num_vecs) 
	         cur_vector=num_vecs;
   	      redraw_data();
	      redraw_scan();
	      if (sync_flag) { 
	         cur_appx = cur_vector;
	         redraw_appx();
	         draw_scan_win2(scan_appx_win,cur_vector,num_eig_appx);
	      }
	   }
	}
	sync_data_flag = 0;
    }
    else if (win_id==scan_eigfn_win) {
	cur_eigfn++;
	if (cur_eigfn > num_eig) 
	   cur_eigfn=num_eig;

	setup_eigfn_win(cur_eigfn);
	redraw_eigfn(cur_eigfn);
	redraw_scan();

	time_delay(time_delay_delta0);

	if (quick_scan_eigfn) {
	   while (getbutton(RIGHTMOUSE)) {
	      cur_eigfn++;
	      if (cur_eigfn > num_eig) 
	         cur_eigfn=num_eig;

		 setup_eigfn_win(cur_eigfn);
		 redraw_eigfn(cur_eigfn);
		 redraw_scan();
		 time_delay(time_delay_delta0);
	   }
	}
    }
    else if (win_id==scan_appx_win) {
	sync_data_flag = sync_flag;

	cur_appx++;
	if (cur_appx > num_vecs) 
	   cur_appx=num_vecs;
	redraw_appx();
	redraw_scan();
	if (sync_flag) { 
	   cur_vector = cur_appx;
	   redraw_data();
	   draw_scan_win(scan_data_win,cur_vector);
	}

	time_delay(time_delay_delta0);

	if (quick_scan_appx) {
	   while (getbutton(RIGHTMOUSE)) {
	      cur_appx++;
	      if (cur_appx > num_vecs) 
		 cur_appx=num_vecs;
		 redraw_appx();
		 redraw_scan();
		 if (sync_flag) { 
		    cur_vector = cur_appx;
		    redraw_data();
	            draw_scan_win(scan_data_win,cur_vector);
	         }
	   }
	}
	sync_data_flag = 0;
    }
    else if (win_id==scan_error_win) {
	cur_error++;
	if (cur_error > num_vecs) 
	   cur_error=num_vecs;
	redraw_error();
	redraw_scan();

	time_delay(time_delay_delta0);

	if (quick_scan_error) {
	   while (getbutton(RIGHTMOUSE)) {
	     cur_error++;
	     if (cur_error > num_vecs) 
	        cur_error=num_vecs;
	     redraw_error();
	     redraw_scan();
	   }
	}
    }
    else if (win_id==scan_datacoef_win) {
	cur_datacoef++;
	if (cur_datacoef > num_eig) 
	   cur_datacoef=num_eig;
	redraw_datacoef();
	redraw_scan();

	time_delay(time_delay_delta0);

	if (quick_scan_datacoef) {
	   while (getbutton(RIGHTMOUSE)) {
	     cur_datacoef++;
	     if (cur_datacoef > num_eig) 
	        cur_datacoef=num_eig;
	     redraw_datacoef();
	     redraw_scan();
	   }
	}
    }
    else if (win_id==scan_appxcoef_win) {
	cur_appxcoef++;
	if (cur_appxcoef > num_eig_appx) 
	   cur_appxcoef=num_eig_appx;
	redraw_appxcoef();
	redraw_scan();

	time_delay(time_delay_delta0);

	if (quick_scan_appxcoef) {
	   while (getbutton(RIGHTMOUSE)) {
	     cur_appxcoef++;
	     if (cur_appxcoef > num_eig_appx) 
	        cur_appxcoef=num_eig_appx;
	     redraw_appxcoef();
	     redraw_scan();
	   }
	}
    }
}
/*--------------------------------------------------------------------*/
update_1d_data(item)
int item;
{
extern win_struct data_win,appx_win,error_win;
extern int 	cur_win;
extern int data_type_flag;


	winset(cur_win);

	switch (item) {
	case 1:		/*--------- SCAN ----------------*/
	viewing_angle(FRONT);
	if(cur_win == data_win.id) {
	   set_win_scan(&data_win);
	   redraw_data();
	   pop_scan();
	}
	else if(cur_win == appx_win.id) {
	   set_win_scan(&appx_win);
	   redraw_appx();
	   pop_scan();
	}
	else if(cur_win == error_win.id) {
	   set_win_scan(&error_win);
	   redraw_error();
	   pop_scan();
	 }
	 break;

	case 2:		/*--------- LANDSCAPE ----------------*/

	if (data_type_flag != RECT) {
	  error_msg("Invalid for data type.");
	  return 0;
	}

	if(cur_win == data_win.id) {
	   set_win_landscape(&data_win);
	   redraw_data();
	}
	else if(cur_win == appx_win.id) {
	   set_win_landscape(&appx_win);
	   redraw_appx();
	}
	else if(cur_win == error_win.id) {
	   set_win_landscape(&error_win);
	   redraw_error();
	 }
	 dials_handler();
	 break;

	case 3:		/*---------- SHADED ---------------*/

	if (data_type_flag != RECT) {
	  error_msg("Invalid for data type.");
	  return 0;
	}

/*	   printf("update_display_type:  type = Contour --> RGBmode\n"); */
	if(cur_win == data_win.id) {
	   set_win_contour(&data_win,1);
	   redraw_data();
	}
	else if(cur_win == appx_win.id) {
	   set_win_contour(&appx_win,1);
	   redraw_appx();
	}
	else if(cur_win == error_win.id) {
	   set_win_contour(&error_win,1);
	   redraw_error();
	 }
	 break;
	}
}
/*--------------------------------------------------------------------*/
set_win_landscape(win)
win_struct *win;
{
	winset(win->id);
	(*win).rgb = 0;
	cmode();
	gconfig();
	push_scan();
	(*win).display_type = LANDSCAPE;
}
/*--------------------------------------------------------------------*/
set_win_scan(win)
win_struct *win;
{
	winset(win->id);
	(*win).rgb = 0;
	cmode();
	gconfig();
	(*win).display_type = SCAN;
}
/*--------------------------------------------------------------------*/
set_win_contour(win,hide_scan)
win_struct *win;
int hide_scan;
{
	winset(win->id);
	(*win).rgb = 1;
	RGBmode();
	gconfig();
	if (hide_scan)
	   push_scan();
	(*win).display_type = SHADED;
}
/*--------------------------------------------------------------------*/
update_2d_data(item)
int item;
{
extern win_struct data_win,mean_win,appx_win,error_win;
extern int 	cur_win;

/*	printf("mouse:update_2d_data: item = %d\n",item); */
/*	printf("mouse:update_2d_data: cur_win = %d\n",cur_win); */

	switch (item) {
	case 1:		/*--------- SCAN ----------------*/
	if(cur_win == data_win.id) {
	   set_win_scan(&data_win);
	   redraw_data();
/*	   pop_scan(); */
	}
	else if(cur_win == appx_win.id) {
	   set_win_scan(&appx_win);
	   redraw_appx();
/*	   pop_scan(); */
	}
	else if(cur_win == error_win.id) {
	   set_win_scan(&error_win);
	   redraw_error();
/*	   pop_scan(); */
	}
	else if(cur_win == mean_win.id) {
	   set_win_scan(&mean_win);
	   redraw_mean();
	}
	break;

	case 2:		/*--------- SHADED ----------------*/
	if(cur_win == data_win.id) {
	   set_win_contour(&data_win,0);
	   redraw_data();
/*	   pop_scan(); */
	}
	else if(cur_win == appx_win.id) {
	   set_win_contour(&appx_win,0);
	   redraw_appx();
/*	   pop_scan(); */
	}
	else if(cur_win == error_win.id) {
	   set_win_contour(&error_win,0);
	   redraw_error();
/*	   pop_scan(); */
	}
	else if(cur_win == mean_win.id) {
	   set_win_contour(&mean_win,0);
	   redraw_mean();
	   pop_scan();
	}
	break;

	case 3:
	   dummy_handler();
	   break;
	}	/* end switch */
	dials_handler();
}
/*--------------------------------------------------------------------*/
time_delay(n)
{
  int i;
  float f;

  for (i=0; i<n; i++)
     f = sin((float)i) * cos((float)i);

  i = (int)f;
  return(i);
}
