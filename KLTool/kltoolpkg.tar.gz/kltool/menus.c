/* menus.c - define all popup menus
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

long	menu1,menu2,menu3,menu4,menu5,menu6,menu7,menu8;
int	data_1d_menu,data_2d_menu;
int	mean_1d_menu,mean_2d_menu;
int	efn_1d_menu,efn_2d_menu;
int	datacoef_menu, appxcoef_menu;
int	eigvals_menu;
int	viewangle_menu;
int	display_type_menu1, display_type_menu2;


take_pic()
{
	system("snapshot");
}
/*--------------------------------------------------------------------*/
create_popup_menus()
{
	int contour_menu,data_color_menu,bkgd_color_menu;
	char buffer[80];
extern int input_handler(),select_handler();
extern int exiting_pgm();
extern int update_1d_data(),update_2d_data();
extern int mean_handler();
extern int decompose_method_handler(),decompose_handler();
extern int appx_handler();
extern int error_handler(),max_error_handler();
extern int plot_eigvals(),plot_vector();
extern int plot_eigfn_vec(),plot_mean_vec();
extern int plot_datacoef_vec(),plot_appxcoef_vec();
extern int eigfn_data_coef_handler(),eigfn_appx_coef_handler();
extern int max_num_eig_handler();
extern int wire_2d_eigfn(),shade_2d_eigfn();
extern int scan_1d_eigfns();
extern int viewangle_handler();
extern int dials_handler();
extern int read_handler(),write_handler();
extern int data_color_handler();
extern int bkgd_color_handler();
extern int sync_handler(),polar_handler(),flip_eigfn();
extern int flags_handler();
extern int contour_type_handler();
extern int galerkin_fs();
extern int window_pos_handler();
extern int cmplx_vec_handler();


    menu1 = defpup("kltool %t|Input %f|Select %f|Exit %f", 
		input_handler,select_handler,exiting_pgm);

    menu2 = defpup("Compute %t|Mean %f|Decompose %f|Approx %f|Error %f|Max Error %f|Galerkin %f",
		mean_handler,decompose_handler,appx_handler,error_handler,
		max_error_handler,galerkin_fs);

    menu3 = defpup("Windows %t %F|1 fullsize|2 horiz|2 vert|4 windows", 
	     window_pos_handler);

    contour_menu = defpup("ContourType %t %F|Height|Laplacian",
			contour_type_handler);

    menu4 = defpup("Flags %t|sync(on/off) %f|KL/SVD %f|rect/polar %f|flip eigfn %f|show flags %f", 
		sync_handler,decompose_method_handler,polar_handler,
		flip_eigfn,flags_handler);

    menu5 = defpup("Read %t %F|data|mean|eiginfo|appx", 
		read_handler);

    menu6 = defpup("Write %t %F|data|mean|eiginfo|appx", 
		write_handler);

    data_color_menu = defpup("Colors %t %F|red|green|yellow|cyan|white", 
		data_color_handler);
    bkgd_color_menu = defpup("Colors %t %F|black|white", 
		bkgd_color_handler);

    menu7 = defpup("Misc %t |data color %m|background %m|snapshot %f",
		data_color_menu,bkgd_color_menu,take_pic);

    menu8 = defpup("Complex %t %F|real|imag|amplitude|phase",
		cmplx_vec_handler);

    viewangle_menu = defpup("ViewAngle %t %F|Front|Top|Side",
			viewangle_handler);

    display_type_menu1 = defpup("DisplayType %t %F|Scan|Landscape|Shaded",
				update_1d_data);
    display_type_menu2 = defpup("DisplayType %t %F|Wireframe|Shaded",
				update_2d_data);

    data_1d_menu = defpup("1-D %t|ViewAngle %m|DisplayType %m|MouseRotate %f|Plot %f",
		viewangle_menu,display_type_menu1,dials_handler,plot_vector);


/*    data_2d_menu = defpup("2-D %t|ViewAngle %m|DisplayType %m|Scale Toggle%f|MouseRotate %f|Plot %f",
		viewangle_menu,display_type_menu2,scale_data_handler, */
    data_2d_menu = defpup("2-D %t|ViewAngle %m|DisplayType %m|MouseRotate %f|Plot %f",
		viewangle_menu,display_type_menu2,dials_handler,plot_vector);
		

    mean_1d_menu = defpup("1-D Mean %t|Plot %f",
		plot_mean_vec);
    mean_2d_menu = defpup("2-D Mean %t|ViewAngle %m|DisplayType %m|MouseRotate %f|Plot %f",
		viewangle_menu,display_type_menu2,dials_handler,plot_mean_vec);

/*    efn_1d_menu = defpup("1-D Eigfn %t|Scan %f|Plot %f|Data coefs %f|Appx coefs %f",
		scan_1d_eigfns,plot_eigfn_vec, */
    efn_1d_menu = defpup("1-D Eigfn %t|Plot %f|Data coefs %f|Appx coefs %f",
		plot_eigfn_vec,
		eigfn_data_coef_handler,eigfn_appx_coef_handler);

    efn_2d_menu = defpup("2-D Eigfn %t|ViewAngle %m|Wireframe %f|Shaded %f|MouseRotate %f|Plot %f|Data coefs %f|Appx coefs %f",
		viewangle_menu,wire_2d_eigfn,shade_2d_eigfn,dials_handler,plot_eigfn_vec,eigfn_data_coef_handler,eigfn_appx_coef_handler);

    datacoef_menu = defpup("DCoefs %t|Plot %f",
		plot_datacoef_vec);
    appxcoef_menu = defpup("ACoefs %t|Plot %f",
		plot_appxcoef_vec);

    eigvals_menu = defpup("Eigvals %t|Max # %f|Plot %f", 
		max_num_eig_handler,plot_eigvals);
}
