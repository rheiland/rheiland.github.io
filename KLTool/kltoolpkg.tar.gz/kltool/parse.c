

#include <stdio.h>



main(argc,argv)
int argc;
char *argv[];
{
	printf("argc = %d\n", argc);
	if (argc < 2) {
	   printf("Usage: %s paramfile\n",argv[0]);
	   exit(-1);
	}
	parse_startup_file(argv[1]);
}
/*--------------------------------------------------*/
/* e.g.,
input   foo.200		# input data filename
data integer		# data type (byte,integer,float,double)
ndim 2			# number of dims (1 or 2)
dim1 64			# dimension of axis 1 (x resolution)
dim2 64			# dimension of axis 2 (y resolution)
complex
*/
parse_startup_file(startup_file)
char *startup_file;
{
	int i, cmplx_flag;
	char *c, buf[120],keyword[80],value[80];
	FILE *fp;
char input_file[80];
int file_res_x,file_res_y, dimension,res_x,res_y,res_xy;
int x_start,x_stop;


	printf("startup_file:  = %s\n", startup_file);

	if ((fp = fopen(startup_file,"r")) == NULL) {
	   printf("ERROR - cannot open startup_file\n");
	   return(1);
	}

	while (get_line(fp,buf, 120) != 0) {
	   sscanf(buf,"%s %s", keyword,value);
	   printf("keyword= %s\n", keyword);

	   if (!strcmp(keyword,"input"))
	      printf("  value= %s\n", value);

	   else if (!strcmp(keyword, "data"))
	      printf("  value= %s\n", value);

	   else if (!strcmp(keyword, "ndim")) {
	      sscanf(value,"%d", &dimension);
	      printf("   dimension = %d\n", dimension);
	   }
	   else if (!strcmp(keyword, "dim1")) {
	      sscanf(value,"%d", &res_x);
	      printf("   res_x = %d\n", res_x);
	   }
	   else if (!strcmp(keyword, "dim2")) {
	      sscanf(value,"%d", &res_y);
	      printf("   res_y = %d\n", res_y);
	   }
	   else if (!strcmp(keyword, "complex")) {
	      cmplx_flag = 1;
	      printf("   cmplx_flag = %d\n", cmplx_flag);
	   }
	}

/*	fscanf(fp,"%s",input_file);
	fscanf(fp,"%d %d", &file_res_x, &file_res_y);
	fscanf(fp,"%d %d", &x_start, &x_stop);
	dimension = 1;
	if (file_res_y > 1)
	   dimension = 2;

	res_x = file_res_x;
	res_y = file_res_y;
	res_xy = res_x * res_y;

	printf("startup_file: input_file = %s\n", input_file);
	printf("startup_file: file_res_x= %d, file_res_y= %d \n", 
		file_res_x,file_res_y); */
}

/*******************************************************************************/
get_line(fp,s,lim)
FILE *fp;
char 	s[];
int	lim;
{
    int	c, i;

    for (i=0; i<=lim-1 && (c=getc(fp))!=EOF && c!='\n'; ++i)
	s[i]=c;
    s[i]='\0';
    return(i);
}
