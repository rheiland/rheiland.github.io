/* vec_ops.c - vector operations
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include "dllist.h"
#include "data_types.h"


#define X	0
#define Y	1

#define VEC_RES  (dimension == 1 ? res_x : res_x*res_y)

extern int dimension,res_x,res_y,res_xy;
extern int vec_flag, ncontours;


/*--------------------------------------------------------------------*/
double  *alloc_vector()
{
    double *dp;

    if (dimension == 1) {
	if (!ncontours)
          dp = NEW(double,sizeof(double)*res_x);
	else
          dp = NEW(double,sizeof(double)*res_x*ncontours*2);
    }
    else if (dimension == 2) {
	if (!vec_flag)
           dp = NEW(double,sizeof(double)*res_x*res_y);
	else
           dp = NEW(double,sizeof(double)*res_xy*2);
    }
    if (dp == NULL) {
       printf("(alloc_vector) ERROR, not enough memory...\n");
       exit(-1);
    }
    return(dp);
}
/*--------------------------------------------------------------------*/
unsigned char  *alloc_vector_uchar()
{
    unsigned char *dp;

    dp = NEW(unsigned char,sizeof(unsigned char)*res_x*res_y);
    return(dp);
}
/*--------------------------------------------------------------------*/
char  *alloc_vector_byte()
{
    char *dp;

/*    if (dimension == 1)
       dp = NEW(char,sizeof(char)*res_x);
    else if (dimension == 2) */
       dp = NEW(char,sizeof(char)*res_x*res_y);
    return(dp);
}
/*--------------------------------------------------------------------*/
float  *alloc_vector_float()
{
    float *dp;

    if (dimension == 1)
       dp = NEW(float,sizeof(float)*res_x);
    else if (dimension == 2)
       dp = NEW(float,sizeof(float)*res_x*res_y);
    return(dp);
}

/*------------------------------------------------------------*/
/* v1 -> v2		*/
vec_copy(v1,v2)
double *v1,*v2;
{
	int i;

	if (!vec_flag)
	  for (i=0; i<res_xy; i++)
	    *(v2+i) = *(v1+i);
	else
	  for (i=0; i<res_xy*2; i++)
	    *(v2+i) = *(v1+i);
}
vec_copy_byte(v1,v2)
char *v1,*v2;
{
	int i;

	for (i=0; i<res_xy; i++)
	   *(v2+i) = *(v1+i);
}
vec_copy_byte_float(v1,v2)
char *v1;
float *v2;
{
	int i;

	for (i=0; i<res_xy; i++)
	   *(v2+i) = *(v1+i);
}
vec_copy_byte_double(v1,v2)
char *v1;
double *v2;
{
	int i;

	for (i=0; i<res_xy; i++)
	   *(v2+i) = *(v1+i);
}
vec_copy_uchar_double(v1,v2)
unsigned char *v1;
double *v2;
{
	int i;

	for (i=0; i<res_xy; i++)
	   *(v2+i) = *(v1+i);
}

/*------------------------------------------------------------*/
/* v2 = v1 * c		*/
vec_mult_scalar(v1,c,v2)
double *v1,c,*v2;
{
	int i;

	if (!vec_flag)
	  for (i=0; i<res_xy; i++)
	    *(v2+i) = c * *(v1+i);
	else
	  for (i=0; i<res_xy*2; i++)
	    *(v2+i) = c * *(v1+i);
}
/*------------------------------------------------------------*/
/* v1 = v1 - v2		*/
vec_subtract(v1,v2)
double *v1,*v2;
{
	int i;

	if (!vec_flag)
	  for (i=0; i<res_xy; i++) 
	    *(v1+i) -= *(v2+i);
	else
	  for (i=0; i<res_xy*2; i++) 
	    *(v1+i) -= *(v2+i);
}
/*------------------------------------------------------------*/
/* v1 = v1 + v2		*/
vec_add(v1,v2)
double *v1,*v2;
{
	int i;

	if (!vec_flag) {
	  for (i=0; i<res_xy; i++) 
	    *(v1+i) += *(v2+i);
	}
	else {
	  for (i=0; i<res_xy*2; i++) 
	    *(v1+i) += *(v2+i);
	}
}
vec_add_float_byte(v1,v2)
float *v1;
char *v2;
{
	int i;

	for (i=0; i<res_xy; i++) 
	   *(v1+i) += *(v2+i);
}
/*------------------------------------------------------------*/
/* v = v / scalar		*/
vec_divide(v,val)
double *v,val;
{
	int i;

	if (!vec_flag)
	  for (i=0; i<res_xy; i++) 
	    *(v+i) /= val;
	else
	  for (i=0; i<res_xy*2; i++) 
	    *(v+i) /= val;
}
vec_divide_float(v,val)
float *v,val;
{
	int i;

	for (i=0; i<res_xy; i++) 
	   *(v+i) /= val;
}
/*------------------------------------------------------------*/
/* return (v1.v2)	*/
double vec_dotprod(v1,v2)
double *v1,*v2;
{
	int i;
	double retval, *vp1,*vp2;

	retval = 0.0;
	if (!vec_flag) {
	  for (i=0; i<res_xy; i++) 
		retval += *(v1+i) * *(v2+i);
	}
	else {
	  vp1 = v1;
	  vp2 = v2;
	  for (i=0; i<res_xy; i++) 
		/*          ui * uj  +  vi * vj  */
		retval += (*vp1 * *vp2) + *(vp1+1) * *(vp2+1);
		vp1++; vp1++;
		vp2++; vp2++;
	}

	return(retval);
}
/*------------------------------------------------------------*/
/* return <v1,(conj)v2>	   */
cmplx_vec_dotprod(ar,ai,br,bi, outr,outi)
double *ar,*ai,*br,*bi, *outr,*outi;
{
	int i;

	*outr = 0.0;
	*outi = 0.0;
	for (i=0; i<res_xy; i++)
	   *outr += *(ar+i) * *(br+i) + *(ai+i) * *(bi+i);
	for (i=0; i<res_xy; i++)
	   *outi += *(ai+i) * *(br+i) - *(ar+i) * *(bi+i);
}
/*------------------------------------------------------------*/
double vec_dotprod_float(v1,v2)
float *v1,*v2;
{
	int i;
	double retval;

	retval = 0.0;
	for (i=0; i<res_xy; i++) 
		retval += *(v1+i) * *(v2+i);

	return(retval);
}
/*------------------------------------------------------------*/
double vec_dotprod_uchar(v1,v2)
unsigned char *v1,*v2;
{
	int i;
	double retval;

	retval = 0.0;
	for (i=0; i<res_xy; i++) 
		retval += *(v1+i) * *(v2+i);

	return(retval);
}
/*------------------------------------------------------------*/
vec_minmax(v,vmin,vmax)
double *v;
double *vmin,*vmax;
{
	int i;


	*vmin= *vmax = *v;

	for (i=1; i<res_xy; i++) {
	   if (*(v+i) < *vmin) 
		*vmin = *(v+i);
	   else if (*(v+i) > *vmax) 
		*vmax = *(v+i);
	}
}
/*------------------------------------------------------------*/
vec_zero(v)
double *v;
{
	int i;

	if (!vec_flag)
	  for (i=0; i<res_xy; i++) 
	    *(v+i) = 0.0;
	else
	  for (i=0; i<res_xy*2; i++) 
	    *(v+i) = 0.0;
}
vec_zero_float(v)
float *v;
{
	int i;

	for (i=0; i<res_xy; i++) 
	   *(v+i) = 0.0;
}
/*------------------------------------------------------------*/
vec_resolution()
{
	return(res_x*res_y);
}
/*------------------------------------------------------------*/
vec_normalize(v)
double *v;
{
	double d, vec_norm();
	int i;

	d = vec_norm(v);

	for (i=0; i<res_xy; i++) 
	   v[i] /= d;
}

/*------------------------------------------------------------*/
double vec_norm(v)
double *v;
{
	int i;
	double s;


	s = 0.0;
	for (i=0; i<res_xy; i++)
	   s += v[i]*v[i];
	s = sqrt(s);
	return(s);
}
/*------------------------------------------------------------*/
vec_to_file(vp,fp)
double *vp;
FILE *fp;
{
	int i,j,k;
	double *v,p[2];
   float screenx,screeny;
	float arrow[3][2],uval,vval;
	float r,dtheta,theta;
extern float ymin,ydiff,polar_rmin,polar_range,vec_scale;
extern int res_x;
extern int data_type_flag;
extern float cur_mtx[4][4];


	if (dimension == 1) {
	     /* binary output file */
	   if ((data_type_flag == RECT) || (data_type_flag == COMPLEX))
	     fwrite(vp,sizeof(double),res_x,fp);	
	   else if (data_type_flag == POLAR) {
	     dtheta = 2*M_PI / res_x;
	     for (i=0; i<res_x; i++) {
	       theta = i*dtheta;
	       r = (*(vp+i)-ymin)*polar_range/ydiff + polar_rmin;
	       p[X] = r *cos(theta);
	       p[Y] = r *sin(theta);
	       fwrite(p,sizeof(double),2,fp);	
               printf(fp,"%f %f\n", p[X],p[Y]);    /* debug */
	     }
	   }

	      /* ascii output */
/*	   for (i=0; i<res_x; i++)
             printf(fp,"%.5e\n", *(vp+i)); */
	}
	else {		/* dimension = 2 */
/*	   printf("vec_to_file:  2d vector -> ascii matrix\n"); */
	   v = vp;

	   if (data_type_flag != VEC2D) {
	     print_cur_mtx();
	     for (j=0; j<res_y; j++) {
	     for (i=0; i<res_x; i++) {
		 p[X] = i;
		 p[Y] = *v; 
/*		 p[X] = i*cur_mtx[0][0] + *v*cur_mtx[0][1] + j*cur_mtx[0][2];
		 p[Y] = i*cur_mtx[1][0] + *v*cur_mtx[1][1] + j*cur_mtx[1][2]; */
		 fwrite(p,sizeof(double),2,fp);

/*		 fprintf(fp,"%.5e ", *v); */
	   	 v++;
	     }
/*	     fprintf(fp,"\n"); */
	     }

/*	     if (res_x == res_y) {
	       for (i=0; i<res_x; i++) {
	       v = vp + i;
	       for (j=0; j<res_y; j++) {
	           v += res_x;
		   p[X] = i*cur_mtx[0][0] + *v*cur_mtx[0][1] + j*cur_mtx[0][2];
		   p[Y] = i*cur_mtx[1][0] + *v*cur_mtx[1][1] + j*cur_mtx[1][2];
		   fwrite(p,sizeof(double),2,fp);
	       }
	       }
	     } */
	   }
	   else {		/* 2D vector field */
	     printf("plotting 2D vector field ...\n");
	     k=0;
	     for (j=0; j<res_y; j++) {
	      for (i=0; i<res_x; i++) {
			 arrow[0][X] = (float)i;
			 arrow[0][Y] = (float)j;
	       uval = *(vp+k)*vec_scale;
			 k++;
	       vval = *(vp+k)*vec_scale;
			 k++;
			 arrow[1][X] = (float)i + uval;
			 arrow[1][Y] = (float)j + vval;
	       arrow[2][X] = (float)i + uval*0.75 - vval*0.10;
	       arrow[2][Y] = (float)j + vval*0.75 + uval*0.10;
			 fwrite(arrow,sizeof(float),6,fp);
	      }
	     }
	   }
	}
}
/*------------------------------------------------------------*/
eigvec_to_file(vp,fp)
double *vp;
FILE *fp;
{
	int i,j,k;
	double *v,p[2],vmin,vmax,vrange;
	float arrow[3][2],uval,vval;
	float r,dtheta,theta;
extern float ymin,ydiff,polar_rmin,polar_range,vec_scale;
extern int res_x;
extern int data_type_flag;

	if (dimension == 1) {
	     /* binary output file */
	   if ((data_type_flag == RECT) || (data_type_flag == COMPLEX))
	     fwrite(vp,sizeof(double),res_x,fp);	
	   else if (data_type_flag == POLAR) {
	     minmax_d(vp,res_x,&vmin,&vmax);
	     vrange = vmax - vmin;

	     dtheta = 2*M_PI / res_x;
	     for (i=0; i<res_x; i++) {
	       theta = i*dtheta;
	       r = (*(vp+i)-vmin)*polar_range/vrange + polar_rmin;
	       p[X] = r *cos(theta);
	       p[Y] = r *sin(theta);
	       fwrite(p,sizeof(double),2,fp);	
	     }
	   }

	      /* ascii output */
/*	   for (i=0; i<res_x; i++)
		fprintf(fp,"%.5e\n", *(vp+i)); */
	}
	else {
/*	   printf("vec_to_file:  2d vector -> ascii matrix\n"); */
	   v = vp;

	   if (!vec_flag) {	/* f(x,y) */
	     for (j=0; j<res_y; j++) {
	     for (i=0; i<res_x; i++) {
		p[X] = i;
		p[Y] = *v;
		fwrite(p,sizeof(double),2,fp);

/*		fprintf(fp,"%.5e ", *v); */
	   	v++;
	     }
/*	     fprintf(fp,"\n"); */
	     }
	   }
	   else {		/* 2D vector field */
	     printf("plotting 2D vector field eigfn...\n");
	     k=0;
	     for (j=0; j<res_y; j++) {
	     for (i=0; i<res_x; i++) {
		arrow[0][X] = (float)i;
		arrow[0][Y] = (float)j;
	        uval = *(vp+k)*vec_scale;
		k++;
	        vval = *(vp+k)*vec_scale;
		k++;
		arrow[1][X] = (float)i + uval;
		arrow[1][Y] = (float)j + vval;
	        arrow[2][X] = (float)i + uval*0.75 - vval*0.10;
	        arrow[2][Y] = (float)j + vval*0.75 + uval*0.10;
		fwrite(arrow,sizeof(float),6,fp);
	     }
	     }
	   }
	}
}
/*------------------------------------------------------------*/
/* (OK, so it's not a vector operation)          */
/*   c = a/b ,  rf. Num.Rec.                     */
complex_div(ar,ai,br,bi, cr,ci)
double ar,ai,br,bi, *cr,*ci;
{
	double r,den;

	if (fabs(br) >= fabs(bi)) {
	   r = bi/br;
	   den = br + r*bi;
	   *cr = (ar + r*ai) / den;
	   *ci = (ai - r*ar) / den;
	}
	else {
	   r = br/bi;
	   den = bi + r*br;
	   *cr = (ar*r + ai) / den;
	   *ci = (ai*r - ar) / den;
	}
}
/*--------------------------------------------------------------------*/
print_cur_mtx(m)
{
extern float cur_mtx[4][4];
	int i;

/*	getmatrix(cur_mtx); */
	printf("------   cur_mtx  ------\n");
	for (i=0; i<4; i++){
	   printf("%f %f %f %f\n", cur_mtx[i][0],cur_mtx[i][1],
				   cur_mtx[i][2],cur_mtx[i][3]);
	}
}
