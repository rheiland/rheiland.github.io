/* window_pos.c - position graphics windows
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <gl.h>
#include "kl_str.h"
#include "disp_types.h"


extern win_struct data_win,mean_win,eigvals_win,eigfn_win,appx_win,error_win,
		datacoef_win,appxcoef_win;

/*extern int max_xpix,max_ypix,half_xpix; */
extern int max_xpix,max_ypix;
extern int bdel,hdel;
extern int popups_height;

/* "full-size" screen:
    top_y = 980
    half_y = 490
    one_third_y = 327
    two_thirds_y = 653
*/
static int half_xpix, half_y, top_y, one_third_y, two_thirds_y;
int window_pos_mode;

/*--------------------------------------------------------------------*/
window_pos_handler(mode)
int mode;
{
/*	printf("window_pos_handler:  mode = %d\n", mode); */
	window_pos_mode = mode;

	switch(window_pos_mode) {
	case 1:
	  window_full();
	  break;
	case 2:
	  windows_top_bottom();
	  break;
	case 3:
	  windows_left_right();
	  break;
	case 4:
	  windows_4();
	  break;
	}
}
/*--------------------------------------------------------------------*/
calc_window_pos()
{
	half_xpix = max_xpix/2;
	top_y = max_ypix - popups_height;
	half_y = top_y/2;
	one_third_y = top_y/3;
	two_thirds_y = 2*one_third_y;
}
/*--------------------------------------------------------------------*/
update_window_pos(winid,x1,x2,y1,y2)
int winid, x1,x2,y1,y2;
{
/*	printf("update_window_pos: winid = %d\n", winid); */

    if (winid > 0) {
       winset(winid);
       winposition(x1,x2,y1,y2);
       return(1);
    }
    return(0);
}
/*--------------------------------------------------------------------*/
window_full()
{
    int x1,x2,y1,y2;

    x1 = bdel;
    x2 = max_xpix-bdel;
    y1 = 0+bdel;
    y2 = top_y - hdel;

    update_window_pos(datacoef_win.id,x1,x2,y1,y2);
    update_window_pos(appxcoef_win.id,x1,x2,y1,y2);
    update_window_pos(error_win.id,x1,x2,y1,y2);
    update_window_pos(appx_win.id,x1,x2,y1,y2);
    update_window_pos(eigvals_win.id,x1,x2,y1,y2);
    update_window_pos(eigfn_win.id,x1,x2,y1,y2);
    update_window_pos(mean_win.id,x1,x2,y1,y2);
    update_window_pos(data_win.id,x1,x2,y1,y2);
    winpop();

    if (data_win.display_type == SCAN)
       pop_scan_win(data_win.id);
}
/*--------------------------------------------------------------------*/
windows_top_bottom()
{
    int x1,x2,y1,y2;

       /* on upper-half */
    x1 = bdel;
    x2 = max_xpix-bdel;
    y1 = half_y+bdel;
    y2 = top_y-hdel;
    update_window_pos(data_win.id,x1,x2,y1,y2);
    update_window_pos(eigvals_win.id,x1,x2,y1,y2);
    update_window_pos(appx_win.id,x1,x2,y1,y2);
    update_window_pos(datacoef_win.id,x1,x2,y1,y2);
    update_window_pos(appxcoef_win.id,x1,x2,y1,y2);

/*    if (data_win.id > 0) {
    win_upper_half(data_win.id);
    winset(data_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (data_win.display_type == SCAN)
       pop_scan_win(data_win.id);
    }

       /* on lower-half */

    x1 = bdel;
    x2 = max_xpix-bdel;
    y1 = 0+bdel;
    y2 = half_y-hdel;
    update_window_pos(mean_win.id,x1,x2,y1,y2);
    update_window_pos(eigfn_win.id,x1,x2,y1,y2);
    update_window_pos(error_win.id,x1,x2,y1,y2);

/*    if (mean_win.id > 0) {
    winset(mean_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    }

    if (eigfn_win.id > 0) {
    winset(eigfn_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (eigfn_win.display_type == SCAN)
       pop_scan_win(eigfn_win.id);
    }

    if (appx_win.id > 0) {
    winset(appx_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (appx_win.display_type == SCAN)
       pop_scan_win(appx_win.id);
    }

    if (error_win.id > 0) {
    winset(error_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (error_win.display_type == SCAN)
       pop_scan_win(error_win.id);
    } */
}
/*--------------------------------------------------------------------*/
windows_left_right()
{
    int x1,x2,y1,y2;


       /* on left-half */
    x1 = bdel;
    x2 = half_xpix-bdel;
    y1 = bdel;
    y2 = top_y-hdel;

    update_window_pos(data_win.id,x1,x2,y1,y2);
    update_window_pos(eigvals_win.id,x1,x2,y1,y2);
    update_window_pos(appx_win.id,x1,x2,y1,y2);
    update_window_pos(datacoef_win.id,x1,x2,y1,y2);
    update_window_pos(appxcoef_win.id,x1,x2,y1,y2);


/*    if (error_win.id > 0) {
    winset(error_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (error_win.display_type == SCAN)
       pop_scan_win(error_win.id);
    }

    if (data_win.id > 0) {
    winset(data_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (data_win.display_type == SCAN)
       pop_scan_win(data_win.id);
    } */


       /* on right-half */
    x1 = half_xpix + bdel;
    x2 = max_xpix-bdel;
    y1 = bdel;
    y2 = top_y-hdel;
    update_window_pos(mean_win.id,x1,x2,y1,y2);
    update_window_pos(eigfn_win.id,x1,x2,y1,y2);
    update_window_pos(error_win.id,x1,x2,y1,y2);

/*    if (mean_win.id > 0) {
    winset(mean_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    }

    if (eigfn_win.id > 0) {
    winset(eigfn_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (eigfn_win.display_type == SCAN)
       pop_scan_win(eigfn_win.id);
    }

    if (appx_win.id > 0) {
    winset(appx_win.id);
    winposition(x1,x2,y1,y2);
    winpop();
    if (appx_win.display_type == SCAN)
       pop_scan_win(appx_win.id);
    } */
}
/*--------------------------------------------------------------------*/
windows_4()
{
    int x1,x2,y1,y2;


    win_upper_left(data_win.id);
    if (data_win.display_type == SCAN)
       pop_scan_win(data_win.id);

    if (mean_win.id > 0) 
    win_upper_right(mean_win.id);

    if (eigvals_win.id > 0) 
    win_lower_left(eigvals_win.id);

    if (eigfn_win.id > 0) {
    win_lower_right(eigfn_win.id);
    if (eigfn_win.display_type == SCAN)
       pop_scan_win(eigfn_win.id);
    }

    if (appx_win.id > 0) {
    win_upper_right(appx_win.id);
    if (appx_win.display_type == SCAN)
       pop_scan_win(appx_win.id);
    }

    if (datacoef_win.id > 0) {
       win_upper_right(datacoef_win.id);
       pop_scan_win(datacoef_win.id);
    }

    if (appxcoef_win.id > 0) {
       win_lower_right(appxcoef_win.id);
       pop_scan_win(appxcoef_win.id);
    }

    if (error_win.id > 0) {
    win_lower_left(error_win.id);
    if (error_win.display_type == SCAN)
       pop_scan_win(error_win.id);
    }
}
/*--------------------------------------------------------------------*/
win_upper_left(win_id)
int win_id;
{
	int x1,x2,y1,y2;

	winset(win_id);
	x1 = bdel;
	x2 = half_xpix - bdel;
	y1 = half_y+bdel;
	y2 = top_y-hdel;
	winposition(x1,x2,y1,y2);
	winpop();
}
win_upper_right(win_id)
int win_id;
{
	int x1,x2,y1,y2;

	winset(win_id);
	x1 = half_xpix + bdel;
	x2 = max_xpix -bdel;
	y1 = half_y+bdel;
	y2 = top_y-hdel;
	winposition(x1,x2,y1,y2);
	winpop();
}
win_lower_left(win_id)
int win_id;
{
	int x1,x2,y1,y2;

	winset(win_id);
	x1 = bdel;
	x2 = half_xpix - bdel;
	y1 = 0+bdel;
	y2 = half_y-hdel;
	winposition(x1,x2,y1,y2);
	winpop();
}
win_lower_right(win_id)
int win_id;
{
	int x1,x2,y1,y2;

	winset(win_id);
	x1 = half_xpix + bdel;
	x2 = max_xpix-bdel;
	y1 = 0+bdel;
	y2 = half_y-hdel;
	winposition(x1,x2,y1,y2);
	winpop();
}
/*--------------------------------------------------------------------*/
win_upper_half(win_id)
int win_id;
{
	int x1,x2,y1,y2;

	winset(win_id);
	x1 = bdel;
	x2 = max_xpix-bdel;
	y1 = half_y+bdel;
	y2 = top_y-hdel;
	winposition(x1,x2,y1,y2);
	winpop();
}
/*--------------------------------------------------------------------*/
window_square()
{
    int x1,x2,y1,y2;

    winset(data_win.id);
    x1 = bdel;
    x2 = 280 + bdel;
    y2 = top_y-hdel;
    y1 = y2 - 280;
    winposition(x1,x2,y1,y2);
    winpop();
    if (data_win.display_type == SCAN)
       pop_scan_win(data_win.id);
}
