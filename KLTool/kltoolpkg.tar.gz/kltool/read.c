/* read_handler.c - Read saved files
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <gl.h>
#include "kl_str.h"

#define STRINGLEN 128

read_handler(item)
int item;
{
	switch(item) {
	case 1:			/* data */
	   read_data();
	   break;
	case 2:			/* mean */
	   read_mean();
	   break;
	case 3:			/* eiginfo */
	   read_eiginfo();
	   break;
	case 4:			/* appx */
	   read_appx();
	   break;
	}
}
/*--------------------------------------------------------------------*/
read_data()
{
	FILE *fpin;
	int i,k;
	char buf[STRINGLEN];
	float *fp;
	double *dp,*alloc_vector();
	vec_struct *vsp,*vsp2;
extern int res_xy;
extern int num_vecs;
extern vec_struct *vec_root;
extern win_struct data_win;


/*	pop_feedback(); */
	k = get_string("Enter data filename: ",buf,STRINGLEN);
        if((fpin=fopen(buf, "r")) == NULL)  {
		error_msg("ERROR - File not found");
		return(-1);
        }

	if (read_header(fpin) < 0)
	   return(-1);

	free_vec_list(vec_root);
	vec_root = NULL;

	fp = NEW(float,sizeof(float)*res_xy);

	pop_feedback();

	k=0;
	while(1) {

		   /* allocate space for vector */
	   dp = alloc_vector();
	   if ( (i=fread(fp,sizeof(float),res_xy,fpin)) != res_xy) {
	   	free(dp);
	   	break;
	   }
	   sprintf(buf,"Reading data vector #%d", k+1);
	   feedback_msg(buf);

	   copy_float_to_double(fp,dp,res_xy);

	   if (k==0) {
		vsp = NEW(vec_struct,sizeof(vec_struct));
		vec_root = vsp;
		vec_root->prev = NULL;
		vec_root->next = NULL;
	   }
	   else {
		vsp2 = NEW(vec_struct,sizeof(vec_struct));
		vsp2->next = NULL;
		vsp->next = vsp2;
		vsp = vsp2;
	   }
	   vsp->dp = dp;
	   k++;

	}
	num_vecs = k;
/*	printf("num_vecs = %d\n", num_vecs); */

	free(fp);

	push_feedback();

	   /* determine if the window is already displayed */
	if (data_win.id < 0) 
	   create_data_win();

	data_extrema();

	redraw_data();
}
/*--------------------------------------------------------------------*/
read_mean()
{
	FILE *fp;
	int k;
	char buf[STRINGLEN];
	double *alloc_vector();
extern double *mean_ptr, *mean_ptr_real,*mean_ptr_imag;
extern int res_xy;
extern win_struct	mean_win;
extern int cmplx_flag;

	k = get_string("Enter mean filename: ",buf,STRINGLEN);
        if((fp=fopen(buf, "r")) == NULL)  {
		error_msg("ERROR - File not found");
		return(-1);
        }

	if (read_header(fp) < 0)
	   return(-1);


	if (!cmplx_flag) {		/* real mean */
	   if (mean_ptr != NULL)
	     free(mean_ptr);
	   mean_ptr = alloc_vector();

	   if ( fread(mean_ptr,sizeof(double),res_xy,fp) != res_xy) {
		error_msg("ERROR reading file");
		free(mean_ptr);
		return(-1);
	   }
	}

	else {				/* complex mean */
	   if (mean_ptr_real != NULL) {
	      free(mean_ptr_real);
	      free(mean_ptr_imag);
	   }
	   mean_ptr_real = alloc_vector();
	   mean_ptr_imag = alloc_vector();

	   if ( fread(mean_ptr_real,sizeof(double),res_xy,fp) != res_xy) {
		error_msg("ERROR reading file");
		free(mean_ptr_real);
		return(-1);
	   }
	   if ( fread(mean_ptr_imag,sizeof(double),res_xy,fp) != res_xy) {
		error_msg("ERROR reading file");
		free(mean_ptr_imag);
		return(-1);
	   }
	   update_cmplx_mean_form();
	}

	data_extrema();


	   /* determine if the window is already displayed */
	if (mean_win.id < 0) 
	   create_mean_win();

	redraw_mean();
}
/*--------------------------------------------------------------------*/
read_eiginfo()
{
	FILE *fp,*fpout;
	int i,k;
	char buf[STRINGLEN];
	vec_struct *usp, *usp2;
	cmplx_vec_struct *cusp, *cusp2;
	float pctsum;
	double *udp, *alloc_vector(),eigval;
	double *urp,*uip;
extern int num_eig;
extern double sum_eigvals;
extern double *wrp, *eigvals;
extern vec_struct *u_root;
extern cmplx_vec_struct *cmplx_u_root;
extern int res_xy;
extern win_struct	eigfn_win;
extern int	cur_eigfn;
extern int	cmplx_flag;
extern float *pct_table,*pctsum_table;



/*	pop_feedback(); */
	k = get_string("Enter eiginfo input filename: ",buf,STRINGLEN);
        if((fp=fopen(buf, "r")) == NULL)  {
	    error_msg("Error opening file.");
	    return(-1);
        }

	fread(&sum_eigvals,sizeof(double),1,fp);
	printf("sum_eigvals = %f\n", sum_eigvals);

	fread(&num_eig,sizeof(int),1,fp);
	printf("num_eig = %d\n",num_eig);

        if (eigvals != NULL) free(eigvals);
	eigvals = (double *)malloc(sizeof(double)*num_eig);

        if (pct_table != NULL) free(pct_table);
	pct_table = (float *)malloc(sizeof(float)*num_eig);
        if (pctsum_table != NULL) free(pctsum_table);
	pctsum_table = (float *)malloc(sizeof(float)*num_eig);

	   /* All eigvals from our symmetric (Hermitian) mtx are real */
	pctsum = 0.0;
	for (i=0; i<num_eig; i++) {
	   fread(&eigval,sizeof(double),1,fp);
	   printf("eigval = %f\n", eigval);
	   *(eigvals+i) = eigval;
	   *(pct_table+i) = eigval/sum_eigvals;
	   pctsum += *(pct_table+i);
	   *(pctsum_table+i) = pctsum;
	}

/*	push_feedback(); */

	update_eigvals_win();


	   /* Read eigfns - if they were written */

	if (read_header(fp) < 0)
	   return(-1);

/*	printf("res_xy = %d\n", res_xy); */

	pop_feedback();

	if (!cmplx_flag) {	/* real (non-complex) eigfns */

	  free_vec_list(u_root);
	  u_root = NULL;


	  for(i=0; i<num_eig; i++) {

	    sprintf(buf,"Reading eigfn #%d", i+1);
	    feedback_msg(buf);

		   /* allocate space for eigenfunction */
	    udp = alloc_vector();
	    if ( (k=fread(udp,sizeof(double),res_xy,fp)) != res_xy) {
/*		pop_feedback(); */
		push_feedback();
		error_msg("ERROR reading file");
		printf("fread = %d\n",k);
	   	free(udp);
	   	break;
	    }

	    if (i==0) {
		usp = NEW(vec_struct,sizeof(vec_struct));
		u_root = usp;
		u_root->prev = NULL;
		u_root->next = NULL;
	    }
	    else {
		usp2 = NEW(vec_struct,sizeof(vec_struct));
		usp2->next = NULL;
		usp->next = usp2;
		usp = usp2;
	    }
	    usp->dp = udp;

	  }
	}
	else {		/* complex eigfns */

	  free_vec_list(u_root);
	  u_root = NULL;

	  free_cmplx_vec_list(cmplx_u_root);
	  cmplx_u_root = NULL;

	   /* Read eigfns */
	  for(i=0; i<num_eig; i++) {

	   sprintf(buf,"Reading eigfn #%d", i+1);
	   feedback_msg(buf);

		   /* allocate space for eigenfunction */
	   udp = alloc_vector();
	   urp = alloc_vector();
	   uip = alloc_vector();
	   if ( (k=fread(urp,sizeof(double),res_xy,fp)) != res_xy) {
/*		pop_feedback(); */
		push_feedback();
		error_msg("ERROR reading file");
		printf("(urp)fread = %d\n",k);
	   	free(urp);
	   	break;
	   }
	   if ( (k=fread(uip,sizeof(double),res_xy,fp)) != res_xy) {
/*		pop_feedback(); */
		push_feedback();
		error_msg("ERROR reading file");
		printf("(uip)fread = %d\n",k);
	   	free(uip);
	   	break;
	   }

	   if (i==0) {
		cusp = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
		cmplx_u_root = cusp;
		cmplx_u_root->prev = NULL;
		cmplx_u_root->next = NULL;

		usp = NEW(vec_struct,sizeof(vec_struct));
		u_root = usp;
		u_root->prev = NULL;
		u_root->next = NULL;
	   }
	   else {
		cusp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
		cusp2->next = NULL;
		cusp->next = cusp2;
		cusp = cusp2;

		usp2 = NEW(vec_struct,sizeof(vec_struct));
		usp2->next = NULL;
		usp->next = usp2;
		usp = usp2;
	   }
	   usp->dp = udp;
	   cusp->drp = urp;
	   cusp->dip = uip;

	  }
          update_cmplx_eigfn_form();
	}

/*	num_eig_max = num_eig;
	printf("num_eig_max = %d\n", num_eig_max); */

	data_extrema();

	if (u_root != NULL) {
	   /* determine if the window is already displayed */
 	  if (eigfn_win.id < 0) 
	    create_eigfn_win();

	  cur_eigfn = 1;
	  setup_eigfn_win(cur_eigfn);
	  redraw_eigfn(cur_eigfn);
	}

	fclose(fp);
	push_feedback();
}
/*--------------------------------------------------------------------*/
read_appx()
{
	FILE *fpin;
	int i,k;
	char buf[STRINGLEN];
	float *fp;
	double *dp, *drp,*dip, *alloc_vector();
	vec_struct *vsp, *vsp2;
	cmplx_vec_struct *cvsp, *cvsp2;
extern int res_xy;
extern int num_vecs;
extern vec_struct *appx_root;
extern cmplx_vec_struct *cmplx_appx_root;
extern win_struct appx_win;
extern int cmplx_flag;
extern int num_eig_appx;


/*	pop_feedback(); */
	k = get_string("Enter appx filename: ",buf,STRINGLEN);
        if((fpin=fopen(buf, "r")) == NULL)  {
		error_msg("ERROR - File not found");
		return(-1);
        }

	if (read_header(fpin) < 0)
	   return(-1);
	fread(&num_eig_appx,sizeof(int),1,fpin);

	free_vec_list(appx_root);

	fp = NEW(float,sizeof(float)*res_xy);


	pop_feedback();

	k=0;
	if (!cmplx_flag) {		/* real */
	while(1) {

		   /* allocate space for vector */
	   dp = alloc_vector();
	   if ( (i=fread(fp,sizeof(float),res_xy,fpin)) != res_xy) {
	   	free(dp);
	   	break;
	   }
	   sprintf(buf,"Reading appx vector #%d", k+1);
	   feedback_msg(buf);

	   copy_float_to_double(fp,dp,res_xy);

	   if (k==0) {
		vsp = NEW(vec_struct,sizeof(vec_struct));
		appx_root = vsp;
		appx_root->prev = NULL;
		appx_root->next = NULL;
	   }
	   else {
		vsp2 = NEW(vec_struct,sizeof(vec_struct));
		vsp2->next = NULL;
		vsp->next = vsp2;
		vsp = vsp2;
	   }
	   vsp->dp = dp;
	   k++;
	}
	}
	else {				/* complex */
	while(1) {

		   /* allocate space for vector */
	   drp = alloc_vector();
	   if ( (i=fread(fp,sizeof(float),res_xy,fpin)) != res_xy) {
	   	free(drp);
	   	break;
	   }
	   copy_float_to_double(fp,drp,res_xy);

	   dip = alloc_vector();
	   if ( (i=fread(fp,sizeof(float),res_xy,fpin)) != res_xy) {
	   	free(dip);
	   	break;
	   }
	   copy_float_to_double(fp,dip,res_xy);

	   sprintf(buf,"Reading appx vector #%d", k+1);
	   feedback_msg(buf);


	   if (k==0) {
		cvsp = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
		cmplx_appx_root = cvsp;
		cmplx_appx_root->prev = NULL;
		cmplx_appx_root->next = NULL;

		vsp = NEW(vec_struct,sizeof(vec_struct));
		appx_root = vsp;
		appx_root->prev = NULL;
		appx_root->next = NULL;
	   }
	   else {
		cvsp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
		cvsp2->next = NULL;
		cvsp->next = cvsp2;
		cvsp = cvsp2;

		vsp2 = NEW(vec_struct,sizeof(vec_struct));
		vsp2->next = NULL;
		vsp->next = vsp2;
		vsp = vsp2;
	   }
	   cvsp->drp = drp;
	   cvsp->dip = dip;

	   dp = alloc_vector();
	   vsp->dp = dp;
	   k++;
	}
        update_cmplx_appx_form();
	}


	num_vecs = k;

	push_feedback();
	free(fp);

	   /* determine if the window is already displayed */
	if (appx_win.id < 0) 
	   create_appx_win();

	data_extrema();

	redraw_appx();
}
/*--------------------------------------------------------------------*/
read_header(fp)
FILE *fp;
{
extern int res_x,res_y,res_xy;
extern int dimension,file_res_x,file_res_y;
extern float xmin,xmax,ymin,ymax,zmin,zmax;

	printf("----------  read_header  --------\n");
	if (fread(&res_x,sizeof(int),1,fp) != 1) {
	   error_msg("ERROR reading header(res_x)");
	   return(-1);
	}
	if (fread(&res_y,sizeof(int),1,fp) != 1) {
	   error_msg("ERROR reading header(res_y)");
	   return(-1);
	}
	printf("  res_x,res_y = %d %d\n", res_x,res_y);

	if ((res_x <= 0) || (res_y <= 0))  {
	   error_msg("ERROR - Bad header information");
	   return(-1);
	}

	res_xy = res_x * res_y;

	file_res_x = res_x;
	file_res_y = res_y;

	dimension = 1;
	if (res_y > 1) dimension = 2;

	fread(&xmin,sizeof(float),1,fp);
	fread(&xmax,sizeof(float),1,fp);
	fread(&ymin,sizeof(float),1,fp);
	fread(&ymax,sizeof(float),1,fp);
	fread(&zmin,sizeof(float),1,fp);
	fread(&zmax,sizeof(float),1,fp);

	printf("  xmin,xmax = %f %f\n", xmin,xmax);
	printf("------------------------\n");
}
/*--------------------------------------------------------------------*/
copy_float_to_double(fp,dp,n)
float *fp;
double *dp;
int n;
{
	int i;

	for (i=0; i<n; i++)
	      *(dp+i) = *(fp+i);
}
