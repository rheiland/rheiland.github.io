/* parse_pde.c - 
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 *
 */
#include <malloc.h>
#include <stdio.h>

#define MAXL 20

extern FILE *fpode, *fpode2;
static FILE *fpparse;

static double foo1;
static char fn_name;
static char time_var;
static char space_var[2];
static int num_space_vars;
/*static int done; */

#define MAXOPS 5
char operators[MAXOPS] = {'+','-','*','/','^'};


/* neq-th equation (ode) */

parse_pde(cp,neq,kmax,fplog,fpin)
double *cp[];
int neq,*kmax;
FILE *fplog,*fpin;
{
	int i;
	char c,op[MAXL];
	char msg[80];


	printf("------------ begin parse_pde (eqn %d) ---------\n",neq+1);

/*	sprintf(msg,"Generating equation %d",neq+1);
	notify_user(msg); */

	  /* Get input file containing PDE and parse it */

	fpparse = fpin;
	printf("parse_pde:  fpparse = %d\n",fpparse);

	parse_fn();

	i = 0;

	while ( next_char(&c) != EOF) {
/*	   printf("c= %c\n", c); */

	   if (an_operator(c) ) {
	      op[i] = '\0';
	      if (i > 0) {
		 printf("operand = ***%s***\n", op);
	         fprintf(fpode," %s ", op);
	         fprintf(fpode2," %s ", op);
		 fprintf(fplog,"operand = ***%s***\n", op);
	      }
	      printf("operator = %c\n",c);
	      fprintf(fpode," %c ", c);
	      fprintf(fpode2," %c ", c);
	      fprintf(fplog,"operator = %c\n",c);

	      i=0;
	   }
	   else if (c=='d') {

	      if (next_char(&c) == EOF) {
		 op[i] = c;
		 i++;
	      }
	      else if (c == '(') {
	         decode_deriv(neq,kmax,cp,fplog);
		 i=0;
	      }
	      else if (an_operator(c) ) {
	         op[i] = '\0';
	         if (i > 0) {
		    printf("operand = ***%s***\n", op);
		    fprintf(fplog,"operand = ***%s***\n", op);
		 }
	         printf("operator = %c\n",c);
	         fprintf(fplog,"operator = %c\n",c);
	      }
	      else {
		 op[i] = c;
		 i++;
	      }
	   }
	   else if (c == fn_name) {
	      expand_fn(op,cp,neq,kmax);
	      i=0;
	   }
	   else if (c=='(') {
	      printf("got a left paren...\n");
	      fprintf(fpode," ( ");
	      fprintf(fpode2," ( ");
	      fprintf(fplog," ( ");
	   }
	   else if (c==')') {
	      printf("got a right paren...\n");
	      fprintf(fpode," ) ");
	      fprintf(fpode2," ) ");
	      fprintf(fplog," ) ");
	   }
	   else {
	      op[i] = c;
	      i++;
	   }
	}
	op[i] = '\0';
	printf("(last)operand = ***%s***\n\n\n", op);
	fprintf(fplog,"(last)operand = ***%s***\n\n\n", op);
}
/*--------------------------------------------------*/ 
operand_is_fn(op)
char op[];
{
	if (op[0]==fn_name)
	   return(1);
	else
	   return(0);
}
/*--------------------------------------------------*/ 
expand_fn(op,cp,n,kmax)
char op[];
double *cp[];
int n,*kmax;
{
	double sum[2];
	int mzero=0;

	printf("expand_fn:  %s\n",op);
/*	fprintf(fplog,"-------expand_fn------\n"); */

/*	phi_dotp_(cp[i],cp[n],kmax,&mzero,sum); */
	     /* res_x = 256 for K-S */
/*	   fprintf(fpode,"a%d * %.8f = ", n+1,res_x*sum[0]); */
/*	   fprintf(fpode,"a%d * %.8f = ", n+1,sum[0]); */
}
/*--------------------------------------------------*/ 
an_operator(c)
char c;
{
	int i;

	for (i=0; i<MAXOPS; i++) {
	   if (c == operators[i]) return(1);
	}
	return(0);
}
/*--------------------------------------------------*/ 
next_char(c)
char *c;
{
	long k;

/*	printf("next_char:  fpparse = %d\n",fpparse); */

	if ((k=getc(fpparse)) == EOF) 
	   return(EOF);

/*printf("next_char: k = %d\n",k); */

	if (k == '\n')
	   return(next_char(c));
	else if (k == ' ')
	   return(next_char(c));
	else if (k == '#') {
	   strip_comment(fpparse);
	   return(next_char(c));
	}

printf("      = %c\n",*c);
	*c = k;
	return(k);
}
/*--------------------------------------------------*/ 
strip_comment()
{
	char c;

	while ((c=getc(fpparse)) != EOF && c != '\n');
}

/*--------------------------------------------------*/ 
/* for n-th ode */
decode_deriv(neq,kmax,cp,fplog)
int neq,*kmax;
double *cp[];
FILE *fplog;
{
	char c,csave;
	int n,m,mzero,expon,i,j,k;
	double sum[2],*cprod;
extern int	num_eig;

	printf("-------decode_deriv------\n");
	fprintf(fplog,"-------decode_deriv------\n");


	next_char(&c);
	printf("  strip dependent var %c\n",c);
	fprintf(fplog,"  strip dependent var %c\n",c);
	next_char(&c);
	printf("  strip %c\n",c);
	fprintf(fplog,"  strip %c\n",c);

	next_char(&c);
	printf("  strip independent var %c\n",c);
	fprintf(fplog,"  strip independent var %c\n",c);

	next_char(&c);
	if (c == ')')
	   m = 1;
	else {		/* assume a ,  */
	   next_char(&c);	/* get deriv */
	   m = (int)c - 48;
	   next_char(&c);	/* strip ")" or  "," for 2-D ? */
	}
	printf("   taking %d-th deriv...\n", m);
	fprintf(fplog,"   taking %d-th deriv...\n", m);

	next_char(&c);	/* exponent operator? */


	if (c == '^') {
	   next_char(&c);	/* get exponent */
	   expon = (int)c - 48;
	   printf("Deriv raised to power %d\n",expon);
	   fprintf(fplog,"Deriv raised to power %d\n",expon);
	}
	else {
	   printf("Deriv *not* raised to a power (char= %c)\n",c);
	   fprintf(fplog,"Deriv *not* raised to a power (char= %c)\n",c);
	   expon = 1;
	   csave = c;
/*	   putc(c,fp); */
	}

	fprintf(fpode,"\n ( ");
	fprintf(fpode2,"\n ( ");

	if (expon==1) {
	   for (n=0; n<num_eig; n++) {

	      phi_dotp_(cp[n],cp[neq],kmax,&m,sum);

/*	      fprintf(fpode,"a%d * %.8e ", n+1,res_x*sum[0]); */
	      fprintf(fpode,"a%d * %.8e ", n+1,sum[0]);
	      fprintf(fpode2,"a%d * %.8f ", n+1,sum[0]);
	      if (n < num_eig-1) {
		 fprintf(fpode," + ");
		 fprintf(fpode2," + ");
	      }
	   }

	}

	else if (expon > 1) {

	   printf("Handling exponent > 1:  m=%d\n",m);

		/* k=[-KMAX,KMAX] of complex values (real,imag) */
	   cprod = (double *)malloc(sizeof(double)*(*kmax)*2*2+1);

	   for (i=0; i<num_eig; i++) {
	   for (j=0; j<num_eig; j++) {

	       phi_mult_(cp[i],cp[j],kmax,&m,cprod);

		  /* debug */
/*	       if (neq==0 && i==0 && j==0) {
		for (k=0; k<=2*(*kmax); k++)
		  printf("     %d   %e %e\n",k-(*kmax),cprod[k*2],cprod[k*2+1]);
	       }
	       printf("cprod[0] = %e %e\n",cprod[*kmax*2],cprod[*kmax*2+1]); */

	       mzero = 0;
	       phi_dotp_(&cprod[*kmax*2],cp[neq],kmax,&mzero,sum);

		printf("a%d*a%d * %e %e", i+1,j+1,sum[0],sum[1]);

		fprintf(fpode,"a%d*a%d * %.8e", i+1,j+1,sum[0]);
		fprintf(fpode2,"a%d*a%d * %.8f", i+1,j+1,sum[0]);

		if (i==(num_eig-1) && j==(num_eig-1) ) ;
		else {
		   fprintf(fpode," + ");
		   fprintf(fpode2," + ");
		}
	   }
	   }
	   free(cprod);
	}


	fprintf(fpode," ) ");
	fprintf(fpode2," ) ");

	fprintf(fpode," %c ", csave);
	fprintf(fpode2," %c ", csave);
	fprintf(fplog," %c \n", csave);
	printf("-------------\n");

	return(1);
}
/*--------------------------------------------------*/ 
get_depend_var()
{
	char c,var[MAXL];
	int i,error_flag;

	error_flag = 0;

	for(i=0; i<MAXL; i++) {
	   if( next_char(&c) == EOF) {
	      error_flag = 1;
	      break;
	   }

	   if (c == ',') {
	      break;
	   }
	   var[i] = c;
	}

	if (error_flag)
	   return(0);

	printf("---dep var= %s\n",var);
}
/*--------------------------------------------------*/ 
parse_fn()
{
	int k;
	char c;

	   /* Simplifying assumption - that the dependent & indep
	      vars are only 1 character each */

	k = next_char(&c);
printf("parse_fn: k = %d\n",k);

	if (k < 'a' || k > 'z') {
	   parse_error("1st line must indicate function, eg, u(t,x)");
	   return(0);
	}
	   /* Store function name */
	fn_name = c;

	k = next_char(&c);
	if (k != '(' ) {
	   parse_error("1st line (function) syntax (1)");
	   return(0);
	}

	   /* time variable */
	k = next_char(&c);
	if (k < 'a' || k > 'z') {
	   parse_error("1st line (function) syntax (2)");
	   return(0);
	}
	time_var = c;

	k = next_char(&c);
	if (k != ',' ) {
	   parse_error("1st line (function) syntax (3)");
	   return(0);
	}

	   /* space variable */
	k = next_char(&c);
	if (k < 'a' || k > 'z') {
	   parse_error("1st line (function) syntax (4)");
	   return(0);
	}
	space_var[0] = c;
	num_space_vars = 1;

	k = next_char(&c);
	if (k == ')' )
	   return(1);
	else if (k != ',' ) {
	   parse_error("1st line (function) syntax (5)");
	   return(0);
	}

	   /* space variable */
	k = next_char(&c);
	if (k < 'a' || k > 'z') {
	   parse_error("1st line (function) syntax (6)");
	   return(0);
	}
	space_var[1] = c;
	num_space_vars++;

	k = next_char(&c);
	if (k == ')' )
	   return(1);
	else {
	   parse_error("1st line (function) syntax (7)");
	   return(0);
	}
}
/*--------------------------------------------------*/ 
print_fn_info()
{
	printf("\n");
	printf("   function name ---%c---\n",fn_name);
	printf("   time var      ---%c---\n",time_var);
	printf("   space var     ---%c---\n",space_var[0]);
	if (num_space_vars > 1)
	   printf("   space var     ---%c---\n",space_var[1]);

	printf("\n");
}
/*--------------------------------------------------*/ 
parse_error(msg)
char *msg;
{
	printf("*** %s\n",msg);
}
