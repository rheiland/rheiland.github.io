/* mean.c 
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include "kl_str.h"

double *mean_ptr = NULL;
double *mean_ptr_real = NULL;
double *mean_ptr_imag = NULL;

char *mean_ptr_byte = NULL;
float *mean_ptr_float = NULL;

vec_struct *caric_root = NULL;
cmplx_vec_struct *cmplx_caric_root = NULL;
vec_struct_byte *caric_root_byte = NULL;
vec_struct_float *caric_root_float = NULL;

/*--------------------------------------------------------------------*/
mean_handler()
{
	int i;
extern win_struct mean_win;
extern char input_format;

	pop_feedback();
	feedback_msg("Computing mean...");

	if (input_format == 'b') {
	   compute_mean_byte();
	   push_feedback(); 
	   return(-1);
	}

	if (compute_mean() < 0)
	    return(-1);

	push_feedback();

	   /* determine if the window is already displayed */
	printf("--- mean_handler:       mean_win.id = %d\n", mean_win.id);

	if (mean_win.id < 0) 
	   create_mean_win();

	redraw_mean();
}
/*--------------------------------------------------------------------*/
compute_mean()
{
	int i,j,k;
	vec_struct *vsp, *csp,*csp2;
	double *alloc_vector();
	char *butns[3];
extern vec_struct *vec_root;
extern int num_vecs;
extern int res_xy;
extern int cmplx_flag;
extern int vec_flag;

	if (cmplx_flag)
	   return(compute_mean_cmplx());

	if (vec_root == NULL) {
	   notify_user("Must read data first");
	   return(-1);
	}

	printf("compute_mean:  num_vecs,res = %d %d\n", num_vecs,res_xy);

	if (mean_ptr != NULL) 
	   free(mean_ptr);

	mean_ptr = alloc_vector();;

	vec_zero(mean_ptr);

	TRACE(vsp,vec_root)
	   vec_add(mean_ptr,vsp->dp);		/* v1 = v1 + v2 */

	   /* Compute mean vector */
	vec_divide(mean_ptr,(double)num_vecs);


	/*--------------------------------------------*/
	feedback_msg("Computing caricatures...");

	k=0;
	TRACE(vsp,caric_root) {
	   free(vsp->dp);
	   free(vsp);
	   k++;
	}
	printf("  freed %d structs of carics\n", k);
	caric_root = NULL;


	TRACE(vsp,vec_root) {

	   csp2 = NEW(vec_struct,sizeof(vec_struct));
	      
	   if (caric_root == NULL) {  /* Begin new list of vectors */
		csp2->next = NULL;
		csp2->prev = NULL;
		csp = csp2;
		caric_root = csp;
	   }
	   else {
		csp2->next = NULL;
		csp2->prev = csp;
		csp->next = csp2;
		csp = csp2;
	   }

	   csp->dp = alloc_vector();	/* alloc space for caric vector */

	   vec_copy(vsp->dp, csp->dp);	/* copy data vec into caric vec */
					
	   vec_subtract(csp->dp,mean_ptr);	/* then subtract the mean */
	}
}
/*--------------------------------------------------------------------*/
compute_mean_cmplx()
{
	int i,j,k;
	cmplx_vec_struct *cvsp, *csp,*csp2;
	double *dp,*drp,*dip, *alloc_vector();
	char *butns[3];
extern cmplx_vec_struct *cmplx_vec_root;
extern int num_vecs;
extern int res_xy;
extern int cmplx_flag;


	if (cmplx_vec_root == NULL) {
	   notify_user("Must read data first");
	   return(-1);
	}

	printf("compute_mean_cmplx:  num_vecs,res = %d %d\n", num_vecs,res_xy);

	if (mean_ptr_real != NULL) {
	   free(mean_ptr_real);
	   free(mean_ptr_imag);
	}

	mean_ptr_real = NEW(double,sizeof(double)*res_xy);
	mean_ptr_imag = NEW(double,sizeof(double)*res_xy);

	vec_zero(mean_ptr_real);
	vec_zero(mean_ptr_imag);

	TRACE(cvsp,cmplx_vec_root) {
	   vec_add(mean_ptr_real,cvsp->drp);		/* v1 = v1 + v2 */
	   vec_add(mean_ptr_imag,cvsp->dip);		/* v1 = v1 + v2 */
	}

	   /* Compute mean vector */
	vec_divide(mean_ptr_real,(double)num_vecs);
	vec_divide(mean_ptr_imag,(double)num_vecs);


	/*--------------------------------------------*/
	feedback_msg("Computing (complex) caricatures...");

	k=0;
	TRACE(cvsp,cmplx_caric_root) {
	   free(cvsp->drp);
	   free(cvsp->dip);
	   free(cvsp);
	   k++;
	}
/*	printf("  freed %d structs of carics\n", k); */
	cmplx_caric_root = NULL;

	TRACE(cvsp,cmplx_vec_root) {

	   csp2 = NEW(cmplx_vec_struct,sizeof(cmplx_vec_struct));
	      
	   if (cmplx_caric_root == NULL) {  /* Begin new list of vectors */
		csp2->next = NULL;
		csp2->prev = NULL;
		csp = csp2;
		cmplx_caric_root = csp;
	   }
	   else {
		csp2->next = NULL;
		csp2->prev = csp;
		csp->next = csp2;
		csp = csp2;
	   }

	   csp->drp = alloc_vector();	/* alloc space for caric vector */
	   csp->dip = alloc_vector();	/* alloc space for caric vector */

	   vec_copy(cvsp->drp, csp->drp);  /* copy data vec into caric vec */
	   vec_copy(cvsp->dip, csp->dip);  /* copy data vec into caric vec */
					
	   vec_subtract(csp->drp,mean_ptr_real);   /* then subtract the mean */
	   vec_subtract(csp->dip,mean_ptr_imag);   /* then subtract the mean */
	}


	   /* get the desired representation of the mean */

	if (mean_ptr != NULL) 
	   free(mean_ptr);

	mean_ptr = NEW(double,sizeof(double)*res_xy);

	update_cmplx_mean_form();
	return(1);
}
/*--------------------------------------------------------------------*/
compute_mean_byte()
{
	int i,j,k;
	vec_struct_byte *vsp;
	vec_struct_float *csp,*csp2;
	float *alloc_vector_float();
	char *butns[3];
	float *bp1;
extern vec_struct_byte *vec_root_byte;
extern int num_vecs;
extern int res_xy;


	if (vec_root_byte == NULL) {
	   notify_user("Must read data first");
	   return(-1);
	}

	printf("compute_mean_byte:  num_vecs,res = %d %d\n", num_vecs,res_xy);

	if (mean_ptr_float != NULL) 
	   free(mean_ptr_float);

	mean_ptr_float = NEW(float,sizeof(float)*res_xy);

	vec_zero_float(mean_ptr_float);

	TRACE(vsp,vec_root_byte)
	   vec_add_float_byte(mean_ptr_float,vsp->dp);	/* v1 = v1 + v2 */

	   /* Compute mean vector */
	vec_divide_float(mean_ptr_float,(float)num_vecs);

	return(1);


	/*--------------------------------------------*/
	feedback_msg("Computing (float) caricatures...");

	k=0;
	TRACE(csp,caric_root_float) {
	   free(csp->dp);
	   free(csp);
	   k++;
	}
	printf("  freed %d structs of carics\n", k);
	caric_root_float = NULL;


	TRACE(vsp,vec_root_byte) {

	   csp2 = NEW(vec_struct_float,sizeof(vec_struct_float));
	      
	   if (caric_root_float == NULL) {/* Begin new list of caric vectors */
		csp2->next = NULL;
		csp2->prev = NULL;
		csp = csp2;
		caric_root_float = csp;
	   }
	   else {
		csp2->next = NULL;
		csp2->prev = csp;
		csp->next = csp2;
		csp = csp2;
	   }

	   csp->dp = alloc_vector_float();  /* alloc space for caric vector */

	   vec_copy_byte_float(vsp->dp, csp->dp);   /* copy data vec into caric vec */
					
		/* Subtract the mean */
	   bp1 = csp->dp;
	   for (i=0; i<res_xy; i++) 
	      *(bp1+i) -= *(mean_ptr_float+i);

	}
}
/*--------------------------------------------------------------------*/
weather_test()
{
	int i,j,k;
	vec_struct_byte *vsp;
	vec_struct_float *csp,*csp2;
	char *alloc_vector_byte();
	float *alloc_vector_float();
	char *butns[3];
	float *bp1;
	FILE *fp;
	float vmin,vmax;
extern vec_struct_byte *vec_root_byte;
extern int num_vecs;
extern int res_xy;
extern float xmin,xmax,ymin,ymax,zmin,zmax;
extern win_struct mean_win;

        if((fp=fopen("nov.mean", "r")) == NULL)  {
		notify_user("ERROR - File not found");
		return(-1);
        }

	if (read_header(fp) < 0)
	   return(-1);

	mean_ptr_float = NEW(float,sizeof(float)*res_xy);

	if ( fread(mean_ptr_float,sizeof(float),res_xy,fp) != res_xy) {
		notify_user("ERROR reading file");
		free(mean_ptr_float);
		return(-1);
	}

	data_extrema();


	if (vec_root_byte == NULL) {
	   notify_user("Must read data first");
	   return(-1);
	}

	printf("compute_mean_byte:  num_vecs,res = %d %d\n", num_vecs,res_xy);


	/*--------------------------------------------*/

	k=0;
	TRACE(csp,caric_root_float) {
	   free(csp->dp);
	   free(csp);
	   k++;
	}
	printf("  freed %d structs of carics\n", k);
	caric_root_float = NULL;


	TRACE(vsp,vec_root_byte) {

	   csp2 = NEW(vec_struct_float,sizeof(vec_struct_float));
	      
	   if (caric_root_float == NULL) {/* Begin new list of caric vectors */
		csp2->next = NULL;
		csp2->prev = NULL;
		csp = csp2;
		caric_root_float = csp;
	   }
	   else {
		csp2->next = NULL;
		csp2->prev = csp;
		csp->next = csp2;
		csp = csp2;
	   }

	   csp->dp = alloc_vector_float();  
	   vec_copy_byte_float(vsp->dp, csp->dp);
					
		/* Subtract the mean */
	   bp1 = csp->dp;
	   for (i=0; i<res_xy; i++) 
	      *(bp1+i) -= *(mean_ptr_float+i);

	   break;
	}

/*	vmin = vmax = *bp1;
	for (i=1; i<res_xy; i++) {
	   if (*(bp1+i) < vmin) 
		vmin = *(bp1+i);
	   else if (*(bp1+i) > vmax) 
		vmax = *(bp1+i);
	}
	printf("(weather_test) vmin,vmax = %f %f\n", vmin,vmax);
	ymin = vmin;
	ymax = vmax; */

	  /* copy to mean */
	for (i=0; i<res_xy; i++) {
	   if (*(bp1+i) < 0.0)
	      *(mean_ptr_float+i) = 0.0;
	   else
	      *(mean_ptr_float+i) = *(bp1+i);
	}

	if (mean_win.id < 0) {
	   create_mean_win();
	   set_win_contour(&mean_win,0);
	}

	redraw_mean();
}
