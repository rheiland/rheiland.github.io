/* iris.c - handle Iris-dependent I/O
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include <gl.h>
#include <device.h>
#include "kl_str.h"

float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;

short	oldx,oldy, newx,newy;
int 	dx,dy,dz;
float  	cur_mtx[4][4],ident_mtx[4][4];
int	dialflg;
int	cur_win,transform_win;

int max_xpix,max_ypix;

/*--------------------------------------------------------------------*/
get_device_info()
{
	max_xpix = getgdesc(GD_XPMAX);
	max_ypix = getgdesc(GD_YPMAX);
	printf("max_xpix,max_ypix = %d %d\n", max_xpix,max_ypix);
}
/*--------------------------------------------------------------------*/
init_graphics()
{
extern win_struct data_win;
extern int popups_win;

    create_initial_windows();
/*    initnames(); */
    create_objects();
    create_popup_menus();
    init_events();
    qenter(REDRAW,(short)data_win.id);
    qenter(REDRAW,(short)popups_win);
}
/*--------------------------------------------------------------------*/
init_session()
{
    init_vars(); 
}

/*--------------------------------------------------------------------*/
/* Indicate what events will be queued during interaction */
init_events()
{    
    qdevice(LEFTMOUSE);
    qdevice(MIDDLEMOUSE);
         /* tie cursor pos to left button */
    tie(LEFTMOUSE,MOUSEX,MOUSEY);
    qdevice(RIGHTMOUSE);
    qdevice(REDRAW);
    qdevice(INPUTCHANGE);
    qdevice(ESCKEY);
    qdevice(KEYBD);
}

/*--------------------------------------------------------------------*/
init_vars()
{

    int i,j;
    static float winsize = 1.0;

    /* ortho args */
    ortho_x1 = ortho_y1 = -winsize;
    ortho_x2 = ortho_y2 =  winsize;

    ortho_z1 = -128.0;
    ortho_z2 =  128.0;


    /* rotate deltas */
    dx = dy = dz = 0;

    for (i=0; i<4; i++)   /* Init identity mtx (negated in z)*/
        for (j=0; j<4; j++) {
            if (i == j)
                ident_mtx[i][j] = 1.0;
            else
                ident_mtx[i][j] = 0.0;
        }

    for (i=0; i<4; i++)   /* Init cur_mtx to identity mtx */
        for (j=0; j<4; j++)
            cur_mtx[i][j] = ident_mtx[i][j];
}


/*--------------------------------------------------------------------*/
/* Interaction control */
interaction()
{
    int i,j,dev;
    short val;
    static int exiting = 0;
    short xval,yval;


double *cp[2];
int neq,kmax;
FILE *fplog,*fpin;
extern FILE *fpode, *fpode2;


    while(!exiting) {
    while(qtest()) {

        dev = qread(&val);
        dialflg = 0;

        switch(dev) {
        case INPUTCHANGE:
                /* user attaches/detaches input focus */
            cur_win = (int)val;
/*	    printf("INPUTCHANGE: cur_win = %d\n", cur_win); */
            break;
        case LEFTMOUSE:

	    dev = qread(&xval);   /* Get X,Y entries on the queue regardless */
	    dev = qread(&yval);   /* (since MOUSEX/Y 'tie'd to LEFT button)  */
/*	    printf("LEFTMOUSE: val= %d,  xval,yval = %d %d\n", val,xval,yval);
	    sleep(1);
	    while (getbutton(LEFTMOUSE)) printf("left down...\n"); */
            if (val)
	       process_leftbutn(cur_win,xval,yval);
            break;
        case MIDDLEMOUSE:

/*
neq=0;
kmax=1;
fplog=fopen("log.out","w");
fpin=fopen("ks.pde","r");
fpode = fopen("ode.sys","w");
fpode2 = fopen("ode2.sys","w");

parse_pde(cp,neq,kmax,fplog,fpin);
*/
            process_middlemouse(val);
            break;
        case RIGHTMOUSE:
            if (val)
	       process_rightbutn(cur_win);
            break;
        case KEYBD:
	    printf("KEYBD: val = %d\n", val);
	    keybd_handler(val);
	    break;
        case REDRAW:
                 /* window is moved or reshaped */
/*            reshapeviewport(); */
	    redraw_window(val);
            break;
        case ESCKEY:
            exiting_pgm();
            break;
        }
    }
    }
}
/*--------------------------------------------------------------------*/
wait_for_mouse_button()
{
    int dev,loop;
    short val;
    short xval,yval;


	loop = 1;
    while(loop) {
    while(qtest()) {
/*	dev = qread(&val); 
        switch(dev) { */
        switch(qread(&val)) {
        case LEFTMOUSE:
	    dev = qread(&xval);   /* Get X,Y entries on the queue regardless */
	    dev = qread(&yval);   /* (since MOUSEX/Y 'tie'd to LEFT button)  */
	    loop = 0;
            break;
        case MIDDLEMOUSE:
	    loop = 0;
            break;
        case RIGHTMOUSE:
	    loop = 0;
            break;
        }
    }
    }
}

/*--------------------------------------------------------------------*/
keybd_handler(val)
short val;
{
	int i,finished,dev,intval;
	char 	number[10],s[10];

extern int scan_data_win,scan_eigfn_win,scan_appx_win,scan_error_win;

	if (cur_win == scan_data_win) {

	number[i] = val;

	finished=0;
	while(!finished) {
	while(qtest()) {

          dev = qread(&val);

          switch(dev) {
          case KEYBD:
/*	    printf("(get_int)KEYBD: val = %d\n", val); */
	    if (val == 13) {	/* carriage return */
		finished = 1;
	    }
	    else if (val == 8) {	/* backspace */
		i--;
		if (i < 0) i=0;
		s[i] = '\0';
		cmov2(0.0,0.0);
		charstr(s);
		intval = atoi(s);
/*		printf("(get_int)intval = %d\n", intval); */

	    }
	  }	/* end switch */

	}
	}
	}
}
/*--------------------------------------------------------------------*/
exiting_pgm()
{
/*    free_memory(); */
    gexit();
    exit(0);
}
/*--------------------------------------------------------------------*/
clear_queue()
{
	short val;

	while(qtest())
	   qread(&val);
}
