/* control.c -
 *
 */

#include <stdio.h>
#include <gl.h>

control_handler()
{
	dummy_handler();
}
