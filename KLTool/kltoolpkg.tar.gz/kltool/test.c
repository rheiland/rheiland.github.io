
#include <stdio.h>

float *list;

main(argc,argv)
int argc;
char *argv[];
{
	char value[80],dtype;

	scanf("%s",value);
	printf("value = %s\n", value);
	dtype = value[0];

	printf("  data type= %c\n", dtype);
}
