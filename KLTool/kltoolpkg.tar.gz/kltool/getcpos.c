/* dummy GL routine needed at ACL/panda */
void getcpos(ix,iy)
short *ix,*iy;
{
}
