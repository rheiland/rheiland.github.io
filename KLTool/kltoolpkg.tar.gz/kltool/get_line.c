
    if (get_line(buf, 132) == 0)
        return(old_value);
    else {
        sscanf(buf,"%lf", &new_value);
        return(new_value);
    }
}

/*******************************************************************************/
get_line(s,lim)
char 	s[];
int	lim;
{
    int	c, i;

    for (i=0; i<=lim-1 && (c=getchar())!=EOF && c!='\n'; ++i)
	s[i]=c;
    s[i]='\0';
    return(i);
}
