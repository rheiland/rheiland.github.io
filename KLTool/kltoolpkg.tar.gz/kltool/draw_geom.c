/* draw_geom.c - draw geometry in windows
 *
 *
 *     Copyright (c) 1992 by 
 *     Dieter Armbruster, Randy Heiland, Eric Kostelich
 *     All Rights Reserved.
 *     This software may be copied provided there is no intent
 *     to sale for profit.
 *
 */

#include <stdio.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/get.h>
#include <fmclient.h>
#include "kl_str.h"
#include "disp_types.h"

#define X  0
#define Y  1
#define Z  2


  /* Current vector # for SCANning */
extern int cur_vector;
extern int cur_eigfn;
extern int cur_appx;
extern int cur_error;
extern int cur_datacoef;
extern int cur_appxcoef;

extern int	data_color;
extern int	scan_win_color;
extern int	eigvals_bar_color;
extern int	geom_win_color;
extern int	mean_geom_color;
extern int	coef_geom_color;
extern int	eigfn_geom_color;
extern int	menu_bar_color;
extern int	menu_bar_text_color;



/*--------------------------------------------------------------------*/
draw_data_geom()
{
       float yscale,cur_vector_scale();

extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern int	dialflg,dx,dy,dz;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern float     rot_mtx[4][4];
extern int	dimension;
extern vec_struct *vec_root;
extern int 	ortho_view;
extern int 	polar_flag;

    int i;
    float M[4][4];

    if (vec_root == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    zbuffer(TRUE);
    zclear();

    pushmatrix();           /* push viewing, projection matrix */
    loadmatrix(ident_mtx);

    if (dialflg) {
       /* The intuitive way of rotating w/ the mouse is to cause
          movement up/down (dy) to rotate about x; left/right (dx) about y */
        rotate(dy,'x');     
        rotate(-dx,'y');
		  ortho_view = 0;
/*        getmatrix(rot_mtx); */
    }

    multmatrix(cur_mtx);     /* premultiplies: i.e., [cur_mtx][rotmat]  */
    getmatrix(cur_mtx);

/*    if ((data_win.display_type == SCAN) && scale_cur_vector) {
       yscale = cur_vector_scale();
       scale(data_win.xscale,yscale,data_win.zscale);
    }
    else */
       scale(data_win.xscale,data_win.yscale,data_win.zscale);

    if (!polar_flag)
       translate(-data_win.xmid,-data_win.ymid,-data_win.zmid);
    getmatrix(M);

    popmatrix();          /* pop viewing, projection matrix */
    multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

    if (data_win.display_type == SHADED) {
	contour_mesh(vec_root,cur_vector);
    }
    else if (data_win.display_type == LANDSCAPE) {
	draw_data(vec_root);
/*	translate(data_win.xmid,data_win.ymid,data_win.zmid);
	scale(0.2/data_win.xscale,0.2/data_win.yscale,0.2/data_win.zscale);
	translate(0.0,-1.0,0.0);
	draw_axes(); */
    }
    else {			/* SCAN mode */
	draw_cur_vector(vec_root,cur_vector,data_color);
        if (dimension > 1) {
	   translate(data_win.xmid,data_win.ymid,data_win.zmid);
	   scale(0.2/data_win.xscale,0.2/data_win.yscale,0.2/data_win.zscale);
	   draw_axes();
	}
    }

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_data_vec2d_geom()
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern vec_struct *vec_root;

    if (vec_root == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);
    translate(-data_win.xmid,-data_win.ymid,0.0);
    draw_cur_vectorfld(vec_root,cur_vector,data_color);

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_uchar_data()
{
       float yscale,cur_vector_scale();

extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern int	dialflg,dx,dy,dz;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern float     rot_mtx[4][4];
extern int	dimension;
extern vec_struct_uchar *vec_root_uchar;
extern int 	ortho_view;

    int i;
    float M[4][4];

    if (vec_root_uchar == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);


    zbuffer(TRUE);
    zclear();


    pushmatrix();           /* push viewing, projection matrix */
    loadmatrix(ident_mtx);

    multmatrix(cur_mtx);     /* premultiplies: i.e., [cur_mtx][rotmat]  */
    getmatrix(cur_mtx);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);

    translate(-data_win.xmid,-data_win.ymid,-data_win.zmid);
    getmatrix(M);

    popmatrix();          /* pop viewing, projection matrix */
    multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

	contour_uchar(vec_root_uchar,cur_vector);

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_mean_geom()
{
	int i,j,n;
	float M[4][4];
	float dtheta,theta;
	double *vp, v[3],r;
extern float	ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct	mean_win;
extern win_struct data_win;
extern int	dialflg,dx,dy,dz;
extern float	cur_mtx[4][4], ident_mtx[4][4];
extern int	dimension,res_x,res_y;
extern double	*mean_ptr;
extern int 	polar_flag,ncontours;
extern float polar_rmin,polar_range;
extern float ymin,ydiff;


	if (mean_ptr == NULL) {
	   printf("draw_mean_geom: NULL mean_ptr\n");
	   return(-1);
	}

	pushmatrix();

	/*				      near,far */
	ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
	lookat(0.,0.,25.,0.,0.,0., 0);

	zbuffer(TRUE);
	zclear();

	pushmatrix();           /* push viewing, projection matrix */
	loadmatrix(ident_mtx);

	if (dimension == 2) {
	   if (dialflg) {
		rotate(dy,'x');     
		rotate(-dx,'y');
	   }

	   multmatrix(cur_mtx);     /* premultiplies:  [cur_mtx][rotmat]  */
	   getmatrix(cur_mtx);
	}

	scale(data_win.xscale,data_win.yscale,data_win.zscale);

	if (!polar_flag)
	   translate(-data_win.xmid,-data_win.ymid,-data_win.zmid);

	getmatrix(M);

	popmatrix();          /* pop viewing, projection matrix */
	multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

	if ((dimension == 2) && (mean_win.display_type == SHADED)) {
		contour_2d_mean();
	}
	else {
		vp = mean_ptr;
		color(mean_geom_color);

		if (dimension == 2) {
		  cur_vector_2d(vp,mean_geom_color);
		}
		else {		/* dimension = 1 */
		  if (polar_flag) {
		    bgnline();
		    v[Z] = 0.0;
		    dtheta = 2*M_PI/res_x;
		    for (i=0; i<res_x; i++) {
			theta = i*dtheta;
	    		r = (*vp-ymin)*polar_range/ydiff + polar_rmin;
	    		v[X] = r *cos(theta);
	    		v[Y] = r *sin(theta);
	    		v3d(v);
	    		vp++;
		    }
		    endline();
		  }
		  else if (ncontours) {		/* contours */
		    v[Z] = 0.0;
	  	    for (n=0; n<ncontours; n++) {
	              bgnline();
	              for (i=0; i<res_x; i++) {
	                v[X] = *vp;
	                vp++;
	                v[Y] = *vp;
	                vp++;
	                v3d(v);
	              }
	              endline();
	            }
		  }
		  else {			/* rectangular coords */
		    for (j=0; j>(-res_y); j--) {
		      bgnline();
		      v[Z] = j;
		      for (i=0; i<res_x; i++) {
	    		v[X] = i;
	    		v[Y] = *vp;
	    		v3d(v);
	    		vp++;
		      }
		      endline();
		    }
		  }
	        }
	}
	popmatrix();
}
/*--------------------------------------------------------------------*/
draw_mean_vec2d_geom()
{
    double *dp,v[3],uval,vval;
    int i,j;
extern double	*mean_ptr;
extern int res_x,res_y;
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern float vec_scale;


    if (mean_ptr == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);
    translate(-data_win.xmid,-data_win.ymid,0.0);

    dp = mean_ptr;
    color(mean_geom_color);

    v[Z] = 0.0;

	for (j=0; j<res_y; j++) {
	for (i=0; i<res_x; i++) {
	   bgnline();
	   v[X] = (float)i;
	   v[Y] = (float)j;
	   v3d(v);

	   uval = *dp*vec_scale;
	   v[X] += uval;
	   dp++;
	   vval = *dp*vec_scale;
	   v[Y] += vval;
	   dp++;
	   v3d(v);


	   /* plus a little barb:  (u,v) perp to (-v,u) */
	   v[X] = (float)i + uval*0.75 - vval*0.10;
	   v[Y] = (float)j + vval*0.75 + uval*0.10;
	   v3d(v);
	   endline();
	}
	}

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_mean_geom_float()
{
	int i,j;
	float M[4][4];
	double *vp, v[3];
extern float	ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct	mean_win,data_win;
extern int	dialflg,dx,dy,dz;
extern float	cur_mtx[4][4], ident_mtx[4][4];
extern int	dimension,res_x,res_y;
extern float	*mean_ptr_float;


	if (mean_ptr_float == NULL) {
	   printf("draw_mean_geom: NULL mean_ptr_float\n");
	   return(-1);
	}

	pushmatrix();

	/*				      near,far */
	ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
	lookat(0.,0.,25.,0.,0.,0., 0);

	zbuffer(TRUE);
	zclear();

	pushmatrix();           /* push viewing, projection matrix */
	loadmatrix(ident_mtx);

	if (dimension == 2) {
	   multmatrix(cur_mtx);     /* premultiplies:  [cur_mtx][rotmat]  */
	   getmatrix(cur_mtx);
	}

	scale(data_win.xscale,data_win.yscale,data_win.zscale);
	translate(-data_win.xmid,-data_win.ymid,-data_win.zmid);

	getmatrix(M);

	popmatrix();          /* pop viewing, projection matrix */
	multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

	contour_2d_mean_float();

	popmatrix();
}

/*--------------------------------------------------------------------*/
draw_eigfn_geom(eigfn_num)
int eigfn_num;
{
	int res,i,j;
	float M[4][4];
	vec_struct *usp;
	double v[3], *vp, zval, vmin,vmax;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern int	dialflg,dx,dy,dz;
extern int	interp_eigfn_flag;
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct	eigfn_win, data_win;
extern int	dimension,res_x,res_y,res_xy;
extern vec_struct *u_root;
extern int 	polar_flag;

/*	printf("----------------- begin draw_eigfn_geom (%d)-----------\n",eigfn_num); */

	if (u_root == NULL) return(-1);


    pushmatrix();

	/*				      near,far */
/*	printf("draw_eigfn_geom: ortho:x1,x2= %f %f   y1,y2= %f %f\n",
			ortho_x1,ortho_x2,ortho_y1,ortho_y2); */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    zbuffer(TRUE);
    zclear();

    pushmatrix();           /* push viewing, projection matrix */
    loadmatrix(ident_mtx);

    if (dimension == 2) {

       if (dialflg) {
          rotate(dy,'x');     
          rotate(-dx,'y');
       }

       multmatrix(cur_mtx);     /* premultiplies: i.e., [cur_mtx][rotmat]  */
       getmatrix(cur_mtx);

    }

    scale(eigfn_win.xscale,eigfn_win.yscale,eigfn_win.zscale);

    if (!polar_flag)
       translate(-eigfn_win.xmid,-eigfn_win.ymid,-eigfn_win.zmid);

    getmatrix(M);

    popmatrix();          /* pop viewing, projection matrix */
    multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

    if ((dimension == 2) && (eigfn_win.display_type == SHADED)) {
	i = 0;
	contour_2d_eigfn(u_root,eigfn_num);
    }
    else {
        if (!polar_flag)
	   draw_cur_vector(u_root,cur_eigfn,eigfn_geom_color);
	else
	   draw_polar_eigfn(u_root,cur_eigfn,eigfn_geom_color);

	if (interp_eigfn_flag)
	   draw_eigfn_interp(eigfn_num);

	if (dimension > 1) {
	  translate(eigfn_win.xmid,eigfn_win.ymid,eigfn_win.zmid);
	  scale(0.2/eigfn_win.xscale,0.2/eigfn_win.yscale,0.2/eigfn_win.zscale);
	  draw_axes();
	}
    }

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_eigfn_vec2d_geom(eigfn_num)
int eigfn_num;
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern vec_struct *u_root;

    if (u_root == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);
    translate(-data_win.xmid,-data_win.ymid,0.0);
    draw_cur_vectorfld(u_root,cur_eigfn,eigfn_geom_color);

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_eigfn_geom_float()
{
	int res,i,j;
	float M[4][4];
	vec_struct *usp;
	double v[3], *vp, zval, vmin,vmax;
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern win_struct	eigfn_win, data_win;
extern int	dimension,res_x,res_y,res_xy;


    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    zbuffer(TRUE);
    zclear();

    pushmatrix();           /* push viewing, projection matrix */
    loadmatrix(ident_mtx);

    if (dimension == 2) {
       multmatrix(cur_mtx);     /* premultiplies: i.e., [cur_mtx][rotmat]  */
       getmatrix(cur_mtx);
    }

    scale(eigfn_win.xscale,eigfn_win.yscale,eigfn_win.zscale);
    translate(-eigfn_win.xmid,-eigfn_win.ymid,-eigfn_win.zmid);

    getmatrix(M);

    popmatrix();          /* pop viewing, projection matrix */
    multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

/*    contour_2d_eigfn_float(); */

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_appx_geom()
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win,appx_win;
extern int	dx,dy,dz;
extern int       dialflg;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern vec_struct *appx_root;
extern int 	polar_flag;
extern int	dimension;

    int i;
    float M[4][4];

	if (appx_root == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

/*    lookat(0.,0.,1., 0.,0.,0., 0); */

    zbuffer(TRUE);
    zclear();


    pushmatrix();           /* push viewing, projection matrix */
    loadmatrix(ident_mtx);


    if (dialflg) {
        rotate(dy,'x');     
        rotate(-dx,'y');
    }

    multmatrix(cur_mtx);     /* premultiplies: i.e., [cur_mtx][rotmat]  */
    getmatrix(cur_mtx);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);

    if (!polar_flag)
       translate(-data_win.xmid,-data_win.ymid,-data_win.zmid);

    getmatrix(M);

    popmatrix();          /* pop viewing, projection matrix */
    multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

    if (appx_win.display_type == SCAN) {
	draw_cur_vector(appx_root,cur_appx,data_color);

        if (dimension > 1) {
	   translate(data_win.xmid,data_win.ymid,data_win.zmid);
	   scale(0.2/data_win.xscale,0.2/data_win.yscale,0.2/data_win.zscale);
	   draw_axes();
	}
    }
    else if (appx_win.display_type == LANDSCAPE) {
	draw_data(appx_root);
    }
    else {	/* contour */
	contour_mesh(appx_root,cur_appx);
    }

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_appx_vec2d_geom()
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern vec_struct *appx_root;

/*    printf("--------------  draw_appx_vec2d_geom() ------------\n"); */
    if (appx_root == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);
    translate(-data_win.xmid,-data_win.ymid,0.0);
    draw_cur_vectorfld(appx_root,cur_appx,data_color);

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_error_geom()
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win,appx_win,error_win;
extern int	dx,dy,dz;
extern int       dialflg;
extern float     cur_mtx[4][4], ident_mtx[4][4];
extern vec_struct *error_root;
extern int 	polar_flag;
extern int 	dimension;

    int i;
    float M[4][4];

/*	if (error_root == NULL) return(-1); */

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

/*    lookat(0.,0.,1., 0.,0.,0., 0); */

    zbuffer(TRUE);
    zclear();


    pushmatrix();           /* push viewing, projection matrix */
    loadmatrix(ident_mtx);

/*    if (dialflg < 0)
        rotate(dy,'x');     
    else if (dialflg == 0)
        rotate(dx,'y');
    else if (dialflg == 1)
        rotate(dz,'z');
    else if (dialflg == 2) */

    if (dialflg) {
       /* The intuitive way of rotating w/ the mouse is to cause
          movement up/down (dy) to rotate about x; left/right (dx) about y */
        rotate(dy,'x');     
        rotate(-dx,'y');
    }

    multmatrix(cur_mtx);     /* premultiplies: i.e., [cur_mtx][rotmat]  */
    getmatrix(cur_mtx);

    if (appx_win.display_type == SCAN) {
       scale(data_win.xscale,data_win.yscale,data_win.zscale);
    }
    else
       scale(data_win.xscale,data_win.yscale,data_win.zscale);

/*    translate(-data_win.xmid,-data_win.ymid,-data_win.zmid); */
    if (!polar_flag)
       translate(-data_win.xmid,0.0,-data_win.zmid);

    getmatrix(M);

    popmatrix();          /* pop viewing, projection matrix */
    multmatrix(M);        /* premultiplies: i.e., [M][VP]   */

    if (error_win.display_type == LANDSCAPE) {
	draw_data(error_root);
    }
    else if (error_win.display_type == SCAN) {
	draw_cur_vector(error_root,cur_error,data_color);

        if (dimension > 1) {
	   translate(data_win.xmid,data_win.ymid,data_win.zmid);
	   scale(0.2/data_win.xscale,0.2/data_win.yscale,0.2/data_win.zscale);
	   draw_axes();
	}
    }
    else {
	contour_error_mesh(error_root,cur_error);
    }

    popmatrix();
}
/*--------------------------------------------------------------------*/
draw_error_vec2d_geom()
{
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2;
extern win_struct data_win;
extern vec_struct *error_root;

    if (error_root == NULL) return(-1);

    pushmatrix();

	/*				      near,far */
    ortho(ortho_x1,ortho_x2,ortho_y1,ortho_y2,ortho_z1,ortho_z2);
    lookat(0.,0.,25.,0.,0.,0., 0);

    scale(data_win.xscale,data_win.yscale,data_win.zscale);
    translate(-data_win.xmid,-data_win.ymid,0.0);
    draw_cur_vectorfld(error_root,cur_error,data_color);

    popmatrix();
}
/*--------------------------------------------------------------------*/
/* Should be pulled up higher in the loop !! (eg, dynamic rotation) */
float cur_vector_scale()
{
	int i,res;
	vec_struct *vsp;
	double *dp,vmin,vmax;
	float scale_val;
extern vec_struct *vec_root;
extern int res_xy;


/*	res = vec_resolution(); */

	i = 0;
	TRACE(vsp,vec_root) {
	   i++;
	   if (i==cur_vector) break;
	}
	dp = vsp->dp;

/*	minmax_d(dp,res_xy,&vmin,&vmax); */
/*	printf("  cur_vector_scale:  min,max = %f %f\n", vmin,vmax); */

	scale_val = 1.6 / (vmax-vmin);
	return(scale_val);
}
/*--------------------------------------------------------------------*/
draw_datacoef_geom()
{
	int i;
	double vmin,vmax;
	double *vp, v[2];
	float xscale,yscale;
	vec_struct *csp;
extern vec_struct *datacoef_root;
extern win_struct datacoef_win;
extern int cur_datacoef;
extern int num_vecs;
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2;


/*	printf("(draw_coef_geom)  neig= %d, num_vecs=%d\n", neig,num_vecs); */

	if (datacoef_root == NULL) {
	   printf("draw_datacoef_geom:  NULL list\n");
	   return(-1);
	}

	i = 0;
	TRACE(csp,datacoef_root) {
	   i++;
	   if (i==cur_datacoef) break;
	}
	vp = csp->dp;
/*	printf("draw_datacoef_geom: vp = %d\n", vp); */

	if (vp == NULL) {
	   printf("draw_datacoef_geom:  NULL data\n");
	   return(-1);
	}

	minmax_d(vp,num_vecs,&vmin,&vmax);
/*	printf("draw_datacoef_geom: vmin,vmax = %f %f\n", vmin,vmax); */

	datacoef_win.xmid = (float)num_vecs/2.0;
	datacoef_win.ymid = vmin + (vmax-vmin) / 2.0;
	datacoef_win.zmid = 0.0;
	datacoef_win.xscale = 1.8 / (float)num_vecs;
	datacoef_win.yscale = 1.8 / (vmax-vmin);
	datacoef_win.zscale = 1.0;

	winset(datacoef_win.id);
	color(geom_win_color);
	clear();

	pushmatrix();
	ortho2(ortho_x1,ortho_x2,ortho_y1,ortho_y2);

	scale(datacoef_win.xscale,datacoef_win.yscale,datacoef_win.zscale);
	translate(-datacoef_win.xmid,-datacoef_win.ymid,-datacoef_win.zmid);

	color(coef_geom_color);

	bgnline();
	for (i=0; i<num_vecs; i++) {
	 	v[X] = i;
	    	v[Y] = *(vp+i);
	    	v2d(v);
	}
	endline();
	popmatrix();
}
/*--------------------------------------------------------------------*/
draw_appxcoef_geom()
{
	int i;
	double vmin,vmax;
	double *vp, v[2];
	float xscale,yscale;
	vec_struct *csp;
extern vec_struct *appxcoef_root;
extern win_struct appxcoef_win;
extern int cur_appxcoef;
extern int num_vecs;
extern float     ortho_x1,ortho_x2,ortho_y1,ortho_y2;


	if (appxcoef_root == NULL) {
	   printf("draw_appxcoef_geom:  NULL list\n");
	   return(-1);
	}

	i = 0;
	TRACE(csp,appxcoef_root) {
	   i++;
	   if (i==cur_appxcoef) break;
	}
	vp = csp->dp;
/*	printf("draw_appxcoef_geom: vp = %d\n", vp); */

	if (vp == NULL) {
	   printf("draw_appxcoef_geom:  NULL data\n");
	   return(-1);
	}

	minmax_d(vp,num_vecs,&vmin,&vmax);
/*	printf("draw_appxcoef_geom: vmin,vmax = %f %f\n", vmin,vmax); */

	appxcoef_win.xmid = (float)num_vecs/2.0;
	appxcoef_win.ymid = vmin + (vmax-vmin) / 2.0;
	appxcoef_win.zmid = 0.0;
	appxcoef_win.xscale = 1.8 / (float)num_vecs;
	appxcoef_win.yscale = 1.8 / (vmax-vmin);
	appxcoef_win.zscale = 1.0;

	winset(appxcoef_win.id);
	color(geom_win_color);
	clear();

	pushmatrix();
	ortho2(ortho_x1,ortho_x2,ortho_y1,ortho_y2);

	scale(appxcoef_win.xscale,appxcoef_win.yscale,appxcoef_win.zscale);
	translate(-appxcoef_win.xmid,-appxcoef_win.ymid,-appxcoef_win.zmid);

	color(coef_geom_color);

	bgnline();
	for (i=0; i<num_vecs; i++) {
	 	v[X] = i;
	    	v[Y] = *(vp+i);
	    	v2d(v);
	}
	endline();
	popmatrix();
}

/*--------------------------------------------------------------------*/
draw_data(vec_root)
vec_struct *vec_root;
{
	int i,count;
	vec_struct *vsp;
	double *dp, v[3];
extern int res_x;

/*	printf("---------- draw_data called\n"); */
	count=0;
	color(data_color);
	TRACE(vsp,vec_root) {
/*	   printf("draw_data: count = %d\n", count); */
	   dp = vsp->dp;
	   bgnline();
	   v[Z] = count;
	   for (i=0; i<res_x; i++) {
		v[X] = i;
		v[Y] = *dp;
		v3d(v);
		dp++;
	   }
	   endline();
	   count--;
	}
}
/*--------------------------------------------------------------------*/
draw_cur_vector(vec_root,vec_num,colorval)
vec_struct *vec_root;
int vec_num;
int colorval;
{
	int count;
	vec_struct *vsp;
	double *dp;
extern int dimension;

	count=0;
	TRACE(vsp,vec_root) {
	   count++;
/*	   if (count == cur_vector) break; */
	   if (count == vec_num) break;
	}
	dp = vsp->dp;

	if (dimension == 1)
	   cur_vector_1d(dp,colorval);
	else
	   cur_vector_2d(dp,colorval);
}
/*--------------------------------------------------------------------*/
draw_cur_vectorfld(vec_root,vec_num,colorval)
vec_struct *vec_root;
int vec_num;
int colorval;
{
	int count,i,j;
	vec_struct *vsp;
	double *dp,v[3], uval,vval;
extern int dimension;
extern int res_x,res_y;
extern float vec_scale;

/*	printf("--------------- draw_cur_vectorfld -------------\n");
	printf("     vec_scale = %f\n",vec_scale); */

	count=0;
	TRACE(vsp,vec_root) {
	   count++;
	   if (count == vec_num) break;
	}
	dp = vsp->dp;

	color(colorval);
	v[Z] = 0.0;

	for (j=0; j<res_y; j++) {
	for (i=0; i<res_x; i++) {
	   bgnline();
	   /* Draw the vector (tail->head) */
	   v[X] = (float)i;
	   v[Y] = (float)j;
	   v3d(v);

	   uval = *dp*vec_scale;
	   v[X] += uval;
	   dp++;
	   vval = *dp*vec_scale;
	   v[Y] += vval;
	   dp++;
	   v3d(v);

	   /* plus a little barb:  (u,v) perp to (-v,u) */
	   v[X] = (float)i + uval*0.75 - vval*0.10;
	   v[Y] = (float)j + vval*0.75 + uval*0.10;
	   v3d(v);

	   endline();
	}
	}
}
/*--------------------------------------------------------------------*/
cur_vector_1d(dp,colorval)
double *dp;
int colorval;
{
	int i,n;
	double v[3],r;
	float dtheta,theta;
extern int res_x,polar_flag,ncontours;
extern float polar_rmin,polar_range;
extern float ymin,ydiff;

	color(colorval);
	v[Z] = 0.0;

	if (polar_flag) {
	  bgnline();
	  dtheta = 2*M_PI / res_x;
	  for (i=0; i<res_x; i++) {
	    theta = i*dtheta;
	    r = (*dp-ymin)*polar_range/ydiff + polar_rmin;
	    v[X] = r *cos(theta);
	    v[Y] = r *sin(theta);
	    v3d(v);
	    dp++;
	  }
	  endline();
	}
	else if (ncontours) {		/* disconnected Contours */
	  for (n=0; n<ncontours; n++) {
	  bgnline();
	  for (i=0; i<res_x; i++) {
	    v[X] = *dp;
	    dp++;
	    v[Y] = *dp;
	    dp++;
	    v3d(v);
	  }
	  endline();
	  }
	}
	else {		/* Rectangular */
	  bgnline();
	  for (i=0; i<res_x; i++) {
	    v[X] = i;
	    v[Y] = *dp;
	    v3d(v);
	    dp++;
	  }
	  endline();
	}
}
/*--------------------------------------------------------------------*/
cur_vector_2d(dp,colorval)
double *dp;
int colorval;
{
	int i,j;
	double *p, v[3];
extern int res_x,res_y;

	p = dp;

	color(colorval);
	for (j=0; j>(-res_y); j--) {
	bgnline();
	v[Z] = j;
	for (i=0; i<res_x; i++) {
	    v[X] = i;
	    v[Y] = *dp;
	    v3d(v);
	    dp++;
	}
	endline();
	}

	for (i=0; i<res_x; i++) {
	bgnline();
	v[X] = i;
	for (j=0; j<res_y; j++) {
	    v[Z] = -j;
	    v[Y] = *(p+j*res_x);
	    v3d(v);
	}
	p++;
	endline();
	}
}
/*--------------------------------------------------------------------*/
/* Assume a 1-D polar function: r(theta)   
   Since eigfn can possibly have r < 0, map r into [rmin>0,rmax] before 
   displaying */
draw_polar_eigfn(vec_root,vec_num,colorval)
vec_struct *vec_root;
int vec_num;
int colorval;
{
	int i;
	vec_struct *vsp;
	double *dp;
	double vmin,vmax,vrange,r,v[3];
	float dtheta,theta;
extern int res_xy;
extern int dimension;
extern float polar_rmin,polar_range;

	i=0;
	TRACE(vsp,vec_root) {
	   i++;
	   if (i == vec_num) break;
	}
	dp = vsp->dp;

	minmax_d(dp,res_xy,&vmin,&vmax);
	vrange = vmax - vmin;

	color(colorval);
	bgnline();
	v[Z] = 0.0;

	dtheta = 2*M_PI / res_xy;
	for (i=0; i<res_xy; i++) {
	    r = (*dp - vmin)*polar_range / vrange + polar_rmin;
	    theta = i*dtheta;
	    v[X] = r *cos(theta);
	    v[Y] = r *sin(theta);
	    v3d(v);
	    dp++;
	}
	endline();
}
/*--------------------------------------------------------------------*/
draw_eigfn_interp(eigfn_num)
int eigfn_num;
{
	int count,i;
	vec_struct *vsp;
	double *dp;
	double v[3];
extern int dimension;
extern vec_struct *u_root;
extern int res_x,res_y;

	if (!eigfns_exist()) return(-1);
	count=0;
	TRACE(vsp,u_root) {
	   count++;
	   if (count == eigfn_num) break;
	}
	dp = vsp->dp;

/*	if (dimension == 1)
	   cur_vector_1d(dp,colorval);
	else
	   cur_vector_2d(dp,colorval); */

	color(YELLOW);
	bgnline();
	v[Z] = 0.0;
	for (i=0; i<res_x; i++) {
	  if(!(i%10)) {
	    v[X] = i;
	    v[Y] = *dp;
	    v3d(v);
	  }
	    dp++;
	}
	endline();
}
/*--------------------------------------------------------------------*/
draw_axes()
{
    int i,count;
    static float v[5][3]={9*0.0};

	v[0][X] = 1.0;
	v[2][Y] = 1.0;
	v[4][Z] = -1.0;
	color(WHITE);
	bgnline();
	    v3f(v[0]);
	    v3f(v[1]);
	    v3f(v[2]);
	    v3f(v[3]);
	    v3f(v[4]);
	endline();
	cmov(v[0][X],0.0,0.0);
	charstr("x");
	cmov(0.0,v[2][Y],0.0);
	charstr("f");
	cmov(0.0,0.0,v[4][Z]);
	charstr("y");
}
