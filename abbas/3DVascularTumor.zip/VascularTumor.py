
import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])

#

import CompuCellSetup
CompuCellSetup.setSimulationXMLFileName("VascularTumor.xml")
sim,simthread = CompuCellSetup.getCoreSimulationObjects()
CompuCellSetup.initializeSimulationObjects(sim,simthread)
import CompuCell

#Create extra player fields here or add attributes

#pyAttributeAdder,listAdder=CompuCellSetup.attachListToCells(sim)

#
##################
##########	PLUGINS
##################
#


#
##################
##########	STEPPABLES
##################
#


from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()


from steppableBasedMitosisSteppables import MitosisSteppable
mitosisSteppable=MitosisSteppable(sim,1)
steppableRegistry.registerSteppable(mitosisSteppable)

from VascularTumorSteppables import VolumeParamSteppable
                                         #sim,frequency,areaThresh,nutrientThresh,necroticThresh
volumeParamSteppable=VolumeParamSteppable(sim,1)
steppableRegistry.registerSteppable(volumeParamSteppable)




#
##################
##########	COMPUCELL3D LOOPS
##################
#

CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)

