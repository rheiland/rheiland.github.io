function TEprof = ExtTE_hash(timedata, duration, neurondata, nNeu, k, l)
% TEprof = ExtTE_hash(trains)
%
%    trains - (data_n, duration), (sparse logical) data trains expressed in a proper way.
%             1st train -> i+d
%             second to (k+1)th -> i^(k)
%             third to (l+1)th -> j^(l)
%             and measures causality from J to I
%
% Returns:
%
%
% Description :
%
%
% Example :
%    
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 6/8/2009

%order = size(trains, 1);
order = nNeu;

if (order ~= k + l + 1)
	error('dimension doesn''t match')
elseif (length(timedata) ~= length(neurondata))
	error('timedata and neurondata are inconsistent')
end


%if (issorted(timedata))
%	sorted_time = timedata;
%	sorted_neu = neurondata;
%else
%	[sorted_time, sort_index] = sort(timedata);
%	sorted_neu = neurondata(sort_index);
%end


counters = hashcounter(timedata, duration, neurondata, nNeu);


TEprof = zeros(1, 2^order);
for i = 0:(2^order-1)
	% calc of prob1
	prob1 = counters(i+1) / duration;
	if prob1 == 0
		continue;
	end

	% calc of prob2
	prob2 = counters(i+1) / (counters(bitset(i,1)+1) + counters(bitset(i,1)));

	% calc of prob3
	inds = bitshift(0:(2^l-1), k+1) + bitand(i, (2^(k+1) - 1));
	%indices for summation. Summing up all "j" related terms.

	if bitget(inds(1), 1) == 0 % even
		prob3 = sum(counters(inds+1)) / (sum(counters(inds+1)) + sum(counters(inds+2)));
	else
		prob3 = sum(counters(inds+1)) / (sum(counters(inds)) + sum(counters(inds+1)));
	end

	TEprof(i+1) = prob1 * log2(prob2 / prob3);
	%TEprof(isnan(TEprof)) = 0;

end
