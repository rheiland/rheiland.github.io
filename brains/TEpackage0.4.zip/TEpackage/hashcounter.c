#include "mex.h"
/* #include <stdio.h> */
/* #include <stdlib.h> */


void hashcounter(double *timedata, int duration, double *neurondata, int n_neu, int n_firings, double *counters);

struct list {
	double key;
	int data;
	struct list *next;
} *listptr;


void mexFunction(
		int nlhs,
		mxArray *plhs[],
		int nrhs,
		const mxArray *prhs[]
		)
{
	/* Declare variable */
	double *timedata, *neurondata;
	double *tmp;
	double *counters;
	int n_neu, duration, n_firings;

	/* Check for proper number of input and output arguments */
	if (nlhs > 1) {
		printf("%d nlhs\n");
		mexErrMsgTxt("Too many output arguments.");
	}

	timedata = mxGetPr(prhs[0]);

	tmp = mxGetPr(prhs[1]);
	duration = (int) tmp[0];

	neurondata = mxGetPr(prhs[2]);

	tmp = mxGetPr(prhs[3]);
	n_neu = (int) tmp[0];

	/* printf("n_neu = %d\n", n_neu); */



	n_firings = mxGetM(prhs[0]);

	plhs[0] = mxCreateDoubleMatrix(1 << n_neu, 1, mxREAL);
	counters = mxGetPr(plhs[0]);


	/* function call */
	hashcounter(timedata, duration, neurondata, n_neu, n_firings, counters);
}

void hashcounter(double *timedata, int duration,  double *neurondata, int n_neu, int n_firings, double *counters) {
	/* main body (hash) */
	int *neurondata_int, *listlength;
	/*int neurondata_int[n_firings];*/
	int i, j, hash, listsize, broken;
	struct list *hlist, *listbuff, *lb, *cur_elem, *newelem;
	int n_timing = 0;

	listsize = n_firings;

	if ((neurondata_int = (int*) malloc(sizeof(int) * n_firings)) == NULL)
		printf("memory allocation error.\n");
	for (i=0;i<n_firings;i++)
		neurondata_int[i] = neurondata[i] - 1;

	if ((hlist = (struct list*) malloc(sizeof(struct list) * listsize)) == NULL)
		printf("memory allocation error.\n");
	if ((listlength = (int*) malloc(sizeof(int) * listsize)) == NULL)
		printf("memory allocation error.\n");



	/* initialization of listlength */

	for (i=0; i<listsize; i++)
		listlength[i] = 0;


	/* keep memory for increasing the length of list */


	if ((listbuff = (struct list*) malloc(sizeof(struct list) * n_firings)) == NULL)
		printf("memory allocation error.\n");

	lb = listbuff;

	/* iteration start */

	for (i=0; i<n_firings; i++) {
		hash = ((int) timedata[i]) % listsize;

		/* printf(" hash is %d\n", hash); */

		if (hash >= listsize){
			printf("hash is wrong\n");
			exit(1);
		}



		if (listlength[hash] == 0) {
			(hlist[hash]).key = timedata[i];
			(hlist[hash]).data = 1 << neurondata_int[i];
			/* printf("neurondata %d\n", neurondata_int[i]); */
			(hlist[hash]).next = NULL;
			listlength[hash]++;
		} else {
			cur_elem = &(hlist[hash]);
			broken = 0;
			for (j=0; j<listlength[hash]; j++) {
				if (timedata[i] == cur_elem->key) {
					cur_elem->data += 1 << neurondata_int[i];
					/* printf("mod neurondata %d\n", neurondata_int[i]); */
					/* printf("data modified\n"); */
					broken = 1;
					break;
				} else {
					if (cur_elem->next != NULL) {
						cur_elem = cur_elem->next;
					}
				}
			}

			if (broken == 0) { /* when nothing conflicting found */
				cur_elem->next = lb++;
				newelem = cur_elem->next;

				/* printf("malloced!\n"); */

				newelem->key = timedata[i];
				newelem->data = 1 << neurondata_int[i];
				newelem->next = NULL;
				listlength[hash]++;
			}
		}
	}




	for (i=0; i<listsize; i++) {
		n_timing += listlength[i];

		cur_elem = &hlist[i];

		for (j=0; j<listlength[i]; j++) {
			counters[cur_elem->data] += 1;
			/* printf("element search, hash: %d, elem: %d\n", i, cur_elem->data); */
			if (cur_elem->next != NULL)
				cur_elem = cur_elem->next;
		}
	}

	free(neurondata_int);
	free(listbuff);
	free(listlength);
	free(hlist);
	counters[0] = duration - n_timing;
}
