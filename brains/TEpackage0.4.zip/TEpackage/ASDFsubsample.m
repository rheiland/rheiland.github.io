function subasdf = ASDFsubsample(asdf, subIndex)
% subasdf = ASDFsubsample(asdf, subIndex)
%
%    asdf - {nNeu+2,1} ASDF to subsample from
%    subIndex - (subNeu,1) indices of subsampled neurons
%
% Returns:
%    subasdf - {subNeu+2,1} subsampled ASDF
%
% Description :
%
%
% Example :
%    
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 2/4/2010

subasdf = asdf(subIndex);

subNeu = length(subIndex);

subasdf{end+1} = asdf{end-1};
subasdf{end+1} = [subNeu, asdf{end}(2)]; % new [nNeu duration]
