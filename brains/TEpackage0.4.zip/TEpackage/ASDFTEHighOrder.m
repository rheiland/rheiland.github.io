function TEmat = ASDFTEHighOrder(asdf, JDelay, rcv_order, snd_order)
% TEmat = ASDFTEHighOrder(asdf, JDelay, rcv_order, snd_order)
%
%    asdf - {nNeu+2,1} Spike data in ASDF (Another Spike Data Format)
%    JDelay - (scalar) Delay time for j
%    rcv_order - order of receiving neuron (k)
%    snd_order - order of sending neuron (l)
%
% Returns:
%    TEmat - (nNeu, nNeu) Transfer entropy value from <row> to <column>
%
% Description :
%    It gives a matrix of transfer entropy of all the pairs of neurons.
%    If you ser large value for the order, you might need to expect long time
%    for computation. ( k+l = 20 is approximately the limit)
%    Please refer to readme.txt fo the package for the information of
%    delay time and order.
%
% Example :
%    for normal 1st order transfer entropy,
%    >> TE = ASDFTEHighOrder(asdf, 1, 1, 1);
%    for 3rd order in sending neuron
%    >> TE = ASDFTEHighOrder(asdf, 1, 1, 3);
%    for 3rd order in both neurons, with delay time of 2 bins
%    >> TE = ASDFTEHighOrder(asdf, 2, 3, 3);
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 4/19/2010

nNeu = asdf{end}(1);
duration = asdf{end}(2);

TEmat = zeros(nNeu);

% From this is basically a copy of ExtendedTE/TEDeepOrder_raster.m
% I know it is a bad habit.
window = max(snd_order + JDelay, 1+rcv_order);

eff_duration = duration - window + 1;


for i = 1:nNeu % for each receiving neuron
	fireIk1 = repmat(asdf{i}', 1, rcv_order+1) + repmat(0:rcv_order, length(asdf{i}), 1) - (window-1);

	timedata_i = [];
	neurondata_i = []; % data box. recyclable

	% modification of receiving train
	for ord = 1:rcv_order+1
		train = fireIk1(:,ord);
		train = train(train>0 & train<=eff_duration);
		timedata_i = [timedata_i;train];
		neurondata_i = [neurondata_i; ord*ones(length(train), 1)];
	end

	for j = 1:nNeu % for each sending neuron
		% modification of sending train
		%size(asdf{j})
		fireJl = repmat(asdf{j}', 1, snd_order) + repmat((JDelay-1):(JDelay+snd_order-2), length(asdf{j}), 1);

		timedata = timedata_i;
		neurondata = neurondata_i;
		for ord = 1:snd_order
			train = fireJl(:,ord);
			train = train(train>0 & train<=eff_duration);
			timedata = [timedata; train];
			neurondata = [neurondata; (rcv_order+1+ord)*ones(length(train), 1)];
		end

		TEmat(j,i) = sum(ExtTE_hash(timedata, eff_duration, neurondata, rcv_order+snd_order+1, rcv_order, snd_order));
	end
end
