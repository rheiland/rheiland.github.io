#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int transentmex(double *timedata, int duration, double *neurondata, int n_neurons, int jdelay, int n_firings, double *trans, int variance_check, double *variance){
	FILE *fp;
	int i, j, k, ii, jj, kk;
	/*int firings[max_firings][2];*/
	/*int end_time=60*60*1000; // given*/
	/*int n_neurons=10; // given*/

	int end_time = duration;

	/* reading data from given matrix */
	int tmp;
	int n_firings_neu[n_neurons];
	for (i=0;i<n_neurons;i++)
		n_firings_neu[i]=0;

	int* firings_neu[n_neurons]; /* data of fired time for each neuron*/

	/* loop to count necessary memory for each neuron */
	for (i=0;i<n_firings;i++){
		n_firings_neu[(int) neurondata[i]-1]++;
	}

	/* malloc the memory */
	for (i=0;i<n_neurons;i++){
		firings_neu[i] = (int*)malloc(n_firings_neu[i] * sizeof(int));

		if (firings_neu[i] == NULL){
			fprintf(stderr,"Error: Memory allocation failed for neuron %d\n",i);
		return 4;
		}
	}
	/*printf("n_neurons=%d\n",n_neurons);*/

	/* after finding how much memory is necessary, reset the counter for the next loop.*/
	for (i=0;i<n_neurons;i++){
		n_firings_neu[i]=0;
	}

	/* save data as of each neuron */
	int neu;
	for (i=0;i<n_firings;i++){
		neu = (int) neurondata[i] - 1;
		firings_neu[neu][n_firings_neu[neu]] = (int) timedata[i] -1;
		n_firings_neu[neu]++;
	}

	/*
	int n_firings=0;
	for (i=0;i<n_neurons;i++)
		n_firings+=n_firings_neu[i]; //total firings
		*/

	/*printf("# of firings is %d\n", n_firings);*/

	/*//code to dump data
	for (i=0;i<n_firings;i++)
		printf("%d %d\n",fire_time[i],fire_neu[i]);
		*/

	/*
	for (i=0;i<n_neurons;i++)
		printf("%d neuron fires %d times\n",i,n_firings_neu[i]);
		*/
	
	/* record firing data separating into each neuron*/
	
	/*
	// code for reporting where they fire
	for (i=0;i<n_neurons;i++){
		printf("neuron %d:",i);
		for (j=0;j<n_firings_neu[i];j++){
			printf(" %d",firings_neu[i][j]);
		}
		printf("\n");
	}
	*/

	/*box for TE*/
	/*double trans[n_neurons][n_neurons];*/

	for (i=0;i<n_neurons;i++){
		for (j=0;j<n_neurons;j++){
			/*code to calculate pare TE*/
			/*i=0;*/
			/*j=1;*/
			/* We take jdelay from input argument. It seems that Aonan's code is taking IDelay as argument,
			 * but it actually takes JDelay. */
			int idelay = 1; /* so far I impose idelay is always less than jdelay*/

			int ef_leng = end_time-jdelay;/*effective length of the data*/


			/* setting up 3 trains for calculation*/
			int longer = (n_firings_neu[i] > n_firings_neu[j])? n_firings_neu[i] : n_firings_neu[j];

			int f_length[3] = {n_firings_neu[i], n_firings_neu[j], n_firings_neu[i]};/* length of firings*/
			/*printf("f_length %d %d %d \n",f_length[0],f_length[1],f_length[2]);*/

			int trains[3][longer+1]; /* +1 for putting big number at the end.*/
			for (k=0;k<n_firings_neu[i];k++){
				trains[0][k] = firings_neu[i][k] - jdelay + idelay; /* track i_t*/
				trains[2][k] = firings_neu[i][k] - jdelay; /* track i_t+d*/
			}
			trains[0][n_firings_neu[i]] = end_time; /* setting final state to ignore*/
			trains[2][n_firings_neu[i]] = end_time;

			for (k=0;k<n_firings_neu[j];k++){
				trains[1][k] = firings_neu[j][k]; /*track j_t*/
			}
			trains[1][n_firings_neu[j]] = end_time;



			char ord[3]; /* space to set order of the things I:0, J:1, R:2*/
			char changed; /* changed one at the loop (ord[0] at the beggining)*/
			int cs[3]={0,0,0}; /* counter for single firings (just a)*/
			int cp[3]={0,0,0};		/* counter for pair firings (a||b||not_c),*/
			/*	p_count[0] means firings of 1 and 2. (but not 0)*/
			int ct=0;	/* counter for triple firings*/

			while (trains[0][cs[0]]<0)
				cs[0]++;
			int cs0offset = cs[0];
			while (trains[2][cs[2]]<0)
				cs[2]++; /*throw away negative time in cs*/
			int cs2offset = cs[2];


			/* initiation*/
			/* order three*/
			if (trains[0][cs[0]] <= trains[1][cs[1]]){
				if (trains[1][cs[1]] <= trains[2][cs[2]]){
					ord[0]=0; ord[1]=1; ord[2]=2; /*xyz*/
				} else if (trains[0][cs[0]] <= trains[2][cs[2]]){
					ord[0]=0; ord[1]=2; ord[2]=1; /*xzy*/
				} else {
					ord[0]=2; ord[1]=0; ord[2]=1; /*zxy*/
				}
			} else if (trains[1][cs[1]] <= trains[2][cs[2]]){
				if (trains[0][cs[0]] <= trains[2][cs[2]]) {
					ord[0]=1; ord[1]=0; ord[2]=2; /*yxz*/
				} else {
					ord[0]=1; ord[1]=2; ord[2]=0; /*yzx*/
				}
			} else {
				ord[0]=2; ord[1]=1; ord[2]=0; /*zyx*/
			}
			/* now ord[] is set.*/

			/*
			// check if it is ordered correctly.
			  printf("offset? %d %d\n",cs0offset,cs2offset);
			  printf("ordered? %d %d %d\n",ord[0],ord[1],ord[2]);
			  printf("ordered? %d %d %d\n",
			  trains[ord[0]][cs[ord[0]]],
			  trains[ord[1]][cs[ord[1]]],
			  trains[ord[2]][cs[ord[2]]]);
			  */

			/*
			// check three trains
			for (k=0;k<longer+1;k++)
				printf("%d ",trains[0][k]);
			printf("\n");
			for (k=0;k<longer+1;k++)
				printf("%d ",trains[1][k]);
			printf("\n");
			for (k=0;k<longer+1;k++)
				printf("%d ",trains[2][k]);
			printf("\n");
			*/


			while (trains[ord[0]][cs[ord[0]]] < ef_leng){  /* while firings have stack*/
				/*printf("3 things are: %d %d %d\n",trains[0][cs[0]],trains[1][cs[1]],trains[2][cs[2]]);*/
				/*printf("3 ords   are: %d %d %d\n",ord[0],ord[1],ord[2]);*/
				/*printf("3 cs     are: %d %d %d\n",cs[ord[0]],cs[ord[1]],cs[ord[2]]);*/
				/*printf("3othings are: %d %d %d\n",trains[ord[0]][cs[ord[0]]],trains[ord[1]][cs[ord[1]]],trains[ord[2]][cs[ord[2]]]);*/
				changed = ord[0];
				if (trains[ord[0]][cs[ord[0]]] == trains[ord[1]][cs[ord[1]]]){
					cs[ord[0]]++;

					if (trains[ord[1]][cs[ord[1]]] == trains[ord[2]][cs[ord[2]]]){
						ct++;
						cs[ord[1]]++;

						if (trains[ord[0]][cs[ord[0]]] <= trains[ord[1]][cs[ord[1]]]){
							ord[0]=ord[2];
							ord[2]=ord[1];
							ord[1]=changed;
						} else {
							ord[0]=ord[2];
							ord[2]=changed;
						}
					} else {
						cp[ord[2]]++;
						/*printf("cp got %d\n",cp[ord[2]]);*/

						if (trains[ord[0]][cs[ord[0]]] <= trains[ord[2]][cs[ord[2]]]){
							ord[0] = ord[1];
							ord[1] = changed;
						} else {
							ord[0] = ord[1];
							ord[1] = ord[2];
							ord[2] = changed;
						}
					}
				} else {
					cs[ord[0]]++;

					if (trains[ord[0]][cs[ord[0]]] <= trains[ord[1]][cs[ord[1]]]){
						; /*no change of order*/
					} else if (trains[ord[0]][cs[ord[0]]] <= trains[ord[2]][cs[ord[2]]]){
						ord[0] = ord[1];
						ord[1] = changed;
					} else {
						ord[0] = ord[1];
						ord[1] = ord[2];
						ord[2] = changed;
					}
				}
			}
			/*printf("csord0 is : %d\n",cs[ord[0]]);*/
			cs[0] -= cs0offset;
			cs[2] -= cs2offset;

			/*printf("cs is %d %d %d\n",cs[0],cs[1],cs[2]);*/
			/*printf("cp is %d %d %d\n",cp[0],cp[1],cp[2]);*/
			/*printf("ct is %d\n",ct);*/

			int count[2][2][2];/* counter for 8 patterns each state explicitly specified*/
			count[1][1][1] = ct;
			count[0][1][1] = cp[0];
			count[1][0][1] = cp[1];
			count[1][1][0] = cp[2];
			count[1][0][0] = cs[0] - cp[1] - cp[2] - ct;
			count[0][1][0] = cs[1] - cp[2] - cp[0] - ct;
			count[0][0][1] = cs[2] - cp[0] - cp[1] - ct;
			count[0][0][0] = ef_leng - (cs[0]+cs[1]+cs[2] -cp[0]-cp[1]-cp[2] -2*ct);

			/*
			int sum=0;
			for (ii=0;ii<2;ii++)
				for (jj=0;jj<2;jj++)
					for (kk=0;kk<2;kk++){
						sum += count[ii][jj][kk];
						printf("%d ",count[ii][jj][kk]);
					}
			printf("\nsum is %d\n", sum);
			if (sum != end_time	- jdelay)
				fprintf(stderr,"Calculation is not consistent!");
				*/

			/* now calculate TE*/

			/*trans[i+j*n_neurons] = 0.0;*/
			double prob1; /* prob P(in+1, in(k) ,jn(l))*/
			double prob2; /* prob P(in+1 | in(k) ,jn(l))*/
			double prob3; /* prob P(in+1 | in(k))*/


			for (ii=0;ii<2;ii++)
				for (jj=0;jj<2;jj++)
					for (kk=0;kk<2;kk++){

						if (count[ii][jj][kk]==0){
							/*printf("broken!\n");*/
							/*;break;*/
						} else {

							prob1 = ((double)count[ii][jj][kk]) / ef_leng;
							prob2 = ((double)count[ii][jj][kk]) / (count[ii][jj][0]+count[ii][jj][1]);
							prob3 = ((double)(count[ii][0][kk] + count[ii][1][kk]) /
									(count[ii][0][0] + count[ii][0][1] + count[ii][1][0] + count[ii][1][1]));
							/*printf("probs are %f %f %f\n", prob1, prob2, prob3);*/
							trans[i*n_neurons+j] += prob1 * log2(prob2/prob3);
						}

					}

			/* calculation of variance (optional) */
			if (variance_check == 1)
				for (ii=0;ii<2;ii++)
					for (jj=0;jj<2;jj++)
						for (kk=0;kk<2;kk++){

							if (count[ii][jj][kk]==0){
								/*printf("broken!\n");*/
								/*;break;*/
							} else {

								prob1 = ((double)count[ii][jj][kk]) / ef_leng;
								prob2 = ((double)count[ii][jj][kk]) / (count[ii][jj][0]+count[ii][jj][1]);
								prob3 = ((double)(count[ii][0][kk] + count[ii][1][kk]) /
										(count[ii][0][0] + count[ii][0][1] + count[ii][1][0] + count[ii][1][1]));
								/*printf("probs are %f %f %f\n", prob1, prob2, prob3);*/
								variance[i*n_neurons+j] += prob1*(1.0-prob1) * pow((log2(prob2/prob3) - trans[i*n_neurons+j]), 2)/ef_leng;

							}
						}





			/*printf("TE of %d to %d = %0.4f\n",j,i,trans[i][j]*100000);*/
		}
	}

	/* free memory */
	for (i=0;i<n_neurons;i++){
		free(firings_neu[i]);
		}


	return 0;
}

void mexFunction(
		int nlhs,
		mxArray *plhs[],
		int nrhs,
		const mxArray *prhs[]
		)
{

	/* Declare variable */
	double *timedata, *neurondata;
	double *tmp;
	double *trans, *variance;
	int n_neurons, duration, jdelay, n_firings;
	int variance_check;

	/* Check for proper number of input and output arguments */
	if (nlhs > 2) {
		printf("%d nlhs\n");
		mexErrMsgTxt("Too many output arguments.");
	}

	/* Check data type of input argument */
	if (!(mxIsDouble(prhs[0]))){
		mexErrMsgTxt("Input argument must be of type double.");
	}
	if (mxGetNumberOfDimensions(prhs[0]) != 2){
		mexErrMsgTxt("Input argument must be two dimensional\n");
	}

	

	timedata = mxGetPr(prhs[0]);

	tmp = mxGetPr(prhs[1]);
	duration = (int) tmp[0];

	neurondata = mxGetPr(prhs[2]);

	tmp = mxGetPr(prhs[3]);
	n_neurons = (int) tmp[0];

	tmp = mxGetPr(prhs[4]);
	jdelay = (int) tmp[0];

	n_firings = mxGetM(prhs[0]);

	/* Set the output */
	plhs[0] = mxCreateDoubleMatrix(n_neurons,n_neurons, mxREAL);
	trans = mxGetPr(plhs[0]);
	/* Check if variance is needed */
	if (nlhs == 2) {
		variance_check = 1;
		plhs[1] = mxCreateDoubleMatrix(n_neurons, n_neurons, mxREAL);
		variance = mxGetPr(plhs[1]);
	} else {
		variance_check = 0;
		plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL); /* smallest possible to save memory */
		variance = mxGetPr(plhs[1]);
	}



	/* Get the size and pointers to input data */

	/* dump the data
	mexPrintf("dur: %d,  n_neu: %d,  ide: %d\n",duration, n_neurons, jdelay);
	int i;
	for (i=0;i<5;i++){
		mexPrintf("data is %f %f\n", timedata[i], neurondata[i]);
	}
	*/

	/* Now call the function */
	transentmex(timedata, duration, neurondata, n_neurons, jdelay, n_firings, trans, variance_check, variance);
}
