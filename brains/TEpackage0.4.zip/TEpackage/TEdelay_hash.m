function TEmat = TEdelay_hash(trains, JDelay)
% TEmat = TEdelay_hash(trains, JDelay)
%
%   trains - (nNeu, duration) Sparse matrix of spikes
%   JDelay - (scalar) delay time
%
% Returns:
%   TEmat - (nNeu, nNeu) transfer entropy from <row> to <column>
%
% Description :
%    This function calculates the transfer entropy value with a delay time.
%    Please refer to readme.txt for the information of delay time.
%
% Example :
%    for normal 1st order TE
%    >> TE = TEdelay_hash(asdf, 1);
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 4/19/2010

nNeu = size(trains, 1);
duration = size(trains, 2);

%strategy: save all the spike information into a cell array.

[allNeu, allTime] = find(trains);

normal = cell(nNeu, 1);
plusJDelay = cell(nNeu, 1);

for i = 1:nNeu
	normal{i} = allTime(find(allNeu == i));
	plusJDelay{i} = normal{i} - JDelay;

	if ~isempty(normal{i})
		while (normal{i}(end) > duration - JDelay);
			if length(normal{i}) >= 2
				normal{i} = normal{i}(1:end-1);
			else
				normal{i} = [];
				break;
			end
		end
	end


	if ~isempty(plusJDelay{i})
		while plusJDelay{i}(1) < 1
			if length(plusJDelay{i}) >= 2
				plusJDelay{i} = plusJDelay{i}(2:end);
			else
				plusJDelay{i} = [];
				break;
			end
		end
	end
end

TEmat = zeros(nNeu, nNeu);

for i = 1:nNeu
	for j = 1:nNeu
		timedata = [plusJDelay{i}; normal{i}; normal{j}];
		nip = 1 * ones(length(plusJDelay{i}), 1);
		ni = 2 * ones(length(normal{i}), 1);
		nj = 3 * ones(length(normal{j}), 1);
		neurondata = [nip; ni; nj];

		TEmat(j, i) = sum(ExtTE_hash(timedata, duration - JDelay, neurondata, 3, 1, 1));
	end
end
