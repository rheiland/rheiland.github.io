function TEdelays = ASDFTEdelays(asdf, delays)
% TEdelays = ASDFTEdelays(asdf, delays)
%
%    asdf - {nNeu, 1} Spikes in ASDF format
%    delays - (t, 1) Vector that contains multiple delay time.
%
% Returns:
%    TEdelays - (nNeu, nNeu, t) TE with multiple delay time.
%
% Description :
%    This function calculates the transfer entropy value with different delay time.
%    Please refer to readme.txt for the information of delay time.
%
% Example :
%    for normal 1st order TE
%    >> TE = ASDFTEdelays(asdf, 1);
%    for delay from 1 to 100 bins.
%    >> TE = ASDFTEdelays(asdf, 1:100);
%    
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 4/21/2010

nNeu = asdf{end}(1);

dels = length(delays);

TEdelays = zeros(nNeu, nNeu, dels);

parfor t = 1:dels
	if mod(t,50)==0
		fprintf(1,'\n')
	end
	fprintf(1,'*')
	TEdelays(:,:,t) = ASDFTEdelay(asdf, delays(t));
end
fprintf(1,'\n')
