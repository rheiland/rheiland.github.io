Package for Transfer Entropy Calculation (Ver. 0.3)
Author: Shinya Ito (Indiana University)
Date: Apr 19, 2010

Index
1. Preparation
2. Usable data format
3. Functions
4. Another Spike Data Format
5. About the order and delay of TE


1. Preparation
Compile C programs with gcc.
(Guide to use gcc in Windows is given in the link below.
http://gnumex.sourceforge.net/ )
>> mex transentmex.c
>> mex hashcounter.c


2. Usable data format
* 2-D Sparse matrix (row_index: neuron_index, column_index: timing)
* Another Spike Data Format (ASDF; described later) (Smaller, Faster, Recommended)


3. Functions (Please refer to help of each function for details)
* TE Calculation
ASDFTEdelays.m
ASDFTEHighOrder.m
TEdelay_hash.m

* Changing Data Format
ASDFToSparse.m
SparseToASDF.m
ASDFsubsample.m

* Supporting functions (not to be excuted directly)
ExtTE_hash.m
ASDFTEdelay.m
hashcounter.c
transentmex.c


4. Another Spike Data Format
Another Spike Data Format is basically cell array of spike timing of each neuron.
Last two cells contains special information of the data.

asdf{end-1}: Binning size in unit of ms (milisecond). (e.g. 1.2 -> 1.2ms/bin, 10 -> 10ms/bin etc...)
asdf{end}: Array of number of neurons, number of total bins of the data
  (e.g. [10 300000] -> 10 neurons, 300000 time bins)

I'm still working on the specification of ASDF and its utilities.
Sorry for current inconvinience.


5. About the order and delay of TE
Order is 'how much you include in the past'.
If you use 3rd order, you include 3 bins before the time you want to predict.

* - the time bin you want to predict
o - the time bin you use for prediction
1st order
train i:   ....o*....
train j:   ....o.....

3rd order
train i:   ..ooo*....
train j:   ..ooo.....

Delay is 'distance of time from what you want to predict to what you use for predict'.

delay=1 (1st order)
train i:   ....o*....
train j:   ....o.....

delay=3 (1st order)
train i:   ....o*....
train j:   ..o.......

You can also combine these two.
