function [TE, SD] = ASDFTEdelay(asdf, JDelay)
% TEmat = ASDFTEdelay(asdf, JDelay)
%
%    asdf - {nNeu,1} ASDF
%    JDelay - (1x1) delay time for the TE
%
% Returns:
%
%
% Description :
%
%
% Example :
%    
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 2/2/2010

info = asdf{end};
n_neu = info(1);
duration = info(2);
binunit = asdf{end - 1};


% very simple check of validity of ASDF
if n_neu ~= size(asdf,1) - 2
	error('Invalid n_neu information is contained in this ASDF');
	return
end


total_firings = 0;
for neu = 1:n_neu
	asdf{neu} = ceil(asdf{neu}); % I need to ceil them since an index can't be a float number
	total_firings = total_firings + length(asdf{neu});
end

neuron_data = zeros(total_firings,1);
time_data = zeros(total_firings,1);
%spikes = ones(total_firings,1);

current = 1;

for neu = 1:n_neu
	leng = length(asdf{neu});
	if leng ~= 0
		range = current:current+leng-1;
		neuron_data(range) = neu;
		time_data(range) = asdf{neu};
		current = current + leng;
	end
end

[TE,VR]=transentmex(time_data, duration, neuron_data, n_neu, JDelay);
SD = sqrt(VR);
