function asdf = SparseToASDF(raster, binunit)
% asdf = SparseToASDF(raster, binunit)
%
%    raster - (n_neu, duration) (Sparse) time raster expressed as a sparse matrix.
%    binunit - (scalar, double) the unit of time in the data in ms. (length of a bin in real scale)
%
% Returns:
%    asdf - {n_neu + 2, 1} ASDF version of the data
%
% Description :
%    This function converts sparse matrix version of the data to ASDF version.
%
% Example :
%    
%
% Author   : Shinya Ito
%            Indiana University
%
% Last modified on 1/20/2010

[n_neu, duration] = size(raster);

asdf = cell(n_neu + 2, 1);

asdf{end} = [n_neu, duration];
asdf{end - 1} = binunit;

for i = 1:n_neu
	asdf{i} = find(raster(i,:));
end
